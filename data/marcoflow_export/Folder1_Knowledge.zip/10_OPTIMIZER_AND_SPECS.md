# MarcoFlow optimizer notes and specs

Reference snapshot from MarcoFlow (2026-10-02). Read-only reference; not runnable on its own. Educational only — not financial advice.


---

## FILE: specs/update_7.0_execution_spec.md

# MarcoFlow v2.0.0 — Developer Implementation Spec

**Target deployment date:** 2026-09-28 (end of market close)\
**Version bump:** 1.0.0 → 2.0.0\
**Scope:** 9 execution/exit fixes. No changes to signal setup, Heat Score, alert parameters, skipEntryHours, knife guard, timeframes, or entry selection criteria.

_Educational only — not financial advice._

---

## HARD CONSTRAINTS (do not touch)

* Signal generation logic, Heat Score calculation, skipEntryHours, knife guard, timeframes, alert parameters, entry selection criteria

* Nightly optimizer task ID `960397fb3`

* Hourly tick task ID `5d90119ed`

* Never print or log values of `HEARTBEAT_SECRET` or `AGENT_SECRET`

* All new log strings must include: "Educational only — not financial advice."

---

## FILES TO MODIFY

The primary targets are the execution loop files. Exact paths depend on your project structure — locate them by searching for where paper trades are entered and monitored:

| File | What changes |
| --- | --- |
| `pages/api/agent/heartbeat.ts` (or `.js`) | E1, E2, E3, F1, C1 (execution entry logic) |
| `pages/api/agent/tick.ts` (or `.js`) | Same entry fixes as heartbeat (applies to legacy tick path) |
| Exit/position-monitoring logic (wherever trailing stop + TP live) | X1, X2, X3, X4 |
| `pages/api/health.ts` | Version bump → "2.0.0" |
| `package.json` | Version field → "2.0.0" |
| Changelog store (wherever `GET /changelog` is served, or DB table) | Add v2.0.0 entry |

---

## FIX E1 — Signal Freshness Validation

**Problem:** Signals fired at 9:30–9:45 ET are executed at 10:16 ET (31–46 min later). The move is over; the stock has bounced. These stale entries are 0% WR and account for \~40% of all executions.

**Where to add it:** In the function that processes queued/pending signals for execution — before the trade entry is created.

**Logic to add (pseudocode):**

```typescript
// Before executing any queued signal, run freshness check
function isSignalFresh(signal: PendingSignal, quote: Quote): boolean {
  const { direction, triggerPrice } = signal;
  const STALE_THRESHOLD = 0.005; // 0.5% — tighten to 0.3% after 5 days of data if results look good

  if (direction === 'SHORT') {
    // SHORT signal: if price is now ABOVE trigger by 0.5%+, the down move is over
    if (quote.bid > triggerPrice * (1 + STALE_THRESHOLD)) {
      logSkip(signal, 'stale_skip', 'SHORT signal stale: currentBid above triggerPrice by > 0.5%. Educational only — not financial advice.');
      return false;
    }
  } else if (direction === 'LONG') {
    // LONG signal: if price is now BELOW trigger by 0.5%+, the up move is over
    if (quote.ask < triggerPrice * (1 - STALE_THRESHOLD)) {
      logSkip(signal, 'stale_skip', 'LONG signal stale: currentAsk below triggerPrice by > 0.5%. Educational only — not financial advice.');
      return false;
    }
  }
  return true;
}

// In execution loop:
for (const signal of pendingSignals) {
  const quote = await getCurrentQuote(signal.symbol);
  if (!isSignalFresh(signal, quote)) {
    // Mark signal as skipped — do NOT create a trade record, do NOT count as loss
    await markSignalSkipped(signal.id, 'stale_skip');
    continue;
  }
  // ... proceed with E2, E3, F1, C1 checks, then execute
}
```

**Key requirement:** Skipped signals must NOT create a trade record and must NOT be counted in PnL or win-rate calculations. They are discarded, not lost.

**`triggerPrice`** = the price stored when the alert originally fired (should already be on your signal/alert record). `currentBid` / `currentAsk` = live quote at time of execution attempt.

---

## FIX E2 — Reactive (Rolling) Execution

**Problem:** Even fresh signals execute in two fixed batches (\~10:16 ET, \~11:14 ET). A signal arriving at 9:40 waits until 10:16. The batch model guarantees lag.

**Where to change it:** In the heartbeat/tick scheduling logic — wherever the two fixed execution windows are defined (likely a time-range check like `if (hour === 10 && minute === 16)`).

**Change:**

Remove the fixed-window gate. On EVERY heartbeat/tick cycle, attempt execution of ALL pending signals that pass the E1 freshness check. Do not restrict to specific clock times.

```typescript
// REMOVE any logic like:
// if (isInBatchWindow()) { executeQueuedSignals(); }

// REPLACE with (runs every tick):
const pendingSignals = await getPendingSignals();
for (const signal of pendingSignals) {
  // E1 check first, then E3 check, then execute
  await attemptExecution(signal);
}
```

**Signals arriving mid-tick:** If a signal is queued while a tick cycle is in progress, it will be picked up on the NEXT tick cycle. This is fine — do not try to inject mid-cycle.

**What does NOT change:** The tick cycle frequency itself, which signals are generated, Heat Score thresholds, alert parameters, or any entry selection criteria.

---

## FIX E3 — Direction Confirmation at Entry

**Problem:** 183/189 confirmed trades are SHORT. LONG trades show 83% immediate reversal (entered at bottom of dip, immediately before bounce). SHORT trades in open session also show high immediate-reversal rate (entering at top of bounce, not bottom of drop).

**Where to add it:** In the same execution loop, after E1 passes, before creating the trade.

**Logic:**

```typescript
// Returns: 'ok' | 'defer' | 'skip'
async function checkDirectionConfirmation(
  signal: PendingSignal,
  symbol: string,
  deferCount: number
): Promise<'ok' | 'defer' | 'skip'> {
  let candles: Candle[];
  try {
    candles = await getLast2Completed1MinCandles(symbol);
  } catch {
    // Graceful fallback: if candle data unavailable, allow execution
    return 'ok';
  }

  if (!candles || candles.length < 2) return 'ok'; // not enough data → allow

  const [mostRecent, previous] = candles; // candles[0] = most recent completed
  const netRising = mostRecent.close > previous.close;
  const netFalling = mostRecent.close < previous.close;

  if (signal.direction === 'SHORT' && netRising) {
    if (deferCount >= 2) {
      logSkip(signal, 'momentum_conflict_skip', 'SHORT deferred 2x: price still rising. Educational only — not financial advice.');
      return 'skip';
    }
    return 'defer'; // try again next tick
  }

  if (signal.direction === 'LONG' && netFalling) {
    if (deferCount >= 2) {
      logSkip(signal, 'momentum_conflict_skip', 'LONG deferred 2x: price still falling. Educational only — not financial advice.');
      return 'skip';
    }
    return 'defer';
  }

  return 'ok';
}

// In execution loop:
const e3Result = await checkDirectionConfirmation(signal, signal.symbol, signal.deferCount ?? 0);
if (e3Result === 'skip') {
  await markSignalSkipped(signal.id, 'momentum_conflict_skip');
  continue;
}
if (e3Result === 'defer') {
  await incrementDeferCount(signal.id); // store deferCount on signal record
  continue; // will retry next tick
}
// 'ok' → proceed to F1, C1, then execute
```

**Requirement:** Store `deferCount` on the signal/pending record so it persists across tick cycles. Reset to 0 when the signal is eventually executed or skipped.

---

## FIX X1 — Repair take_profit Trigger Logic

**Problem:** 20 of 26 take_profit exits are actual losses. The TP fires when price crosses back through a band level — catching the reversal, not the profit target. Trades peak +2–3% favorable, fully reverse, and TP fires at a loss.

**Where to change it:** In the position monitoring loop — wherever the `take_profit` exit condition is evaluated.

**Replace all existing TP trigger logic with:**

```typescript
function checkTakeProfit(trade: OpenTrade, quote: Quote): boolean {
  const { direction, entryPrice, targetPct } = trade;

  if (direction === 'SHORT') {
    // TP only when price is ACTUALLY BELOW the target — not when it crosses from any direction
    return quote.bid <= entryPrice * (1 - targetPct);
  } else if (direction === 'LONG') {
    // TP only when price is ACTUALLY ABOVE the target
    return quote.ask >= entryPrice * (1 + targetPct);
  }
  return false;
}

// In exit monitoring:
if (checkTakeProfit(trade, quote)) {
  await closeTrade(trade, 'take_profit', quote);
}
```

**Remove:** Any logic that fires TP when price crosses a band from above/below, or when price was previously beyond the target and crosses back. The target must be actively met at the moment of the check.

`targetPct` should be whatever the existing target percentage is on the trade record (e.g., 0.0075 for 0.75%).

---

## FIX X2 — ATR-Calibrated Stop Placement

**Problem:** Fixed-percentage stops get hit by normal open-session bid-ask noise before trades can develop. 84% of open-session stop-loss trades show zero favorable movement — the stop fires before the trade breathes.

**Where to add it:** In the trade entry function — when a trade is created, calculate and store the stopPct dynamically.

**Logic:**

```typescript
function computeStopPct(atr14: number | null, price: number, nowET: Date): number {
  // Fallback if ATR unavailable
  if (!atr14 || atr14 <= 0) {
    return getExistingDefaultStop(); // use whatever the current default is
  }

  const atrPct = (atr14 / price) * 100;
  const hourET = nowET.getHours(); // assumes nowET is already in ET timezone
  const minET = nowET.getMinutes();
  const totalMinutes = hourET * 60 + minET;

  const isOpenSession = totalMinutes >= 9 * 60 + 50 && totalMinutes < 11 * 60; // 9:50–11:00 ET
  const isMidday = totalMinutes >= 11 * 60 && totalMinutes < 14 * 60; // 11:00–14:00 ET
  const isHighVol = atrPct > 0.7;

  if (isOpenSession) {
    return Math.max(atrPct * 1.5, 1.5);
  } else if (isMidday) {
    return Math.max(atrPct * 1.0, 0.8);
  } else if (isHighVol) {
    return Math.max(atrPct * 1.3, 1.3);
  } else {
    return Math.max(atrPct * 1.2, 1.0);
  }
}

// In trade entry:
const stopPct = computeStopPct(quote.atr14, quote.price, new Date()); // convert to ET before passing
const trade = await createTrade({
  ...tradeData,
  stopPct, // store on record — this overrides/replaces the fixed default for this trade
});
```

**ATR source:** Use whatever ATR data is already being fetched for the symbol (likely from the Alpaca or market data provider). The 14-period ATR on a 1-minute or 5-minute bar is appropriate. If unavailable, fall back to the existing default stop — do not block the trade.

**`stopPct` is stored as a percentage** (e.g., 1.5 means 1.5%, which is 0.015 of price).

---

## FIX X3 — Lower Trailing Stop Activation Threshold

**Problem:** The trailing stop achieves 87% WR in midday on fresh entries but only 21% in open session. The activation threshold likely requires more favorable movement than open-session trades typically produce before reversing — trades hit the hard stop before trailing ever engages.

**Where to change it:** In the position monitoring loop — wherever the trailing stop activation condition is checked.

**Replace the existing static activation threshold with:**

```typescript
function getTrailingStopParams(
  trade: OpenTrade,
  atrPct: number,
  nowET: Date
): { activateAt: number; trailDistance: number } {
  const totalMinutes = nowET.getHours() * 60 + nowET.getMinutes();
  const isOpenSession = totalMinutes >= 9 * 60 + 50 && totalMinutes < 11 * 60;
  const isMidday = totalMinutes >= 11 * 60 && totalMinutes < 14 * 60;
  const isHighVol = atrPct > 0.7;

  if (isOpenSession) {
    return { activateAt: 0.35, trailDistance: 0.30 }; // activate at 0.35% favorable, trail 0.30%
  } else if (isMidday) {
    return { activateAt: 0.50, trailDistance: 0.40 };
  } else if (isHighVol) {
    return { activateAt: 0.60, trailDistance: 0.45 };
  } else {
    // default (outside 9:50–14:00 or no session data)
    return { activateAt: 0.50, trailDistance: 0.40 };
  }
}

// In position monitoring:
const trailParams = getTrailingStopParams(trade, currentAtrPct, new Date());
const favorableMovePct = getFavorableMovePct(trade, quote); // how far in the money this trade is currently

if (!trade.trailingActive && favorableMovePct >= trailParams.activateAt) {
  // Activate trailing stop for this trade
  await activateTrailingStop(trade, trailParams.trailDistance);
}
```

**All values are percentages** (0.35 means 0.35% of price).

---

## FIX X4 — Time-Exit Trailing Safety Net

**Problem:** 24 time-exit trades, 0% WR, avg PnL −$3.71. Hard closing near-breakeven positions at session end guarantees crystallizing a small loss.

**Where to change it:** In the time-exit logic — wherever trades are force-closed as the session nears end (typically `T - 30 min` before close).

**Replace hard-close-all with:**

```typescript
async function handleTimeExit(trade: OpenTrade, quote: Quote, minutesToClose: number): Promise<void> {
  if (minutesToClose > 30) return; // not yet in time-exit window

  const pnlPct = computePnlPct(trade, quote); // current PnL as % of entry

  if (pnlPct < -0.3) {
    // Trade is losing more than -0.3% — hard close as before
    await closeTrade(trade, 'time_exit', quote);
    return;
  }

  if (pnlPct >= -0.3 && pnlPct <= 0.1) {
    // Near breakeven — switch to aggressive trailing instead of hard close
    // This allows late-day drift to register as a small winner
    if (!trade.timeExitTrailingActive) {
      await activateAggressiveTrailingStop(trade, 0.15); // 0.15% trail distance
      await updateTradeFlag(trade.id, 'timeExitTrailingActive', true);
      await logEvent(trade.id, 'time_exit_trailing', 'Near-breakeven at T-30: switched to aggressive trailing (0.15%). Educational only — not financial advice.');
    }
    // Do NOT hard close — let the trailing stop handle the exit
    return;
  }

  if (pnlPct > 0.1) {
    // Trade is winning — do not force close; let existing trailing stop run
    return;
  }
}

// The exit reason when this trailing stop eventually fires should be:
exitReason = 'time_exit_trailing'; // distinguishable from regular 'time_exit'
```

**`computePnlPct`:** For SHORT, `pnlPct = (entryPrice - currentBid) / entryPrice * 100`. For LONG, `pnlPct = (currentAsk - entryPrice) / entryPrice * 100`.

---

## FIX F1 — ETF + RSI Divergence Skip

**Problem:** The optimizer's avoid list is 100% ETF-driven. Four confirmed conditions running 14.8%–18.8% WR all involve ETFs with RSI divergence. These are systematically losing conditions.

**Where to add it:** In the execution loop, after E1/E2/E3 pass, before creating the trade.

**Logic:**

```typescript
function shouldSkipForEtfDivergence(signal: PendingSignal): boolean {
  const { isEtf, rsiDivergence, direction } = signal;

  if (!isEtf) return false;
  if (!rsiDivergence) return false; // null/undefined/empty → no divergence present

  // Momentum-aligned means: SHORT with bearish divergence, or LONG with bullish divergence
  // If the divergence is non-null, it's present — check direction alignment
  // rsiDivergence field likely stores: 'bullish' | 'bearish' | null
  const isMomentumAligned =
    (direction === 'SHORT' && rsiDivergence === 'bearish') ||
    (direction === 'LONG' && rsiDivergence === 'bullish');

  // Also catch: any RSI divergence on an ETF regardless of exact alignment
  // (the optimizer's avoid list covers multiple ETF+divergence combos)
  // Use this broader check if `isMomentumAligned` is too narrow for your data model:
  const hasDivergence = rsiDivergence !== null && rsiDivergence !== '';

  return isEtf && hasDivergence;
}

// In execution loop (after E3):
if (shouldSkipForEtfDivergence(signal)) {
  await markSignalSkipped(signal.id, 'etf_divergence_skip');
  await logSkip(signal, 'etf_divergence_skip', 'ETF with RSI divergence: execution skipped. Educational only — not financial advice.');
  continue;
}
```

**Does NOT affect:** Alert generation, Heat Score, signal ranking, or any UI display of the signal.

---

## FIX C1 — Condition-Weighted Position Sizing

**Problem:** All signals execute at the same $640 size regardless of whether they match the optimizer's best conditions (85%+ WR) or the weakest conditions (<30% WR).

**Where to add it:** In the trade entry function, just before the trade is created — determine size before calling `createTrade`.

**Logic:**

```typescript
type ConditionScore = 0 | 1 | 2 | 3;
// 0 = no top-10 conditions matched
// 1 = rank 4-10 only
// 2 = one top-3 stack matched
// 3 = multiple top-3 stacks matched

function scoreSignalConditions(signal: PendingSignal): { score: ConditionScore; fullSize: boolean } {
  const { direction, atrPct, choppyRegime, signedVolume, rsiDivergence, rsi, flowAligned, flowSell, vwapSideAligned, rsi5 } = signal;

  // Top-3 stacks (85%+ historical WR)
  const stackA = choppyRegime === true && signedVolume !== undefined && signedVolume < -0.25 && atrPct > 0.7;
  const stackB = direction === 'SHORT' && atrPct > 0.7 && rsiDivergence === 'bullish';
  const stackC = rsi !== undefined && rsi >= 55 && rsi <= 65 && flowAligned === true && atrPct !== undefined && atrPct >= 0.3 && atrPct <= 0.7;

  const topStacksMatched = [stackA, stackB, stackC].filter(Boolean).length;

  if (topStacksMatched >= 1) {
    return { score: topStacksMatched >= 2 ? 3 : 2, fullSize: true };
  }

  // Rank 4-10 conditions (use whichever fields your data model exposes)
  const rank4_10Conditions = [
    direction === 'SHORT' && flowSell === true && rsi5 !== undefined && rsi5 > 70,
    flowSell === true && vwapSideAligned === true && rsi5 !== undefined && rsi5 > 70,
    // Add additional optimizer rank 4-10 conditions here as your data model supports them
  ];
  const anyRank4_10Matched = rank4_10Conditions.some(Boolean);

  if (anyRank4_10Matched) {
    return { score: 1, fullSize: true };
  }

  // No top-10 conditions matched → 50% size
  return { score: 0, fullSize: false };
}

// In trade entry:
const { score: conditionScore, fullSize } = scoreSignalConditions(signal);
const FULL_SIZE = 640;  // $640 standard
const HALF_SIZE = 320;  // $320 = 50%
const positionSize = fullSize ? FULL_SIZE : HALF_SIZE;

const trade = await createTrade({
  ...tradeData,
  positionSize,
  conditionScore, // store 0-3 on trade record for analysis
});
```

**Fallback:** If ANY of the condition fields (`atrPct`, `rsi`, `flowAligned`, etc.) are undefined/null for a signal, default to full size (`$640`). Never block a trade on missing condition data — just score it as 0 and execute at full size if in doubt.

**Note on field names:** The exact field names on your signal/alert record may differ from the pseudocode above. Map `choppyRegime`, `signedVolume`, `rsiDivergence`, `rsi`, `flowAligned`, `flowSell`, `vwapSideAligned`, `rsi5`, `atrPct`, `isEtf` to whatever your actual Prisma schema fields are.

---

## VERSION BUMP

### `package.json`

```json
{
  "version": "2.0.0"
}
```

### `/api/health` route

```typescript
// pages/api/health.ts (or app/api/health/route.ts)
import pkg from '../../package.json';

export default function handler(req, res) {
  res.json({
    status: 'healthy',
    version: pkg.version, // will now return "2.0.0"
    database: 'connected', // keep existing DB ping logic
  });
}
```

Or hardcode `"2.0.0"` directly if dynamic import from package.json is cumbersome in your setup.

### Changelog entry

Add to wherever your `/changelog` route (or DB table) stores version history:

```
v2.0.0 (2026-09-28): E1 freshness validation, E2 rolling execution, E3 direction confirmation, X1 TP logic fix, X2 ATR stops, X3 trailing activation, X4 time-exit safety net, F1 ETF divergence skip, C1 condition-weighted sizing. Educational only — not financial advice.
```

---

## DATABASE SCHEMA ADDITIONS (if needed)

If your Prisma schema doesn't already have these fields, add them:

```prisma
model Trade {
  // ... existing fields ...
  stopPct           Float?   // computed at entry by X2 (dynamic ATR stop)
  conditionScore    Int?     // 0-3, computed at entry by C1
  skipReason        String?  // 'stale_skip' | 'momentum_conflict_skip' | 'etf_divergence_skip'
  timeExitTrailingActive Boolean @default(false) // X4
}

model Signal {
  // ... existing fields ...
  deferCount        Int     @default(0) // E3 — number of times deferred for direction check
  skipped           Boolean @default(false)
  skipReason        String?
}
```

Run `yarn prisma migrate dev --name v2_execution_fields` after schema changes.

---

## IMPLEMENTATION ORDER (within the deploy)

Implement and test in this order — each depends on the previous being correct:

1. **E1** (freshness validation) — simplest, highest ROI, standalone check before any other logic

2. **X1** (TP trigger fix) — pure logic correction, no external data dependencies

3. **F1** (ETF divergence skip) — simple field check at execution

4. **X2** (ATR-calibrated stops) — requires ATR data at entry; add graceful fallback

5. **E2** (reactive execution) — remove batch-window gate

6. **E3** (direction confirmation) — requires candle data; add graceful fallback

7. **X3** (trailing activation) — modify existing trailing stop logic

8. **X4** (time-exit safety net) — modify end-of-session close logic

9. **C1** (condition-weighted sizing) — score at execution, adjust position size

10. **Version bump** — `package.json` + `/api/health` + changelog

---

## VERIFICATION AFTER DEPLOY

```bash
# Confirm version bump deployed
curl https://marcoflow.abacusai.app/api/health
# Expected: { "status": "healthy", "version": "2.0.0", "database": "connected" }
```

Also verify:

* `GET /changelog` shows the v2.0.0 entry (or wherever your changelog is stored)

* A test paper trade triggered manually shows the new `stopPct` and `conditionScore` fields populated

* No changes to alert generation, Heat Score display, or signal setup in the UI

---

## PHASE 0 (user action — no code change)

Before deploying v2.0.0, turn off the two active optimizer rules that were enabled last week (via the optimizer UI). The analysis baseline was built on the pre-filter trade population. Running execution fixes on top of active entry filters creates confounding variables. Clean baseline first, then re-enable optimizer rules in Week 5 once execution fixes are verified.

---

## PROJECTED IMPACT (from analysis of 2,391 paper trades, 9/2–9/28/26)

| Fix | Expected WR lift |
| --- | --- |
| E1 — Freshness validation | +15 to +23 WR points |
| E2 — Reactive execution | +8 to +12 pts |
| E3 — Direction confirmation | +5 to +8 pts |
| X1 — TP logic fix | +10.6 pts |
| X2 — ATR-calibrated stops | +12 to +16 pts on stop-loss trades |
| X3 — Trailing activation | +5 to +8 pts |
| X4 — Time-exit safety net | +3 to +5 pts |
| F1 — ETF divergence skip | +3 to +5 pts |
| C1 — Condition-weighted sizing | Concentrates gains on best days |
| **Combined conservative** | **65–75% portfolio WR** |
| **Best-condition days** | **85%+ achievable** |

Baseline: 37.1% WR, −$2,907 PnL (paper portfolio).

---

_Educational only — not financial advice. All projections derived from historical paper trading data. Past performance does not indicate future results._

---

## FILE: specs/hourly_task_playbook.md

# MarcoFlow Signal Tracker Playbook

## Task Overview
This task invokes the MarcoFlow `/api/agent/tick` endpoint to record signals and resolve outcomes during trading hours.

## Key Facts
- **Endpoint**: `https://marcoflow.abacusai.app/api/agent/tick`
- **Method**: POST
- **Auth**: Requires a Bearer token in the `Authorization` header.
- **Script**: `/home/ubuntu/shared/marcoflow_tick.sh` manages the HTTP request and parsing.
- **Logs**: Success and failure are logged with timestamps to `/home/ubuntu/shared/marcoflow_tick.log`.
- **App Directory**: `/home/ubuntu/trading_signals_app/nextjs_space`

## Lessons & Troubleshooting
- The script exits with 0 on successful response (`ok=true`) and 1 otherwise.
- The `marketOpen` flag in the JSON response indicates if the US market is currently open.
- **Resolution**: Outcome resolution occurs both during and after market hours if `ok: true`.
- **Latency**: Chunked scan of 3,430 symbols takes ~10-15 minutes total.
- **Database**: Signal records in `public."SignalObservation"`; paper trades in `public."PaperTrade"`; performance tracking in `public."PerformanceSummary"`.
- **isIntradayExecutable 12:00 PM ET cutoff**: Setups observed after 12:00 PM ET produce 0 alerts/entries due to the 4h hold requirement (EOD 3:55 PM exit).

## Update 4.11 Status (Sep 16 2026)
- **Status**: 2:00 PM ET tick complete.
- **Tick Log (Today)**:
    - 02:06 PM ET: 2:00 PM tick complete; 3,430 symbols scanned; 365 signals recorded; 0 alerts sent; 0 paper entries (post-cutoff).
- **System Health**: Active. Record phase stable with 365 signals captured.


---

## FILE: optimizer/PLAYBOOK.md

# MarcoFlow Execution Optimizer — Playbook

**Objective:** Each nightly run analyzes the clean execution window, identifies
concrete execution-mechanic leaks, and posts 0–3 data-backed propose-only
guardrail changes to the live proposals endpoint. Wins accumulate as the owner
approves changes and the execution_quality_index trends upward.

---

## System Context

- **App:** MarcoFlow — short-heavy intraday paper trading, Alpaca paper account.
- **Clean window:** `PaperTrade.exitTime >= '2026-08-27'`.
- **Metric (snapshot 2026-09-25, n=1,970 closed):** win_rate_pct **33.65** |
  avg_return_pct **−0.2515** (spec baseline 35.40 / −0.2078). Weekly win-rate:
  47.4 → 33.7 → 38.8 → 27.0 → 24.3; post-approval cohort (exit ≥ 9/21):
  24.34 / −0.4662 (n=341). Recent regime is hostile to the short book — the
  component trend is down; never attribute metric moves to changes without
  cohort-level checks.
- **Guardrails (compiled; overrides marked):**
  - `maxPositionsPerSymbol: 1` (ON — count-based cap)
  - `marketableLimitExitsEnabled: true`, `limitBufferPct: 0.3`
  - `restingShortTpEnabled: true` — **OVERRIDE ACTIVE** (approved 9/20, applied 9/21; proposal cmuan6jxp0000lp08bwxdbi5i)
  - `giveBackGuardEnabled: false` — **PENDING proposal posted 9/25** (id cmuhfcgae01oeoz0892otsavp)
  - `lockTriggerPct: 0.8`, `lockFloorPct: 0.5`
  - `staleEntryGuardEnabled: true`, `maxAdverseDriftPct: 0.6`
  - `fillSlippageGuardEnabled: true` (observability only), `maxFillSlippagePct: 1.5`
  - `liquidityGateEnabled: true`, `minEntryPrice: 3`, `maxEntrySpreadPct: 4`
  - `advGateEnabled: false`, `minAdvDollars: 20_000_000`

---

## Allowed Guardrail Keys (exhaustive — never propose anything outside this list)

`marketableLimitExitsEnabled`, `limitBufferPct`,
`giveBackGuardEnabled`, `lockTriggerPct`, `lockFloorPct`,
`staleEntryGuardEnabled`, `maxAdverseDriftPct`,
`fillSlippageGuardEnabled`, `maxFillSlippagePct`,
`restingShortTpEnabled`,
`maxPositionsPerSymbol`,
`liquidityGateEnabled`, `minEntryPrice`, `maxEntrySpreadPct`,
`advGateEnabled`, `minAdvDollars`.

**NEVER** propose: `skipEntryHours`, `knifeGuardEnabled`, `knifeMinRsi`,
signal/heat scoring, setup/alert identification, or any out-of-scope key.
The endpoint enforces this and will reject out-of-scope proposals.

---

## Known Execution Leaks — Status (updated 2026-09-25)

### 1. SHORT Take-Profit give-back → `restingShortTpEnabled` (APPLIED — watch)
- Post-fix sample (exit ≥ 9/22, n=26 SHORT TP exits): avg peak +1.925% → avg close
  −0.088% (give-back 2.013; 20/26 green→red). KPI count(peak≥1.5 & close≤0) inside
  SHORT TP exits: 8→20→21→19→21 by week — worsening began before the fix too;
  regime-confounded, n small.
- Verdict: NOT yet visibly resolved. Re-measure after 2+ more sessions under a
  normal tape. Cannot re-propose (override active).

### 2. Trailing-stop give-back → `giveBackGuardEnabled` (PENDING — posted 9/25)
- 602 trailing exits: avg peak +0.657% → avg close +0.112%; 464/602 (77%) gave
  back >50% of peak; post-9/22: 84/100 (84%). Lock replay: 91/173 armed exits
  (peak ≥0.8%) closed below the +0.5% floor (avg +0.04%; ≈ +0.46%/trade
  recoverable on those 91).
- Next: confirm approval/apply; then measure lock behavior and tune
  `lockTriggerPct`/`lockFloorPct` (0.8/0.5 arm only ~29% of trailing peaks; avg
  trailing peak 0.657%).

### 3. Position duplication (OPEN — no guardrail-key lever)
- 111 symbol-days with ≥3 same-day entries; 450 extra (rank≥2) entries,
  −$1,095 marginal (−$1,016 since 9/8). 98% of same-day re-entries are <60s
  apart with repeated same portionIndex = within-scan fill race, not strategy.
- `maxPositionsPerSymbol` already 1 → cannot be fixed by any allowed key.
  Escalate as an app-side single-flight/dedupe fix. Never send no-op proposals.

### 4. Stop-loss with no favorable peak → `maxAdverseDriftPct` (HOLD)
- 452/560 stops never went favorable; but post-5.0 avg stop return improved
  (−1.089 vs −1.524 pre) → hold tightening 0.6→0.4 until more post data.
  Fill-time adverse drift >0.3% still correlates with weak outcomes (post-era
  drift 0.3–0.6 bucket −0.795 avg) — enforcement watch.

### 5. ADV gate → `advGateEnabled` / `minAdvDollars` (BLOCKED — no data)
- `StockDataCache` still holds no ADV series (42 'daily' rows only). Hold until
  IEX-ADV data is queryable.

### 6. Fill slippage (observability only — no action path)
- 10 fill_slippage notes ≥1.5% total (max 2.06% on 9/25); guard is
  observability-only, cannot be tightened into a gate via keys.

---

## Proposal Quality Rules

1. **Evidence bar:** only propose with a concrete number from the clean window;
   else post `proposals: []` (valid success).
2. **No duplicates:** skip keys with PENDING proposals or active overrides.
3. **Priority order:** 1) `giveBackGuardEnabled` (pending); 2) `lockTriggerPct`/
   `lockFloorPct` (only after giveBackGuard is live + measured); 3) `maxAdverseDriftPct`
   (needs more post-5.0 data); 4) `advGateEnabled`/`minAdvDollars` (when ADV data
   lands); 5) duplication / TP items — escalate only, no key-addressable action.
4. **Format:** title, leak (with numbers), changeSummary ("Enable X (false -> true)"),
   guardrailKey, proposedValue (bool/number), backtest (one line with numbers).
5. **Discipline:** one substantive change per lever per run; sequence lock params;
   never send no-ops; prefer fewer, stronger proposals.
6. **Type safety:** bool keys take true/false; number keys take numbers.

---

## Lessons (distilled)

- **9/25:** posted `giveBackGuardEnabled` (single top lever). Trailing give-back
  (~0.545%/trade, 77% of exits >50%) is the largest key-addressable leak left
  after the TP fix landed.
- **9/25:** same-day symbol re-entries are bursts (<60s, same portionIndex) — a
  within-scan fill race; no guardrail key governs it; −$1,095 marginal needs an
  app-side fix.
- **9/25:** post-approval cohort deeply negative (24.3% win) — regime confound;
  evaluate changes on cohorts, not the headline metric alone.
- **9/21:** first propose→approve→apply cycle completed (restingShortTp).
- **Update 5.0** (marketable limits) live: stop-loss fills improved; TP give-back
  still open.
- Single-feature short vetoes are harmful in backtest — never re-propose.
- ADV gate needs IEX data before any proposal.

---

## Per-Run Checklist

1. Compute metric (win_rate_pct, avg_return_pct) — note trend direction.
2. Check proposals/overrides for status changes since last run.
3. Re-measure applied changes on post-apply cohorts (restingShortTp now;
   giveBackGuard once live).
4. Apply proposal quality rules (evidence, no dupes, priority, one-change discipline).
5. POST proposals (0–3 max; prefer fewer with stronger evidence).
6. Update this PLAYBOOK with conclusions; write run record (`runs/run-NNNN.md`;
   task spec also uses `runs/run-YYYY-MM-DD.md`).


---

## FILE: optimizer/MEASUREMENT.md

# Execution Quality Measurement Recipe

## Metric: `execution_quality_index` (composite)

A composite of two sub-metrics measured over the **clean execution window**
(all `PaperTrade` rows with `status = 'CLOSED'` and `exitTime >= '2026-08-27'`).
Exit prices before 2026-08-27 are polluted; never include them.

### Sub-metrics

| Name | Direction | Weight | Baseline | lo | hi |
|---|---|---|---|---|---|
| `win_rate_pct` | increase | 1 | 35.40 | 25 | 50 |
| `avg_return_pct` | increase | 2 | −0.2078 | −0.50 | 0.10 |

- **`win_rate_pct`**: `COUNT(returnPct > 0) / COUNT(*) * 100` over the clean window.
- **`avg_return_pct`**: `AVG(returnPct)` over the clean window (in %, not decimal).

The runtime combines them with the weights above into the single `execution_quality_index` trend chart. The evaluator's job is to measure and report EACH named sub-metric; never compute the overall index.

---

## Measurement Procedure (run each grading pass)

1. Connect to Postgres using `DATABASE_URL` from `/home/ubuntu/shared/.env`.
2. Run the following query **exactly**:

```sql
SELECT
  ROUND(
    COUNT(*) FILTER (WHERE "returnPct" > 0)::numeric
    / NULLIF(COUNT(*), 0)::numeric * 100
  , 2) AS win_rate_pct,
  ROUND(AVG("returnPct")::numeric, 4) AS avg_return_pct
FROM "PaperTrade"
WHERE status = 'CLOSED'
  AND "exitTime" >= '2026-08-27';
```

3. Report the result as a JSON object with keys matching the component names **exactly**:

```json
{ "win_rate_pct": <number>, "avg_return_pct": <number> }
```

This is the only output the evaluator produces. Do not generate any proposals, modify any data, or call any external endpoints.

---

## Shell command (automated grading)

```bash
source /home/ubuntu/shared/.env && psql "$DATABASE_URL" -t -A -c \
  "SELECT json_build_object('win_rate_pct', ROUND(COUNT(*) FILTER (WHERE \"returnPct\" > 0)::numeric / NULLIF(COUNT(*),0)::numeric * 100, 2), 'avg_return_pct', ROUND(AVG(\"returnPct\")::numeric, 4)) FROM \"PaperTrade\" WHERE status = 'CLOSED' AND \"exitTime\" >= '2026-08-27'"
```

Expected output shape: `{"win_rate_pct":35.40,"avg_return_pct":-0.2078}`

---

## Immutability

This file and its shell command are **immutable** once the task is created.
The running agent (optimizer) must never edit this file or any helper scripts
referenced here. The evaluator reads this file independently each grading pass.


---

## FILE: optimizer/carryover.md

Objective: Improve execution quality of MarcoFlow intraday paper trades (clean window: exitTime >= 2026-08-27) by surfacing data-backed guardrail proposals that reduce execution leaks — fill slippage, give-back on winners, stale entries, and position duplication — causing win rate and average return per trade to trend upward over time.. Metric: execution_quality_index (increase). Baseline: 0.463333.
1 runs · best 0.391444 (run 1) · current 0.391444 · 1 regressed
Sub-metric trends (recent runs):
  win_rate_pct: 33.65
  avg_return_pct: -0.2515
Recent runs (most recent last):
  - run 1: 0.463333 -> 0.391444 [regressed] — Posted giveBackGuardEnabled=true to /api/optimizer/proposals (id cmuhfcgae01oeoz0892otsavp); updated PLAYBOOK.md + run records. · [win_rate_pct=33.65, avg_return_pct=-0.2515]
Full detail for any run: runs/run-<NNNN>.md in this folder.

---

## FILE: optimizer/measurement_spec.json

{
  "objective": "Improve execution quality of MarcoFlow intraday paper trades (clean window: exitTime >= 2026-08-27) by surfacing data-backed guardrail proposals that reduce execution leaks — fill slippage, give-back on winners, stale entries, and position duplication — causing win rate and average return per trade to trend upward over time.",
  "metric_name": "execution_quality_index",
  "metric_type": "composite",
  "components": [
    {
      "name": "win_rate_pct",
      "direction": "increase",
      "weight": 1,
      "baseline": 35.4,
      "lo": 25,
      "hi": 50
    },
    {
      "name": "avg_return_pct",
      "direction": "increase",
      "weight": 2,
      "baseline": -0.2078,
      "lo": -0.5,
      "hi": 0.10
    }
  ],
  "measure_command": "source /home/ubuntu/shared/.env && psql \"$DATABASE_URL\" -t -A -c \"SELECT json_build_object('win_rate_pct', ROUND(COUNT(*) FILTER (WHERE \\\"returnPct\\\" > 0)::numeric / NULLIF(COUNT(*),0)::numeric * 100, 2), 'avg_return_pct', ROUND(AVG(\\\"returnPct\\\")::numeric, 4)) FROM \\\"PaperTrade\\\" WHERE status = 'CLOSED' AND \\\"exitTime\\\" >= '2026-08-27'\"",
  "measurement_needs_connectors": false,
  "grade_at": "run_end",
  "flexible_schedule": false
}


---

## FILE: optimizer/runs/run-0001.md

# Run 0001 — 2026-09-25 (scheduled; improvement iteration 1)

**Hypothesis:** With the 9/21 `restingShortTpEnabled` fix applied, the next-highest
expected-value execution leak is the trailing-stop give-back; enabling
`giveBackGuardEnabled` should protect locked gains on exits that currently give
back >50% of peak. Also: re-measure the post-fix TP cohort and re-assess
duplication, stale stops, slippage and ADV-gate evidence with four more sessions
of data.

**What changed (files / artefacts):**
- Posted 1 proposal to `POST /api/optimizer/proposals` (HTTP 200):
  `giveBackGuardEnabled: true` — "Give-back guard for trailing-stop exits"
  → created id `cmuhfcgae01oeoz0892otsavp` (PENDING owner approval); `rejected: []`.
- `PLAYBOOK.md` updated in place (metric reading, leak statuses, priority order, lessons).
- This record: `runs/run-0001.md`. Task-format record: `runs/run-2026-09-25.md`.
  Prior off-schedule record (2026-09-21) archived verbatim to `runs/run-2026-09-21.md`.

**Sanity-check evidence (clean window, exitTime ≥ 2026-08-27):**
- Metric: win_rate_pct 33.65 | avg_return_pct −0.2515 (n=1,970). Weekly win-rate
  47.4→33.7→38.8→27.0→24.3 (declining); post-approval cohort (≥9/21): 24.34 / −0.4662.
- Proposal basis (trailing): 602 exits, avg peak +0.657% → avg close +0.112%; 464/602
  (77%) gave back >50% of peak; post-9/22: 84/100 (84%). Lock replay: 91/173 armed
  exits below the +0.5% floor (avg +0.04%; ≈ +0.46%/trade on those 91).
- restingShortTp post-fix: SHORT TP n=26, give-back 2.01% avg; KPI count(peak≥1.5 &
  red) within SHORT TP exits weekly 8→20→21→19→21 (not yet resolved; small n;
  regime confound).
- Duplication: 111 sym-days ≥3 entries; 450 extra entries −$1,095 marginal; 98% of
  same-day re-entries <60s (race). `maxPositionsPerSymbol` already 1 → no key-level action.
- Stops: post-5.0 avg −1.089 (vs −1.524 pre) → hold `maxAdverseDriftPct` tightening.
- Proposal verified in DB (`OptimizerProposal` PENDING) + `ChangeLogEntry`
  `proposal_created` (actor=optimizer) at 2026-09-25 20:39:40 UTC.

**Attempts tried / reverted:** none reverted. Considered and deferred this run:
`lockTriggerPct`/`lockFloorPct` tuning (sequence: only after giveBackGuard is live
and measured); `maxAdverseDriftPct` 0.6→0.4 (stops improving; medium evidence);
`minEntryPrice` raise (n too small); `advGate` (no ADV data); duplication (no allowed key).

**What I learned:**
- Trailing give-back is the largest key-addressable leak left after the TP fix; the
  pending giveBackGuard is its sequenced fix and post-apply measurement is next.
- The duplication leak is a within-scan fill race; only an app-side single-flight fix
  addresses it — no guardrail key can.
- Post-approval cohorts are regime-confounded (−0.47 avg) — evaluate applied changes
  on cohorts, not the headline metric alone.


---

## FILE: optimizer/runs/run-2026-09-21.md

# Run 0001 — 2026-09-21 (off-schedule follow-up)

**Trigger:** Owner follow-up to the finished run: "give me the first batch from Friday's analysis."

**Delivered:** Batch 1 of the Friday Sep 18 Continuous Review — headline + conditions ranked #1–10 of 28.
- Output file (per-run, outside shared/): `friday_analysis/review-2026-09-18-batch-1.md`
- Batches 2–3 queued for follow-up: conditions #11–20; then #21–28 + 4 avoids + layer stats.

**Optimizer action:** Posted the first live proposal to `/api/optimizer/proposals`:
- id `cmuan6jxp0000lp08bwxdbi5i` — `restingShortTpEnabled: true` ("Resting take-profit for SHORT exits").
- Evidence: 199 clean-window SHORT TP exits — avg peak +2.44% vs avg close +1.32% (1.12% give-back; 68 peaked green then closed red). Resting limit at 80% of peak ≈ +1.95% (+0.63%/trade).
- Endpoint response: `{"ok":true,"created":1}`. Verified: PENDING in-app + `proposal_created` ChangeLogEntry.
- No duplicate PENDING proposals or active overrides existed. `giveBackGuardEnabled` deferred (sequence: after TP fix lands). No other keys cleared the evidence bar this run.

**Metric snapshot (pre-approval):** win_rate_pct 35.60 · avg_return_pct −0.2066 · n=1,629 (clean window, exitTime ≥ 2026-08-27).

**Notes:** Off-schedule run (scheduled cadence ≈ 7pm ET weekdays). Watch: owner approval of `cmuan6jxp0000lp08bwxdbi5i`; then re-measure SHORT TP give-back on fresh exits.


**RSI ledger note:** `report_rsi_change` failed to persist this run (3 attempts) — change summary for the ledger: "Posted first live proposal restingShortTpEnabled=true (cmuan6jxp0000lp08bwxdbi5i); delivered Friday-review Batch 1 (#1–10 of 28) to owner."


---

## FILE: optimizer/runs/run-2026-09-25.md

# Run 2026-09-25 — MarcoFlow Nightly Execution Optimizer

**Metric snapshot (clean window: CLOSED trades, exitTime ≥ 2026-08-27, n = 1,970):**
- **win_rate_pct: 33.65**
- **avg_return_pct: −0.2515**
- Trend: weekly win-rate 47.4 → 33.7 → 38.8 → 27.0 → 24.3; recent (post-9/21) cohort
  24.34 / −0.4662 — market regime has been hostile to the short book; both components
  are below the spec baseline (35.40 / −0.2078).

**Proposals submitted (1):**

```json
{
  "runDate": "2026-09-25",
  "proposals": [
    {
      "title": "Give-back guard for trailing-stop exits",
      "leak": "602 trailing-stop exits closed +0.112% avg after peaking +0.657% — 77% (464/602) gave back more than half their peak; post-9/22 window: 84/100 (84%).",
      "changeSummary": "Enable giveBackGuardEnabled (false -> true)",
      "guardrailKey": "giveBackGuardEnabled",
      "proposedValue": true,
      "backtest": "Est. lock replay (trigger 0.8% / floor 0.5%): 91 of 173 lock-armed exits closed below the +0.5% floor (avg +0.04%); flooring at +0.5% ≈ +0.46%/trade on those 91."
    }
  ]
}
```

**API response (sanitized):** `HTTP 200 — {"ok":true,"created":1,"ids":["cmuhfcgae01oeoz0892otsavp"],"rejected":[]}`

Verified in DB: `OptimizerProposal` row PENDING for `giveBackGuardEnabled` +
`ChangeLogEntry` `proposal_created` (actor=optimizer) at 2026-09-25 20:39:40 UTC.

**Prior approved proposal — measured effect:**
- `restingShortTpEnabled` (approved 9/20, applied 9/21): post-fix SHORT TP exits (n=26)
  show avg peak +1.93% → close −0.09% (give-back 2.01%); KPI count(peak≥1.5 & red)
  within SHORT TP exits 8→20→21→19→21 weekly → NOT yet visibly resolved; small sample
  plus hostile regime; re-measure over the next sessions.

**Other assessments this run (no proposal):**
- Duplication still live: 111 symbol-days with ≥3 same-day entries; 450 extra (rank≥2)
  entries −$1,095 marginal (−$1,016 since 9/8); 98% of same-day re-entries <60s apart
  with repeated same portionIndex → within-scan fill race. `maxPositionsPerSymbol` is
  already 1, so no guardrail-key change can address it (needs an app-side dedupe fix).
- Stop-loss: 452/560 stops never went favorable; post-5.0 average improved (−1.089 vs
  −1.524 pre) → hold `maxAdverseDriftPct` tightening (monitor).
- Fill slippage notes: 10 events ≥1.5% (max 2.06% on 9/25); guard is observability-only.
- ADV data still unavailable in `StockDataCache` (42 'daily' rows only).

