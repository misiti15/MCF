# 07 — Pulling Live Data from MarcoFlow

Base URL: `https://marcoflow.abacusai.app`. All responses are JSON. Status codes below were checked on 2026-10-02 (~12:00 ET).

> **Safety rule:** another system should only ever call the **read-only GET endpoints** in section 1. The endpoints in section 3 start scans, alerts or paper trades. Calling them from a second system can double-trade or fight MarcoFlow's own scheduler.

## 1. Public read-only endpoints (no auth)

| Endpoint | Returns | Params |
|---|---|---|
| `GET /api/health` | `{status, database, version}` — liveness and version (7.0.0) | — |
| `GET /api/observations` | Counts (total / pending / wins / losses / expired), last recorded/resolved timestamps, and the most recent observation rows | `limit` (10–100, default 40) |
| `GET /api/performance` | Aggregate signal stats: win rate, long/short, by heat range, by trade type, by regime, top strategies, market regime | — (uses a capped recent sample of resolved rows) |
| `GET /api/scorecard` | Alerted-signal scorecard: total alerted, decided, wins, losses, expired, win rate and Wilson LB, avg return, per-day breakdown | — |
| `GET /api/paper/status` | Paper portfolio (fund, portion size, open trades, total P&L) and recent trades | `limit` (max 200, default 50) |
| `GET /api/review` | Latest strategy review: best rule, Wilson LB, recommendations, avoid list, layer stats | `history` (include past runs) |
| `GET /api/simulations` | Daily playbook simulations with lessons | `limit` (1–90, default 40) |
| `GET /api/insights` | Plain-English insight cards computed from all resolved observations | — |
| `GET /api/screener` | Live scan results with Heat Score per symbol | `filter` (buy/sell/all), `sort` (heat/volume/change), `symbol`, `category`, `minHeat`, `tradeType` |
| `GET /api/heat-tracker/{symbol}` | Heat Score breakdown for one symbol | `interval` (default 5m) |
| `GET /api/stocks/{symbol}` | Price data for one symbol | — |
| `GET /api/backtest/{symbol}` | Runs MarcoFlow's backtester on one symbol (CPU-heavy, use sparingly) | `interval`, `entryThreshold`, `stopLoss`, `takeProfit`, `maxHoldBars` |

Notes on interpretation:
- `/api/scorecard` win rate is **wins / (wins + losses)**, excluding expired. `/api/observations` counts include expired. The two will differ.
- `/api/performance` aggregates a capped recent sample (`totalResolved` shows its size), not the full table. For full history use the export.
- The screener and heat-tracker hit live market data. Don't poll them faster than every 5 minutes; MarcoFlow's own bars update at that cadence.

### Examples
```bash
curl -s https://marcoflow.abacusai.app/api/health
curl -s "https://marcoflow.abacusai.app/api/observations?limit=100"
curl -s "https://marcoflow.abacusai.app/api/paper/status?limit=200"
curl -s https://marcoflow.abacusai.app/api/review
```

```python
import requests
BASE = "https://marcoflow.abacusai.app"
obs = requests.get(f"{BASE}/api/observations", params={"limit": 100}, timeout=30).json()
# keys: counts, lastRecordedAt, lastResolvedAt, observations, serverTime, marketOpen
for row in obs["observations"]:
    print(row["observedAt"], row["direction"], row["heat"], row["status"])
```

## 2. Login-gated endpoints (website session; return 401 to scripts)
`/api/changelog`, `/api/optimizer/proposals` (GET), `/api/optimizer/proposals/{id}`, `/api/optimizer/overrides`, `/api/strategies`, `/api/strategies/configure`, `/api/signals/history`.

## 3. Secret-protected endpoints — these ACT, do not call from another system

| Endpoint | Auth | Effect |
|---|---|---|
| `POST /api/agent/tick` | `Authorization: Bearer <AGENT_SECRET>` | Records/resolves signals, runs alerts or strategy review (`mode=record\|resolve\|both\|alert\|review`, `offset`, `limit`, `force`) |
| `POST /api/paper/tick` | Bearer `<AGENT_SECRET>` | Enters and exits paper trades |
| `GET/POST /api/agent/heartbeat` | `?key=<HEARTBEAT_SECRET>` | Full self-orchestrated pass: scan chunk, alerts, paper tick; Daily Brief after close |
| `/api/agent/daily-brief`, `/api/eod-recap`, `/api/eod-losses`, `/api/agent/postmortem`, `/api/agent/self-correct` | `?key=<AGENT_SECRET>` or Bearer | Reports; `send=1` emails the owner |
| `POST /api/review`, `POST /api/simulations` | Bearer `<AGENT_SECRET>` | Recompute and store a review / simulation |
| `POST /api/optimizer/proposals` | `<AGENT_SECRET>` | Creates optimizer proposals (optimizer is paused) |

A plain `GET` on `/api/agent/tick` or `/api/paper/tick` without a secret is harmless; it only returns a hint and whether the market is open.

## 4. Getting full history (beyond what the API exposes)
The public API returns summaries and recent rows only. There is no endpoint that pages through the full `SignalObservation` or `PaperTrade` tables. Options:
1. Use this pack's `data/` snapshot (complete to 2026-10-02 ~15:50 ET).
2. Ask the MarcoFlow builder to re-run the export for a fresh snapshot.
3. Ask for a new **read-only, key-protected export endpoint** (for example `GET /api/export/trades?since=...`) so the new system can pull incremental data on demand. Not built yet; it would be a MarcoFlow code change.
