# MarcoFlow Knowledge Pack — START HERE

**Purpose:** give a new trading system (built with Claude / Claude Code) everything MarcoFlow has learned: all recorded data, what works and what doesn't, history and reasoning, open and tabled work, the owner's standing rules, and how to pull live data from MarcoFlow.

**Snapshot date:** 2026-10-02 (data exported ~15:50 ET, mid-session, so 10/2 is partial).
**MarcoFlow version at export:** 7.0.0 (Update 7.0, shipped 2026-09-28).
**Trading mode:** intraday, short-heavy, Alpaca **paper** account only (no real money has ever been traded).

> Educational only — not financial advice.

---

## Read in this order

| # | File | What it gives you |
|---|---|---|
| 00 | `00_START_HERE.md` | This index, plus quick-start queries |
| 01 | `01_SYSTEM_OVERVIEW_AND_HISTORY.md` | Architecture, the full pipeline, and a dated timeline of every milestone and update |
| 02 | `02_DATA_DICTIONARY.md` | Every exported table and column, units, enums, data eras and caveats |
| 03 | `03_STATS_SNAPSHOT.md` | Computed results: by era, direction, exit reason, give-back, hour and day |
| 04 | `04_WHAT_WORKS_WHAT_DOESNT.md` | Validated findings, failed ideas, rejected approaches, with the numbers |
| 05 | `05_OPEN_ISSUES_AND_TABLED_TASKS.md` | Known bugs, reliability problems, tabled and deferred work |
| 06 | `06_RULES_AND_PREFERENCES.md` | The owner's standing rules and working preferences |
| 07 | `07_LIVE_DATA_ACCESS.md` | MarcoFlow's live API: endpoints, auth, examples, safety rules |

## Folders

| Folder | Contents |
|---|---|
| `data/` | Full database export. `marcoflow.sqlite` (all tables, indexed) plus one CSV per table (`SignalObservation.csv.gz` is gzipped). `export_manifest.json` lists rows, columns and types. |
| `code/` | Snapshot of MarcoFlow's core logic: `lib/` (scanner, Heat score, recorder, alert checker, paper trader, execution v7, guardrails, strategy review, Alpaca client, Daily Brief), `prisma/schema.prisma`, and key `api/` routes. Reference only — it will not run standalone. |
| `optimizer/` | Notes from the nightly execution optimizer (now paused): playbook, measurement spec, run records. |
| `specs/` | The Update 7.0 execution spec the owner wrote, and the hourly scheduled-task playbook. |

**Deliberately excluded:** the `User` table (login credentials), `StockDataCache` (transient price cache), and all secrets (API keys, tokens, database URLs). Wherever a secret is needed you will see a placeholder such as `<AGENT_SECRET>`.

---

## How a new system should use this pack

1. **Load context:** read files 01, 04, 05 and 06 into the planning context before designing anything. They are short on purpose.
2. **Query, don't re-derive:** use `data/marcoflow.sqlite` for any historical question. It is self-contained and indexed on time and symbol.
3. **Respect the data eras:** paper-trade exit prices before **2026-08-28** are partly corrupted (see 02). Use `entryTime >= '2026-08-28'` for anything about execution quality.
4. **Separate signal edge from execution edge:** `SignalObservation` measures whether the *signal* was right (its own target/stop/horizon rules). `PaperTrade` measures what actually got captured after fills, slippage and exits. MarcoFlow's central lesson is that these differ a lot.
5. **Pull fresh data:** after the snapshot date, use the read-only public endpoints in 07. Never call the trading or tick endpoints from another system unless you intend to trigger MarcoFlow trading.

---

## Quick start

### Python + pandas
```python
import sqlite3, pandas as pd
con = sqlite3.connect("data/marcoflow.sqlite")

# Clean-window paper trades
trades = pd.read_sql("""
  SELECT * FROM PaperTrade
  WHERE status = 'CLOSED' AND entryTime >= '2026-08-28'
""", con, parse_dates=["entryTime", "exitTime"])

# Win rate and give-back by exit reason
trades["win"] = trades.returnPct > 0
print(trades.groupby("exitReason").agg(n=("id","count"), win=("win","mean"),
      avg_ret=("returnPct","mean"), avg_peak=("peakPct","mean")))

# Live, resolved signal observations joined to the trades they produced
obs = pd.read_sql("""
  SELECT o.*, t.returnPct AS paperReturnPct, t.exitReason
  FROM SignalObservation o
  LEFT JOIN PaperTrade t ON t.observationId = o.id
  WHERE o.source = 'live' AND o.status IN ('WIN','LOSS','EXPIRED')
""", con, parse_dates=["observedAt"])
```

### Pure SQL (sqlite3 CLI)
```sql
-- Signal-level edge: shorts that follow a drop vs shorts that fade a rip (clean window)
SELECT CASE WHEN momentum <= -5 THEN 'follow_drop'
            WHEN momentum >=  5 THEN 'fade_rip' ELSE 'other' END AS bucket,
       COUNT(*) n,
       ROUND(100.0*SUM(status='WIN')/COUNT(*),1) win_pct,
       ROUND(AVG(returnPct),3) avg_ret
FROM SignalObservation
WHERE direction='SHORT' AND source='live'
  AND status IN ('WIN','LOSS','EXPIRED') AND observedAt >= '2026-08-28'
GROUP BY bucket;
```

### Timestamps
All timestamps are **UTC** ISO strings. Market time is America/New_York. During the export window (EDT) ET = UTC − 4 hours. Pre-computed `etHour`, `dayOfWeek` and `sessionSlot` columns exist on both main tables.
