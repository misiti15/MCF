# 03 — MarcoFlow Stats Snapshot (computed from the exported data)

Generated directly from `data/marcoflow.sqlite`. Paper trading on an Alpaca PAPER account (no real money). Portfolio: $80,000 fund, $640 per position (Update 7.0: $640 full / $320 half). ET dates assume UTC-4 (EDT).

### Paper trades — overall

| closed trades | wins | win % | avg return % | total P&L $ | first entry (UTC) | last entry (UTC) |
|---|---|---|---|---|---|---|
| 2709 | 991 | 36.60 | -0.22 | -3320.27 | 2026-08-20T15:03:28.320000 | 2026-10-02T15:25:06.816000 |

### Paper trades by version era
Pre-8/28 exit prices are partly wrong (quote bug fixed in Update 3.0) — use 8/28+ as the clean window.

| era | trades | win % | avg ret % | P&L $ |
|---|---|---|---|---|
| 0 pre-3.0 (exit data partly corrupted) | 586 | 53.90 | -0.01 | -78.47 |
| 1 Update 3.0 clean fills (8/28-9/7) | 628 | 38.50 | -0.19 | -677.26 |
| 2 Update 3.5 (9/8-9/10) | 170 | 42.90 | -0.07 | -67.64 |
| 3 Update 4.0 (9/11-9/16) | 372 | 26.60 | -0.37 | -794.77 |
| 4 Update 5.0/6.x (9/17-9/28) | 646 | 24.50 | -0.38 | -1329.48 |
| 5 Update 7.0 (9/29+) | 307 | 33.60 | -0.26 | -372.65 |

### Paper trades by direction (clean window 8/28+)

| direction | trades | win % | avg ret % | P&L $ |
|---|---|---|---|---|
| LONG | 167 | 25.10 | -0.65 | -661.23 |
| SHORT | 1956 | 32.40 | -0.25 | -2580.57 |

### Paper trades by exit reason (clean window 8/28+)

| exit reason | trades | win % | avg ret % | avg peak % | P&L $ |
|---|---|---|---|---|---|
| trailing_stop | 664 | 56.20 | 0.12 | 0.66 | 395.57 |
| stop_loss | 608 | 3.80 | -1.16 | 0.06 | -3840.53 |
| time_exit | 486 | 22.00 | -0.27 | 0.16 | -709.65 |
| take_profit | 348 | 46.60 | 0.45 | 1.61 | 909.25 |
| time_exit_trailing | 15 | 53.30 | -0.03 | 0.35 | -0.24 |
| eod_close | 2 | 100.00 | 0.62 | 0.81 | 3.80 |

### Give-back profile by peak favorable move (clean window 8/28+)
Core finding: winners give back most of their peak; "never worked" trades are the bulk of losses.

| bucket | trades | avg peak % | avg captured % | ended red | P&L $ |
|---|---|---|---|---|---|
| a peak >=1% | 390 | 1.78 | 0.59 | 149 | 1253.75 |
| b peak 0.5-1% | 327 | 0.69 | 0.18 | 90 | 281.40 |
| c peak 0.15-0.5% | 566 | 0.31 | -0.27 | 376 | -820.61 |
| d never worked (<0.15%) | 840 | 0.02 | -0.87 | 818 | -3956.34 |

### Paper trades by ET entry hour (clean window 8/28+)
Hours 9 and 12 are deliberately skipped for entries (skipEntryHours) since 9/2.

| ET hour | trades | win % | avg ret % | P&L $ |
|---|---|---|---|---|
| 9 | 144 | 36.80 | -0.59 | -521.68 |
| 10 | 1013 | 29.20 | -0.33 | -1844.58 |
| 11 | 887 | 34.80 | -0.17 | -696.36 |
| 12 | 79 | 21.50 | -0.42 | -179.18 |

### Paper trades by day (clean window 8/28+)
Days missing = system was down (scheduler orphaned), weekends, or holidays.

| ET date | trades | wins | win % | P&L $ |
|---|---|---|---|---|
| 2026-08-28 | 207 | 100 | 48.30 | -88.92 |
| 2026-08-31 | 77 | 29 | 37.70 | -0.62 |
| 2026-09-02 | 198 | 75 | 37.90 | -281.55 |
| 2026-09-03 | 88 | 16 | 18.20 | -276.59 |
| 2026-09-04 | 58 | 22 | 37.90 | -29.58 |
| 2026-09-08 | 71 | 25 | 35.20 | -81.45 |
| 2026-09-09 | 41 | 22 | 53.70 | 23.69 |
| 2026-09-10 | 58 | 26 | 44.80 | -9.88 |
| 2026-09-11 | 85 | 26 | 30.60 | -128.11 |
| 2026-09-14 | 194 | 44 | 22.70 | -503.86 |
| 2026-09-15 | 53 | 21 | 39.60 | -53.57 |
| 2026-09-16 | 40 | 8 | 20.00 | -109.23 |
| 2026-09-17 | 187 | 43 | 23.00 | -345.75 |
| 2026-09-18 | 78 | 31 | 39.70 | -78.61 |
| 2026-09-21 | 81 | 24 | 29.60 | -188.20 |
| 2026-09-22 | 48 | 19 | 39.60 | -63.07 |
| 2026-09-25 | 212 | 31 | 14.60 | -598.25 |
| 2026-09-28 | 40 | 10 | 25.00 | -55.60 |
| 2026-09-29 | 121 | 56 | 46.30 | -15.26 |
| 2026-09-30 | 52 | 19 | 36.50 | -5.17 |
| 2026-10-01 | 87 | 10 | 11.50 | -326.69 |
| 2026-10-02 | 47 | 18 | 38.30 | -25.53 |

### Signal observations by status and source
Observation-level outcomes use the tracker's own target/stop/horizon rules (see 02_DATA_DICTIONARY), independent of paper execution.

| source | status | count | avg return % |
|---|---|---|---|
| backfill | EXPIRED | 37098 | 0.06 |
| backfill | LOSS | 13424 | -1.50 |
| backfill | WIN | 8156 | 2.00 |
| live | EXPIRED | 55025 | -0.11 |
| live | LOSS | 16299 | -1.50 |
| live | PENDING | 1061 |  |
| live | WIN | 36582 | 0.81 |

### Signal observations by direction (live, resolved, 8/28+)

| direction | resolved | WIN % | avg return % |
|---|---|---|---|
| LONG | 10924 | 31.60 | -0.20 |
| SHORT | 41186 | 36.60 | 0.01 |

### Signal observations by market regime (live, resolved)

| regime | resolved | WIN % | avg return % |
|---|---|---|---|
|  | 34 | 47.10 | 0.63 |
| bear | 8291 | 34.60 | -0.13 |
| bull | 75754 | 33.10 | 0.00 |
| neutral | 23827 | 36.10 | -0.00 |

### Observations recorded per ET day (live, last 30 days with data)

| ET date | observations | alerted |
|---|---|---|
| 2026-08-20 | 5891 | 94 |
| 2026-08-21 | 2531 | 111 |
| 2026-08-24 | 1119 | 69 |
| 2026-08-25 | 2329 | 266 |
| 2026-08-26 | 2489 | 373 |
| 2026-08-27 | 2628 | 423 |
| 2026-08-28 | 2815 | 598 |
| 2026-08-31 | 1507 | 202 |
| 2026-09-01 | 1258 | 0 |
| 2026-09-02 | 2425 | 611 |
| 2026-09-03 | 2551 | 260 |
| 2026-09-04 | 2078 | 106 |
| 2026-09-07 | 2865 | 141 |
| 2026-09-08 | 2136 | 147 |
| 2026-09-09 | 2889 | 180 |
| 2026-09-10 | 2375 | 182 |
| 2026-09-11 | 2409 | 287 |
| 2026-09-14 | 2608 | 800 |
| 2026-09-15 | 2292 | 246 |
| 2026-09-16 | 2457 | 159 |
| 2026-09-17 | 2696 | 479 |
| 2026-09-18 | 2473 | 212 |
| 2026-09-21 | 2867 | 48 |
| 2026-09-22 | 683 | 185 |
| 2026-09-25 | 2556 | 540 |
| 2026-09-28 | 1680 | 299 |
| 2026-09-29 | 2464 | 323 |
| 2026-09-30 | 1733 | 103 |
| 2026-10-01 | 2337 | 85 |
| 2026-10-02 | 978 | 178 |
