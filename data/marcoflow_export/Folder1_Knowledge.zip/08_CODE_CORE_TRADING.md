# MarcoFlow core trading code

Reference snapshot from MarcoFlow (2026-10-02). Read-only reference; not runnable on its own. Educational only — not financial advice.


---

## FILE: code/lib/execution-v2.ts

```typescript
/**
 * MarcoFlow Update 7.0 (v7.0.0, 9/28/26) — execution/exit fixes E1, E3, F1, X2, X3, X4, C1.
 * EXECUTION-ONLY: nothing here changes signal generation, Heat Score, alert
 * parameters, skipEntryHours, the knife guard, timeframes or entry selection.
 * Every helper degrades gracefully (missing data never blocks a trade).
 */
import { prisma } from '@/lib/db';
import { getLast1MinBars } from '@/lib/alpaca';

export const V2_NOTE = 'Educational only — not financial advice.';

export type SkipReason = 'stale_skip' | 'momentum_conflict_skip' | 'etf_divergence_skip';

export function etMinutes(d = new Date()): number {
  const et = new Date(d.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  return et.getHours() * 60 + et.getMinutes();
}

export function etDateKey(d = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(d);
}

const isOpenSession = (m: number) => m >= 9 * 60 + 50 && m < 11 * 60; // 9:50–11:00 ET
const isMidday = (m: number) => m >= 11 * 60 && m < 14 * 60;           // 11:00–14:00 ET
const HIGH_VOL_ATR_PCT = 0.7;

// ---- E1: signal freshness ----
export const STALE_THRESHOLD = 0.005; // 0.5%

export function isSignalFresh(
  direction: string,
  triggerPrice: number,
  q: { bid: number; ask: number; price: number },
): boolean {
  if (!(triggerPrice > 0)) return true;
  if (direction === 'SHORT') {
    const bid = q.bid > 0 ? q.bid : q.price;
    return !(bid > triggerPrice * (1 + STALE_THRESHOLD));
  }
  if (direction === 'LONG') {
    const ask = q.ask > 0 ? q.ask : q.price;
    return !(ask > 0 && ask < triggerPrice * (1 - STALE_THRESHOLD));
  }
  return true;
}

// ---- E3: direction confirmation on the last 2 completed 1-min candles ----
export const MAX_DEFERS = 2;

export async function checkDirectionConfirmation(
  direction: string,
  symbol: string,
  deferCount: number,
): Promise<'ok' | 'defer' | 'skip'> {
  let bars: Array<{ close: number }> | null = null;
  try {
    bars = await getLast1MinBars(symbol, 2);
  } catch {
    return 'ok'; // candle data unavailable → allow
  }
  if (!bars || bars.length < 2) return 'ok';
  const [mostRecent, previous] = bars;
  const conflict =
    (direction === 'SHORT' && mostRecent.close > previous.close) ||
    (direction === 'LONG' && mostRecent.close < previous.close);
  if (!conflict) return 'ok';
  return deferCount >= MAX_DEFERS ? 'skip' : 'defer';
}

// ---- F1: ETF + RSI divergence ----
// Divergence uses the SAME definitions the strategy review / optimizer used:
//   bullish = RSI(14) < 35 while fast RSI(5) > 40
//   bearish = RSI(14) > 65 while fast RSI(5) < 60
export function rsiDivergence(rsi: number | null, rsiShort: number | null): 'bullish' | 'bearish' | null {
  if (rsi == null || rsiShort == null) return null;
  if (rsi < 35 && rsiShort > 40) return 'bullish';
  if (rsi > 65 && rsiShort < 60) return 'bearish';
  return null;
}

export function shouldSkipForEtfDivergence(sig: { assetClass: string | null; rsi: number | null; rsiShort: number | null }): boolean {
  return sig.assetClass === 'etf' && rsiDivergence(sig.rsi, sig.rsiShort) !== null;
}

// ---- X2: ATR-calibrated stop (percent units, e.g. 1.5 = 1.5%) ----
export function computeStopPct(atrPct: number | null, mins: number, defaultStop: number): number {
  if (atrPct == null || !(atrPct > 0)) return defaultStop;
  if (isOpenSession(mins)) return Math.max(atrPct * 1.5, 1.5);
  if (isMidday(mins)) return Math.max(atrPct * 1.0, 0.8);
  if (atrPct > HIGH_VOL_ATR_PCT) return Math.max(atrPct * 1.3, 1.3);
  return Math.max(atrPct * 1.2, 1.0);
}

// ---- X3: session-aware trailing activation / distance (percent units) ----
export function getTrailingStopParams(atrPct: number | null, mins: number): { activateAt: number; trailDistance: number } {
  if (isOpenSession(mins)) return { activateAt: 0.35, trailDistance: 0.3 };
  if (isMidday(mins)) return { activateAt: 0.5, trailDistance: 0.4 };
  if (atrPct != null && atrPct > HIGH_VOL_ATR_PCT) return { activateAt: 0.6, trailDistance: 0.45 };
  return { activateAt: 0.5, trailDistance: 0.4 };
}

// ---- X4: time-exit safety net ----
export const TIME_EXIT_WINDOW_MIN = 30;    // T-30 before the 16:00 ET close
export const TIME_EXIT_LOSS_CUT = -0.3;    // below this → hard close as before
export const TIME_EXIT_BE_CEIL = 0.1;      // -0.3..+0.1 → aggressive trail
export const TIME_EXIT_TRAIL_PCT = 0.15;   // aggressive trail distance

export function pnlPctBidAsk(direction: string, entry: number, q: { bid: number; ask: number; price: number }): number {
  if (direction === 'SHORT') {
    const bid = q.bid > 0 ? q.bid : q.price;
    return ((entry - bid) / entry) * 100;
  }
  const ask = q.ask > 0 ? q.ask : q.price;
  return ((ask - entry) / entry) * 100;
}

// ---- C1: condition-weighted sizing ----
export const FULL_SIZE = 640;
export const HALF_SIZE = 320;

export interface SizingInput {
  direction: string;
  atrPct: number | null;
  marketRegime: string | null;
  buyPressure: number | null;
  rsi: number | null;
  rsiShort: number | null;
  vwapDistPct: number | null;
}

export function scoreSignalConditions(s: SizingInput): { score: 0 | 1 | 2 | 3; fullSize: boolean } {
  const div = rsiDivergence(s.rsi, s.rsiShort);
  const flowAligned = s.buyPressure != null &&
    ((s.direction === 'LONG' && s.buyPressure > 0.15) || (s.direction === 'SHORT' && s.buyPressure < -0.15));
  const flowSell = s.buyPressure != null && s.buyPressure < -0.25;
  const vwapSideAligned = s.vwapDistPct != null &&
    ((s.direction === 'LONG' && s.vwapDistPct > 0.05) || (s.direction === 'SHORT' && s.vwapDistPct < -0.05));
  const atr = s.atrPct;

  const stackA = s.marketRegime === 'neutral' && s.buyPressure != null && s.buyPressure < -0.25 && atr != null && atr > 0.7;
  const stackB = s.direction === 'SHORT' && atr != null && atr > 0.7 && div === 'bullish';
  const stackC = s.rsi != null && s.rsi >= 55 && s.rsi <= 65 && flowAligned && atr != null && atr >= 0.3 && atr <= 0.7;
  const top = [stackA, stackB, stackC].filter(Boolean).length;
  if (top >= 1) return { score: top >= 2 ? 3 : 2, fullSize: true };

  const rank4to10 = [
    s.direction === 'SHORT' && flowSell && s.rsiShort != null && s.rsiShort > 70,
    flowSell && vwapSideAligned && s.rsiShort != null && s.rsiShort > 70,
  ].some(Boolean);
  if (rank4to10) return { score: 1, fullSize: true };

  // Missing condition data → never penalise: score 0 but keep full size.
  const anyMissing = [s.atrPct, s.marketRegime, s.buyPressure, s.rsi, s.rsiShort, s.vwapDistPct].some(v => v == null);
  return { score: 0, fullSize: anyMissing };
}

// ---- Signal skip / defer bookkeeping (skips never create a trade record) ----
export async function markSignalSkipped(id: string, symbol: string, direction: string, reason: SkipReason): Promise<void> {
  await prisma.signalObservation.update({ where: { id }, data: { skipped: true, skipReason: reason, deferCount: 0 } });
  console.log(`[paper-trader v2] ${reason} ${direction} ${symbol} — execution skipped (no trade recorded). ${V2_NOTE}`);
}

export async function incrementDeferCount(id: string, symbol: string, direction: string, n: number): Promise<void> {
  await prisma.signalObservation.update({ where: { id }, data: { deferCount: { increment: 1 } } });
  console.log(`[paper-trader v2] momentum_defer ${direction} ${symbol} (defer ${n + 1}/${MAX_DEFERS}) — retry next tick. ${V2_NOTE}`);
}

// ---- "Conclude the trading day" switch: no new entries for the given ET date ----
const CONCLUDED_KEY = 'trading_concluded';

export async function isTradingConcludedToday(): Promise<boolean> {
  try {
    const row = await prisma.agentState.findUnique({ where: { key: CONCLUDED_KEY } });
    return (row?.valueJson as any)?.etDate === etDateKey();
  } catch {
    return false;
  }
}

export async function concludeTradingDay(): Promise<string> {
  const etDate = etDateKey();
  await prisma.agentState.upsert({
    where: { key: CONCLUDED_KEY },
    create: { key: CONCLUDED_KEY, valueJson: { etDate, at: new Date().toISOString() } },
    update: { valueJson: { etDate, at: new Date().toISOString() } },
  });
  return etDate;
}

```

---

## FILE: code/lib/paper-trader.ts

```typescript
/**
 * Paper-trading engine for MarcoFlow.
 *
 * Capital model: $4000 fund split into 10 rotating $400 portions.
 * Closed portions recycle same-day.
 *
 * BAKED-IN EDGES (data-backed, run 8/19):
 *   1. TIME-OF-DAY: Full aggression mornings (9:30–11 ET),
 *      standard midday (11–14), reduced/skip power-hour (14–16).
 *   2. TRAILING STOP: activates after +0.3%, trails 0.3% from peak.
 *      Hard stop 1.25%, take-profit 1.5%, max hold 2h.
 *
 * Entry qualification: piggybacks on confirmed act-now alerts
 * (alertedAt IS NOT NULL, PENDING status, recent).
 * Among qualifying signals, ranks by Wilson confidence lower-bound.
 */

import { prisma } from '@/lib/db';
import {
  placeOrder, closePosition, cancelOrder, getLatestQuotes,
  getPositions, isAlpacaConfigured, getOrder, getAsset, getAvgDollarVolume,
  type AlpacaOrder,
} from '@/lib/alpaca';
import { getGuardrails } from '@/lib/trading-guardrails';
import {
  V2_NOTE, etMinutes, isSignalFresh, checkDirectionConfirmation, shouldSkipForEtfDivergence,
  computeStopPct, getTrailingStopParams, scoreSignalConditions, markSignalSkipped,
  incrementDeferCount, isTradingConcludedToday, pnlPctBidAsk, FULL_SIZE, HALF_SIZE,
  TIME_EXIT_WINDOW_MIN, TIME_EXIT_LOSS_CUT, TIME_EXIT_BE_CEIL, TIME_EXIT_TRAIL_PCT,
} from '@/lib/execution-v2';

// ---- Configuration (all configurable for A/B experiments) ----
const PORTION_COUNT = 125;
const PORTION_SIZE = 640;                          // $640 per portion
const TOTAL_FUND = PORTION_SIZE * PORTION_COUNT;   // $80,000
const MAX_CONCURRENT = PORTION_COUNT;              // deploy all 125 portions — maximize data collection

// Exit rules (data-backed sweet-spot from parameter sweep 8/19)
const TAKE_PROFIT_PCT = 1.5;
const STOP_LOSS_PCT = 1.25;
const MAX_HOLD_MINUTES = 120;  // 2 hours

// Trailing stop
const TRAIL_ACTIVATION_PCT = 0.3;  // activate once up this much
const TRAIL_DISTANCE_PCT = 0.3;    // trail this far below peak

// Time-of-day confidence thresholds (Wilson LB)
const MORNING_MIN_LB = 58;    // 9:30–11 ET — be aggressive
const MIDDAY_MIN_LB = 60;     // 11–14 ET — standard
const POWER_HOUR_MIN_LB = 68; // 14–16 ET — only the best

// How recently a signal must have been alerted to be eligible
const ENTRY_LOOKBACK_MINUTES = 12; // just over 2 scan cycles

// ---- Helpers ----
function etNow(): { h: number; m: number; mins: number; slot: string; day: number } {
  const et = new Date(new Date().toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const h = et.getHours();
  const m = et.getMinutes();
  const mins = h * 60 + m;
  const slot = mins < 11 * 60 ? 'open' : mins < 14 * 60 ? 'midday' : 'power_hour';
  return { h, m, mins, slot, day: et.getDay() };
}

function isMarketOpen(): boolean {
  const { mins, day } = etNow();
  if (day === 0 || day === 6) return false;
  return mins >= 9 * 60 + 30 && mins < 16 * 60;
}

function confidenceFloor(): number {
  const { slot } = etNow();
  if (slot === 'open') return MORNING_MIN_LB;
  if (slot === 'midday') return MIDDAY_MIN_LB;
  return POWER_HOUR_MIN_LB;
}

function favorablePct(direction: string, entry: number, current: number): number {
  return direction === 'LONG'
    ? ((current - entry) / entry) * 100
    : ((entry - current) / entry) * 100;
}

function trailingStopPrice(direction: string, peakPrice: number): number {
  return direction === 'LONG'
    ? peakPrice * (1 - TRAIL_DISTANCE_PCT / 100)
    : peakPrice * (1 + TRAIL_DISTANCE_PCT / 100);
}

function stopPrice(direction: string, entry: number): number {
  return direction === 'LONG'
    ? entry * (1 - STOP_LOSS_PCT / 100)
    : entry * (1 + STOP_LOSS_PCT / 100);
}

function takeProfitPrice(direction: string, entry: number): number {
  return direction === 'LONG'
    ? entry * (1 + TAKE_PROFIT_PCT / 100)
    : entry * (1 - TAKE_PROFIT_PCT / 100);
}

// ---- Portfolio state ----
export interface PortfolioState {
  totalFund: number;
  portionSize: number;
  portionCount: number;
  maxConcurrent: number;
  openTrades: number;
  availablePortions: number;
  totalPnl: number;
  totalTrades: number;
  wins: number;
  losses: number;
  winRate: number;
  todayTrades: number;
  todayPnl: number;
  todayWins: number;
  todayLosses: number;
  equity: number; // fund + realized P&L
}

export async function getPortfolioState(): Promise<PortfolioState> {
  const openTrades = await prisma.paperTrade.count({ where: { status: 'OPEN' } });
  const closed = await prisma.paperTrade.findMany({
    where: { status: 'CLOSED' },
    select: { pnlDollars: true, returnPct: true, createdAt: true },
  });

  const totalPnl = closed.reduce((s, t) => s + (t.pnlDollars || 0), 0);
  const wins = closed.filter(t => (t.pnlDollars || 0) > 0).length;
  const losses = closed.length - wins;

  // Today's trades
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const todayClosed = closed.filter(t => t.createdAt >= todayStart);
  const todayPnl = todayClosed.reduce((s, t) => s + (t.pnlDollars || 0), 0);
  const todayOpen = await prisma.paperTrade.count({ where: { status: 'OPEN', createdAt: { gte: todayStart } } });

  return {
    totalFund: TOTAL_FUND,
    portionSize: PORTION_SIZE,
    portionCount: PORTION_COUNT,
    maxConcurrent: MAX_CONCURRENT,
    openTrades,
    availablePortions: Math.max(0, MAX_CONCURRENT - openTrades),
    totalPnl: Math.round(totalPnl * 100) / 100,
    totalTrades: closed.length,
    wins,
    losses,
    winRate: closed.length > 0 ? Math.round((wins / closed.length) * 1000) / 10 : 0,
    todayTrades: todayClosed.length + todayOpen,
    todayPnl: Math.round(todayPnl * 100) / 100,
    todayWins: todayClosed.filter(t => (t.pnlDollars || 0) > 0).length,
    todayLosses: todayClosed.filter(t => (t.pnlDollars || 0) <= 0).length,
    equity: Math.round((TOTAL_FUND + totalPnl) * 100) / 100,
  };
}

// ---- Entry logic ----
export interface EntryResult {
  entered: number;
  skipped: number;
  errors: string[];
  entries: Array<{ symbol: string; direction: string; shares: number; price: number }>;
}

export async function evaluateEntries(): Promise<EntryResult> {
  const GR = await getGuardrails();
  const result: EntryResult = { entered: 0, skipped: 0, errors: [], entries: [] };

  if (!isAlpacaConfigured()) {
    result.errors.push('Alpaca not configured');
    return result;
  }
  if (!isMarketOpen()) {
    return result; // silent: no entries outside market hours
  }
  // Owner concluded today's session: no new entries until the next ET date.
  if (await isTradingConcludedToday()) return result;

  // Task 6 (time-of-day): skip entries during proven-loser hours (ET). The first
  // 30 min (hour 9) and noon (hour 12) were the two worst clean-window cohorts.
  const { h: entryHour } = etNow();
  if (GR.skipEntryHours.includes(entryHour)) return result;

  // How many portions are available?
  const openCount = await prisma.paperTrade.count({ where: { status: 'OPEN' } });
  let slotsAvailable = MAX_CONCURRENT - openCount;
  if (slotsAvailable <= 0) return result;

  // Find the next available portion index
  const openPortions = await prisma.paperTrade.findMany({
    where: { status: 'OPEN' },
    select: { portionIndex: true },
  });
  const usedIndices = new Set(openPortions.map(t => t.portionIndex));

  // Find qualifying signals: recently alerted act-now setups not yet paper-traded
  const since = new Date(Date.now() - ENTRY_LOOKBACK_MINUTES * 60 * 1000);
  const candidates = await prisma.signalObservation.findMany({
    where: {
      alertedAt: { gte: since },
      status: 'PENDING',
      source: 'live',
      skipped: false, // v2: E1/E3/F1-skipped signals are discarded, never retried
    },
    orderBy: { alertedAt: 'desc' },
    take: 50,
  });

  if (candidates.length === 0) return result;

  // PER-SYMBOL POSITION CAP (Update 3.0b, 8/27; count-based in Update 4.0, 9/11)
  // Prevents correlated blowups from stacking the same name across multiple portions.
  // Update 4.0: count-based instead of a boolean Set. The old Set only reflected
  // positions open at tick START, so two same-symbol candidates in one ranked loop
  // both slipped through (TARS filled twice, 2s apart, on 9/8). We now track a per-
  // symbol count of currently-open positions PLUS a per-tick "opened this tick" counter
  // (openedThisTick, incremented on each successful fill below), and gate every entry on
  // (existingOpen + openedThisTick) < GR.maxPositionsPerSymbol. Default cap 1
  // preserves the one-per-symbol intent while atomically closing the duplicate hole.
  const openSymbolCounts = new Map<string, number>();
  for (const t of await prisma.paperTrade.findMany({ where: { status: 'OPEN' }, select: { symbol: true } })) {
    const k = t.symbol.toUpperCase();
    openSymbolCounts.set(k, (openSymbolCounts.get(k) || 0) + 1);
  }
  const openedThisTick = new Map<string, number>(); // per-symbol fills placed during THIS tick
  const symbolAtCap = (sym: string) => {
    const k = sym.toUpperCase();
    return (openSymbolCounts.get(k) || 0) + (openedThisTick.get(k) || 0) >= GR.maxPositionsPerSymbol;
  };

  // Load the latest strategy review for confidence scoring
  const review = await prisma.strategyReview.findFirst({ orderBy: { runAt: 'desc' } });
  const minLB = confidenceFloor();

  // Score and rank candidates
  interface Candidate {
    signal: typeof candidates[0];
    confidence: number;
    ruleName: string;
  }
  const ranked: Candidate[] = [];

  for (const sig of candidates) {
    if (symbolAtCap(sig.symbol)) continue; // per-symbol position cap (count-based)

    // Check if already paper-traded this signal
    const existing = await prisma.paperTrade.findFirst({
      where: { observationId: sig.id },
    });
    if (existing) continue;

    // Use the signal's heat as a rough confidence proxy if no review
    // The alert-checker already validated against qualifying rules;
    // we extract the Wilson LB from the stored review data if available
    let lb = Math.abs(sig.heat); // fallback: heat as proxy
    let ruleName = 'heat-proxy';

    if (review) {
      // The signal was alerted, meaning it matched a rule with LB >= 60.
      // We use the review's best rule LB as the confidence for now.
      // (Full per-signal rule-matching would require re-running predicates,
      //  but the alert checker already did that work — trust its filter.)
      lb = review.bestWinRateLB;
      ruleName = review.bestRuleLabel;
    }

    if (lb < minLB) {
      result.skipped++;
      continue;
    }

    // ---- LONG side ----
    if (sig.direction === 'LONG') {
      if (GR.moveMagnitudeGateEnabled) {
        // Update 3.5: longs trade ONLY on proven-positive move bands.
        //   hard-dip bounce (momentum <= longDipMaxMomentum): 55.2% win, +$77
        //   strong up-move   (momentum >= longUpMinMomentum):  42.9% win, +$55
        // Flat/shallow-dip longs (the -$309 / -$43 graveyards) stay benched.
        if (GR.longsMode !== 'movers') { result.skipped++; continue; }
        const m = sig.momentum;
        const isMover = m != null &&
          (m <= GR.longDipMaxMomentum || m >= GR.longUpMinMomentum);
        if (!isMover) { result.skipped++; continue; } // benched longs incl. null-momentum
      } else {
        // Legacy bench path (gate disabled): longs off unless explicitly enabled.
        if (!GR.longsEnabled) { result.skipped++; continue; }
        if (lb < GR.longMinLB) { result.skipped++; continue; }
      }
    }

    // Task 5 (falling-knife short guard): don't short into a deep-oversold bounce.
    if (sig.direction === 'SHORT' && GR.knifeGuardEnabled
        && sig.rsi != null && sig.rsi <= GR.knifeMinRsi) {
      result.skipped++;
      continue;
    }

    // Update 3.5 (CORRECTED 9/8): DIRECTIONAL short-move gate. Skip only SHORTs that
    // FADE a rip (momentum >= +shortSkipRipAbovePct) — the real loser (43.9% win at
    // signal level, -0.34% avg). KEEP shorts that FOLLOW a drop (negative momentum) —
    // our single best population (75.7% win, 668 obs). The knife guard already trims
    // deep-drop bounces, so the two compose. Null momentum never blocks (other guards).
    if (sig.direction === 'SHORT' && GR.moveMagnitudeGateEnabled && sig.momentum != null) {
      if (sig.momentum >= GR.shortSkipRipAbovePct) { result.skipped++; continue; }
      if (GR.shortMinMovePct > 0 && Math.abs(sig.momentum) < GR.shortMinMovePct) {
        result.skipped++; continue; // flat-chop floor (off by default)
      }
    }

    // Update 4.0 (2a) Directional buy-pressure confirmation gate. The flow must
    // confirm the trade direction: a SHORT needs selling pressure (buyPressure <= 0),
    // a LONG needs buying pressure (buyPressure >= 0). JBIO (+0.41) and SBET (+0.27)
    // were shorted with buyers in control and lost. Pure skip; null buyPressure never
    // blocks (mirrors the null-momentum pattern). 0 is the confirmation boundary.
    if (GR.directionalConfirmGateEnabled && sig.buyPressure != null) {
      if (sig.direction === 'SHORT' && sig.buyPressure > 0) { result.skipped++; continue; }
      if (sig.direction === 'LONG'  && sig.buyPressure < 0) { result.skipped++; continue; }
    }

    // Update 4.0 (2b) RSI-rising short veto. The short rule requires RSI FALLING;
    // TARS had rsiSlope +6.2 (RSI rising = bounce underway) and the knife guard
    // (RSI<=30) missed it (RSI 31.2). Skip a SHORT when rsiSlope > 0. Pure skip;
    // null rsiSlope never blocks. PAYS/SBET/JBIO had negative slope so they pass.
    if (GR.rsiSlopeShortVetoEnabled && sig.direction === 'SHORT'
        && sig.rsiSlope != null && sig.rsiSlope > 0) {
      result.skipped++;
      continue;
    }

    // Task 3 (liquidity): skip sub-threshold prices (penny/illiquid names).
    if (GR.liquidityGateEnabled && sig.entryPrice < GR.minEntryPrice) {
      result.skipped++;
      continue;
    }

    // Update 3.5 (liquidity ADV gate): skip thin names by ~20-day avg dollar volume.
    // Default OFF (advGateEnabled=false) so this makes ZERO extra API calls until a
    // supervised enable. A null ADV (data hiccup) never blocks.
    if (GR.advGateEnabled) {
      const adv = await getAvgDollarVolume(sig.symbol);
      if (adv != null) {
        if (adv < GR.minAdvDollars) {
          result.errors.push(`${sig.symbol}: ADV $${(adv / 1e6).toFixed(1)}M < $${(GR.minAdvDollars / 1e6).toFixed(0)}M cap`);
          result.skipped++;
          continue;
        }
      }
    }

    ranked.push({ signal: sig, confidence: lb, ruleName });
  }

  // Sort by confidence descending. We deliberately DON'T pre-slice to the
  // number of open slots: some candidates aren't executable — a SHORT priced
  // above the $40 portion needs a whole share Alpaca won't fractionally short,
  // or the asset simply isn't shortable at Alpaca. Pre-slicing let those
  // un-executable shorts occupy the slots and silently crowd out executable
  // setups (e.g. LONGs, which trade fine via fractional notional), producing
  // zero fills even while real setups existed. Instead we walk the full ranked
  // list and keep attempting until the available slots are actually filled.
  ranked.sort((a, b) => b.confidence - a.confidence);

  for (const cand of ranked) {
    if (slotsAvailable <= 0) break;
    const sig = cand.signal;
    // Update 4.0 (2c): re-check the per-symbol cap here — multiple same-symbol
    // candidates can be in `ranked` (they were all under the cap during ranking when
    // openedThisTick was 0). Counting opened-this-tick closes the duplicate-fill hole.
    if (symbolAtCap(sig.symbol)) { result.skipped++; continue; }
    // Find free portion index
    let portionIdx = 0;
    while (usedIndices.has(portionIdx) && portionIdx < PORTION_COUNT) portionIdx++;
    if (portionIdx >= PORTION_COUNT) break;

    try {
      const { h } = etNow();

      // Live pre-trade checks right before committing capital: spread cap (Task 3)
      // and v2.0.0 E1 freshness (replaces the Update 3.5 stale-entry guard).
      try {
        const q = (await getLatestQuotes([sig.symbol])).get(sig.symbol.toUpperCase());
        // Task 3 (liquidity): skip names whose bid/ask is too wide to fill cleanly.
        if (GR.liquidityGateEnabled && q && q.bid > 0 && q.ask > 0) {
          const mid = (q.bid + q.ask) / 2;
          const spreadPct = ((q.ask - q.bid) / mid) * 100;
          if (spreadPct > GR.maxEntrySpreadPct) {
            result.errors.push(`${sig.symbol}: spread ${spreadPct.toFixed(1)}% > ${GR.maxEntrySpreadPct}% cap`);
            result.skipped++;
            continue;
          }
        }
        // v2.0.0 E1: SHORT stale if bid > trigger +0.5%; LONG stale if ask < trigger -0.5%.
        if (q && q.valid && q.price > 0 && !isSignalFresh(sig.direction, sig.entryPrice, q)) {
          await markSignalSkipped(sig.id, sig.symbol, sig.direction, 'stale_skip');
          result.skipped++;
          continue;
        }
      } catch { /* quote unavailable — don't block entry on a data hiccup */ }

      // v2.0.0 E3: last two completed 1-min candles must not be moving against us.
      const e3 = await checkDirectionConfirmation(sig.direction, sig.symbol, sig.deferCount ?? 0);
      if (e3 === 'skip') {
        await markSignalSkipped(sig.id, sig.symbol, sig.direction, 'momentum_conflict_skip');
        result.skipped++;
        continue;
      }
      if (e3 === 'defer') {
        await incrementDeferCount(sig.id, sig.symbol, sig.direction, sig.deferCount ?? 0);
        result.skipped++;
        continue;
      }

      // v2.0.0 F1: ETF with RSI divergence → skip execution (alerts/UI unaffected).
      if (shouldSkipForEtfDivergence(sig)) {
        await markSignalSkipped(sig.id, sig.symbol, sig.direction, 'etf_divergence_skip');
        result.skipped++;
        continue;
      }

      // v2.0.0 C1: condition-weighted sizing ($640 full / $320 half).
      const { score: conditionScore, fullSize } = scoreSignalConditions(sig);
      const positionSize = fullSize ? FULL_SIZE : HALF_SIZE;
      // v2.0.0 X2: ATR-calibrated stop, locked on the trade at entry.
      const tradeStopPct = Math.round(computeStopPct(sig.atrPct, etMinutes(), STOP_LOSS_PCT) * 1000) / 1000;

      let order: AlpacaOrder;

      if (sig.direction === 'LONG') {
        // Fractional dollar-based (Phase 1)
        order = await placeOrder({
          symbol: sig.symbol,
          side: 'buy',
          type: 'market',
          time_in_force: 'day',
          notional: positionSize.toFixed(2),
        });
      } else {
        // SHORT: whole shares only (Alpaca does not allow fractional shorts),
        // so a portion can only short a stock priced under the portion size.
        const shareCount = Math.floor(positionSize / sig.entryPrice);
        if (shareCount < 1) {
          result.errors.push(`${sig.symbol} SHORT: price $${sig.entryPrice} exceeds portion $${positionSize}`);
          result.skipped++;
          continue;
        }
        // Skip assets Alpaca won't let us short (many inverse/leveraged ETFs,
        // hard-to-borrow names). Cached, so we don't re-attempt them each tick.
        const asset = await getAsset(sig.symbol);
        if (!asset || !asset.tradable || !asset.shortable) {
          result.errors.push(`${sig.symbol} SHORT: not shortable at Alpaca`);
          result.skipped++;
          continue;
        }
        order = await placeOrder({
          symbol: sig.symbol,
          side: 'sell',
          type: 'market',
          time_in_force: 'day',
          qty: shareCount.toString(),
        });
      }

      // Wait briefly for fill (market orders fill quickly)
      let filledOrder = order;
      if (order.status !== 'filled') {
        await new Promise(r => setTimeout(r, 2000));
        try { filledOrder = await getOrder(order.id); } catch { filledOrder = order; }
      }

      const filledPrice = filledOrder.filled_avg_price
        ? parseFloat(filledOrder.filled_avg_price)
        : sig.entryPrice;
      const filledQty = filledOrder.filled_qty
        ? parseFloat(filledOrder.filled_qty)
        : (sig.direction === 'LONG' ? positionSize / sig.entryPrice : Math.floor(positionSize / sig.entryPrice));
      const dollarAmt = filledPrice * filledQty;

      // Update 3.5 fill-slippage guard (observability only): flag fills that landed
      // far from the signal price. No auto-close — this feeds the resting-limit /
      // liquidity work by measuring how much execution slippage we're eating.
      let notes: string | null = null;
      if (GR.fillSlippageGuardEnabled && sig.entryPrice > 0 && filledOrder.filled_avg_price) {
        const slipPct = Math.abs(filledPrice - sig.entryPrice) / sig.entryPrice * 100;
        if (slipPct > GR.maxFillSlippagePct) {
          notes = `fill_slippage ${slipPct.toFixed(2)}% (signal $${sig.entryPrice.toFixed(2)} -> fill $${filledPrice.toFixed(2)})`;
          console.warn(`[paper-trader] SLIPPAGE ${sig.symbol} ${sig.direction}: ${notes}`);
        }
      }

      await prisma.paperTrade.create({
        data: {
          symbol: sig.symbol,
          direction: sig.direction,
          portionIndex: portionIdx,
          entryPrice: filledPrice,
          entryTime: new Date(),
          shares: filledQty,
          dollarAmount: Math.round(dollarAmt * 100) / 100,
          status: 'OPEN',
          peakPrice: filledPrice,
          peakPct: 0,
          troughPrice: filledPrice,
          troughPct: 0,
          observationId: sig.id,
          alpacaOrderId: order.id,
          sessionSlot: etNow().slot,
          etHour: h,
          heat: sig.heat,
          confidence: cand.confidence,
          ruleName: cand.ruleName,
          notes,
          stopPct: tradeStopPct,
          atrPct: sig.atrPct,
          conditionScore,
        },
      });
      if ((sig.deferCount ?? 0) > 0) {
        await prisma.signalObservation.update({ where: { id: sig.id }, data: { deferCount: 0 } });
      }

      usedIndices.add(portionIdx);
      // Update 4.0 (2c): record this fill so a second same-symbol candidate in this
      // same tick is caught by symbolAtCap() and cannot duplicate the position.
      const capKey = sig.symbol.toUpperCase();
      openedThisTick.set(capKey, (openedThisTick.get(capKey) || 0) + 1);
      slotsAvailable--;
      result.entered++;
      result.entries.push({
        symbol: sig.symbol,
        direction: sig.direction,
        shares: filledQty,
        price: filledPrice,
      });

      console.log(`[paper-trader] ENTERED ${sig.direction} ${sig.symbol} x${filledQty.toFixed(4)} @ $${filledPrice.toFixed(2)} (portion #${portionIdx}, confidence ${cand.confidence.toFixed(1)}, size $${positionSize}, score ${conditionScore}, stop ${tradeStopPct}%). ${V2_NOTE}`);
    } catch (e: any) {
      result.errors.push(`${sig.symbol}: ${e?.message?.slice(0, 120)}`);
      console.error(`[paper-trader] entry failed ${sig.symbol}:`, e?.message);
    }
  }

  return result;
}

// ---- Exit / position monitoring logic ----
export interface MonitorResult {
  checked: number;
  closed: number;
  trailingActivated: number;
  errors: string[];
  exits: Array<{ symbol: string; reason: string; returnPct: number; pnl: number }>;
}

// Concurrency guard for monitorPositions. The fast exit-monitor loop (~60s)
// and the 5-minute full paper tick both call monitorPositions; the hourly
// daemon can too. Never let two runs overlap — two concurrent close attempts
// could race on the same OPEN trade. Single Node event loop + a module flag set
// before any await = an effective mutex. Reversible: this only skips a redundant
// overlapping run; it never changes trade logic.
let monitorInFlight = false;

export async function monitorPositions(): Promise<MonitorResult> {
  const GR = await getGuardrails();
  const result: MonitorResult = { checked: 0, closed: 0, trailingActivated: 0, errors: [], exits: [] };

  if (monitorInFlight) return result; // another monitor pass is already running
  monitorInFlight = true;
  try {

  const openTrades = await prisma.paperTrade.findMany({ where: { status: 'OPEN' } });
  if (openTrades.length === 0) return result;

  // Fetch live quotes for all open symbols
  const symbols = [...new Set(openTrades.map(t => t.symbol))];
  let quotes: Awaited<ReturnType<typeof getLatestQuotes>>;
  try {
    quotes = await getLatestQuotes(symbols);
  } catch (e: any) {
    result.errors.push(`Quote fetch failed: ${e?.message?.slice(0, 100)}`);
    return result;
  }

  for (const trade of openTrades) {
    result.checked++;
    const q = quotes.get(trade.symbol.toUpperCase());
    // Skip on missing OR untrustworthy quotes (one-sided / stale / absurd).
    // This is the key guard against false stop-losses from garbage prices.
    if (!q || !q.valid || !(q.price > 0)) continue;

    const currentPrice = q.price;
    const favPct = favorablePct(trade.direction, trade.entryPrice, currentPrice);
    const advPct = -favorablePct(trade.direction, trade.entryPrice, currentPrice);

    // Update peak/trough tracking
    let newPeakPrice = trade.peakPrice || trade.entryPrice;
    let newPeakPct = trade.peakPct || 0;
    let newTroughPrice = trade.troughPrice || trade.entryPrice;
    let newTroughPct = trade.troughPct || 0;

    if (favPct > newPeakPct) {
      newPeakPct = favPct;
      newPeakPrice = currentPrice;
    }
    if (advPct > newTroughPct) {
      newTroughPct = advPct;
      newTroughPrice = currentPrice;
    }

    // Determine exit reason (if any)
    let exitReason: string | null = null;

    const nowMins = etMinutes();

    // 1. Hard stop-loss — v2.0.0 X2: per-trade ATR-calibrated stop (legacy trades
    // without one keep the fixed default).
    const hardStopPct = trade.stopPct != null && trade.stopPct > 0 ? trade.stopPct : STOP_LOSS_PCT;
    if (favPct <= -hardStopPct) {
      exitReason = 'stop_loss';
    }

    // 2. Take-profit — v2.0.0 X1: fires ONLY when the target is actively met at the
    // touch we would exit against (SHORT: bid at/below target; LONG: ask at/above).
    // No band-cross / previously-beyond logic.
    if (!exitReason) {
      const tpPx = takeProfitPrice(trade.direction, trade.entryPrice);
      const tpHit = trade.direction === 'SHORT'
        ? (q.bid > 0 ? q.bid : currentPrice) <= tpPx
        : (q.ask > 0 ? q.ask : currentPrice) >= tpPx;
      if (tpHit) exitReason = 'take_profit';
    }

    // 2b. Give-back lock (Update 3.5, toggled — default OFF). Once a position has
    // peaked >= lockTriggerPct favorable, exit if it retraces to <= lockFloorPct so
    // a solid gain doesn't round-trip to flat/red. Backtested-promising (+$173 on the
    // 62 giveback trades) but off by default — it can also cap a runner, and much of
    // the giveback is exit fill-slippage a tick-based lock only partly fixes.
    if (!exitReason && GR.giveBackGuardEnabled
        && newPeakPct >= GR.lockTriggerPct && favPct <= GR.lockFloorPct) {
      exitReason = 'giveback_lock';
    }

    // 3. Trailing stop — v2.0.0 X3: session/ATR-aware activation; the trail distance
    // is locked on the trade when it activates.
    let trailingActive = trade.trailingActive;
    let currentTrailingStop = trade.trailingStop;
    let trailDistancePct = trade.trailDistancePct;
    let timeExitTrailingActive = trade.timeExitTrailingActive;

    if (!exitReason && !timeExitTrailingActive) {
      const tp = getTrailingStopParams(trade.atrPct, nowMins);
      if (!trailingActive && favPct >= tp.activateAt) {
        trailingActive = true;
        trailDistancePct = tp.trailDistance;
        result.trailingActivated++;
        console.log(`[paper-trader] trailing stop ACTIVATED for ${trade.symbol} at +${favPct.toFixed(2)}% (trail ${tp.trailDistance}%). ${V2_NOTE}`);
      }
      if (trailingActive) {
        const dist = (trailDistancePct ?? TRAIL_DISTANCE_PCT) / 100;
        currentTrailingStop = trade.direction === 'LONG'
          ? newPeakPrice * (1 - dist)
          : newPeakPrice * (1 + dist);
        const trailHit = trade.direction === 'LONG'
          ? currentPrice <= currentTrailingStop
          : currentPrice >= currentTrailingStop;
        if (trailHit) exitReason = 'trailing_stop';
      }
    }

    // 3b. v2.0.0 X4 aggressive time-exit trail (0.15%), ratchets only in our favor.
    if (!exitReason && timeExitTrailingActive) {
      const d = TIME_EXIT_TRAIL_PCT / 100;
      const cand = trade.direction === 'LONG' ? currentPrice * (1 - d) : currentPrice * (1 + d);
      currentTrailingStop = currentTrailingStop == null ? cand
        : trade.direction === 'LONG' ? Math.max(currentTrailingStop, cand) : Math.min(currentTrailingStop, cand);
      const hit = trade.direction === 'LONG' ? currentPrice <= currentTrailingStop : currentPrice >= currentTrailingStop;
      if (hit) exitReason = 'time_exit_trailing';
    }

    // 4. Time exit (max hold OR T-30 before close) — v2.0.0 X4 safety net:
    //   pnl < -0.3%        → hard close (time_exit) as before
    //   -0.3% .. +0.1%     → switch to aggressive 0.15% trail instead of closing
    //   > +0.1%            → don't force close; existing trailing keeps running
    // The 3:55 PM ET eod_close below still flattens everything (no overnight holds).
    if (!exitReason && !timeExitTrailingActive) {
      const holdMinutes = (Date.now() - trade.entryTime.getTime()) / (60 * 1000);
      const minutesToClose = 16 * 60 - nowMins;
      if (holdMinutes >= MAX_HOLD_MINUTES || minutesToClose <= TIME_EXIT_WINDOW_MIN) {
        const pnlPct = pnlPctBidAsk(trade.direction, trade.entryPrice, q);
        if (pnlPct < TIME_EXIT_LOSS_CUT) {
          exitReason = 'time_exit';
        } else if (pnlPct <= TIME_EXIT_BE_CEIL) {
          timeExitTrailingActive = true;
          const d = TIME_EXIT_TRAIL_PCT / 100;
          currentTrailingStop = trade.direction === 'LONG' ? currentPrice * (1 - d) : currentPrice * (1 + d);
          console.log(`[paper-trader] time_exit_trailing ${trade.symbol}: near-breakeven (${pnlPct.toFixed(2)}%) — switched to aggressive trailing (0.15%). ${V2_NOTE}`);
        }
      }
    }

    // 5. EOD close (market closing within 5 minutes)
    if (!exitReason) {
      const { mins } = etNow();
      if (mins >= 15 * 60 + 55) { // 3:55 PM ET
        exitReason = 'eod_close';
      }
    }

    if (exitReason) {
      // Close the position on Alpaca and capture the REAL fill price so our
      // recorded stats match Alpaca exactly (was previously the quote mid).
      //
      // Update 5.0 — marketable-limit exit (the #1 profit-leak fix). Instead of a
      // plain market close (which sweeps a thin book and bled ~2.5% round-trip on the
      // give-back cohort), price a LIMIT order THROUGH the touch: a buy-to-cover just
      // ABOVE the ask, a sell just BELOW the bid. It fills like a market order on
      // liquid names but caps the worst-case fill at limitBufferPct. If it does NOT
      // fill (thin/fast market) we cancel it and fall back to a guaranteed market
      // close, so a position — especially a protective stop — is never left open.
      // Whole-share SHORT exits only: Alpaca rejects limit orders on the fractional-
      // share LONG positions (notional entries), which keep the market close.
      const exitSide: 'buy' | 'sell' = trade.direction === 'LONG' ? 'sell' : 'buy';
      const wholeShareExit = trade.direction === 'SHORT'
        && Number.isInteger(trade.shares) && trade.shares >= 1;

      let closeOrder: AlpacaOrder | null = null;
      let usedLimit = false;

      if (GR.marketableLimitExitsEnabled && wholeShareExit) {
        const buf = GR.limitBufferPct / 100;
        const ref = exitSide === 'buy'
          ? (q.ask > 0 ? q.ask : currentPrice)   // buy-to-cover references the ask
          : (q.bid > 0 ? q.bid : currentPrice);  // sell references the bid
        const limitPx = exitSide === 'buy' ? ref * (1 + buf) : ref * (1 - buf);
        try {
          closeOrder = await placeOrder({
            symbol: trade.symbol,
            side: exitSide,
            type: 'limit',
            time_in_force: 'day',
            qty: trade.shares.toString(),
            limit_price: limitPx.toFixed(2),
          });
          usedLimit = true;
        } catch (e: any) {
          console.warn(`[paper-trader] limit exit ${trade.symbol} failed, market fallback:`, e?.message?.slice(0, 100));
          closeOrder = null;
        }
      }

      // If a limit was used, give it a moment to fill; if it doesn't, cancel it and
      // fall back to a market close so the position ALWAYS closes (protective-exit
      // reliability trumps the slippage cap).
      if (usedLimit && closeOrder) {
        if (closeOrder.status !== 'filled') {
          await new Promise(r => setTimeout(r, 2500));
          try { closeOrder = await getOrder(closeOrder.id); } catch { /* keep */ }
        }
        if (closeOrder.status !== 'filled') {
          try { await cancelOrder(closeOrder.id); } catch { /* may already be terminal */ }
          console.warn(`[paper-trader] limit exit ${trade.symbol} unfilled (${closeOrder.status}) — market fallback`);
          closeOrder = null;
          usedLimit = false;
        }
      }

      // Market fallback — also the default path for fractional LONG exits.
      if (!closeOrder) {
        try {
          closeOrder = await closePosition(trade.symbol);
        } catch (e: any) {
          // Position may have already been closed
          console.warn(`[paper-trader] close ${trade.symbol} warn:`, e?.message?.slice(0, 100));
        }
      }

      // Resolve the actual exit fill price from the close order.
      let exitFillPrice = currentPrice;
      let exitOrderId: string | null = null;
      let exitSource = usedLimit ? 'limit' : 'quote';
      if (closeOrder) {
        exitOrderId = closeOrder.id;
        let filled = closeOrder;
        if (filled.status !== 'filled') {
          await new Promise(r => setTimeout(r, 1500));
          try { filled = await getOrder(closeOrder.id); } catch { /* keep original */ }
        }
        if (filled.filled_avg_price && parseFloat(filled.filled_avg_price) > 0) {
          exitFillPrice = parseFloat(filled.filled_avg_price);
          exitSource = usedLimit ? 'limit_fill' : 'fill';
        }
      }

      // Compute return/PnL from the REAL exit fill, not the live quote.
      const realFavPct = favorablePct(trade.direction, trade.entryPrice, exitFillPrice);
      const returnPct = Math.round(realFavPct * 1000) / 1000;
      const pnlDollars = Math.round(trade.dollarAmount * (realFavPct / 100) * 100) / 100;

      await prisma.paperTrade.update({
        where: { id: trade.id },
        data: {
          status: 'CLOSED',
          exitPrice: exitFillPrice,
          alpacaExitId: exitOrderId,
          exitTime: new Date(),
          exitReason,
          returnPct,
          pnlDollars,
          peakPrice: newPeakPrice,
          peakPct: Math.round(newPeakPct * 1000) / 1000,
          troughPrice: newTroughPrice,
          troughPct: Math.round(newTroughPct * 1000) / 1000,
          trailingActive,
          trailingStop: currentTrailingStop,
          trailDistancePct,
          timeExitTrailingActive,
        },
      });

      result.closed++;
      result.exits.push({ symbol: trade.symbol, reason: exitReason, returnPct, pnl: pnlDollars });
      console.log(`[paper-trader] CLOSED ${trade.symbol} ${trade.direction} — ${exitReason} — return ${returnPct}% pnl $${pnlDollars} (exit@${exitFillPrice.toFixed(2)} via ${exitSource})`);
    } else {
      // Just update tracking
      await prisma.paperTrade.update({
        where: { id: trade.id },
        data: {
          peakPrice: newPeakPrice,
          peakPct: Math.round(newPeakPct * 1000) / 1000,
          troughPrice: newTroughPrice,
          troughPct: Math.round(newTroughPct * 1000) / 1000,
          trailingActive,
          trailingStop: currentTrailingStop,
          trailDistancePct,
          timeExitTrailingActive,
        },
      });
    }
  }

  return result;

  } finally {
    monitorInFlight = false;
  }
}

// ---- Combined tick (called every 5 minutes by scanner) ----
export interface PaperTickResult {
  entries: EntryResult;
  monitor: MonitorResult;
  portfolio: PortfolioState;
}

export async function paperTick(): Promise<PaperTickResult> {
  // Always monitor open positions first (exits before entries)
  const monitor = await monitorPositions();
  // Then evaluate new entries
  const entries = await evaluateEntries();
  // Return current state
  const portfolio = await getPortfolioState();
  return { entries, monitor, portfolio };
}

// ---- Trade history for dashboard ----
export interface TradeHistoryRow {
  id: string;
  symbol: string;
  direction: string;
  entryPrice: number;
  exitPrice: number | null;
  entryTime: string;
  exitTime: string | null;
  shares: number;
  dollarAmount: number;
  status: string;
  exitReason: string | null;
  returnPct: number | null;
  pnlDollars: number | null;
  peakPct: number | null;
  troughPct: number | null;
  trailingActive: boolean;
  heat: number | null;
  confidence: number | null;
  sessionSlot: string | null;
  portionIndex: number;
}

export async function getTradeHistory(limit = 50): Promise<TradeHistoryRow[]> {
  const trades = await prisma.paperTrade.findMany({
    orderBy: { createdAt: 'desc' },
    take: limit,
  });
  return trades.map(t => ({
    id: t.id,
    symbol: t.symbol,
    direction: t.direction,
    entryPrice: t.entryPrice,
    exitPrice: t.exitPrice,
    entryTime: t.entryTime.toISOString(),
    exitTime: t.exitTime?.toISOString() || null,
    shares: t.shares,
    dollarAmount: t.dollarAmount,
    status: t.status,
    exitReason: t.exitReason,
    returnPct: t.returnPct,
    pnlDollars: t.pnlDollars,
    peakPct: t.peakPct,
    troughPct: t.troughPct,
    trailingActive: t.trailingActive,
    heat: t.heat,
    confidence: t.confidence,
    sessionSlot: t.sessionSlot,
    portionIndex: t.portionIndex,
  }));
}

// ---- Daily scorecard with the Update 3.0 accuracy marker ----
// Everything with an ET exit day BEFORE this date used the old exit-recording
// path (quote-mid exit prices — partly error-inflated). From this day forward
// exits are recorded from Alpaca's real fills. The cutoff lets the dashboard
// show a clear "before vs after" line and true day-over-day progress.
export const UPDATE3_CUTOFF_ET = '2026-08-28';

function etDayKey(d: Date): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(d);
}

export interface ScorecardDay {
  day: string;              // YYYY-MM-DD (ET)
  era: 'legacy' | 'update3';
  trades: number;
  wins: number;
  losses: number;
  winRate: number | null;   // %
  pnl: number;              // realized $ that day
  cumulativeEraPnl: number; // running $ within the era
}

export interface DailyScorecard {
  cutoff: string;
  days: ScorecardDay[];
  legacy: { days: number; trades: number; wins: number; losses: number; winRate: number | null; pnl: number };
  update3: { days: number; trades: number; wins: number; losses: number; winRate: number | null; pnl: number };
}

export async function getDailyScorecard(): Promise<DailyScorecard> {
  const all = await prisma.paperTrade.findMany({
    where: { status: 'CLOSED' },
    orderBy: { exitTime: 'asc' },
    select: { exitTime: true, pnlDollars: true },
  });

  const byDay = new Map<string, { pnl: number; trades: number; wins: number; losses: number }>();
  for (const t of all) {
    if (!t.exitTime) continue;
    const day = etDayKey(t.exitTime);
    const e = byDay.get(day) || { pnl: 0, trades: 0, wins: 0, losses: 0 };
    const pnl = t.pnlDollars || 0;
    e.pnl += pnl;
    e.trades++;
    if (pnl > 0) e.wins++;
    else if (pnl < 0) e.losses++;
    byDay.set(day, e);
  }

  const legacy = { days: 0, trades: 0, wins: 0, losses: 0, winRate: null as number | null, pnl: 0 };
  const update3 = { days: 0, trades: 0, wins: 0, losses: 0, winRate: null as number | null, pnl: 0 };
  let cumLegacy = 0, cumUpdate3 = 0;

  const days: ScorecardDay[] = [...byDay.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([day, v]) => {
      const era: 'legacy' | 'update3' = day < UPDATE3_CUTOFF_ET ? 'legacy' : 'update3';
      const bucket = era === 'legacy' ? legacy : update3;
      bucket.days++;
      bucket.trades += v.trades;
      bucket.wins += v.wins;
      bucket.losses += v.losses;
      bucket.pnl += v.pnl;
      const cum = era === 'legacy' ? (cumLegacy += v.pnl) : (cumUpdate3 += v.pnl);
      const decided = v.wins + v.losses;
      return {
        day,
        era,
        trades: v.trades,
        wins: v.wins,
        losses: v.losses,
        winRate: decided ? Math.round((v.wins / decided) * 1000) / 10 : null,
        pnl: Math.round(v.pnl * 100) / 100,
        cumulativeEraPnl: Math.round(cum * 100) / 100,
      };
    });

  for (const b of [legacy, update3]) {
    const decided = b.wins + b.losses;
    b.winRate = decided ? Math.round((b.wins / decided) * 1000) / 10 : null;
    b.pnl = Math.round(b.pnl * 100) / 100;
  }

  return { cutoff: UPDATE3_CUTOFF_ET, days, legacy, update3 };
}

// ---- Equity curve (daily snapshots) ----
export async function getEquityCurve(): Promise<Array<{ date: string; equity: number; trades: number; pnl: number }>> {
  const all = await prisma.paperTrade.findMany({
    where: { status: 'CLOSED' },
    orderBy: { exitTime: 'asc' },
    select: { exitTime: true, pnlDollars: true },
  });

  const byDay = new Map<string, { pnl: number; trades: number }>();
  for (const t of all) {
    if (!t.exitTime) continue;
    const day = t.exitTime.toISOString().slice(0, 10);
    const entry = byDay.get(day) || { pnl: 0, trades: 0 };
    entry.pnl += t.pnlDollars || 0;
    entry.trades++;
    byDay.set(day, entry);
  }

  let cumPnl = 0;
  const curve: Array<{ date: string; equity: number; trades: number; pnl: number }> = [];
  for (const [date, v] of [...byDay.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
    cumPnl += v.pnl;
    curve.push({ date, equity: Math.round((TOTAL_FUND + cumPnl) * 100) / 100, trades: v.trades, pnl: Math.round(v.pnl * 100) / 100 });
  }
  return curve;
}

```

---

## FILE: code/lib/trading-guardrails.ts

```typescript
/**
 * MarcoFlow trading guardrails — single source of truth for the profitability /
 * efficiency filters shipped 9/2/26. Every value here is REVERSIBLE from this
 * one file, so any change can be rolled back instantly if it disrupts results.
 *
 * All thresholds are justified against the CLEAN data window (>= 2026-08-28, the
 * Update 3.0 exit-accuracy fix). Backtest figures are recorded inline so future
 * reviews (and the nightly self-correction job) can see the original rationale.
 *
 * Clean-window baseline (482 closed paper trades):
 *   ALL   42.3% win, -0.139% avg, -$371
 *   LONG  26.0% win, -0.807% avg, -$476   <- proven loser, benched (task 2)
 *   SHORT 46.4% win, +0.028% avg, +$104
 */

export interface TradingGuardrails {
  // ---- Task 2: long side is a proven loser. Benched (still recorded, not traded). ----
  longsEnabled: boolean;
  longMinLB: number; // if re-enabled later, only take longs at/above this Wilson LB

  // ---- Task 6: skip entries during the worst time-of-day cohorts (ET hour). ----
  //   hour 9 (first 30 min): 36.8% win, -$522 over 144 trades (single worst cohort)
  //   hour 12 (noon):        21.5% win, -$179 over 79 trades
  // Removing both would have improved clean-window P&L by ~$700.
  skipEntryHours: number[];

  // ---- Task 5: falling-knife short guard. ----
  // Shorting into deep oversold rebounds: RSI<=30 shorts were 40.0% win, -$13.
  // Matches the owner's recurring "we short right into a bounce" observation.
  knifeGuardEnabled: boolean;
  knifeMinRsi: number; // skip a SHORT when signal RSI <= this value

  // ---- Task 3: liquidity / tradability gate (protective before real capital). ----
  // No clean-window trade was below $3.12, and sub-$5 names were actually winners,
  // so a $3 floor trims nothing historically but blocks future penny-stock signals.
  // The spread cap is forward-only protection (entry spread isn't stored history).
  liquidityGateEnabled: boolean;
  minEntryPrice: number; // skip if entry price below this
  maxEntrySpreadPct: number; // skip if live bid/ask spread wider than this at entry

  // ---- Task 1: resting take-profit LIMIT for shorts (fixes "hit target, booked loss"). ----
  // 23.5% of trades that peaked >= +0.75% still closed red — a 5-minute tick-cadence
  // artifact (market close fires after the target already passed). A resting limit at
  // the target captures it intra-tick. GATED OFF pending supervised rollout so nothing
  // that could disrupt results goes live unattended.
  restingShortTpEnabled: boolean;

  // ==================================================================
  // UPDATE 3.5 (9/7/26) — all additions below are independently toggled
  // and reversible from this one file. Backtests are on the trustworthy
  // price window (>= 2026-08-28) unless noted.
  // ==================================================================

  // ---- Move-magnitude quality gate (composes WITH knife guard + hour-skips) ----
  // Adds pure skip conditions, so it can only remove trades, never force one — it
  // intersects with the existing guards and cannot interfere with them.
  moveMagnitudeGateEnabled: boolean; // master switch for the momentum filters below
  //
  // SHORTS — CORRECTED (9/8/26). The earlier |momentum| >= 5 gate was too blunt: it
  // lumped two OPPOSITE populations together and threw away our best one. Measured at
  // signal-observation level (the dataset unbiased by execution toggles), clean window
  // >= 8/28:
  //   FADE the rip    (SHORT, momentum >= +5):  81 obs, 43.9% win, -0.34% -> the real loser
  //   FOLLOW the drop (SHORT, momentum <= -5): 668 obs, 75.7% win, +0.17% -> our WORKHORSE
  // So the gate is now DIRECTIONAL: skip ONLY the rip-fades, KEEP the drop-follows (our
  // single best population). The knife guard (RSI<=30) already trims deep-drop bounce
  // risk in the <=-7 band, so the two compose cleanly. The old "skip |momentum|>=5"
  // rule removed losses only by amputating the edge — this keeps the edge.
  shortSkipRipAbovePct: number; // skip a SHORT when signal momentum >= this (fading a rip)
  shortMinMovePct: number;  // optional flat-chop floor (skip SHORT when |momentum| < this).
                            // DATA DOES NOT SUPPORT a floor — default 0 (off); exposed as a lever.
  //
  // LONGS — re-enabled ONLY on proven-positive move bands (replaces the flat bench).
  //   hard-dip bounce (momentum <= -5%): 29 trades, 55.2% win, +$77
  //   strong up-move   (momentum >= +5%): 126 trades, 42.9% win, +$55
  // Everything between (flat -$309, shallow dip -$43) stays benched. Thin sample on the
  // dip band — fully reversible via longsMode:'off'.
  longsMode: 'off' | 'movers'; // 'movers' = only the qualifying bands below trade
  longDipMaxMomentum: number;  // a LONG qualifies when momentum <= this (e.g. -5)
  longUpMinMomentum: number;   // a LONG also qualifies when momentum >= this (e.g. +5)

  // ---- Lane A execution fixes (each independently toggled) ----
  // Give-back lock: 62 trades peaked >= 0.8% then closed <= 0.2% (-$93). Locking the
  // gain (exit if a >=0.8% peak retraces to <= 0.5%) modelled +$173 on those trades.
  // CAVEAT: the giveback is largely EXIT FILL-SLIPPAGE on illiquid names (41 of 62 were
  // "take_profit" reason yet filled red), so a tick-based lock is only a partial fix —
  // the deeper fix is resting limits + the liquidity gate. Shipped OFF by default; the
  // lock could also cap a runner, so it needs a supervised session before going live.
  giveBackGuardEnabled: boolean;
  lockTriggerPct: number; // once peak favorable >= this, arm the lock
  lockFloorPct: number;   // ...then exit if favorable retraces to <= this
  //
  // Stale-entry guard: don't enter if the live mid has already drifted against the
  // trade vs the signal's entry price (fast stop-out / entry-timing protection).
  // Pure protection (only skips bad entries) — default ON. Reuses the spread quote.
  staleEntryGuardEnabled: boolean;
  maxAdverseDriftPct: number; // skip if live price already moved this far against us
  //
  // Fill-slippage guard: after a fill, flag (in notes + log) when the fill landed far
  // from the signal price. Observability-only for now (no auto-close) so it cannot
  // disrupt live behavior; informs the resting-limit / liquidity work.
  fillSlippageGuardEnabled: boolean;
  maxFillSlippagePct: number; // flag a fill when |fill - signalPrice|/signalPrice > this

  // ---- Liquidity enrichment: average-dollar-volume (ADV) gate (structural) ----
  // Real-capital prerequisite (borrow/locate + exit slippage on thin names). ONE
  // daily-bars API call per candidate that clears the prior gates (per-symbol cached).
  // Update 4.0 (9/11/26): SHIPPED-BUT-OFF. Calibration showed $20M IEX-ADV blocks ~93%
  // of current signal flow, so it stays off pending a nightly-optimizer-calibrated
  // threshold (see GUARDRAILS block below for the full finding). Reversible.
  advGateEnabled: boolean;
  minAdvDollars: number; // skip a candidate whose ~20-day avg dollar volume is below this

  // ==================================================================
  // UPDATE 4.0 (9/11/26) — three corrective entry guardrails from four
  // bad 9/8 SHORTs. All PURE SKIPS, null-safe (a null field never blocks),
  // each independently toggled/reversible from this one file.
  // ==================================================================

  // ---- (2a) Directional buy-pressure confirmation gate ----
  // The midday-selling-pressure rule REQUIRES selling pressure for a short, yet
  // JBIO (+0.41) and SBET (+0.27) were shorted with POSITIVE buyPressure (buyers in
  // control) and both lost. Require flow to confirm direction (0 = boundary):
  //   SHORT skipped when buyPressure > 0 ; LONG skipped when buyPressure < 0.
  // Keeps PAYS (-0.34) and TARS (-0.30) shorts (flow confirmed).
  directionalConfirmGateEnabled: boolean;

  // ---- (2b) RSI-rising short veto ----
  // The rule requires RSI FALLING for a short; TARS had rsiSlope +6.2 (RSI rising =
  // bounce underway) and the knife guard (RSI<=30) missed it (RSI 31.2). Skip a SHORT
  // when rsiSlope > 0. PAYS/SBET/JBIO had negative slope, so they pass this gate.
  rsiSlopeShortVetoEnabled: boolean;

  // ---- (2c) Max positions per symbol (count-based) ----
  // Two identical TARS shorts filled 2s apart because the openSymbols Set only saw
  // positions open at tick START — two same-symbol candidates in one ranked loop both
  // slipped through. Count-based cap over (existing-open + opened-this-tick) closes the
  // hole atomically. Default 1 preserves the one-per-symbol intent; bump to 2 for real
  // capital (one number).
  maxPositionsPerSymbol: number;

  // ==================================================================
  // UPDATE 5.0 (9/17/26) — EXECUTION-ONLY: marketable-limit exits.
  // The #1 profit leak is exit fill-slippage, NOT setup selection: over
  // the clean window ~103 trades peaked POSITIVE then closed red AT the
  // fill (take_profit cohort peaked +2.21% avg -> closed -0.268%, ~2.5%
  // round-trip surrendered at the close). Root cause: every exit fired a
  // plain MARKET order (closePosition DELETE), which sweeps a thin book.
  // Fix: price the exit as a LIMIT order placed THROUGH the touch — a
  // buy-to-cover just ABOVE the ask, a sell just BELOW the bid. It fills
  // like a market order on our (mostly liquid) names but caps the
  // worst-case fill. If the limit does NOT fill (thin/fast market) we
  // cancel it and fall back to a guaranteed market close, so a position —
  // especially a protective stop — is never left open/unmanaged. Applies
  // to whole-share SHORT exits only: Alpaca rejects limit orders on the
  // fractional-share LONG positions (notional entries), which keep the
  // market close. Fully reversible from this one flag.
  // ==================================================================
  marketableLimitExitsEnabled: boolean;
  limitBufferPct: number; // price the exit limit this % THROUGH the touch; also the
                          // worst-case fill cap. See rationale in the GUARDRAILS block.
}

export const GUARDRAILS: TradingGuardrails = {
  // Task 2
  longsEnabled: false,
  longMinLB: 72,

  // Task 6
  skipEntryHours: [9, 12],

  // Task 5
  knifeGuardEnabled: true,
  knifeMinRsi: 30,

  // Task 3
  liquidityGateEnabled: true,
  minEntryPrice: 3,
  maxEntrySpreadPct: 4,

  // Task 1 (gated off)
  restingShortTpEnabled: false,

  // ---- Update 3.5 ----
  // Move-magnitude gate (ON — DIRECTIONAL: skip short rip-fades, keep short drop-follows)
  moveMagnitudeGateEnabled: true,
  shortSkipRipAbovePct: 5, // skip only rip-fades; drop-follows (75.7% workhorse) stay ON
  shortMinMovePct: 0, // flat-chop floor OFF (data doesn't support it)
  longsMode: 'movers',
  longDipMaxMomentum: -5,
  longUpMinMomentum: 5,

  // Lane A execution fixes
  giveBackGuardEnabled: false, // implemented + backtested-promising, off pending supervised session
  lockTriggerPct: 0.8,
  lockFloorPct: 0.5,
  staleEntryGuardEnabled: true, // pure entry protection
  maxAdverseDriftPct: 0.6,
  fillSlippageGuardEnabled: true, // observability only (flags, never auto-closes)
  maxFillSlippagePct: 1.5,

  // Liquidity ADV gate — Update 4.0: SHIPPED-BUT-OFF. Calibration on live IEX data
  // (9/11/26) showed $20M IEX-ADV blocks ~93% of current signal flow (only 4 of the
  // top-60 recent signal names clear it, 3 of them ETFs). getAvgDollarVolume uses the
  // IEX feed (~2-3% of consolidated tape), so $20M IEX ≈ ~$700M-1B consolidated — far
  // too high a bar for the current microcap-heavy universe. Would gut trading (violates
  // "100% operational"). Held OFF for a supervised, nightly-optimizer-calibrated
  // threshold. Reversible: advGateEnabled:true. minAdvDollars kept for that tuning.
  advGateEnabled: false,
  minAdvDollars: 20_000_000,

  // ---- Update 4.0 corrective entry guardrails (all pure skips, null-safe) ----
  // Both single-feature short vetoes below are SHIPPED-BUT-OFF: backtested on resolved
  // signals (status>=8/28, ~16.5k SHORTs/14d) they FAILED to separate winners from
  // losers in aggregate, so blanket-gating would amputate profit. Real separator work
  // (feature COMBINATIONS) is routed to the nightly optimizer. Reversible per toggle.
  directionalConfirmGateEnabled: false, // buyPressure>0-blocked shorts were STILL +EV (59.3% win / +0.063% avg) — gate cuts profit
  rsiSlopeShortVetoEnabled: false,      // rsiSlope>0-blocked shorts were actually BETTER (61.9% win / +0.096% avg) — gate is HARMFUL
  maxPositionsPerSymbol: 1,             // ON (safe bug-fix): count-based cap closes the within-tick duplicate-fill hole (TARS). Bump to 2 for real capital.

  // ---- Update 5.0 execution: marketable-limit exits ----
  marketableLimitExitsEnabled: true, // ON — core exit-slippage fix; market fallback keeps protective stops fully reliable.
  limitBufferPct: 0.3, // 0.3% THROUGH the touch. Why 0.3 and not the owner's floated 0.005%:
                       //   - 0.005% (=0.00005 fraction) is ~1/60th of a single 0.3% spread and
                       //     far tighter than these names' real spreads (entry cap alone is 4%),
                       //     so a 0.005% limit would sit BEHIND the market and simply not fill.
                       //   - Referencing the ask (cover) / bid (sell) already crosses the spread;
                       //     +0.3% on top guarantees a marketable fill while capping the WORST
                       //     fill at ~0.3% beyond the touch vs the ~2.5% round-trip bled today.
                       //   Tunable here; the market fallback means even an unfilled limit still closes.
};

// NOTE (task 4 — DEFERRED, not active): a tighter hard stop (0.8% vs 1.25%) showed
// only a marginal, path-order-approximate edge for shorts (pessimistic +0.098% vs
// +0.089% avg) and no rescue for longs. Changing a core risk parameter on a marginal,
// approximate signal risks disrupting results, so the stop is left at 1.25% pending a
// live A/B. Recorded here for the nightly review to revisit on cleaner, larger data.

// ==================================================================
// RUNTIME OVERRIDE LAYER (Update 6.0 — nightly self-improving optimizer)
// ------------------------------------------------------------------
// GUARDRAILS above is the compiled DEFAULT (source of truth). The nightly
// optimizer proposes EXECUTION-ONLY changes; when the owner APPROVES one in the
// app, a single row is written to the GuardrailOverride table. getGuardrails()
// merges those approved overrides on top of the defaults so the very next
// trading tick picks the change up LIVE — no redeploy. Declining/resetting an
// override deletes the row and the compiled default is restored instantly.
// Fully reversible, per key. If the DB is unreachable we fall back to the
// compiled defaults so trading never breaks.
// ==================================================================
import { prisma } from './db';

// Keys the optimizer must NEVER change (scope lock: setup/alert identification,
// heat, timeframe/hour exclusions, knife guard). Enforced on the write path so a
// bad proposal can never flip a forbidden lever even if it reaches the DB.
export const FORBIDDEN_OVERRIDE_KEYS: (keyof TradingGuardrails)[] = [
  'skipEntryHours',
  'knifeGuardEnabled',
  'knifeMinRsi',
];

export function isOverridableKey(key: string): key is keyof TradingGuardrails {
  return (
    Object.prototype.hasOwnProperty.call(GUARDRAILS, key) &&
    !FORBIDDEN_OVERRIDE_KEYS.includes(key as keyof TradingGuardrails)
  );
}

// Validate that a proposed value is type-compatible with the compiled default,
// so a malformed override can never corrupt live trading behavior.
export function isValidOverrideValue(key: string, value: any): boolean {
  if (!isOverridableKey(key)) return false;
  const def = (GUARDRAILS as any)[key];
  if (Array.isArray(def)) {
    return Array.isArray(value) && value.every((v) => typeof v === typeof def[0] || def.length === 0);
  }
  return typeof value === typeof def && value !== null && value !== undefined;
}

let _cache: { at: number; value: TradingGuardrails } | null = null;
const CACHE_TTL_MS = 30_000;

export function invalidateGuardrailCache() {
  _cache = null;
}

/**
 * Live guardrails = compiled defaults merged with any APPROVED overrides in the
 * DB. Cached for 30s to avoid a query on every tick iteration. On any DB error
 * we return the compiled defaults so trading is never blocked.
 */
export async function getGuardrails(): Promise<TradingGuardrails> {
  const now = Date.now();
  if (_cache && now - _cache.at < CACHE_TTL_MS) return _cache.value;
  const merged: TradingGuardrails = { ...GUARDRAILS };
  try {
    const rows = await prisma.guardrailOverride.findMany();
    for (const row of rows) {
      if (isValidOverrideValue(row.key, row.valueJson as any)) {
        (merged as any)[row.key] = row.valueJson;
      }
    }
    _cache = { at: now, value: merged };
    return merged;
  } catch (e) {
    console.error('[guardrails] override merge failed, using compiled defaults:', e);
    return merged;
  }
}

```

---

## FILE: code/lib/heat-tracker.ts

```typescript
// HeatTracker - Real-time Buy/Sell pressure indicator
// Combines volume, momentum, RSI, price action, trend, and MACD into a single "heat" score
// ENHANCED: More responsive formula that produces meaningful signals

import { IntradayDataPoint } from './data-provider';
import { detectCandlestickPatterns, candlestickHeatContribution, CandlestickPattern } from './candlestick-patterns';

export interface HeatTrackerResult {
  heat: number; // -100 (strong sell) to +100 (strong buy)
  mode: 'BUY' | 'SELL' | 'NEUTRAL';
  isRedline: boolean; // True when signal is very strong (>=70 or <=-70)
  components: {
    volumeHeat: number; // Volume vs average
    momentumHeat: number; // Price momentum
    rsiHeat: number; // RSI-based signal
    priceActionHeat: number; // Current price position in range
    trendHeat: number; // EMA trend direction
    macdHeat: number; // MACD signal
    candlestickHeat: number; // Candlestick pattern signal
    vwapHeat: number; // Position relative to the session VWAP
  };
  indicators: {
    rsi: number;
    volumeRatio: number; // current bar volume vs 20-bar average
    volumeSurge: number; // last-5 bars avg vs prior-15 bars avg
    buyPressure: number; // signed-volume proxy, -1 (all selling) to +1 (all buying)
    priceChange: number;
    momentum: number;
    ema9: number;
    ema21: number;
    macd: number;
    vwap: number; // session volume-weighted average price (0 when unavailable)
    vwapDistPct: number; // signed % distance of price from session VWAP
    rsiSlope: number; // RSI now minus RSI ~15 min ago (>0 = momentum turning up / stabilizing)
    atrPct: number; // ATR(14) as % of price — intraday volatility
    vwapReclaim: number; // +1 = just reclaimed above VWAP, -1 = just lost VWAP, 0 = no cross
    rsiShort: number; // RSI(5) — fast intraday momentum, ~25 min of price action
  };
  // Key drivers explaining WHY this stock has its heat rating
  keyDrivers: string[];
  // Detected candlestick patterns
  candlestickPatterns: CandlestickPattern[];
  timestamp: number;
}

// Calculate RSI (unchanged but with smoothing)
function calculateRSI(prices: number[], period: number = 14): number {
  if (prices.length < period + 1) return 50;
  
  let gains = 0;
  let losses = 0;
  
  for (let i = prices.length - period; i < prices.length; i++) {
    const change = prices[i] - prices[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }
  
  const avgGain = gains / period;
  const avgLoss = losses / period;
  
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

// Calculate EMA
function calculateEMA(prices: number[], period: number): number {
  if (prices.length < period) return prices[prices.length - 1] || 0;
  
  const multiplier = 2 / (period + 1);
  let ema = prices.slice(0, period).reduce((sum, p) => sum + p, 0) / period;
  
  for (let i = period; i < prices.length; i++) {
    ema = (prices[i] - ema) * multiplier + ema;
  }
  return ema;
}

// Calculate MACD
function calculateMACD(prices: number[]): { macd: number; signal: number; histogram: number } {
  if (prices.length < 26) return { macd: 0, signal: 0, histogram: 0 };
  
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);
  const macd = ema12 - ema26;
  
  // Simplified signal line (would need full calculation for accuracy)
  const signal = macd * 0.9; // Approximation
  const histogram = macd - signal;
  
  return { macd, signal, histogram };
}

// Calculate momentum (rate of change) with multiple periods
function calculateMomentum(prices: number[], period: number = 10): number {
  if (prices.length < period) return 0;
  const current = prices[prices.length - 1];
  const past = prices[prices.length - period];
  return past > 0 ? ((current - past) / past) * 100 : 0;
}

// Calculate average volume
function calculateAvgVolume(data: IntradayDataPoint[], period: number = 20): number {
  if (data.length < period) return data.reduce((sum, d) => sum + d.volume, 0) / Math.max(1, data.length);
  const recent = data.slice(-period);
  return recent.reduce((sum, d) => sum + d.volume, 0) / period;
}

// Calculate recent volume surge (last 5 bars vs previous 15)
function calculateVolumeSurge(data: IntradayDataPoint[]): number {
  if (data.length < 20) return 1;
  const recent5 = data.slice(-5).reduce((sum, d) => sum + d.volume, 0) / 5;
  const prev15 = data.slice(-20, -5).reduce((sum, d) => sum + d.volume, 0) / 15;
  return prev15 > 0 ? recent5 / prev15 : 1;
}

// Signed-volume proxy over the recent window: volume on up-closing bars minus
// volume on down-closing bars, normalized by total volume. This is a FREE
// approximation of buy vs sell aggression from price+volume alone. It is NOT
// true order-flow (Level 2 / time-and-sales) — that requires a paid real-time
// feed (a Phase B upgrade). Range: -1 (all selling) .. +1 (all buying).
function calculateBuyPressure(data: IntradayDataPoint[], period: number = 20): number {
  const recent = data.slice(-period);
  if (recent.length < 2) return 0;
  let signed = 0;
  let total = 0;
  for (let i = 1; i < recent.length; i++) {
    const bar = recent[i];
    const prev = recent[i - 1];
    const v = bar.volume || 0;
    total += v;
    // Direction of the bar: close vs its own open, falling back to prev close.
    const up = bar.close > (bar.open ?? prev.close);
    const down = bar.close < (bar.open ?? prev.close);
    if (up) signed += v;
    else if (down) signed -= v;
  }
  return total > 0 ? Math.max(-1, Math.min(1, signed / total)) : 0;
}

// ET calendar-day key for a bar timestamp, used to isolate the CURRENT trading
// session so VWAP resets each day instead of bleeding across the overnight gap.
function etDayKey(ts: number): string {
  return new Date(ts).toLocaleDateString('en-US', { timeZone: 'America/New_York' });
}

// Session VWAP: the volume-weighted average price for the CURRENT trading day
// only. VWAP is the single most-watched intraday reference line — institutions
// anchor to it all day, so whether price is above or below it is a strong,
// genuinely intraday signal. We walk backward from the latest bar and stop the
// moment the ET day changes, so only today's bars count. Returns null when the
// session has no volume yet (e.g. the very first bar).
function calculateSessionVWAP(data: IntradayDataPoint[]): number | null {
  if (data.length === 0) return null;
  const lastDay = etDayKey(data[data.length - 1].timestamp);
  let pv = 0; // sum of typical price * volume
  let vol = 0;
  for (let i = data.length - 1; i >= 0; i--) {
    if (etDayKey(data[i].timestamp) !== lastDay) break; // session boundary
    const d = data[i];
    const typical = (d.high + d.low + d.close) / 3;
    pv += typical * (d.volume || 0);
    vol += d.volume || 0;
  }
  return vol > 0 ? pv / vol : null;
}

// Main HeatTracker calculation - ENHANCED for better responsiveness
export function calculateHeatTracker(data: IntradayDataPoint[]): HeatTrackerResult {
  if (data.length < 20) {
    return {
      heat: 0,
      mode: 'NEUTRAL',
      isRedline: false,
      components: { volumeHeat: 0, momentumHeat: 0, rsiHeat: 0, priceActionHeat: 0, trendHeat: 0, macdHeat: 0, candlestickHeat: 0, vwapHeat: 0 },
      indicators: { rsi: 50, volumeRatio: 1, volumeSurge: 1, buyPressure: 0, priceChange: 0, momentum: 0, ema9: 0, ema21: 0, macd: 0, vwap: 0, vwapDistPct: 0, rsiSlope: 0, atrPct: 0, vwapReclaim: 0, rsiShort: 50 },
      keyDrivers: ['Insufficient data'],
      candlestickPatterns: [],
      timestamp: Date.now(),
    };
  }
  
  const prices = data.map(d => d.close);
  const currentPrice = prices[prices.length - 1];
  const currentVolume = data[data.length - 1].volume;
  const avgVolume = calculateAvgVolume(data);
  const keyDrivers: string[] = [];
  
  // Calculate indicators
  const rsi = calculateRSI(prices);
  const rsiShort = calculateRSI(prices, 5);
  const momentum5 = calculateMomentum(prices, 5);
  const momentum10 = calculateMomentum(prices, 10);
  const ema9 = calculateEMA(prices, 9);
  const ema21 = calculateEMA(prices, 21);
  const { macd, histogram } = calculateMACD(prices);
  const volumeRatio = avgVolume > 0 ? currentVolume / avgVolume : 1;
  const volumeSurge = calculateVolumeSurge(data);
  
  // 1. Volume Heat (-20 to +20) - Enhanced sensitivity
  // Higher weight for volume surges
  let volumeHeat = 0;
  if (volumeSurge > 2) {
    volumeHeat = 20; // Major volume surge
    keyDrivers.push(`🔥 Volume surge ${volumeSurge.toFixed(1)}x`);
  } else if (volumeRatio > 1.5) {
    volumeHeat = Math.min(20, (volumeRatio - 1) * 20);
    keyDrivers.push(`📊 High volume ${volumeRatio.toFixed(1)}x avg`);
  } else if (volumeRatio < 0.5) {
    volumeHeat = -10; // Low volume = caution
  } else {
    volumeHeat = (volumeRatio - 1) * 15;
  }
  
  // 2. RSI Heat (-25 to +25) - More responsive
  let rsiHeat = 0;
  if (rsi >= 80) {
    rsiHeat = -25; // Extreme overbought
    keyDrivers.push(`⚠️ RSI overbought (${rsi.toFixed(0)})`);
  } else if (rsi >= 70) {
    rsiHeat = -((rsi - 70) / 10) * 20;
    keyDrivers.push(`📉 RSI high (${rsi.toFixed(0)})`);
  } else if (rsi <= 20) {
    rsiHeat = 25; // Extreme oversold
    keyDrivers.push(`🎯 RSI oversold (${rsi.toFixed(0)})`);
  } else if (rsi <= 30) {
    rsiHeat = ((30 - rsi) / 10) * 20;
    keyDrivers.push(`📈 RSI low (${rsi.toFixed(0)})`);
  } else if (rsi < 45) {
    rsiHeat = (45 - rsi) / 15 * 10; // Mild bullish
  } else if (rsi > 55) {
    rsiHeat = (55 - rsi) / 15 * 10; // Mild bearish
  }
  
  // 3. Momentum Heat (-20 to +20) - Combined short & medium term
  const avgMomentum = (momentum5 * 0.6 + momentum10 * 0.4);
  let momentumHeat = Math.min(20, Math.max(-20, avgMomentum * 8));
  if (Math.abs(avgMomentum) > 1.5) {
    keyDrivers.push(avgMomentum > 0 ? `🚀 Strong upward momentum` : `📉 Strong downward momentum`);
  }
  
  // 4. Price Action Heat (-15 to +15) - Position in range
  const recentHigh = Math.max(...data.slice(-20).map(d => d.high));
  const recentLow = Math.min(...data.slice(-20).map(d => d.low));
  const range = recentHigh - recentLow;
  const pricePosition = range > 0 ? (currentPrice - recentLow) / range : 0.5;
  
  let priceActionHeat = 0;
  if (pricePosition <= 0.2) {
    priceActionHeat = 15; // Near support
    keyDrivers.push(`💎 Near support level`);
  } else if (pricePosition >= 0.8) {
    priceActionHeat = -15; // Near resistance
    keyDrivers.push(`🔻 Near resistance level`);
  } else {
    priceActionHeat = (0.5 - pricePosition) * 20;
  }
  
  // 5. Trend Heat (-15 to +15) - EMA crossover/trend direction
  let trendHeat = 0;
  const emaDiff = ((ema9 - ema21) / ema21) * 100;
  if (ema9 > ema21) {
    trendHeat = Math.min(15, emaDiff * 5);
    if (emaDiff > 0.5) keyDrivers.push(`📈 Bullish trend (EMA9 > EMA21)`);
  } else {
    trendHeat = Math.max(-15, emaDiff * 5);
    if (emaDiff < -0.5) keyDrivers.push(`📉 Bearish trend (EMA9 < EMA21)`);
  }
  
  // 6. MACD Heat (-10 to +10)
  let macdHeat = 0;
  const macdPct = currentPrice > 0 ? (macd / currentPrice) * 100 : 0;
  macdHeat = Math.min(10, Math.max(-10, macdPct * 20));
  if (macdPct > 0.3) {
    keyDrivers.push(`✅ Bullish MACD`);
  } else if (macdPct < -0.3) {
    keyDrivers.push(`❌ Bearish MACD`);
  }
  
  // 7. Candlestick Pattern Heat (-15 to +15)
  const candlestickPatterns = detectCandlestickPatterns(data);
  const candlestickResult = candlestickHeatContribution(candlestickPatterns);
  const candlestickHeat = candlestickResult.heat;
  keyDrivers.push(...candlestickResult.drivers);
  
  // 8. VWAP Heat (-12 to +12) - position vs the session volume-weighted avg price.
  // Above VWAP = bullish control, below = bearish control. This is a true
  // intraday reference (resets each session) rather than a multi-day lookback.
  const vwap = calculateSessionVWAP(data);
  let vwapHeat = 0;
  let vwapDistPct = 0;
  if (vwap && vwap > 0) {
    vwapDistPct = ((currentPrice - vwap) / vwap) * 100;
    // ~1% away from VWAP saturates the contribution at ±12.
    vwapHeat = Math.max(-12, Math.min(12, vwapDistPct * 12));
    if (vwapDistPct > 0.1) keyDrivers.push(`🟢 Above VWAP (+${vwapDistPct.toFixed(2)}%)`);
    else if (vwapDistPct < -0.1) keyDrivers.push(`🔴 Below VWAP (${vwapDistPct.toFixed(2)}%)`);
  }

  // ---- Entry-quality factors (available at entry time, no lookahead) ----
  // RSI slope: is oversold momentum still falling, or turning back up? A rising
  // RSI off a low is the classic "the knife has landed" stabilization signal.
  const rsiPrev = calculateRSI(prices.slice(0, Math.max(2, prices.length - 3)));
  const rsiSlope = rsi - rsiPrev;
  // ATR(14) as % of price — how violent the recent swings are.
  let atrPct = 0;
  {
    const per = Math.min(14, data.length - 1);
    let s = 0;
    for (let i = data.length - per; i < data.length; i++) {
      const tr = Math.max(
        data[i].high - data[i].low,
        Math.abs(data[i].high - data[i - 1].close),
        Math.abs(data[i].low - data[i - 1].close),
      );
      s += tr;
    }
    const atr = s / per;
    atrPct = currentPrice > 0 ? (atr / currentPrice) * 100 : 0;
  }
  // VWAP reclaim: did price cross back across VWAP in the last ~15 min? A long
  // that has just reclaimed VWAP is far safer than one still knifing below it.
  let vwapReclaim = 0;
  if (data.length > 6) {
    const past = data.slice(0, data.length - 3);
    const vwPast = calculateSessionVWAP(past);
    const pricePast = past[past.length - 1].close;
    const distPast = vwPast && vwPast > 0 ? ((pricePast - vwPast) / vwPast) * 100 : 0;
    if (vwapDistPct > 0 && distPast <= 0) vwapReclaim = 1;
    else if (vwapDistPct < 0 && distPast >= 0) vwapReclaim = -1;
  }

  // Combine all components with weights
  // Max possible: 20 + 25 + 20 + 15 + 15 + 10 + 15 + 12 = 132, clamped to 100
  const rawHeat = volumeHeat + rsiHeat + momentumHeat + priceActionHeat + trendHeat + macdHeat + candlestickHeat + vwapHeat;
  
  // Apply a slight amplifier to make signals more pronounced when multiple indicators align
  const alignmentBonus = (
    (volumeHeat > 5 && momentumHeat > 5 ? 5 : 0) +
    (rsiHeat > 10 && priceActionHeat > 5 ? 5 : 0) +
    (volumeHeat < -5 && momentumHeat < -5 ? -5 : 0) +
    (rsiHeat < -10 && priceActionHeat < -5 ? -5 : 0) +
    (candlestickHeat > 5 && trendHeat > 3 ? 3 : 0) +
    (candlestickHeat < -5 && trendHeat < -3 ? -3 : 0)
  );
  
  const heat = Math.min(100, Math.max(-100, rawHeat + alignmentBonus));
  
  // Determine mode and redline status
  const mode: 'BUY' | 'SELL' | 'NEUTRAL' = heat > 20 ? 'BUY' : heat < -20 ? 'SELL' : 'NEUTRAL';
  const isRedline = Math.abs(heat) >= 70;
  
  // Price change for display
  const previousPrice = prices.length > 1 ? prices[prices.length - 2] : currentPrice;
  const priceChange = previousPrice > 0 ? ((currentPrice - previousPrice) / previousPrice) * 100 : 0;
  
  // Ensure we have at least one key driver
  if (keyDrivers.length === 0) {
    if (heat > 20) keyDrivers.push('📊 Multiple mild bullish signals');
    else if (heat < -20) keyDrivers.push('📊 Multiple mild bearish signals');
    else keyDrivers.push('⏳ Neutral - waiting for clearer signal');
  }
  
  return {
    heat: Math.round(heat),
    mode,
    isRedline,
    components: {
      volumeHeat: Math.round(volumeHeat * 10) / 10,
      momentumHeat: Math.round(momentumHeat * 10) / 10,
      rsiHeat: Math.round(rsiHeat * 10) / 10,
      priceActionHeat: Math.round(priceActionHeat * 10) / 10,
      trendHeat: Math.round(trendHeat * 10) / 10,
      macdHeat: Math.round(macdHeat * 10) / 10,
      candlestickHeat: Math.round(candlestickHeat * 10) / 10,
      vwapHeat: Math.round(vwapHeat * 10) / 10,
    },
    indicators: {
      rsi: Math.round(rsi * 10) / 10,
      volumeRatio: Math.round(volumeRatio * 100) / 100,
      volumeSurge: Math.round(volumeSurge * 100) / 100,
      buyPressure: Math.round(calculateBuyPressure(data) * 1000) / 1000,
      priceChange: Math.round(priceChange * 100) / 100,
      momentum: Math.round(avgMomentum * 100) / 100,
      ema9: Math.round(ema9 * 100) / 100,
      ema21: Math.round(ema21 * 100) / 100,
      macd: Math.round(macd * 1000) / 1000,
      vwap: vwap ? Math.round(vwap * 100) / 100 : 0,
      vwapDistPct: Math.round(vwapDistPct * 1000) / 1000,
      rsiSlope: Math.round(rsiSlope * 10) / 10,
      atrPct: Math.round(atrPct * 1000) / 1000,
      vwapReclaim,
      rsiShort: Math.round(rsiShort * 10) / 10,
    },
    keyDrivers,
    candlestickPatterns,
    timestamp: Date.now(),
  };
}

```

---

## FILE: code/lib/signal-recorder.ts

```typescript
// Signal Recorder — MarcoFlow's learning engine
// Runs on a schedule (via the agent tick endpoint). Two jobs:
//   1. RECORD: scan the watchlist, snapshot any notable signal into the DB
//   2. RESOLVE: for signals past their horizon, measure what actually happened
// Over time this builds a real, growing accuracy dataset drawn from live markets.

import { prisma } from './db';
import { fetchIntradayData, IntradayDataPoint } from './data-provider';
import { calculateHeatTracker } from './heat-tracker';
import { getAllStocks, STOCK_CATEGORIES } from './stock-screener';
import { getMarketRegime } from './market-regime';

// Build a symbol -> { assetClass, category } lookup from the master universe so
// each observation can be sliced by asset class (stock vs ETF) and sector.
const SYMBOL_META: Record<string, { assetClass: string; category: string }> = (() => {
  const map: Record<string, { assetClass: string; category: string }> = {};
  for (const [category, list] of Object.entries(STOCK_CATEGORIES as Record<string, { symbol: string }[]>)) {
    for (const s of list) {
      map[s.symbol] = { assetClass: category.startsWith('etf') ? 'etf' : 'stock', category };
    }
  }
  return map;
})();

// Time-of-day bucket (US Eastern). Markets: 9:30-16:00 ET.
function sessionInfo(now: Date = new Date()): { etHour: number; dayOfWeek: number; sessionSlot: string } {
  const et = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const etHour = et.getHours();
  const minutes = etHour * 60 + et.getMinutes();
  let sessionSlot = 'after_hours';
  if (minutes >= 9 * 60 + 30 && minutes < 11 * 60) sessionSlot = 'open';
  else if (minutes >= 11 * 60 && minutes < 14 * 60) sessionSlot = 'midday';
  else if (minutes >= 14 * 60 && minutes <= 16 * 60) sessionSlot = 'power_hour';
  return { etHour, dayOfWeek: et.getDay(), sessionSlot };
}

// Only record signals at least this strong (absolute heat). Keeps the dataset
// focused on meaningful setups, honoring "quality over quantity".
const RECORD_THRESHOLD = 30;

// Don't record the same symbol+direction more than once within this window.
const DEDUPE_MINUTES = 90;

// How many symbols to fetch at once. The universe is now large enough that a
// strictly sequential pass would not finish inside the scan interval, so we run
// a small worker pool. Kept deliberately modest to stay gentle on the free data
// source (well under the rate at which it starts throttling).
// Sequential processing — one symbol at a time within each request to keep
// peak memory absolutely minimal. Each request handles only ~100 symbols
// (chunked by the scanner), and processes them one-by-one.
const SCAN_CONCURRENCY = 1;
const SCAN_DELAY_MS = 20;

// With concurrency=1 and small chunks from the scanner, batching within
// a single request is unnecessary. Process all symbols in the chunk sequentially.
const BATCH_SIZE = 50; // small batches to keep peak memory low
const BATCH_PAUSE_MS = 100; // brief pause between batches for GC

// Default trade parameters used to judge outcomes.
const DEFAULT_HORIZON_HOURS = 4;
// Legacy fallback only. Rows recorded before Aug 14 2026 carry 2.0 / 1.5 and are
// still resolved against those stored values, so old history is never re-graded.
const DEFAULT_TARGET_PCT = 2;
const DEFAULT_STOP_PCT = 1.5;

// ---- ADAPTIVE BASE TARGET (Aug 14 2026) ------------------------------------
// The flat +2% target was close to the worst configuration we tested: over 1692
// bar-by-bar simulations it returned +0.111%/trade in the opening window and was
// NEGATIVE in every later slot (-0.078% 10am-12pm, -0.048% 12-2pm). Measured
// alternatives, same -1.5% stop: 1.00% target = 76.3% win rate, +0.276%/trade,
// 108-min hold; 0.75% target = 81.7% win rate, +0.261%/trade, and positive in
// EVERY time slot. So the base target is now sized to the slot instead of fixed.
//
// The stop stays at -1.5%. A no-stop / tight-stop variant was tested and lost at
// every level (0.20% take-profit hits 84.1% of the time but the 15.9% of misses
// average -1.16%, net -0.016%/trade). The wide stop is what creates the edge.
//
// HONESTY NOTE: this changes the definition of a WIN for newly recorded setups.
// Scorecard figures from before and after this date are not directly comparable,
// and the improvement is a real strategy change, not a relabelling of old data.
const OPEN_TARGET_PCT = 1.0;    // 9:30-10:00 ET
const MIDDAY_TARGET_PCT = 0.75; // 10:00 ET onward
const ADAPTIVE_STOP_PCT = 1.5;

function baseTargetPct(at: Date): number {
  const et = new Date(at.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const mins = et.getHours() * 60 + et.getMinutes();
  return mins < 600 ? OPEN_TARGET_PCT : MIDDAY_TARGET_PCT;
}

export interface RecordSummary {
  scanned: number;
  recorded: number;
  skippedDuplicate: number;
  errors: number;
  recordedSymbols: string[];
}

export interface ResolveSummary {
  checked: number;
  resolved: number;
  wins: number;
  losses: number;
  expired: number;
  stillPending: number;
}

// Is the US market currently open? (approx, ignores holidays). Times in ET.
export function isMarketHours(now: Date = new Date()): boolean {
  // Convert to ET
  const et = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const day = et.getDay(); // 0 Sun .. 6 Sat
  if (day === 0 || day === 6) return false;
  const minutes = et.getHours() * 60 + et.getMinutes();
  return minutes >= 9 * 60 + 30 && minutes <= 16 * 60; // 9:30 - 16:00
}

// A trade is "cleanly intraday-executable" only if it is entered on a weekday
// during market hours AND its full holding window (horizon) would finish before
// that same day's close (16:00 ET). These are the only setups a trader could
// honestly open AND close inside one session under the strategy's own rules, so
// the intraday leaderboard is built strictly from them. This is a FILTER of
// which trades qualify — it never changes any trade's recorded outcome, and it
// is deliberately conservative so intraday accuracy is never overstated.
export function isIntradayExecutable(observedAt: Date, horizonHours: number | null = DEFAULT_HORIZON_HOURS): boolean {
  const et = new Date(observedAt.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const day = et.getDay();
  if (day === 0 || day === 6) return false;
  const entryMin = et.getHours() * 60 + et.getMinutes();
  const openMin = 9 * 60 + 30;
  const closeMin = 16 * 60;
  const holdMin = (horizonHours ?? DEFAULT_HORIZON_HOURS) * 60;
  return entryMin >= openMin && entryMin + holdMin <= closeMin;
}

// ---------------------------------------------------------------------------
// RECORD
// ---------------------------------------------------------------------------
// Default is deliberately above the current universe size so the full list is
// always scanned; pass a smaller number only to cap a one-off run.
export async function recordSignals(maxSymbols = 5000, offset = 0): Promise<RecordSummary> {
  const allStocks = getAllStocks();
  const stocks = allStocks.slice(offset, offset + maxSymbols);
  const summary: RecordSummary = {
    scanned: 0,
    recorded: 0,
    skippedDuplicate: 0,
    errors: 0,
    recordedSymbols: [],
  };

  const dedupeSince = new Date(Date.now() - DEDUPE_MINUTES * 60 * 1000);

  // Capture the market environment once for this whole pass so every signal is
  // tagged with the conditions it happened in (bull/bear/neutral, trailing SPY).
  const regime = await getMarketRegime().catch(() => null);
  const session = sessionInfo();

  const scanOne = async (stock: { symbol: string; name: string }) => {
    try {
      const data = await fetchIntradayData(stock.symbol, '5m');
      summary.scanned++;
      if (!data || data.length < 60) return;

      const heatResult = calculateHeatTracker(data);
      const absHeat = Math.abs(heatResult.heat);
      if (absHeat < RECORD_THRESHOLD) return;

      const direction = heatResult.heat > 0 ? 'LONG' : 'SHORT';
      const last = data[data.length - 1];

      // Dedupe: skip if we already logged this symbol+direction recently
      const existing = await prisma.signalObservation.findFirst({
        where: {
          symbol: stock.symbol,
          direction,
          observedAt: { gte: dedupeSince },
        },
        select: { id: true },
      });
      if (existing) {
        summary.skippedDuplicate++;
        return;
      }

      const comps: any = heatResult.components || {};
      const meta = SYMBOL_META[stock.symbol] || { assetClass: 'stock', category: 'other' };
      await prisma.signalObservation.create({
        data: {
          symbol: stock.symbol,
          name: stock.name,
          interval: '5m',
          heat: Math.round(heatResult.heat * 10) / 10,
          direction,
          entryPrice: last.close,
          rsi: heatResult.indicators?.rsi ?? null,
          momentum: comps.momentumHeat ?? comps.momentum ?? null,
          volumeComp: comps.volumeHeat ?? comps.volume ?? null,
          volumeRatio: heatResult.indicators?.volumeRatio ?? null,
          volumeSurge: heatResult.indicators?.volumeSurge ?? null,
          buyPressure: heatResult.indicators?.buyPressure ?? null,
          vwapDistPct: heatResult.indicators?.vwapDistPct ?? null,
          rsiSlope: heatResult.indicators?.rsiSlope ?? null,
          atrPct: heatResult.indicators?.atrPct ?? null,
          vwapReclaim: heatResult.indicators?.vwapReclaim ?? null,
          rsiShort: heatResult.indicators?.rsiShort ?? null,
          candlestick: comps.candlestickHeat ?? null,
          trendComp: comps.trendHeat ?? comps.trend ?? null,
          keyDrivers: heatResult.keyDrivers ?? [],
          tradeType: isIntradayExecutable(new Date(), DEFAULT_HORIZON_HOURS) ? 'intraday' : 'short_swing',
          assetClass: meta.assetClass,
          category: meta.category,
          sessionSlot: session.sessionSlot,
          etHour: session.etHour,
          dayOfWeek: session.dayOfWeek,
          marketRegime: regime?.regime ?? null,
          spyChange5d: regime?.spyChange5d ?? null,
          spyChange1mo: regime?.spyChange1mo ?? null,
          vixLevel: regime?.vixLevel ?? null,
          status: 'PENDING',
          horizonHours: DEFAULT_HORIZON_HOURS,
          targetPct: baseTargetPct(new Date()),
          stopPct: ADAPTIVE_STOP_PCT,
        },
      });
      summary.recorded++;
      summary.recordedSymbols.push(stock.symbol);
    } catch (e) {
      summary.errors++;
    }
  };

  // Process in batches to keep peak memory bounded. Each batch runs its
  // own worker pool, and we pause between batches so V8 can GC the HTTP
  // response buffers and parsed JSON from the previous batch.
  for (let i = 0; i < stocks.length; i += BATCH_SIZE) {
    const batch = stocks.slice(i, i + BATCH_SIZE);
    const batchQueue = [...batch];
    const runBatchWorker = async () => {
      while (batchQueue.length > 0) {
        const stock = batchQueue.shift();
        if (!stock) break;
        await scanOne(stock);
        await new Promise(r => setTimeout(r, SCAN_DELAY_MS));
      }
    };
    await Promise.all(
      Array.from({ length: Math.min(SCAN_CONCURRENCY, batchQueue.length) }, () => runBatchWorker())
    );
    // Pause between batches — gives V8 a window to garbage-collect.
    if (i + BATCH_SIZE < stocks.length) {
      await new Promise(r => setTimeout(r, BATCH_PAUSE_MS));
    }
  }

  return summary;
}

// ---------------------------------------------------------------------------
// RESOLVE
// ---------------------------------------------------------------------------
export async function resolvePendingSignals(maxToResolve = 600): Promise<ResolveSummary> {
  const summary: ResolveSummary = {
    checked: 0,
    resolved: 0,
    wins: 0,
    losses: 0,
    expired: 0,
    stillPending: 0,
  };

  // Only pull rows whose horizon has already elapsed, so the budget is never
  // wasted on signals that cannot resolve yet. We use the default horizon as the
  // DB pre-filter (rows with a longer horizon are still re-checked per-row below).
  const now = Date.now();
  const overdueBefore = new Date(now - DEFAULT_HORIZON_HOURS * 3600 * 1000);

  // Priority pass: rows that were actually emailed as alerts (confirmed OR
  // forming). These feed the scorecard and the EOD report, so they must be
  // graded promptly and never sit behind the much larger pool of un-alerted
  // observations. This changes only WHICH pending rows are resolved first — the
  // outcome/grading logic is identical for every row.
  const alertedPending = await prisma.signalObservation.findMany({
    where: {
      status: 'PENDING',
      observedAt: { lt: overdueBefore },
      OR: [{ alertedAt: { not: null } }, { formingAlertedAt: { not: null } }],
    },
    orderBy: { observedAt: 'asc' },
    take: maxToResolve,
  });

  const remaining = Math.max(0, maxToResolve - alertedPending.length);
  const otherPending = remaining > 0
    ? await prisma.signalObservation.findMany({
        where: {
          status: 'PENDING',
          observedAt: { lt: overdueBefore },
          alertedAt: null,
          formingAlertedAt: null,
        },
        orderBy: { observedAt: 'asc' },
        take: remaining,
      })
    : [];

  const pending = [...alertedPending, ...otherPending];

  // Group by symbol so we fetch each symbol's data only once
  const bySymbol: Record<string, typeof pending> = {};
  for (const p of pending) {
    const horizonMs = (p.horizonHours || DEFAULT_HORIZON_HOURS) * 3600 * 1000;
    if (now < p.observedAt.getTime() + horizonMs) {
      summary.stillPending++;
      continue;
    }
    (bySymbol[p.symbol] ||= []).push(p);
  }

  for (const symbol of Object.keys(bySymbol)) {
    let data: IntradayDataPoint[] = [];
    try {
      data = await fetchIntradayData(symbol, '5m');
    } catch {
      continue;
    }
    if (!data || data.length === 0) continue;

    for (const obs of bySymbol[symbol]) {
      summary.checked++;
      const outcome = evaluateOutcome(obs, data);
      if (!outcome) {
        summary.stillPending++;
        continue;
      }
      try {
        await prisma.signalObservation.update({
          where: { id: obs.id },
          data: {
            status: outcome.status,
            resolvedAt: new Date(),
            exitPrice: outcome.exitPrice,
            returnPct: outcome.returnPct,
            maxFavorablePct: outcome.maxFavorablePct,
            maxAdversePct: outcome.maxAdversePct,
            pathComplete: outcome.pathComplete,
            outcomeNote: outcome.note,
          },
        });
        summary.resolved++;
        if (outcome.status === 'WIN') summary.wins++;
        else if (outcome.status === 'LOSS') summary.losses++;
        else summary.expired++;
      } catch {
        // ignore individual update failures
      }
    }
    await new Promise(r => setTimeout(r, 80));
  }

  return summary;
}

interface Outcome {
  status: 'WIN' | 'LOSS' | 'EXPIRED';
  exitPrice: number;
  returnPct: number;
  maxFavorablePct: number;
  maxAdversePct: number;
  pathComplete: boolean;
  note: string;
}

// Walk the bars after the observation and determine what happened first:
// target hit (WIN), stop hit (LOSS), or horizon elapsed (EXPIRED at last close).
function evaluateOutcome(obs: any, data: IntradayDataPoint[]): Outcome | null {
  const entryTime = obs.observedAt.getTime();
  const horizonMs = (obs.horizonHours || DEFAULT_HORIZON_HOURS) * 3600 * 1000;
  const endTime = entryTime + horizonMs;
  const isLong = obs.direction === 'LONG';
  const entry = obs.entryPrice;
  const target = obs.targetPct || DEFAULT_TARGET_PCT;
  const stop = obs.stopPct || DEFAULT_STOP_PCT;

  // Bars strictly after the observation, up to the horizon
  const window = data.filter(d => d.timestamp > entryTime && d.timestamp <= endTime);
  if (window.length === 0) {
    // No data in window yet. If plenty of time has passed and still no data,
    // the market may have been closed — fall back to any bars after entry.
    const after = data.filter(d => d.timestamp > entryTime);
    if (after.length === 0) return null;
    window.push(...after.slice(0, 48));
  }

  let maxFav = 0;
  let maxAdv = 0;

  // First-touch result (WIN or LOSS). We capture it the moment target/stop is
  // hit — which is what defines the trade's accuracy outcome — but we DELIBERATELY
  // keep scanning the rest of the horizon so maxFav/maxAdv reflect the TRUE
  // full-path extremes. Those extremes power the honest exit-percentage optimizer
  // (how far winners actually ran, how deep they dipped first); they must not be
  // truncated at the first touch. The WIN/LOSS/EXPIRED status itself is unchanged.
  let hit: Omit<Outcome, 'maxFavorablePct' | 'maxAdversePct' | 'pathComplete'> | null = null;

  for (const bar of window) {
    const favPrice = isLong ? bar.high : bar.low;
    const advPrice = isLong ? bar.low : bar.high;
    const favPct = isLong
      ? ((favPrice - entry) / entry) * 100
      : ((entry - favPrice) / entry) * 100;
    const advPct = isLong
      ? ((entry - advPrice) / entry) * 100
      : ((advPrice - entry) / entry) * 100;
    if (favPct > maxFav) maxFav = favPct;
    if (advPct > maxAdv) maxAdv = advPct;

    if (hit === null) {
      // Target hit first? (checked before stop to preserve prior priority)
      if (favPct >= target) {
        hit = {
          status: 'WIN',
          exitPrice: isLong ? entry * (1 + target / 100) : entry * (1 - target / 100),
          returnPct: Math.round(target * 100) / 100,
          note: 'Hit target',
        };
      } else if (advPct >= stop) {
        // Stop hit?
        hit = {
          status: 'LOSS',
          exitPrice: isLong ? entry * (1 - stop / 100) : entry * (1 + stop / 100),
          returnPct: -Math.round(stop * 100) / 100,
          note: 'Hit stop',
        };
      }
    }
  }

  if (hit) {
    return {
      ...hit,
      maxFavorablePct: Math.round(maxFav * 100) / 100,
      maxAdversePct: Math.round(maxAdv * 100) / 100,
      pathComplete: true,
    };
  }

  // Horizon elapsed — exit at last bar close
  const lastClose = window[window.length - 1].close;
  const returnPct = isLong
    ? ((lastClose - entry) / entry) * 100
    : ((entry - lastClose) / entry) * 100;
  return {
    status: 'EXPIRED',
    exitPrice: lastClose,
    returnPct: Math.round(returnPct * 100) / 100,
    maxFavorablePct: Math.round(maxFav * 100) / 100,
    maxAdversePct: Math.round(maxAdv * 100) / 100,
    pathComplete: true,
    note: 'Time exit',
  };
}

// ---------------------------------------------------------------------------
// PERFORMANCE STATS (for on-site display)
// ---------------------------------------------------------------------------
export interface PerformanceStats {
  totalRecorded: number;
  totalResolved: number;
  pending: number;
  winRate: number;              // % of resolved that were profitable
  avgReturn: number;
  longWinRate: number;
  shortWinRate: number;
  byHeatRange: { range: string; trades: number; winRate: number; avgReturn: number }[];
  byTradeType: { type: string; trades: number; winRate: number; avgReturn: number }[];
  byRegime: { regime: string; trades: number; winRate: number; avgReturn: number }[];
  topSymbols: { symbol: string; trades: number; winRate: number; avgReturn: number }[];
  intradayStats: { trades: number; winRate: number; avgReturn: number };
  recent: {
    symbol: string; direction: string; heat: number; status: string;
    returnPct: number | null; observedAt: string; resolvedAt: string | null;
  }[];
  lastUpdated: string;
  dataStartedAt: string | null;
  liveCount: number;
  backfillCount: number;
}

function wr(arr: { returnPct: number | null }[]): number {
  const done = arr.filter(a => a.returnPct !== null);
  if (done.length === 0) return 0;
  return Math.round((done.filter(a => (a.returnPct as number) > 0).length / done.length) * 1000) / 10;
}
function avg(arr: { returnPct: number | null }[]): number {
  const done = arr.filter(a => a.returnPct !== null);
  if (done.length === 0) return 0;
  return Math.round((done.reduce((s, a) => s + (a.returnPct as number), 0) / done.length) * 100) / 100;
}

export async function getPerformanceStats(): Promise<PerformanceStats> {
  const [totalRecorded, pending, resolved, earliest, backfillCount] = await Promise.all([
    prisma.signalObservation.count(),
    prisma.signalObservation.count({ where: { status: 'PENDING' } }),
    prisma.signalObservation.findMany({
      where: { status: { not: 'PENDING' } },
      select: {
        symbol: true, direction: true, heat: true, status: true,
        returnPct: true, tradeType: true, observedAt: true, resolvedAt: true,
        marketRegime: true, horizonHours: true,
      },
      orderBy: { resolvedAt: 'desc' },
      take: 5000,
    }),
    prisma.signalObservation.findFirst({ orderBy: { observedAt: 'asc' }, select: { observedAt: true } }),
    prisma.signalObservation.count({ where: { source: 'backfill' } }),
  ]);

  const longs = resolved.filter(r => r.direction === 'LONG');
  const shorts = resolved.filter(r => r.direction === 'SHORT');

  const heatRanges = [
    { range: '30-45', min: 30, max: 45 },
    { range: '45-60', min: 45, max: 60 },
    { range: '60-75', min: 60, max: 75 },
    { range: '75+', min: 75, max: 9999 },
  ];
  const byHeatRange = heatRanges.map(r => {
    const a = resolved.filter(x => Math.abs(x.heat) >= r.min && Math.abs(x.heat) < r.max);
    return { range: r.range, trades: a.length, winRate: wr(a), avgReturn: avg(a) };
  });

  const types = ['intraday', 'short_swing', 'long_swing'];
  const byTradeType = types
    .map(t => {
      const a = resolved.filter(x => x.tradeType === t);
      return { type: t, trades: a.length, winRate: wr(a), avgReturn: avg(a) };
    })
    .filter(t => t.trades > 0);

  const regimes = ['bull', 'neutral', 'bear'];
  const byRegime = regimes
    .map(rg => {
      const a = resolved.filter(x => x.marketRegime === rg);
      return { regime: rg, trades: a.length, winRate: wr(a), avgReturn: avg(a) };
    })
    .filter(r => r.trades > 0);

  const symbolMap: Record<string, typeof resolved> = {};
  for (const r of resolved) (symbolMap[r.symbol] ||= []).push(r);
  const topSymbols = Object.keys(symbolMap)
    .map(sym => ({
      symbol: sym,
      trades: symbolMap[sym].length,
      winRate: wr(symbolMap[sym]),
      avgReturn: avg(symbolMap[sym]),
    }))
    .filter(s => s.trades >= 3)
    .sort((a, b) => b.winRate - a.winRate)
    .slice(0, 8);

  const intradayResolved = resolved.filter(r => isIntradayExecutable(r.observedAt, r.horizonHours));
  const intradayStats = {
    trades: intradayResolved.length,
    winRate: wr(intradayResolved),
    avgReturn: avg(intradayResolved),
  };

  const recent = resolved.slice(0, 12).map(r => ({
    symbol: r.symbol,
    direction: r.direction,
    heat: r.heat,
    status: r.status,
    returnPct: r.returnPct,
    observedAt: r.observedAt.toISOString(),
    resolvedAt: r.resolvedAt ? r.resolvedAt.toISOString() : null,
  }));

  return {
    totalRecorded,
    totalResolved: resolved.length,
    pending,
    winRate: wr(resolved),
    avgReturn: avg(resolved),
    longWinRate: wr(longs),
    shortWinRate: wr(shorts),
    byHeatRange,
    byTradeType,
    byRegime,
    topSymbols,
    intradayStats,
    recent,
    lastUpdated: new Date().toISOString(),
    dataStartedAt: earliest ? earliest.observedAt.toISOString() : null,
    liveCount: totalRecorded - backfillCount,
    backfillCount,
  };
}

// ---------------------------------------------------------------------------
// STRATEGY DISCOVERY — the "Top 5" rolling leaderboard
// ---------------------------------------------------------------------------
// The tool's job is to *find what works*. We slice the resolved-outcome dataset
// along many dimensions — direction, trade type, asset class, time of day, heat
// strength, and market regime (plus a few high-value combinations) — and rank
// every segment by a statistically honest score. This is deliberately open to
// ALL possibilities: whatever genuinely produces a high success rate rises to
// the top. We never inflate; segments with too little data are held back.

export interface DiscoveredStrategy {
  id: string;
  name: string;
  description: string;
  dimension: string;      // e.g. "Direction", "Time of day", "Market regime"
  trades: number;
  winRate: number;
  avgReturn: number;
  score: number;          // Wilson lower-bound win rate (sample-aware ranking)
  edge: number;           // winRate minus overall baseline winRate
  executionSteps: string[]; // honest step-by-step plan derived from the segment
}

export interface StrategyDiscoveryResult {
  baselineWinRate: number;
  totalResolved: number;
  minTradesRequired: number;
  enoughData: boolean;
  topStrategies: DiscoveredStrategy[];
  watchList: DiscoveredStrategy[];   // segments to keep an eye on (worst performers)
  // Intraday-first board — the tool's primary focus. Built only from trades that
  // can honestly be opened and closed within a single session.
  intradayBaselineWinRate: number;
  intradayResolved: number;
  intradayStrategies: DiscoveredStrategy[];
  lastUpdated: string;
}

// Minimum resolved trades before a segment is eligible for the leaderboard.
// Kept modest early on so the board comes alive quickly, but high enough to
// avoid crowning a 3-trade fluke.
const MIN_TRADES_FOR_STRATEGY = 6;

type ResolvedRow = {
  direction: string; heat: number; returnPct: number | null; tradeType: string | null;
  assetClass: string | null; sessionSlot: string | null; marketRegime: string | null;
  category: string | null; observedAt: Date; horizonHours: number | null;
};

function segStats(rows: ResolvedRow[]) {
  const done = rows.filter(r => r.returnPct !== null);
  const n = done.length;
  const wins = done.filter(r => (r.returnPct as number) > 0).length;
  const winRate = n ? wins / n : 0;
  const avgReturn = n ? done.reduce((s, r) => s + (r.returnPct as number), 0) / n : 0;
  return { n, wins, winRate, avgReturn };
}

// Wilson score lower bound — rewards both a high win rate AND a solid sample.
function wilsonLB(wins: number, n: number, z = 1.28): number {
  if (n === 0) return 0;
  const p = wins / n;
  const denom = 1 + (z * z) / n;
  const centre = p + (z * z) / (2 * n);
  const margin = z * Math.sqrt((p * (1 - p) + (z * z) / (4 * n)) / n);
  return (centre - margin) / denom;
}

// Human-readable, honest step-by-step execution plan derived from a segment's
// OWN trades. It never invents parameters: direction and typical entry strength
// come straight from the trades in the segment; target, stop and the same-day
// exit are the exact fixed rules every observation was measured against.
function buildExecutionSteps(rows: ResolvedRow[]): string[] {
  if (rows.length === 0) return [];
  const longs = rows.filter(r => r.direction === 'LONG').length;
  const shorts = rows.length - longs;
  const dirText = shorts === 0 ? 'LONG (bullish)'
    : longs === 0 ? 'SHORT (bearish)'
    : longs >= shorts ? 'mostly LONG (bullish)' : 'mostly SHORT (bearish)';

  const absHeats = rows.map(r => Math.abs(r.heat));
  const minHeat = Math.round(Math.min(...absHeats));
  const avgHeat = Math.round(absHeats.reduce((a, b) => a + b, 0) / absHeats.length);

  const slotCount: Record<string, number> = {};
  for (const r of rows) if (r.sessionSlot) slotCount[r.sessionSlot] = (slotCount[r.sessionSlot] || 0) + 1;
  const topSlot = Object.keys(slotCount).sort((a, b) => slotCount[b] - slotCount[a])[0];
  const SLOT_WINDOW: Record<string, string> = {
    open: 'during the opening bell (9:30–11:00 ET)',
    midday: 'midday (11:00 ET–2:00 PM ET)',
    power_hour: 'in the power hour (2:00–4:00 PM ET)',
  };
  const timeText = topSlot && SLOT_WINDOW[topSlot]
    ? `Enter ${SLOT_WINDOW[topSlot]}, and no later than 12:00 PM ET so the trade can close the same session.`
    : 'Enter between 9:30 AM and 12:00 PM ET so the full trade can complete before the same-day close.';

  return [
    `Wait for a ${dirText} HeatTracker reading around ${avgHeat} (at least ${minHeat}).`,
    timeText,
    'Set a profit target of +2% and a stop-loss of −1.5% from your entry price.',
    'If neither target nor stop is hit, close the position by 4:00 PM ET the same day — never hold overnight.',
  ];
}

// Build a ranked leaderboard from a given set of resolved trades. Used for both
// the intraday-only board (the tool's primary focus) and the all-timeframes
// board. Scoring is IDENTICAL and sample-aware for both — the only difference is
// which trades feed each board. This is never a re-weighting of outcomes.
function buildBoard(rows: ResolvedRow[]): { baselineWinRate: number; totalResolved: number; scored: DiscoveredStrategy[] } {
  const baseline = segStats(rows);
  const baselineWinRate = Math.round(baseline.winRate * 1000) / 10;

  const SLOT_LABELS: Record<string, string> = {
    open: 'the opening bell (9:30–11 ET)',
    midday: 'midday (11–2 ET)',
    power_hour: 'the power hour (2–4 ET)',
  };
  const REGIME_LABELS: Record<string, string> = {
    bull: 'an uptrending market',
    bear: 'a downtrending market',
    neutral: 'a choppy / sideways market',
  };
  const TYPE_LABELS: Record<string, string> = {
    intraday: 'Intraday',
    short_swing: 'Short swing',
    long_swing: 'Long swing',
  };

  const candidates: { id: string; name: string; description: string; dimension: string; rows: ResolvedRow[] }[] = [];
  const add = (id: string, name: string, description: string, dimension: string, pred: (r: ResolvedRow) => boolean) =>
    candidates.push({ id, name, description, dimension, rows: rows.filter(pred) });

  add('dir-long', 'Long signals', 'Going long on positive-heat setups.', 'Direction', r => r.direction === 'LONG');
  add('dir-short', 'Short signals', 'Going short on negative-heat setups.', 'Direction', r => r.direction === 'SHORT');
  for (const t of ['intraday', 'short_swing', 'long_swing']) {
    add(`type-${t}`, `${TYPE_LABELS[t]} trades`, `All ${TYPE_LABELS[t].toLowerCase()} setups regardless of symbol.`, 'Trade type', r => r.tradeType === t);
  }
  add('asset-stock', 'Individual stocks only', 'Signals on single-name stocks (excludes ETFs).', 'Asset class', r => r.assetClass === 'stock');
  add('asset-etf', 'ETFs only', 'Signals on index & sector ETFs (excludes single stocks).', 'Asset class', r => r.assetClass === 'etf');
  for (const s of ['open', 'midday', 'power_hour']) {
    add(`slot-${s}`, `Trades during ${SLOT_LABELS[s].split(' (')[0]}`, `Only setups entered during ${SLOT_LABELS[s]}.`, 'Time of day', r => r.sessionSlot === s);
  }
  add('heat-strong', 'Strong signals (heat 60+)', 'Only the strongest readings (absolute heat ≥ 60).', 'Signal strength', r => Math.abs(r.heat) >= 60);
  add('heat-mid', 'Moderate signals (heat 45–60)', 'Mid-strength readings (absolute heat 45–60).', 'Signal strength', r => Math.abs(r.heat) >= 45 && Math.abs(r.heat) < 60);
  for (const rg of ['bull', 'bear', 'neutral']) {
    add(`regime-${rg}`, `Trading in ${REGIME_LABELS[rg].split(' (')[0]}`, `All signals taken while the market was in ${REGIME_LABELS[rg]}.`, 'Market regime', r => r.marketRegime === rg);
  }
  add('combo-long-bull', 'Longs in an uptrend', 'Going long only when the broad market is trending up (trade with the tide).', 'Combination', r => r.direction === 'LONG' && r.marketRegime === 'bull');
  add('combo-short-bear', 'Shorts in a downtrend', 'Going short only when the broad market is trending down.', 'Combination', r => r.direction === 'SHORT' && r.marketRegime === 'bear');
  add('combo-strong-long', 'Strong longs (heat 60+)', 'High-conviction long setups with absolute heat ≥ 60.', 'Combination', r => r.direction === 'LONG' && Math.abs(r.heat) >= 60);
  add('combo-open-momentum', 'Opening-bell momentum', 'Strong setups (heat ≥ 50) taken in the first 90 minutes.', 'Combination', r => r.sessionSlot === 'open' && Math.abs(r.heat) >= 50);

  const scored: DiscoveredStrategy[] = candidates
    .map(c => {
      const s = segStats(c.rows);
      return {
        id: c.id,
        name: c.name,
        description: c.description,
        dimension: c.dimension,
        trades: s.n,
        winRate: Math.round(s.winRate * 1000) / 10,
        avgReturn: Math.round(s.avgReturn * 100) / 100,
        score: Math.round(wilsonLB(s.wins, s.n) * 1000) / 10,
        edge: Math.round((s.winRate * 100 - baselineWinRate) * 10) / 10,
        executionSteps: buildExecutionSteps(c.rows),
      };
    })
    .filter(s => s.trades >= MIN_TRADES_FOR_STRATEGY);

  return { baselineWinRate, totalResolved: baseline.n, scored };
}

export async function discoverTopStrategies(): Promise<StrategyDiscoveryResult> {
  const rows: ResolvedRow[] = await prisma.signalObservation.findMany({
    where: { status: { not: 'PENDING' }, returnPct: { not: null } },
    select: {
      direction: true, heat: true, returnPct: true, tradeType: true,
      assetClass: true, sessionSlot: true, marketRegime: true, category: true,
      observedAt: true, horizonHours: true,
    },
    take: 20000,
  });

  // Primary focus: trades that can be honestly opened AND closed within a single
  // session. This filters WHICH trades feed the intraday board; it never alters
  // any recorded outcome.
  const intradayRows = rows.filter(r => isIntradayExecutable(r.observedAt, r.horizonHours));

  const all = buildBoard(rows);
  const intraday = buildBoard(intradayRows);

  const topStrategies = [...all.scored].sort((a, b) => b.score - a.score || b.avgReturn - a.avgReturn).slice(0, 5);
  const watchList = [...all.scored].sort((a, b) => a.score - b.score).slice(0, 3);
  const intradayStrategies = [...intraday.scored].sort((a, b) => b.score - a.score || b.avgReturn - a.avgReturn).slice(0, 5);

  return {
    baselineWinRate: all.baselineWinRate,
    totalResolved: all.totalResolved,
    minTradesRequired: MIN_TRADES_FOR_STRATEGY,
    enoughData: all.scored.length > 0,
    topStrategies,
    watchList,
    intradayBaselineWinRate: intraday.baselineWinRate,
    intradayResolved: intraday.totalResolved,
    intradayStrategies,
    lastUpdated: new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// LIVE MONITORING — recent observations feed + agent status
// ---------------------------------------------------------------------------
export interface ObservationRow {
  id: string;
  symbol: string;
  name: string | null;
  direction: string;
  heat: number;
  tradeType: string | null;
  assetClass: string | null;
  sessionSlot: string | null;
  marketRegime: string | null;
  status: string;
  entryPrice: number;
  returnPct: number | null;
  observedAt: string;
  resolvedAt: string | null;
}

export interface LiveFeed {
  counts: { total: number; pending: number; resolved: number; wins: number; losses: number; expired: number };
  lastRecordedAt: string | null;
  lastResolvedAt: string | null;
  observations: ObservationRow[];
  serverTime: string;
  marketOpen: boolean;
}

export async function getLiveFeed(limit = 40): Promise<LiveFeed> {
  const [total, pending, wins, losses, expired, latest, lastResolved, recent] = await Promise.all([
    prisma.signalObservation.count(),
    prisma.signalObservation.count({ where: { status: 'PENDING' } }),
    prisma.signalObservation.count({ where: { status: 'WIN' } }),
    prisma.signalObservation.count({ where: { status: 'LOSS' } }),
    prisma.signalObservation.count({ where: { status: 'EXPIRED' } }),
    prisma.signalObservation.findFirst({ orderBy: { observedAt: 'desc' }, select: { observedAt: true } }),
    prisma.signalObservation.findFirst({ where: { resolvedAt: { not: null } }, orderBy: { resolvedAt: 'desc' }, select: { resolvedAt: true } }),
    prisma.signalObservation.findMany({
      orderBy: { observedAt: 'desc' },
      take: limit,
      select: {
        id: true, symbol: true, name: true, direction: true, heat: true, tradeType: true,
        assetClass: true, sessionSlot: true, marketRegime: true, status: true,
        entryPrice: true, returnPct: true, observedAt: true, resolvedAt: true,
      },
    }),
  ]);

  return {
    counts: { total, pending, resolved: wins + losses + expired, wins, losses, expired },
    lastRecordedAt: latest ? latest.observedAt.toISOString() : null,
    lastResolvedAt: lastResolved?.resolvedAt ? lastResolved.resolvedAt.toISOString() : null,
    observations: recent.map(r => ({
      id: r.id,
      symbol: r.symbol,
      name: r.name,
      direction: r.direction,
      heat: r.heat,
      tradeType: r.tradeType,
      assetClass: r.assetClass,
      sessionSlot: r.sessionSlot,
      marketRegime: r.marketRegime,
      status: r.status,
      entryPrice: r.entryPrice,
      returnPct: r.returnPct,
      observedAt: r.observedAt.toISOString(),
      resolvedAt: r.resolvedAt ? r.resolvedAt.toISOString() : null,
    })),
    serverTime: new Date().toISOString(),
    marketOpen: isMarketHours(),
  };
}
```

---

## FILE: code/lib/alert-checker.ts

```typescript
import { prisma } from '@/lib/db';
import {
  getRulePredicate,
  getRulePredicateExcludingHeat,
  getRuleHeatFloor,
  ruleNonHeatConditionCount,
  type ReviewRow,
} from '@/lib/strategy-review';
import { isIntradayExecutable } from '@/lib/signal-recorder';
import { getRealtimeQuotes, isRealtimeConfigured, driftPct, hasRunAway } from '@/lib/realtime-quotes';

// ---------------------------------------------------------------------------
// TRADE-SIGNAL ALERT CHECKER
//
// Two kinds of email alerts, both driven off the latest self-review's
// qualifying rules (Wilson lower-bound >= 60%):
//
//   1. CONFIRMED alert  — a freshly-recorded signal FULLY matches a qualifying
//      rule right now. "This setup is live."
//   2. FORMING pre-alert — a freshly-recorded signal already matches all the
//      structural conditions of a qualifying rule (direction, time, regime,
//      asset, etc.) and its momentum (heat) is building toward the rule's
//      trigger but hasn't reached it yet. "A setup is forming — prep now so you
//      don't miss the entry." This is the anticipatory heads-up.
//
// Every alert now spells out a "Buy by" and "Sell by" time so the entry/exit
// window is explicit and honest (all setups are same-session intraday).
//
// Confidence tiers (user-defined Aug 3 2026):
//   Low:      50-60%  ->  no alert
//   Moderate: 60-65%  ->  alert
//   High:     65%+    ->  alert
// ---------------------------------------------------------------------------

const DEFAULT_HORIZON = 4;
const MIN_ALERT_LB = 60;         // only alert at Moderate (60%+)
const MAX_ALERTS_PER_DAY = 1000;  // effectively uncapped (user: never turn down a setup); high sentinel only guards a runaway loop
const MAX_FORMING_PER_DAY = 1000; // effectively uncapped; dedupe (symbol|direction) still prevents repeats
const FORMING_HEAT_GAP = 14;     // heat points below a rule's trigger that still count as "approaching"
const FRESH_MINUTES = 40;        // only consider signals recorded in the last scan cycle

// How far a setup may drift in our favour on the real-time feed before we treat
// it as already gone. Our validated edge is +2% target against a -1.5% stop; if
// 1% of the move has already happened while the delayed data caught up, the
// remaining reward/risk is materially worse than the one we measured. Suppress
// rather than alert late — sending a setup whose price has evaporated is a
// false setup, even though the signal itself was real when it formed.
const MAX_FAVOURABLE_DRIFT_PCT = 1.0;
const ALERT_RECIPIENT = 'misiti15@gmail.com';
const CLOSE_MIN = 16 * 60;       // 16:00 ET market close, in minutes

// ---- TARGET REACHABILITY GUARD (added Aug 14 2026) -------------------------
// Diagnosed from the CVS/CI 11:24am pre-alerts of Aug 13. Both were real
// oversold readings, but the tape they sat in could not physically deliver the
// +2% target we quote: CVS projected ~1.3% of remaining range for the rest of
// the session, CI ~1.2%. They skimmed 0.26% and 0.20% and then trended down.
//
// The projection is a random-walk estimate of how far a name can still travel
// before the close:   projectedRange = atrPct * sqrt(5-min bars left in RTH)
// We refuse to quote a target the projection cannot support. Measured over
// 58,999 resolved observations, requiring projection >= target lifts the share
// of setups that actually reach +2% from 14% to 22%, and applied to our own
// alert history it blocks CVS, CI and every other dud from Aug 13 while keeping
// AMD (the one win).
//
// REVISED Aug 14 2026 (clamp, don't suppress). The first version of this guard
// simply refused to send anything whose projection fell short of the quoted
// target. That threw away real setups: TFC (proj 1.06%) and PNC (proj 1.00%)
// were both tradeable for a 0.15-0.30% skim on Aug 13 and the guard would have
// deleted them. The setups were fine; only the +2% target was wrong. So instead
// of dropping the alert we now trim the quoted target down to what the session
// can still deliver, and suppress only when there is essentially no range left
// (projection below MIN_QUOTED_TARGET_PCT).
//
// NOTE: this guard does NOT change the +2%/-1.5% definition our win rates are
// scored against. Scoring stays deliberately stricter than what we quote, so a
// trimmed target can never make the scorecard look better than it earned.
const REQUIRE_REACHABLE_TARGET = true;
const MIN_ATR_PCT_FALLBACK = 0.20; // used when atrPct was never recorded
const MIN_QUOTED_TARGET_PCT = 0.40; // below this a skim is not worth the spread

interface ReviewRuleRec {
  id: string;
  label: string;
  winRate: number;
  winRateLB: number;
  trades: number;
  layers: number;
  avgReturn: number;
  exitTargetPct?: number | null;
  exitStopPct?: number | null;
  exitReachRate?: number | null;
}

function confidenceTier(lb: number): 'High' | 'Moderate' {
  return lb >= 65 ? 'High' : 'Moderate';
}

function etDateKey(d: Date): string {
  return d.toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
}

function etMinutes(d: Date): number {
  const et = new Date(d.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  return et.getHours() * 60 + et.getMinutes();
}

function fmtClock(mins: number): string {
  const m = Math.max(0, Math.min(24 * 60 - 1, Math.round(mins)));
  let h = Math.floor(m / 60);
  const mm = m % 60;
  const ap = h >= 12 ? 'PM' : 'AM';
  let hh = h % 12;
  if (hh === 0) hh = 12;
  return `${hh}:${mm.toString().padStart(2, '0')} ${ap}`;
}

// Derive the honest same-session entry/exit window for a setup.
//   buyBy   = last clock time a trade can still be OPENED and have its full
//             holding window finish before the 16:00 ET close (= 16:00 - hold).
//   sellBy  = about one holding window after this signal, never past the close.
function deriveWindow(observedAt: Date, horizonHours: number | null) {
  const h = horizonHours ?? DEFAULT_HORIZON;
  const entryMin = etMinutes(observedAt);
  const buyByMin = CLOSE_MIN - h * 60;
  const sellByMin = Math.min(entryMin + h * 60, CLOSE_MIN);
  return { buyBy: fmtClock(buyByMin), sellBy: fmtClock(sellByMin), holdHours: h };
}

// 5-minute bars remaining in the regular session at this moment.
function barsLeftInSession(at: Date): number {
  return Math.max(0, Math.floor((CLOSE_MIN - etMinutes(at)) / 5));
}

// Random-walk estimate of the favourable range still available before the close.
function projectedRangePct(atrPct: number | null, at: Date): number {
  const atr = atrPct && atrPct > 0 ? atrPct : MIN_ATR_PCT_FALLBACK;
  return atr * Math.sqrt(barsLeftInSession(at));
}

// True when the session can still plausibly deliver a worthwhile skim at all.
function targetIsReachable(sig: any, _targetPct: number): boolean {
  if (!REQUIRE_REACHABLE_TARGET) return true;
  return projectedRangePct(sig.atrPct ?? null, sig.observedAt) >= MIN_QUOTED_TARGET_PCT;
}

// The target we actually quote: the rule's target, trimmed to the range the
// session can still deliver, and rounded down to a clean 0.05%.
function reachableTarget(sig: any, rawTargetPct: number): number {
  if (!REQUIRE_REACHABLE_TARGET) return rawTargetPct;
  const proj = projectedRangePct(sig.atrPct ?? null, sig.observedAt);
  if (proj >= rawTargetPct) return rawTargetPct;
  return Math.max(MIN_QUOTED_TARGET_PCT, Math.floor(proj * 20) / 20);
}

function fmtPrice(n: number): string {
  return n.toFixed(2);
}

function fmtPct(n: number): string {
  return `${n >= 0 ? '+' : ''}${n.toFixed(1)}%`;
}

export interface AlertResult {
  sent: number;
  skippedDuplicate: number;
  skippedCap: number;
  skippedUnreachable: number;
  alerts: { symbol: string; direction: string; tier: string }[];
  error?: string;
}

function emptyResult(): AlertResult {
  return { sent: 0, skippedDuplicate: 0, skippedCap: 0, skippedUnreachable: 0, alerts: [] };
}

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

async function loadQualifyingRules(): Promise<{ review: any; qualifying: ReviewRuleRec[] } | null> {
  const review = await prisma.strategyReview.findFirst({ orderBy: { runAt: 'desc' } });
  if (!review) return null;

  const recs: ReviewRuleRec[] = (review.recommendations as any[]) || [];
  const allRules = [...recs];
  if (!allRules.find(r => r.id === review.bestRuleId)) {
    allRules.push({
      id: review.bestRuleId,
      label: review.bestRuleLabel,
      winRate: review.bestWinRate,
      winRateLB: review.bestWinRateLB,
      trades: review.bestRuleTrades,
      layers: review.bestRuleId.split('+').length,
      avgReturn: 0,
      exitTargetPct: review.bestExitTargetPct,
      exitStopPct: review.bestExitStopPct,
      exitReachRate: review.bestExitReachRate,
    });
  }
  const qualifying = allRules.filter(r => r.winRateLB >= MIN_ALERT_LB);
  return { review, qualifying };
}

function rowFromSignal(sig: any): ReviewRow {
  return {
    direction: sig.direction,
    heat: sig.heat,
    returnPct: null,
    tradeType: sig.tradeType,
    assetClass: sig.assetClass,
    sessionSlot: sig.sessionSlot,
    marketRegime: sig.marketRegime,
    rsi: sig.rsi,
    volumeRatio: sig.volumeRatio,
    volumeSurge: sig.volumeSurge,
    buyPressure: sig.buyPressure,
    vwapDistPct: sig.vwapDistPct,
    rsiSlope: sig.rsiSlope ?? null,
    atrPct: sig.atrPct ?? null,
    vwapReclaim: sig.vwapReclaim ?? null,
    rsiShort: sig.rsiShort ?? null,
    maxFavorablePct: null,
    maxAdversePct: null,
    pathComplete: null,
    observedAt: sig.observedAt,
    horizonHours: sig.horizonHours,
  };
}

// Today's already-alerted symbol|direction keys (ET day) for dedupe.
async function alertedKeysToday(field: 'alertedAt' | 'formingAlertedAt'): Promise<Set<string>> {
  const today = etDateKey(new Date());
  const dayStart = new Date(`${today}T00:00:00-04:00`);
  const rows = await prisma.signalObservation.findMany({
    where: { [field]: { not: null }, observedAt: { gte: dayStart } } as any,
    select: { symbol: true, direction: true },
  });
  return new Set(rows.map(a => `${a.symbol}|${a.direction}`));
}

type AlertEntry = {
  signal: any;
  matchingRules: ReviewRuleRec[];
  bestRule: ReviewRuleRec;
};

// Build one setup card. stage 'confirmed' = live setup; 'forming' = prep heads-up.
function buildCard(entry: AlertEntry, review: any, stage: 'confirmed' | 'forming'): string {
  const sig = entry.signal;
  const isLong = sig.direction === 'LONG';
  const entryPrice = sig.entryPrice;

  // The quoted target never exceeds the slot's base target (1.00% before 10:00
  // ET, 0.75% after). A rule's learned exit plan can still pull it LOWER, and
  // reachableTarget() then trims it further to the range actually left today.
  const slotBase = etMinutes(sig.observedAt) < 600 ? 1.0 : 0.75;
  const ruleTarget = entry.bestRule.exitTargetPct ?? review.bestExitTargetPct ?? (sig.targetPct || slotBase);
  const rawExitTarget = Math.min(ruleTarget, slotBase);
  const exitTarget = reachableTarget(sig, rawExitTarget);
  const targetTrimmed = exitTarget < rawExitTarget - 0.001;
  // Stop is floored at 1.50%. The tested edge comes from the ASYMMETRY (small
  // target, wide stop); a learned stop tighter than this turns 80%-green configs
  // into coin flips because losses start matching wins in size.
  const MIN_QUOTED_STOP_PCT = 1.5;
  const exitStop = Math.max(
    MIN_QUOTED_STOP_PCT,
    entry.bestRule.exitStopPct ?? review.bestExitStopPct ?? (sig.stopPct || 1.5)
  );

  const targetPrice = isLong ? entryPrice * (1 + exitTarget / 100) : entryPrice * (1 - exitTarget / 100);
  const stopPrice = isLong ? entryPrice * (1 - exitStop / 100) : entryPrice * (1 + exitStop / 100);

  const tier = confidenceTier(entry.bestRule.winRateLB);
  const dirColor = isLong ? '#22c55e' : '#ef4444';
  const dirWord = isLong ? 'Buy (Long)' : 'Sell Short';

  const win = deriveWindow(sig.observedAt, sig.horizonHours);
  const heatFloor = getRuleHeatFloor(entry.bestRule.id);
  const absHeat = Math.abs(sig.heat);

  const accent = stage === 'forming' ? '#d97706' : (tier === 'High' ? '#16a34a' : '#eab308');
  const stageBadge = stage === 'forming' ? '⏳ FORMING — prep only, do NOT buy yet' : `✅ CONFIRMED — ${tier} confidence, act now`;

  const entryLabel = stage === 'forming' ? 'Watch price' : 'Entry near';

  const formingLine = stage === 'forming'
    ? `<p style="margin:0 0 10px;font-size:13px;color:#2563eb;background:#eff6ff;padding:8px 10px;border-radius:6px;">
         Momentum is building toward this high-confidence setup: strength is about <strong>${Math.round(absHeat)}</strong> now and it triggers around <strong>${heatFloor}</strong>. Get ready — if it confirms you'll get a follow-up alert.
       </p>`
    : '';

  let rulesHtml = '';
  if (entry.matchingRules.length > 1) {
    rulesHtml = `<p style="margin:8px 0 4px;font-size:12px;color:#888;">Also lines up with:</p><ul style="margin:0;padding-left:16px;font-size:12px;color:#666;">`;
    for (const r of entry.matchingRules.slice(1, 4)) {
      rulesHtml += `<li>${r.label.replace(/^Only /, '')} — ${r.winRateLB}% floor (${confidenceTier(r.winRateLB)})</li>`;
    }
    if (entry.matchingRules.length > 4) rulesHtml += `<li>+${entry.matchingRules.length - 4} more</li>`;
    rulesHtml += `</ul>`;
  }

  return `
    <div style="background:#f9fafb;border-radius:12px;padding:20px;margin:16px 0;border-left:4px solid ${accent};">
      <div style="margin-bottom:12px;">
        <span style="background:${accent};color:white;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;">${stageBadge}</span>
        <span style="font-size:11px;color:#888;margin-left:6px;">${entry.bestRule.winRateLB}% conservative floor · ${entry.bestRule.trades} trades</span>
      </div>
      <h3 style="margin:0 0 8px;font-size:20px;color:#333;">
        <span style="color:${dirColor};font-weight:700;">${stage === 'forming' ? 'Watch to ' + (isLong ? 'Buy' : 'Sell Short') : dirWord}</span> ${sig.symbol}
        ${sig.name ? `<span style="font-size:13px;color:#888;font-weight:400;"> — ${sig.name}</span>` : ''}
      </h3>
      ${formingLine}
      <table style="width:100%;font-size:14px;color:#333;margin:12px 0;border-collapse:collapse;">
        <tr>
          <td style="padding:6px 12px;background:white;"><strong>${entryLabel}</strong></td>
          <td style="padding:6px 12px;background:white;font-weight:700;">$${fmtPrice(entryPrice)}</td>
        </tr>
        <tr>
          <td style="padding:6px 12px;background:white;"><strong>Target (${fmtPct(exitTarget)})</strong>${targetTrimmed ? `<div style="font-size:11px;color:#6b7280;">trimmed from ${fmtPct(rawExitTarget)} — that is all the range left today</div>` : ''}</td>
          <td style="padding:6px 12px;background:white;color:#22c55e;font-weight:700;">$${fmtPrice(targetPrice)}</td>
        </tr>
        <tr>
          <td style="padding:6px 12px;background:white;"><strong>Stop (${fmtPct(-exitStop)})</strong></td>
          <td style="padding:6px 12px;background:white;color:#ef4444;font-weight:700;">$${fmtPrice(stopPrice)}</td>
        </tr>
        <tr>
          <td style="padding:6px 12px;background:#f3f4f6;border-top:1px solid #e5e7eb;"><strong>Buy by</strong></td>
          <td style="padding:6px 12px;background:#f3f4f6;border-top:1px solid #e5e7eb;">${win.buyBy} ET <span style="color:#888;font-size:11px;">(last entry that fits a ~${win.holdHours}h hold before close)</span></td>
        </tr>
        <tr>
          <td style="padding:6px 12px;background:#f3f4f6;"><strong>Sell by</strong></td>
          <td style="padding:6px 12px;background:#f3f4f6;">${win.sellBy} ET <span style="color:#888;font-size:11px;">(≈${win.holdHours}h after entry; always exit by 4:00 PM ET close)</span></td>
        </tr>
      </table>
      <p style="margin:8px 0 0;font-size:12px;color:#666;">
        <strong>Setup:</strong> ${entry.bestRule.label.replace(/^Only /, 'Only ')}
      </p>
      ${rulesHtml}
      ${buildTicket(sig, stage, isLong, entryPrice, targetPrice, stopPrice, exitTarget, exitStop, win)}
    </div>`;
}

// ---------------------------------------------------------------------------
// AUTOMATION TICKET
//
// Every confirmed alert now carries the exact order package an automated router
// would receive, so the emails Phillip reads today are the same instruction set
// the machine will act on later. Nothing here places a trade — it is the
// specification, printed for review. Deliberately expressed as a bracket (OCO)
// so entry, target and stop travel together and no leg can be left orphaned.
//
// Sizing is risk-normalised rather than dollar-denominated: we never store an
// account balance, so the ticket says how much of trading capital to commit such
// that the stop costs a fixed fraction of capital. That keeps every setup the
// same size in risk terms regardless of the stock's price or volatility.
// ---------------------------------------------------------------------------
const RISK_PER_TRADE_PCT = 0.5;   // a full stop costs 0.5% of trading capital
const MAX_POSITION_PCT = 25;      // never commit more than 25% of capital to one name
const NO_CHASE_BUFFER_PCT = 0.25; // refuse the entry if price has moved this far past the quote

function buildTicket(
  sig: any,
  stage: 'confirmed' | 'forming',
  isLong: boolean,
  entryPrice: number,
  targetPrice: number,
  stopPrice: number,
  exitTarget: number,
  exitStop: number,
  win: { buyBy: string; sellBy: string; holdHours: number },
): string {
  // Position size such that a full stop = RISK_PER_TRADE_PCT of capital.
  const rawPositionPct = (RISK_PER_TRADE_PCT / exitStop) * 100;
  const positionPct = Math.min(MAX_POSITION_PCT, rawPositionPct);
  const capped = rawPositionPct > MAX_POSITION_PCT;

  // Do-not-chase limit: the worst price the router may pay.
  const maxEntry = isLong
    ? entryPrice * (1 + NO_CHASE_BUFFER_PCT / 100)
    : entryPrice * (1 - NO_CHASE_BUFFER_PCT / 100);

  const side = isLong ? 'BUY' : 'SELL_SHORT';
  const exitSide = isLong ? 'SELL' : 'BUY_TO_COVER';
  const proj = projectedRangePct(sig.atrPct ?? null, sig.observedAt);

  const payload = {
    symbol: sig.symbol,
    side,
    order_type: 'LIMIT',
    limit_price: +maxEntry.toFixed(2),
    quantity: `${positionPct.toFixed(1)}% of trading capital`,
    time_in_force: 'DAY',
    bracket: {
      take_profit: { type: 'LIMIT', price: +targetPrice.toFixed(2), pct: +exitTarget.toFixed(2) },
      stop_loss: { type: 'STOP', price: +stopPrice.toFixed(2), pct: -Math.abs(+exitStop.toFixed(2)) },
      oco: true,
    },
    force_flat_by: `${win.sellBy} ET`,
    entry_valid_until: `${win.buyBy} ET`,
    risk_per_trade_pct: RISK_PER_TRADE_PCT,
    projected_session_range_pct: +proj.toFixed(2),
    mode: 'PAPER_REVIEW_ONLY',
  };

  const heading = stage === 'forming'
    ? 'Draft ticket — not armed until this setup confirms'
    : 'Automation ticket — exactly what the automated system would submit';

  const row = (k: string, v: string) =>
    `<tr><td style="padding:4px 10px;color:#9ca3af;font-size:12px;white-space:nowrap;">${k}</td>` +
    `<td style="padding:4px 10px;color:#e5e7eb;font-size:12px;font-family:ui-monospace,Menlo,monospace;">${v}</td></tr>`;

  return `
    <div style="background:#404040;border-radius:10px;padding:14px 12px;margin:14px 0 0;">
      <p style="margin:0 0 8px;font-size:11px;font-weight:700;letter-spacing:.4px;color:#4CBB17;text-transform:uppercase;">${heading}</p>
      <table style="width:100%;border-collapse:collapse;">
        ${row('Action', `${side} ${sig.symbol}`)}
        ${row('Order', `LIMIT @ $${fmtPrice(maxEntry)} <span style="color:#9ca3af;">(do not chase past this)</span>`)}
        ${row('Size', `${positionPct.toFixed(1)}% of trading capital${capped ? ' <span style="color:#9ca3af;">(capped)</span>' : ''}`)}
        ${row('Take profit', `${exitSide} LIMIT @ $${fmtPrice(targetPrice)} (${fmtPct(exitTarget)})`)}
        ${row('Stop loss', `${exitSide} STOP @ $${fmtPrice(stopPrice)} (${fmtPct(-exitStop)})`)}
        ${row('Bracket', 'OCO — first leg filled cancels the other')}
        ${row('Entry valid until', `${win.buyBy} ET`)}
        ${row('Force flat by', `${win.sellBy} ET`)}
        ${row('Projected range left', `${proj.toFixed(2)}% <span style="color:#9ca3af;">(the ${exitTarget}% target is sized to fit inside this)</span>`)}
        ${row('Mode', 'PAPER / REVIEW ONLY — no live order is placed')}
      </table>
      <p style="margin:10px 0 4px;font-size:10px;color:#9ca3af;">Machine payload</p>
      <pre style="margin:0;padding:10px;background:#2d2d2d;border-radius:6px;color:#d1d5db;font-size:10px;line-height:1.5;overflow-x:auto;white-space:pre-wrap;word-break:break-word;">${JSON.stringify(payload, null, 2)}</pre>
      <p style="margin:8px 0 0;font-size:11px;color:#9ca3af;">
        Size is risk-normalised: a full stop costs ${RISK_PER_TRADE_PCT}% of trading capital on every setup,
        so a $9 stock and a $900 stock carry identical risk. Educational only — not financial advice.
      </p>
    </div>`;
}

async function sendEmail(subject: string, htmlBody: string): Promise<void> {
  try {
    const appUrl = process.env.NEXTAUTH_URL || '';
    const response = await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_TRADE_SIGNAL_ALERT,
        subject,
        body: htmlBody,
        is_html: true,
        recipient_email: ALERT_RECIPIENT,
        sender_email: appUrl ? `noreply@${new URL(appUrl).hostname}` : undefined,
        sender_alias: 'MarcoFlow',
      }),
    });
    const res = await response.json();
    if (!res.success && !res.notification_disabled) {
      console.error('Alert email failed:', res);
    }
  } catch (e: any) {
    console.error('Alert email error:', e?.message);
  }
}

function wrapEmail(headerLine: string, cardsHtml: string, stage: 'confirmed' | 'forming', liveCount: number = 0): string {
  const etNow = new Date().toLocaleString('en-US', { timeZone: 'America/New_York', dateStyle: 'medium', timeStyle: 'short' });
  const actionBanner = stage === 'confirmed'
    ? `<div style="background:#dcfce7;border-left:6px solid #16a34a;padding:16px 18px;margin:0 0 4px;">
         <p style="margin:0;font-size:17px;font-weight:800;color:#15803d;">✅ CONFIRMED — you can act on these now</p>
         <p style="margin:6px 0 0;font-size:13px;color:#166534;">The trigger has fired. These are live entries — review each one and use your own judgment before you buy or sell.</p>
       </div>`
    : `<div style="background:#fef3c7;border-left:6px solid #d97706;padding:16px 18px;margin:0 0 4px;">
         <p style="margin:0;font-size:17px;font-weight:800;color:#b45309;">⏳ FORMING — get ready, do NOT buy yet</p>
         <p style="margin:6px 0 0;font-size:13px;color:#92400e;">These are lining up but have <strong>not triggered</strong>. This is a heads-up to watch them — you'll get a separate <strong>✅ CONFIRMED</strong> alert if and when one actually fires. No action required right now.</p>
       </div>`;
  const formingNote = stage === 'forming'
    ? `<p style="margin:0 0 4px;">A "forming" heads-up means the conditions are lining up but the trigger hasn't fired yet — it's a prompt to get ready, not a confirmed entry. Prices update on the next ~5-min scan.</p>`
    : liveCount > 0
      ? `<p style="margin:0 0 4px;">Prices below are <strong>real-time</strong>, re-checked against a live feed at the moment this alert was sent. Setups that had already run more than ${MAX_FAVOURABLE_DRIFT_PCT}% past their entry were dropped rather than sent to you late.</p>`
      : `<p style="margin:0 0 4px;">Prices are from the most recent scan (~15-min delayed free data). The exact live price may differ slightly — use these as a guide.</p>`;
  return `
  <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:600px;margin:0 auto;color:#333;">
    <div style="background:#404040;padding:16px 20px;border-radius:12px 12px 0 0;">
      <h1 style="margin:0;font-size:20px;color:#4CBB17;">MarcoFlow</h1>
      <p style="margin:4px 0 0;font-size:12px;color:#ccc;">${headerLine} · ${etNow} ET</p>
    </div>
    ${actionBanner}
    <div style="padding:4px 0;">
      ${cardsHtml}
    </div>
    <div style="padding:16px 20px;font-size:11px;color:#999;border-top:1px solid #eee;">
      ${formingNote}
      <p style="margin:0 0 4px;">Confidence = Wilson lower-bound (conservative floor) of the historical win rate for this setup.</p>
      <p style="margin:0;"><strong>Educational only — not financial advice.</strong> MarcoFlow is a research tool. Use your own judgment.</p>
    </div>
  </div>`;
}

// ---------------------------------------------------------------------------
// 1. CONFIRMED alerts — freshly-recorded signals that FULLY match a rule now.
// ---------------------------------------------------------------------------
export async function checkAndSendAlerts(): Promise<AlertResult> {
  const result = emptyResult();
  const loaded = await loadQualifyingRules();
  if (!loaded || loaded.qualifying.length === 0) return result;
  const { review, qualifying } = loaded;

  const predicates = qualifying.map(r => ({ rule: r, test: getRulePredicate(r.id) }));

  const since = new Date(Date.now() - FRESH_MINUTES * 60 * 1000);
  const freshSignals = await prisma.signalObservation.findMany({
    where: { observedAt: { gte: since }, alertedAt: null, status: 'PENDING' },
    take: 500,
  });
  if (freshSignals.length === 0) return result;

  const alertedSet = await alertedKeysToday('alertedAt');
  let todayAlertCount = alertedSet.size;

  const alertEntries: AlertEntry[] = [];
  for (const sig of freshSignals) {
    if (!isIntradayExecutable(sig.observedAt, sig.horizonHours ?? DEFAULT_HORIZON)) continue;
    const key = `${sig.symbol}|${sig.direction}`;
    if (alertedSet.has(key)) { result.skippedDuplicate++; continue; }
    if (todayAlertCount >= MAX_ALERTS_PER_DAY) { result.skippedCap++; continue; }

    const row = rowFromSignal(sig);
    const matchingRules = predicates.filter(p => p.test(row)).map(p => p.rule);
    if (matchingRules.length === 0) continue;
    matchingRules.sort((a, b) => b.winRateLB - a.winRateLB);

    const best = matchingRules[0];
    const quotedTarget = best.exitTargetPct ?? review.bestExitTargetPct ?? (sig.targetPct || 2);
    if (!targetIsReachable(sig, quotedTarget)) {
      console.log(`[reach] suppressing ${sig.symbol} ${sig.direction} — projected remaining range ${projectedRangePct(sig.atrPct ?? null, sig.observedAt).toFixed(2)}% is below the ${MIN_QUOTED_TARGET_PCT}% minimum skim (rule target ${quotedTarget}%)`);
      result.skippedUnreachable++;
      continue;
    }

    alertEntries.push({ signal: sig, matchingRules, bestRule: best });
    alertedSet.add(key);
    todayAlertCount++;
  }

  if (alertEntries.length === 0) return result;

  // ---- Real-time price confirmation (Alpaca free tier; no-op without keys) ----
  // The scan runs on ~15-min delayed data. Before we tell Phillip to act, we
  // re-check the handful of symbols that passed against a live feed. Two jobs:
  // quote him a price that actually exists right now, and drop anything that
  // has already made its move while our data was catching up.
  let liveUsed = 0;
  if (isRealtimeConfigured()) {
    try {
      const live = await getRealtimeQuotes(alertEntries.map(e => e.signal.symbol));
      const survivors: AlertEntry[] = [];
      const persist: Array<{ id: string; price: number; at: Date; drift: number }> = [];

      for (const entry of alertEntries) {
        const sig = entry.signal;
        const q = live.get(sig.symbol.toUpperCase());
        if (!q) { survivors.push(entry); continue; }

        const drift = driftPct(sig.entryPrice, q.price);
        persist.push({ id: sig.id, price: q.price, at: q.at, drift });

        if (hasRunAway(sig.direction, sig.entryPrice, q.price, MAX_FAVOURABLE_DRIFT_PCT)) {
          console.log(`[realtime] suppressing ${sig.symbol} ${sig.direction} — already moved ${drift}% since scan`);
          continue;
        }

        // Quote the live price, not the stale one.
        sig.entryPrice = q.price;
        liveUsed++;
        survivors.push(entry);
      }

      // Record live price on every checked signal — including suppressed ones —
      // so we can measure afterwards how much the delay actually costs us.
      await Promise.all(persist.map(p =>
        prisma.signalObservation.update({
          where: { id: p.id },
          data: { livePrice: p.price, livePriceAt: p.at, livePriceDrift: p.drift },
        }).catch(() => undefined)
      ));

      alertEntries.length = 0;
      alertEntries.push(...survivors);
    } catch (err) {
      // Never let the real-time layer block a real alert.
      console.error('[realtime] confirmation step failed, sending on delayed prices:', err);
    }
  }

  if (alertEntries.length === 0) return result;

  const subject = alertEntries.length === 1
    ? `✅ ACT NOW — ${confidenceTier(alertEntries[0].bestRule.winRateLB)} confidence: ${alertEntries[0].signal.symbol} ${alertEntries[0].signal.direction} | MarcoFlow`
    : `✅ ACT NOW — ${alertEntries.length} confirmed ${alertEntries.some(a => a.bestRule.winRateLB >= 65) ? 'high' : 'moderate'}-confidence setups | MarcoFlow`;

  const cards = alertEntries.map(e => buildCard(e, review, 'confirmed')).join('');
  await sendEmail(subject, wrapEmail('Trade signal alert', cards, 'confirmed', liveUsed));

  await prisma.signalObservation.updateMany({
    where: { id: { in: alertEntries.map(a => a.signal.id) } },
    data: { alertedAt: new Date() },
  });

  result.sent = alertEntries.length;
  result.alerts = alertEntries.map(a => ({ symbol: a.signal.symbol, direction: a.signal.direction, tier: confidenceTier(a.bestRule.winRateLB) }));
  return result;
}

// ---------------------------------------------------------------------------
// 2. FORMING pre-alerts — structural conditions of a qualifying rule already
//    match and momentum (heat) is building toward the trigger but not there yet.
// ---------------------------------------------------------------------------
export async function checkAndSendFormingAlerts(): Promise<AlertResult> {
  const result = emptyResult();
  const loaded = await loadQualifyingRules();
  if (!loaded || loaded.qualifying.length === 0) return result;
  const { review, qualifying } = loaded;

  // Only rules that have BOTH a heat trigger and at least one structural layer.
  const rules = qualifying
    .map(r => ({ rule: r, floor: getRuleHeatFloor(r.id), test: getRulePredicateExcludingHeat(r.id), nonHeat: ruleNonHeatConditionCount(r.id) }))
    .filter(x => x.floor > 0 && x.nonHeat > 0);
  if (rules.length === 0) return result;

  const since = new Date(Date.now() - FRESH_MINUTES * 60 * 1000);
  const freshSignals = await prisma.signalObservation.findMany({
    where: { observedAt: { gte: since }, formingAlertedAt: null, status: 'PENDING' },
    take: 500,
  });
  if (freshSignals.length === 0) return result;

  // Skip symbols already forming-alerted today, and any already confirmed today.
  const formingSet = await alertedKeysToday('formingAlertedAt');
  const confirmedSet = await alertedKeysToday('alertedAt');
  let todayCount = formingSet.size;

  const alertEntries: AlertEntry[] = [];
  for (const sig of freshSignals) {
    if (!isIntradayExecutable(sig.observedAt, sig.horizonHours ?? DEFAULT_HORIZON)) continue;
    const key = `${sig.symbol}|${sig.direction}`;
    if (formingSet.has(key) || confirmedSet.has(key)) { result.skippedDuplicate++; continue; }
    if (todayCount >= MAX_FORMING_PER_DAY) { result.skippedCap++; continue; }

    const row = rowFromSignal(sig);
    const absHeat = Math.abs(sig.heat);
    // Forming toward a rule = structural match, heat below trigger but within reach.
    const matchingRules = rules
      .filter(x => absHeat < x.floor && absHeat >= x.floor - FORMING_HEAT_GAP && x.test(row))
      .map(x => x.rule);
    if (matchingRules.length === 0) continue;
    matchingRules.sort((a, b) => b.winRateLB - a.winRateLB);

    const bestForming = matchingRules[0];
    const formingTarget = bestForming.exitTargetPct ?? review.bestExitTargetPct ?? (sig.targetPct || 2);
    if (!targetIsReachable(sig, formingTarget)) {
      console.log(`[reach] suppressing forming ${sig.symbol} ${sig.direction} — projected remaining range ${projectedRangePct(sig.atrPct ?? null, sig.observedAt).toFixed(2)}% is below the ${MIN_QUOTED_TARGET_PCT}% minimum skim (rule target ${formingTarget}%)`);
      result.skippedUnreachable++;
      continue;
    }

    alertEntries.push({ signal: sig, matchingRules, bestRule: bestForming });
    formingSet.add(key);
    todayCount++;
  }

  if (alertEntries.length === 0) return result;

  const subject = alertEntries.length === 1
    ? `⏳ GET READY (don't buy yet) — ${alertEntries[0].signal.symbol} ${alertEntries[0].signal.direction} forming | MarcoFlow`
    : `⏳ GET READY (don't buy yet) — ${alertEntries.length} setups forming | MarcoFlow`;

  const cards = alertEntries.map(e => buildCard(e, review, 'forming')).join('');
  await sendEmail(subject, wrapEmail('Setup forming — prep now', cards, 'forming'));

  await prisma.signalObservation.updateMany({
    where: { id: { in: alertEntries.map(a => a.signal.id) } },
    data: { formingAlertedAt: new Date() },
  });

  result.sent = alertEntries.length;
  result.alerts = alertEntries.map(a => ({ symbol: a.signal.symbol, direction: a.signal.direction, tier: 'Forming' }));
  return result;
}

```

---

## FILE: code/lib/strategy-review.ts

```typescript
import { prisma } from '@/lib/db';
import { isIntradayExecutable } from '@/lib/signal-recorder';

// ---------------------------------------------------------------------------
// CONTINUOUS REVIEW ENGINE (Phase 2)
//
// An agentic, self-running review loop. On each run it studies the ENTIRE
// growing set of resolved trades and asks a single honest question:
//   "Which entry conditions would GENUINELY have produced a higher win rate?"
//
// It explores a wide space of candidate refinement rules (single conditions and
// pairwise combinations across direction, signal strength, time of day, market
// regime, asset class and RSI) and scores every one of them on the intraday-
// executable trades — the tool's primary mission. Scoring uses the Wilson score
// lower bound so a lucky handful of trades can never win, and nothing is ever
// re-weighted or inflated: these are plain counterfactual win rates measured on
// real recorded outcomes. The output is a ranked set of recommendations (what
// to lean into), a list of conditions to avoid (what genuinely hurts), and the
// single best honest rule with step-by-step execution. Snapshots are stored so
// the app can show whether accuracy is truly improving as the dataset grows.
// ---------------------------------------------------------------------------

const DEFAULT_HORIZON_HOURS = 4;

// Honest sample-size gates. Combinations need a few more trades than single
// conditions before we are willing to trust — and surface — them.
const MIN_LIFT_TO_RECOMMEND = 3;   // percentage points above baseline
const MIN_LIFT_TO_AVOID = -4;      // percentage points below baseline

// How many supporting layers a single rule may stack. Each extra layer must
// come from a DIFFERENT metric family, so we are always adding genuinely new
// evidence (e.g. direction + RSI + volume + time-of-day + regime), never
// re-stating the same idea. We explore all the way to 5 layers; whether a deep
// stack ever gets SURFACED is governed entirely by the honest data gates below,
// so 4- and 5-layer rules only appear once enough real trades back them.
const MAX_STACK_DEPTH = 3;

// Anti-clustering guards. A rule that only ever fired inside two or three
// unusual sessions has NOT been tested against the market - it has been tested
// against a couple of mornings. Trades taken on the same day share the same
// news, the same tape and the same regime, so they are nowhere near
// independent evidence. We therefore (a) refuse to surface a rule that has not
// proven itself across several separate days, and (b) cap how many trades any
// single day may contribute to the conservative floor we score on.
const MIN_DISTINCT_DAYS = 5;
const MAX_TRADES_PER_DAY = 4;

// Honest sample-size gates by stack depth. A deeper stack fires less often, so
// we demand progressively MORE completed trades before we will trust — or even
// surface — it. Combined with Wilson lower-bound scoring, this stops a lucky
// handful of narrow trades from ever looking like a real edge.
function minTradesForDepth(depth: number): number {
  switch (depth) {
    case 1: return 12;
    case 2: return 15;
    case 3: return 20;
    case 4: return 25;
    default: return 30; // 5+ stacked layers
  }
}

export type ReviewRow = {
  direction: string;
  heat: number;
  returnPct: number | null;
  tradeType: string | null;
  assetClass: string | null;
  sessionSlot: string | null;
  marketRegime: string | null;
  rsi: number | null;
  volumeRatio: number | null;
  volumeSurge: number | null;
  buyPressure: number | null;
  vwapDistPct: number | null;
  rsiSlope: number | null;
  atrPct: number | null;
  vwapReclaim: number | null;
  rsiShort: number | null;
  maxFavorablePct: number | null;
  maxAdversePct: number | null;
  pathComplete: boolean | null;
  observedAt: Date;
  horizonHours: number | null;
};

export type Condition = {
  key: string;
  label: string;
  family: string;
  test: (r: ReviewRow) => boolean;
};

export interface ReviewRule {
  id: string;
  label: string;
  dimension: string;   // "Direction", "Combination", etc.
  layers: number;      // how many supporting conditions are stacked (1..5)
  trades: number;
  // How many DIFFERENT trading days those trades came from, and the
  // de-clustered ('effective') sample the conservative floor is scored on.
  // Twenty trades taken on one freak morning are one piece of evidence, not
  // twenty, so we cap how much any single day can contribute.
  distinctDays: number;
  effTrades: number;
  winRate: number;
  winRateLB: number;   // Wilson lower bound (conservative floor)
  avgReturn: number;
  lift: number;        // winRate minus intraday baseline
  // Data-driven exit plan learned from the real full-path trades in this rule
  // (null until enough clean, path-complete trades have resolved).
  exitTargetPct: number | null;   // suggested profit target, e.g. hold for +X%
  exitStopPct: number | null;     // suggested stop loss, e.g. sell by -Y%
  exitReachRate: number | null;   // % of these setups that reached the target
  exitBasis: number | null;       // number of clean full-path trades used
}

// Per-depth coverage tally: for each number of stacked layers, how many rules
// we explored, how many cleared the honest data gate, and the best floor found.
// Powers the "3 layers · x strategies · 4 layers · needs more data" display.
export interface LayerStat {
  depth: number;
  explored: number;    // candidate rules tested at this depth
  qualified: number;   // rules that cleared the min-trades gate
  minTrades: number;   // the honest sample gate for this depth
  bestWinRate: number | null;
  bestWinRateLB: number | null;
  bestTrades: number | null;
  needMore: boolean;   // true when no rule at this depth has enough trades yet
}

export interface StrategyReviewResult {
  runAt: string;
  datasetSize: number;
  intradayResolved: number;
  baselineWinRate: number;
  bestWinRate: number;
  bestWinRateLB: number;
  bestRuleId: string;
  bestRuleLabel: string;
  bestRuleTrades: number;
  bestRuleSteps: string[];
  recommendations: ReviewRule[];
  avoid: ReviewRule[];
  trend: 'first' | 'improving' | 'flat' | 'declining';
  trendDelta: number;
  narrative: string;
  enoughData: boolean;
  layerStats: LayerStat[];
  maxDepth: number;
  // Data-driven exit plan for the single best rule (null until enough clean data).
  bestExitTargetPct: number | null;
  bestExitStopPct: number | null;
  bestExitReachRate: number | null;
  bestExitBasis: number | null;
}

function wilsonLB(wins: number, n: number, z = 1.28): number {
  if (n === 0) return 0;
  const p = wins / n;
  const denom = 1 + (z * z) / n;
  const centre = p + (z * z) / (2 * n);
  const margin = z * Math.sqrt((p * (1 - p) + (z * z) / (4 * n)) / n);
  return (centre - margin) / denom;
}

function segStats(rows: ReviewRow[]) {
  const done = rows.filter(r => r.returnPct !== null);
  const n = done.length;
  const wins = done.filter(r => (r.returnPct as number) > 0).length;
  const winRate = n ? wins / n : 0;
  const avgReturn = n ? done.reduce((s, r) => s + (r.returnPct as number), 0) / n : 0;
  return { n, wins, winRate, avgReturn };
}

// Minutes since ET midnight for an observation timestamp. Used by the
// fine-grained intraday timing conditions (9:30 = 570).
//
// Memoised on the raw epoch value: the rule search evaluates these timing tests
// millions of times, and an uncached Intl/toLocaleString call per test made a
// full-history review take many minutes instead of seconds.
const etMinutesCache = new Map<number, number>();
export function etMinutesFromMidnight(d: Date): number {
  const t = d.getTime();
  const hit = etMinutesCache.get(t);
  if (hit !== undefined) return hit;
  const s = d.toLocaleString('en-US', { timeZone: 'America/New_York', hour12: false, hour: '2-digit', minute: '2-digit' });
  const [h, m] = s.split(':').map(Number);
  const mins = h * 60 + m;
  etMinutesCache.set(t, mins);
  return mins;
}
// ET calendar day for an observation, used to measure how many SEPARATE
// sessions a rule's evidence actually spans. Memoised for the same reason.
const etDayCache = new Map<number, string>();
function etDayKey(d: Date): string {
  const t = d.getTime();
  const hit = etDayCache.get(t);
  if (hit !== undefined) return hit;
  const s = d.toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
  etDayCache.set(t, s);
  return s;
}

// The full space of conditions the review agent explores. Grouped by family so
// that combinations only ever pair conditions from DIFFERENT families (pairing
// "heat >= 50" with "heat >= 60" would be meaningless).
export function buildConditions(): Condition[] {
  const c: Condition[] = [];
  c.push({ key: 'dir-long', label: 'go long (bullish setups)', family: 'direction', test: r => r.direction === 'LONG' });
  c.push({ key: 'dir-short', label: 'go short (bearish setups)', family: 'direction', test: r => r.direction === 'SHORT' });

  c.push({ key: 'heat-40', label: 'heat strength 40+', family: 'heat', test: r => Math.abs(r.heat) >= 40 });
  c.push({ key: 'heat-50', label: 'heat strength 50+', family: 'heat', test: r => Math.abs(r.heat) >= 50 });
  c.push({ key: 'heat-60', label: 'heat strength 60+', family: 'heat', test: r => Math.abs(r.heat) >= 60 });
  c.push({ key: 'heat-70', label: 'heat strength 70+', family: 'heat', test: r => Math.abs(r.heat) >= 70 });

  c.push({ key: 'slot-open', label: 'enter at the open (9:30–11 ET)', family: 'session', test: r => r.sessionSlot === 'open' });
  c.push({ key: 'slot-midday', label: 'enter midday (11–2 ET)', family: 'session', test: r => r.sessionSlot === 'midday' });
  c.push({ key: 'slot-power', label: 'enter in the power hour (2–4 ET)', family: 'session', test: r => r.sessionSlot === 'power_hour' });
  // Finer opening windows. The first minutes after the bell are the most
  // violent stretch of the day, so "enter at the open" is too blunt a layer —
  // these let the engine test whether waiting out the initial chaos actually
  // wins more often than buying the 9:30 bell itself.
  c.push({ key: 'open-first10', label: 'enter in the first 10 minutes (9:30–9:40 ET)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 570 && etMinutesFromMidnight(r.observedAt) < 580 });
  c.push({ key: 'open-after10', label: 'enter after the first 10 minutes settle (9:40–11 ET)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 580 && etMinutesFromMidnight(r.observedAt) < 660 });
  c.push({ key: 'open-after20', label: 'enter after the first 20 minutes settle (9:50–11 ET)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 590 && etMinutesFromMidnight(r.observedAt) < 660 });
  c.push({ key: 'slot-earlypm', label: 'enter in the early afternoon (1–2 ET)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 780 && etMinutesFromMidnight(r.observedAt) < 840 });
  // Sharper early-bell slices to directly answer "is the first 5–10 minutes
  // genuinely worse?". These isolate the opening 15 minutes from the rest of
  // the first hour so the engine can PROVE, on outcomes, whether waiting past
  // the volatile bell wins more often. (Scan cadence is ~5-min bars, so 15-min
  // buckets are the finest slices the data can honestly support.)
  c.push({ key: 'open-first15', label: 'enter in the first 15 minutes (9:30–9:45 ET)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 570 && etMinutesFromMidnight(r.observedAt) < 585 });
  c.push({ key: 'open-945-1030', label: 'enter 9:45–10:30 ET (after the first chaos)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 585 && etMinutesFromMidnight(r.observedAt) < 630 });
  c.push({ key: 'open-1030-11', label: 'enter 10:30–11 ET', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 630 && etMinutesFromMidnight(r.observedAt) < 660 });
  c.push({ key: 'open-after15', label: 'enter after the first 15 minutes settle (9:45–11 ET)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 585 && etMinutesFromMidnight(r.observedAt) < 660 });
  // Afternoon slices so afternoon opportunities are first-class citizens, not an
  // afterthought — the tool must surface good setups at ANY time of day.
  c.push({ key: 'slot-latemorning', label: 'enter late morning (11–12 ET)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 660 && etMinutesFromMidnight(r.observedAt) < 720 });
  c.push({ key: 'slot-lunch', label: 'enter around lunch (12–1 ET)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 720 && etMinutesFromMidnight(r.observedAt) < 780 });
  c.push({ key: 'slot-midafternoon', label: 'enter mid-afternoon (2–3 ET)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 840 && etMinutesFromMidnight(r.observedAt) < 900 });
  c.push({ key: 'slot-close', label: 'enter into the close (3–4 ET)', family: 'session', test: r => etMinutesFromMidnight(r.observedAt) >= 900 && etMinutesFromMidnight(r.observedAt) < 960 });

  c.push({ key: 'reg-bull', label: 'when the market is trending up', family: 'regime', test: r => r.marketRegime === 'bull' });
  c.push({ key: 'reg-bear', label: 'when the market is trending down', family: 'regime', test: r => r.marketRegime === 'bear' });
  c.push({ key: 'reg-neutral', label: 'in a choppy / sideways market', family: 'regime', test: r => r.marketRegime === 'neutral' });

  c.push({ key: 'asset-stock', label: 'on individual stocks', family: 'asset', test: r => r.assetClass === 'stock' });
  c.push({ key: 'asset-etf', label: 'on ETFs', family: 'asset', test: r => r.assetClass === 'etf' });

  c.push({ key: 'rsi-os', label: 'when RSI is oversold (<35)', family: 'rsi', test: r => r.rsi !== null && r.rsi < 35 });
  c.push({ key: 'rsi-mid', label: 'when RSI is neutral (35–65)', family: 'rsi', test: r => r.rsi !== null && r.rsi >= 35 && r.rsi <= 65 });
  c.push({ key: 'rsi-ob', label: 'when RSI is overbought (>65)', family: 'rsi', test: r => r.rsi !== null && r.rsi > 65 });
  // Finer RSI slices. The coarse 35–65 "neutral" band lumps a genuinely strong
  // dip-buy zone together with a mediocre one, so the engine could never tell
  // them apart. These let it isolate deep-oversold entries (buy low) and the
  // low/high halves of neutral, and prove on real outcomes which is best.
  c.push({ key: 'rsi-deep-os', label: 'when RSI is deeply oversold (<25)', family: 'rsi', test: r => r.rsi !== null && r.rsi < 25 });
  c.push({ key: 'rsi-dip', label: 'when RSI is in the dip-buy zone (25–45)', family: 'rsi', test: r => r.rsi !== null && r.rsi >= 25 && r.rsi < 45 });
  c.push({ key: 'rsi-mid-low', label: 'when RSI is mid-low (45–55)', family: 'rsi', test: r => r.rsi !== null && r.rsi >= 45 && r.rsi < 55 });
  c.push({ key: 'rsi-mid-high', label: 'when RSI is mid-high (55–65)', family: 'rsi', test: r => r.rsi !== null && r.rsi >= 55 && r.rsi <= 65 });

  // Volume study (Phase A). These use FREE per-bar volume — magnitude, surge,
  // and a signed buy/sell-pressure proxy — NOT true order-flow (Phase B).
  c.push({ key: 'vol-surge', label: 'on a volume surge (recent volume >1.5× the prior burst)', family: 'volume', test: r => r.volumeSurge !== null && r.volumeSurge > 1.5 });
  c.push({ key: 'vol-high', label: 'on above-average volume (>1.3× the 20-bar average)', family: 'volume', test: r => r.volumeRatio !== null && r.volumeRatio > 1.3 });
  c.push({ key: 'vol-thin', label: 'on thin volume (below 70% of average)', family: 'volume', test: r => r.volumeRatio !== null && r.volumeRatio < 0.7 });
  c.push({ key: 'flow-buy', label: 'when buying pressure dominates (signed volume > +0.25)', family: 'flow', test: r => r.buyPressure !== null && r.buyPressure > 0.25 });
  c.push({ key: 'flow-sell', label: 'when selling pressure dominates (signed volume < −0.25)', family: 'flow', test: r => r.buyPressure !== null && r.buyPressure < -0.25 });
  c.push({ key: 'flow-aligned', label: 'when buy/sell pressure agrees with the trade direction', family: 'flow', test: r => r.buyPressure !== null && ((r.direction === 'LONG' && r.buyPressure > 0.15) || (r.direction === 'SHORT' && r.buyPressure < -0.15)) });

  // VWAP: position relative to the session volume-weighted average price. Above
  // VWAP = buyers in control on the day, below = sellers. 'Aligned' means price
  // is on the VWAP side that agrees with the trade (long above / short below).
  c.push({ key: 'vwap-above', label: "when price is trading above the day's VWAP", family: 'vwap', test: r => r.vwapDistPct !== null && r.vwapDistPct > 0.05 });
  c.push({ key: 'vwap-below', label: "when price is trading below the day's VWAP", family: 'vwap', test: r => r.vwapDistPct !== null && r.vwapDistPct < -0.05 });
  c.push({ key: 'vwap-aligned', label: 'when price is on the VWAP side matching the trade (long above / short below)', family: 'vwap', test: r => r.vwapDistPct !== null && ((r.direction === 'LONG' && r.vwapDistPct > 0.05) || (r.direction === 'SHORT' && r.vwapDistPct < -0.05)) });

  // ---- Entry-quality factors (the anti-"falling knife" study) --------------
  // These target the core problem: a setup can meet every criterion and still
  // keep sliding for the next 20–60 minutes. Each factor tests whether the
  // move is actually STABILIZING at entry, not just cheap. All are computed at
  // scan time from free 5-min bars and recorded on every observation.

  // Momentum direction (RSI slope over ~15 min). A LOW RSI alone is a falling
  // knife; a low-and-RISING RSI is a turn. Aligned = rising for longs / falling
  // for shorts, i.e. momentum is swinging toward the trade at the moment of entry.
  c.push({ key: 'mom-rising', label: 'when momentum is turning up (RSI rising over the last ~15 min)', family: 'momentum', test: r => r.rsiSlope !== null && r.rsiSlope > 1 });
  c.push({ key: 'mom-falling', label: 'when momentum is rolling over (RSI falling over the last ~15 min)', family: 'momentum', test: r => r.rsiSlope !== null && r.rsiSlope < -1 });
  c.push({ key: 'mom-aligned', label: 'when short-term momentum agrees with the trade (RSI rising for longs / falling for shorts)', family: 'momentum', test: r => r.rsiSlope !== null && ((r.direction === 'LONG' && r.rsiSlope > 1) || (r.direction === 'SHORT' && r.rsiSlope < -1)) });

  // Volatility (ATR as % of price). Calm entries tend to follow through; wild
  // ones whip through fixed stops. Thresholds from the measured distribution
  // (p25≈0.24%, p50≈0.42%, p75≈0.72%).
  c.push({ key: 'atr-calm', label: 'in calm conditions (ATR under 0.3% of price)', family: 'volatility', test: r => r.atrPct !== null && r.atrPct < 0.3 });
  c.push({ key: 'atr-mid', label: 'in normal volatility (ATR 0.3–0.7% of price)', family: 'volatility', test: r => r.atrPct !== null && r.atrPct >= 0.3 && r.atrPct < 0.7 });
  c.push({ key: 'atr-wild', label: 'in high volatility (ATR above 0.7% of price)', family: 'volatility', test: r => r.atrPct !== null && r.atrPct >= 0.7 });

  // VWAP reclaim/loss — a FRESH cross of the day's VWAP in the last ~15 min.
  // Buying a reclaim (price just crossed back above VWAP) is the classic
  // confirmation that the knife has stopped falling. Aligned = reclaim for
  // longs / loss for shorts.
  c.push({ key: 'vwap-reclaim', label: 'right as price reclaims the VWAP (just crossed back above)', family: 'reclaim', test: r => r.vwapReclaim === 1 });
  c.push({ key: 'vwap-lost', label: 'right as price loses the VWAP (just crossed below)', family: 'reclaim', test: r => r.vwapReclaim === -1 });
  c.push({ key: 'vwap-cross-aligned', label: 'on a fresh VWAP cross in the trade direction (reclaim for longs / loss for shorts)', family: 'reclaim', test: r => r.vwapReclaim !== null && ((r.direction === 'LONG' && r.vwapReclaim === 1) || (r.direction === 'SHORT' && r.vwapReclaim === -1)) });

  // ---- Short-period RSI (RSI 5 = ~25 min of price action) --------------------
  // Tests the user's theory: a fast RSI captures intraday/day-to-day momentum
  // changes that the standard RSI(14) smooths out. Same buckets as the standard
  // RSI family, plus a divergence condition where RSI(14) is oversold but RSI(5)
  // is already turning up — the classic multi-timeframe confirmation.
  c.push({ key: 'rsi5-low', label: 'when fast RSI(5) is oversold (below 30)', family: 'rsi5', test: r => r.rsiShort !== null && r.rsiShort < 30 });
  c.push({ key: 'rsi5-mid', label: 'when fast RSI(5) is in the neutral zone (30–70)', family: 'rsi5', test: r => r.rsiShort !== null && r.rsiShort >= 30 && r.rsiShort <= 70 });
  c.push({ key: 'rsi5-high', label: 'when fast RSI(5) is overbought (above 70)', family: 'rsi5', test: r => r.rsiShort !== null && r.rsiShort > 70 });
  c.push({ key: 'rsi-diverge-bull', label: 'bullish RSI divergence: RSI(14) still oversold but fast RSI(5) already turning up (>40)', family: 'rsi-diverge', test: r => r.rsi !== null && r.rsiShort !== null && r.rsi < 35 && r.rsiShort > 40 });
  c.push({ key: 'rsi-diverge-bear', label: 'bearish RSI divergence: RSI(14) still overbought but fast RSI(5) already dropping (<60)', family: 'rsi-diverge', test: r => r.rsi !== null && r.rsiShort !== null && r.rsi > 65 && r.rsiShort < 60 });
  c.push({ key: 'rsi-diverge-aligned', label: 'RSI divergence aligned with trade (bull-diverge for longs / bear-diverge for shorts)', family: 'rsi-diverge', test: r => {
    if (r.rsi === null || r.rsiShort === null) return false;
    if (r.direction === 'LONG') return r.rsi < 35 && r.rsiShort > 40;
    if (r.direction === 'SHORT') return r.rsi > 65 && r.rsiShort < 60;
    return false;
  } });
  return c;
}

// Reconstruct the AND-predicate for a saved rule id (condition keys joined by
// '+'). Returns a function that tests whether a row matches every layer of the
// rule. Unknown keys are ignored so an older/newer rule id never crashes.
export function getRulePredicate(ruleId: string): (r: ReviewRow) => boolean {
  const byKey = new Map(buildConditions().map(c => [c.key, c] as const));
  const conds = ruleId.split('+').map(k => byKey.get(k)).filter((c): c is Condition => !!c);
  if (conds.length === 0) return () => false;
  return (r: ReviewRow) => conds.every(c => c.test(r));
}

// The minimum absolute heat a rule requires (from its heat-XX layer), or 0 if
// the rule has no heat requirement. Used by the anticipatory "setup forming"
// pre-alerts to know how far momentum still has to build before the setup fires.
export function getRuleHeatFloor(ruleId: string): number {
  let floor = 0;
  for (const k of ruleId.split('+')) {
    const m = /^heat-(\d+)$/.exec(k);
    if (m) floor = Math.max(floor, parseInt(m[1], 10));
  }
  return floor;
}

// How many NON-heat conditions a rule stacks (direction, time, regime, asset,
// RSI, volume, flow). A rule needs at least one for an anticipatory pre-alert
// to be meaningful (otherwise "heat approaching X" would match everything).
export function ruleNonHeatConditionCount(ruleId: string): number {
  const byKey = new Map(buildConditions().map(c => [c.key, c] as const));
  return ruleId.split('+')
    .map(k => byKey.get(k))
    .filter((c): c is Condition => !!c && c.family !== 'heat').length;
}

// Predicate testing only the NON-heat layers of a rule. Lets the pre-alert ask
// "does this symbol already match the structural conditions, with heat still
// building toward the trigger?" Returns false when the rule has no non-heat
// layers so heat-only rules never generate broad forming alerts.
export function getRulePredicateExcludingHeat(ruleId: string): (r: ReviewRow) => boolean {
  const byKey = new Map(buildConditions().map(c => [c.key, c] as const));
  const conds = ruleId.split('+')
    .map(k => byKey.get(k))
    .filter((c): c is Condition => !!c && c.family !== 'heat');
  if (conds.length === 0) return () => false;
  return (r: ReviewRow) => conds.every(c => c.test(r));
}

function ruleLabel(conds: Condition[]): string {
  return `Only ${conds.map(c => c.label).join(' and ')}`;
}

function dimensionFor(conds: Condition[]): string {
  if (conds.length === 1) {
    const map: Record<string, string> = {
      direction: 'Direction', heat: 'Signal strength', session: 'Time of day',
      regime: 'Market regime', asset: 'Asset class', rsi: 'RSI condition',
      volume: 'Volume', flow: 'Order-flow proxy', vwap: 'VWAP position',
    };
    return map[conds[0].family] || 'Condition';
  }
  return `${conds.length}-layer stack`;
}

// ---------------------------------------------------------------------------
// DATA-DRIVEN EXIT PLAN
// Learn honest hold/sell percentages from the REAL full trade paths of a rule,
// never from guesses. We only use rows whose full-horizon extremes were actually
// measured (pathComplete === true), so the numbers are not biased by the old
// resolver that truncated the path at first target/stop touch.
// ---------------------------------------------------------------------------
export type ExitPlan = {
  target: number;      // suggested profit target, % (hold for +target)
  stop: number;        // suggested stop loss, % (sell by -stop)
  reachRate: number;   // % of these setups that reached +target
  basis: number;       // number of clean full-path trades used
};

const MIN_EXIT_SAMPLE = 20; // need at least this many clean trades to suggest exits

// p in [0,1]; sortedAsc is ascending. Linear-interpolated percentile.
function pct(sortedAsc: number[], p: number): number {
  if (sortedAsc.length === 0) return 0;
  if (sortedAsc.length === 1) return sortedAsc[0];
  const idx = p * (sortedAsc.length - 1);
  const lo = Math.floor(idx);
  const hi = Math.ceil(idx);
  if (lo === hi) return sortedAsc[lo];
  return sortedAsc[lo] + (sortedAsc[hi] - sortedAsc[lo]) * (idx - lo);
}

// Derive an honest exit plan from the true full-path MFE/MAE of a rule's trades.
//  - target = median distance price actually ran in favor (50th pct of MFE)
//  - reachRate = share of setups that reached that target
//  - stop = how deep WINNERS typically dipped first (75th pct of winners' MAE)
// Everything is a plain percentile of observed data — fully explainable, no guess.
function computeExit(rows: ReviewRow[]): ExitPlan | null {
  const clean = rows.filter(
    r => r.pathComplete === true && r.maxFavorablePct != null && r.maxAdversePct != null
  );
  if (clean.length < MIN_EXIT_SAMPLE) return null;

  const favs = clean.map(r => r.maxFavorablePct as number).sort((a, b) => a - b);
  let target = pct(favs, 0.5);
  target = Math.max(0.5, Math.round(target * 10) / 10);

  const reached = clean.filter(r => (r.maxFavorablePct as number) >= target).length;
  const reachRate = Math.round((reached / clean.length) * 1000) / 10;

  // Stop from how far winners dipped against us before running to target.
  const winnerAdv = clean
    .filter(r => (r.maxFavorablePct as number) >= target)
    .map(r => r.maxAdversePct as number)
    .sort((a, b) => a - b);
  const advPool = winnerAdv.length >= 8
    ? winnerAdv
    : clean.map(r => r.maxAdversePct as number).sort((a, b) => a - b);
  let stop = pct(advPool, 0.75);
  stop = Math.max(0.3, Math.round(stop * 10) / 10);

  return { target, stop, reachRate, basis: clean.length };
}

function buildStepsForRule(rows: ReviewRow[], conds: Condition[], exit?: ExitPlan | null): string[] {
  if (rows.length === 0) return [];
  const longs = rows.filter(r => r.direction === 'LONG').length;
  const shorts = rows.length - longs;
  const dirText = shorts === 0 ? 'LONG (bullish)'
    : longs === 0 ? 'SHORT (bearish)'
    : longs >= shorts ? 'mostly LONG (bullish)' : 'mostly SHORT (bearish)';
  const absHeats = rows.map(r => Math.abs(r.heat));
  const minHeat = Math.round(Math.min(...absHeats));
  const avgHeat = Math.round(absHeats.reduce((a, b) => a + b, 0) / absHeats.length);
  // Spell out EVERY supporting layer explicitly so the user can see exactly
  // which conditions must all line up before acting.
  const layerLines = conds.map((c, i) => {
    const s = c.label.charAt(0).toUpperCase() + c.label.slice(1);
    return `Layer ${i + 1}: ${s}.`;
  });
  const stackIntro = conds.length === 1
    ? 'Require this condition before you act:'
    : `Require ALL ${conds.length} supporting layers to line up at once — every one must be true before you act:`;
  const exitStep = exit
    ? `Take profit around +${exit.target}% (price reached that in ${exit.reachRate}% of these exact setups) and cap losses at −${exit.stop}% (winners rarely dipped past that first). Close by 4:00 PM ET — never hold overnight. Based on ${exit.basis} completed trades.`
    : 'Until enough of these trades finish resolving, use a starting profit target of +2% and a stop-loss of −1.5%, and close by 4:00 PM ET — never hold overnight. These will sharpen to data-driven levels as more trades complete.';
  return [
    stackIntro,
    ...layerLines,
    // Only add the generic timing window when the rule does not already carry a
    // timing layer of its own — otherwise the steps contradict themselves
    // ("enter 9:40–11" followed by "enter 9:30–12").
    ...(conds.some(c => c.family === 'session')
      ? ['Enter early enough that the trade can fully complete before the same-day close — never hold overnight.']
      : ['Enter between 9:30 AM and 12:00 PM ET so the trade can fully complete before the same-day close.']),
    'Enter between 9:30 AM and 12:00 PM ET so the trade can fully complete before the same-day close.',
    exitStep,
  ];
}

export async function runStrategyReview(): Promise<StrategyReviewResult> {
  // STRATIFIED sample across the FULL history (not just the newest rows).
  // With 100K+ observations, loading everything OOMs the ~256 MB ceiling, but
  // capping to the 8K most-RECENT rows starved the review: recent live days are
  // so dense that 8K rows only cover ~3 trading days — below MIN_DISTINCT_DAYS,
  // so no rule could ever qualify and the deep 60-day backfill was ignored.
  // Instead we cap rows PER TRADING DAY, which spans every day in the history
  // (~67 days) while keeping the total at the proven-safe ~8K footprint.
  const PER_DAY_CAP = 120;   // resolved rows sampled per trading day
  const REVIEW_CAP = 8500;   // overall safety ceiling (proven memory-safe)
  const rows: ReviewRow[] = await prisma.$queryRaw<ReviewRow[]>`
    SELECT direction, heat, "returnPct", "tradeType", "assetClass", "sessionSlot",
           "marketRegime", rsi, "volumeRatio", "volumeSurge", "buyPressure",
           "vwapDistPct", "rsiSlope", "atrPct", "vwapReclaim", "rsiShort",
           "maxFavorablePct", "maxAdversePct", "pathComplete", "observedAt", "horizonHours"
    FROM (
      SELECT *, ROW_NUMBER() OVER (
        PARTITION BY (("observedAt" AT TIME ZONE 'America/New_York')::date)
        ORDER BY random()
      ) AS rn
      FROM "SignalObservation"
      WHERE status <> 'PENDING' AND "returnPct" IS NOT NULL
    ) t
    WHERE rn <= ${PER_DAY_CAP}
    ORDER BY random()
    LIMIT ${REVIEW_CAP}
  `;

  const intraday = rows.filter(r => isIntradayExecutable(r.observedAt, r.horizonHours ?? DEFAULT_HORIZON_HOURS));
  const baseline = segStats(intraday);
  const baselineWinRate = Math.round(baseline.winRate * 1000) / 10;

  const conditions = buildConditions();

  // Assemble every candidate rule by STACKING supporting layers: each single
  // condition, then every 2-layer combo, then every 3-layer combo — always
  // drawing each layer from a DIFFERENT metric family so we keep adding genuinely
  // new evidence rather than re-stating the same idea. This is the user's
  // "add another supporting metric and see if the win rate goes even higher"
  // mandate: a deeper stack fires less often, but if it clears the honest gates
  // it is the strongest case to act on.
  type Candidate = { id: string; label: string; dimension: string; depth: number; conds: Condition[]; rule: ReviewRule };
  const candidates: Candidate[] = [];
  const exploredByDepth = new Array(MAX_STACK_DEPTH + 1).fill(0);

  // Smallest sample gate across all depths. Because stacking another layer can
  // only ever SHRINK the matching set, any branch already below this floor can
  // never produce a rule we would trust - so we stop descending it. That prune,
  // plus filtering the PARENT's rows instead of rescanning the whole history at
  // every node, is what keeps the full (untruncated) history search fast enough
  // to finish inside the request budget.
  const MIN_GATE = Math.min(...Array.from({ length: MAX_STACK_DEPTH }, (_, i) => minTradesForDepth(i + 1)));

  const buildStacks = (start: number, chosen: Condition[], parentRows: ReviewRow[]) => {
    if (chosen.length >= 1) {
      exploredByDepth[chosen.length]++;
      // Single pass, no intermediate arrays: this runs once per candidate rule.
      // We tally per DAY as well as overall so we can tell twenty independent
      // trades apart from twenty trades taken on one unusual morning.
      let sN = 0, sWins = 0, sSum = 0;
      const perDay = new Map<string, { n: number; wins: number }>();
      for (let k = 0; k < parentRows.length; k++) {
        const row = parentRows[k];
        const rp = row.returnPct;
        if (rp === null) continue;
        sN++; sSum += rp;
        if (rp > 0) sWins++;
        const day = etDayKey(row.observedAt);
        const d = perDay.get(day);
        if (d) { d.n++; if (rp > 0) d.wins++; }
        else perDay.set(day, { n: 1, wins: rp > 0 ? 1 : 0 });
      }
      const s = { n: sN, wins: sWins, winRate: sN ? sWins / sN : 0, avgReturn: sN ? sSum / sN : 0 };
      // De-clustered sample: no single session may contribute more than
      // MAX_TRADES_PER_DAY trades to the conservative floor.
      let effN = 0, effWins = 0;
      Array.from(perDay.values()).forEach(d => {
        const capped = Math.min(d.n, MAX_TRADES_PER_DAY);
        effN += capped;
        effWins += Math.round((d.wins / d.n) * capped);
      });
      const distinctDays = perDay.size;
      if (s.n >= minTradesForDepth(chosen.length) && distinctDays >= MIN_DISTINCT_DAYS) {
        // Exit plan (target/stop percentiles) is DEFERRED: it needs several
        // sorts over the matching set, and computing it for every one of the
        // hundreds of thousands of candidates is what made the search crawl.
        // We fill it in below, only for the handful of rules we actually surface.
        const id = chosen.map(c => c.key).join('+');
        const label = ruleLabel(chosen);
        const dimension = dimensionFor(chosen);
        candidates.push({
          id, label, dimension,
          depth: chosen.length,
          conds: [...chosen],
          rule: {
            id, label, dimension,
            layers: chosen.length,
            trades: s.n,
            distinctDays,
            effTrades: effN,
            winRate: Math.round(s.winRate * 1000) / 10,
            // Scored on the de-clustered sample, never the raw one. This is the
            // honest floor: it cannot be inflated by one lucky session.
            winRateLB: Math.round(wilsonLB(effWins, effN) * 1000) / 10,
            avgReturn: Math.round(s.avgReturn * 100) / 100,
            lift: Math.round((s.winRate * 100 - baselineWinRate) * 10) / 10,
            exitTargetPct: null,
            exitStopPct: null,
            exitReachRate: null,
            exitBasis: null,
          },
        });
      }
    }
    if (chosen.length >= MAX_STACK_DEPTH) return;
    const usedFamilies = new Set(chosen.map(c => c.family));
    for (let i = start; i < conditions.length; i++) {
      const cond = conditions[i];
      if (usedFamilies.has(cond.family)) continue; // one layer per family
      const sub = parentRows.filter(r => cond.test(r));
      if (sub.length < MIN_GATE) continue; // cannot qualify now, nor any deeper
      buildStacks(i + 1, [...chosen, cond], sub);
    }
  };
  buildStacks(0, [], intraday);

  const scored: ReviewRule[] = candidates.map(c => c.rule);

  // Per-depth coverage tally. "explored" counts every candidate we tested at
  // that depth; "qualified" counts those that cleared the honest trade gate.
  const layerStats: LayerStat[] = [];
  for (let d = 1; d <= MAX_STACK_DEPTH; d++) {
    const explored = exploredByDepth[d];
    const atDepth = scored.filter(r => r.layers === d).sort((a, b) => b.winRateLB - a.winRateLB);
    const top = atDepth[0];
    layerStats.push({
      depth: d,
      explored,
      qualified: atDepth.length,
      minTrades: minTradesForDepth(d),
      bestWinRate: top ? top.winRate : null,
      bestWinRateLB: top ? top.winRateLB : null,
      bestTrades: top ? top.trades : null,
      needMore: atDepth.length === 0,
    });
  }

  const rankedByLB = [...scored].sort((a, b) => b.winRateLB - a.winRateLB || b.avgReturn - a.avgReturn);

  const best = rankedByLB[0];

  const eligibleRecs = rankedByLB.filter(
    r => r.lift >= MIN_LIFT_TO_RECOMMEND && r.winRateLB > baselineWinRate,
  );

  // Breadth guarantee across BOTH direction AND time-of-day.
  //
  // A pure global top-N ranked only by confidence floor can collapse onto one
  // corner of the book: on 2026-08-19 every top rule was a midday/late-morning
  // SHORT, so the tool sent ZERO long setups and stayed dark all morning even
  // though the eligible pool held hundreds of honest long, short and all-day
  // rules covering the open. The alert engine can only surface a setup whose
  // direction AND entry time are covered by a qualifying rule, so a lop-sided
  // recommendation list silently blinds the tool to whole segments of the day.
  //
  // We fix that by deliberately keeping the strongest rules for each cell of a
  // {direction x session-bucket} matrix, plus a generous set of all-day
  // (no-session) rules per direction that blanket every entry time. Every rule
  // still clears the exact same honest gates (lift over baseline, conservative
  // sample floor) it always did -- we only ensure both sides of the book and
  // every part of the session are represented. We never lower the quality bar.
  const REC_PER_CELL = 6;         // top rules per (direction x session bucket)
  const REC_ALLDAY_PER_DIR = 10;  // extra all-day rules per direction
  const coversLong = (r: ReviewRule) => !r.id.includes('dir-short');
  const coversShort = (r: ReviewRule) => !r.id.includes('dir-long');
  // A rule carries at most one session condition (one layer per family). Map it
  // to a coarse bucket; rules with no session condition cover the whole day.
  const sessionBucket = (id: string): 'open' | 'midday' | 'power' | 'allday' => {
    if (/(?:^|\+)(?:slot-open|open-)/.test(id)) return 'open';
    if (/(?:^|\+)(?:slot-midday|slot-latemorning|slot-lunch|slot-earlypm)/.test(id)) return 'midday';
    if (/(?:^|\+)(?:slot-power|slot-midafternoon|slot-close)/.test(id)) return 'power';
    return 'allday';
  };
  const recMap = new Map<string, ReviewRule>();
  // eligibleRecs is already sorted best-first, so slice() takes the top of each
  // cell. Direction-agnostic rules qualify under both directions (deduped).
  for (const covers of [coversLong, coversShort]) {
    const pool = eligibleRecs.filter(covers);
    for (const r of pool.filter(x => sessionBucket(x.id) === 'allday').slice(0, REC_ALLDAY_PER_DIR)) recMap.set(r.id, r);
    for (const bucket of ['open', 'midday', 'power'] as const) {
      for (const r of pool.filter(x => sessionBucket(x.id) === bucket).slice(0, REC_PER_CELL)) recMap.set(r.id, r);
    }
  }
  const recommendations = Array.from(recMap.values()).sort(
    (a, b) => b.winRateLB - a.winRateLB || b.avgReturn - a.avgReturn,
  );
  const avoid = [...scored]
    .filter(r => r.lift <= MIN_LIFT_TO_AVOID)
    .sort((a, b) => a.winRate - b.winRate)
    .slice(0, 4);
  // Now that we know WHICH rules we will show, compute their exit plans. Doing
  // it here (a dozen rules) instead of inside the search (hundreds of thousands
  // of candidates) is the difference between seconds and many minutes.
  const condsById = new Map(candidates.map(c => [c.id, c.conds] as const));
  const surfaced = new Map<string, ReviewRule>();
  if (best) surfaced.set(best.id, best);
  for (const r of recommendations) surfaced.set(r.id, r);
  for (const r of avoid) surfaced.set(r.id, r);
  for (const rule of Array.from(surfaced.values())) {
    const conds = condsById.get(rule.id);
    if (!conds) continue;
    const exit = computeExit(intraday.filter(r => conds.every(c => c.test(r))));
    rule.exitTargetPct = exit ? exit.target : null;
    rule.exitStopPct = exit ? exit.stop : null;
    rule.exitReachRate = exit ? exit.reachRate : null;
    rule.exitBasis = exit ? exit.basis : null;
  }

  // Compare with the previous snapshot to report an honest improvement trend.
  const prev = await prisma.strategyReview.findFirst({ orderBy: { runAt: 'desc' } });
  let trend: StrategyReviewResult['trend'] = 'first';
  let trendDelta = 0;
  if (prev) {
    trendDelta = Math.round((((best?.winRateLB ?? baselineWinRate) - prev.bestWinRateLB)) * 10) / 10;
    trend = trendDelta > 1 ? 'improving' : trendDelta < -1 ? 'declining' : 'flat';
  }

  const bestCand = best ? candidates.find(c => c.id === best.id) : undefined;
  const bestRows = bestCand ? intraday.filter(r => bestCand.conds.every(c => c.test(r))) : [];
  const bestExit = bestCand ? computeExit(bestRows) : null;
  const bestRuleSteps = bestCand ? buildStepsForRule(bestRows, bestCand.conds, bestExit) : [];

  const enoughData = !!best;
  const narrative = buildNarrative({
    intradayResolved: baseline.n, baselineWinRate, best, recCount: recommendations.length,
    avoidCount: avoid.length, trend, trendDelta, prev: !!prev,
  });

  return {
    runAt: new Date().toISOString(),
    datasetSize: rows.length,
    intradayResolved: baseline.n,
    baselineWinRate,
    bestWinRate: best?.winRate ?? baselineWinRate,
    bestWinRateLB: best?.winRateLB ?? baselineWinRate,
    bestRuleId: best?.id ?? '',
    bestRuleLabel: best?.label ?? 'Not enough data yet',
    bestRuleTrades: best?.trades ?? 0,
    bestRuleSteps,
    recommendations,
    avoid,
    trend,
    trendDelta,
    narrative,
    enoughData,
    layerStats,
    maxDepth: MAX_STACK_DEPTH,
    bestExitTargetPct: bestExit ? bestExit.target : null,
    bestExitStopPct: bestExit ? bestExit.stop : null,
    bestExitReachRate: bestExit ? bestExit.reachRate : null,
    bestExitBasis: bestExit ? bestExit.basis : null,
  };
}

function buildNarrative(p: {
  intradayResolved: number; baselineWinRate: number; best?: ReviewRule;
  recCount: number; avoidCount: number; trend: string; trendDelta: number; prev: boolean;
}): string {
  if (!p.best) {
    return `The review agent studied ${p.intradayResolved} intraday trades but not enough matched any single refinement rule yet. As the dataset grows it will surface the conditions that genuinely raise the win rate.`;
  }
  const parts: string[] = [];
  parts.push(
    `Reviewed ${p.intradayResolved} intraday trades. The strongest honest edge right now is "${p.best.label}": ${p.best.winRate}% win rate (conservative floor ${p.best.winRateLB}%) across ${p.best.trades} trades — ${p.best.lift >= 0 ? '+' : ''}${p.best.lift} points versus the ${p.baselineWinRate}% intraday baseline.`,
  );
  if (p.recCount > 0) {
    parts.push(`${p.recCount} condition${p.recCount === 1 ? '' : 's'} genuinely beat the baseline with a solid sample and ${p.avoidCount > 0 ? `${p.avoidCount} to steer clear of` : 'none clearly worth avoiding'}.`);
  }
  if (p.trend === 'improving') parts.push(`Accuracy is improving — the best honest floor rose ${p.trendDelta} points since the last review.`);
  else if (p.trend === 'declining') parts.push(`The best honest floor slipped ${Math.abs(p.trendDelta)} points since the last review; the agent will keep watching as more trades resolve.`);
  else if (p.trend === 'flat') parts.push('Accuracy held steady versus the last review.');
  parts.push('These are counterfactual results measured on real recorded outcomes — sample-aware and never inflated. Educational only, not financial advice.');
  return parts.join(' ');
}

// Persist a review snapshot to the database.
export async function saveStrategyReview(r: StrategyReviewResult) {
  return prisma.strategyReview.create({
    data: {
      datasetSize: r.datasetSize,
      intradayResolved: r.intradayResolved,
      baselineWinRate: r.baselineWinRate,
      bestWinRate: r.bestWinRate,
      bestWinRateLB: r.bestWinRateLB,
      bestRuleId: r.bestRuleId,
      bestRuleLabel: r.bestRuleLabel,
      bestRuleTrades: r.bestRuleTrades,
      bestRuleSteps: r.bestRuleSteps,
      recommendations: r.recommendations as any,
      avoid: r.avoid as any,
      trend: r.trend,
      trendDelta: r.trendDelta,
      narrative: r.narrative,
      layerStats: r.layerStats as any,
      bestExitTargetPct: r.bestExitTargetPct,
      bestExitStopPct: r.bestExitStopPct,
      bestExitReachRate: r.bestExitReachRate,
      bestExitBasis: r.bestExitBasis,
    },
  });
}

// Run a review and store it. Used by the API and the scheduled tick.
export async function runAndSaveReview(): Promise<StrategyReviewResult> {
  const result = await runStrategyReview();
  try {
    await saveStrategyReview(result);
  } catch (e) {
    console.error('Failed to persist strategy review:', e);
  }
  return result;
}

// Run a review only if the last one is older than the given number of hours.
// Lets the scheduled agent keep reviewing roughly once a day at no extra cost.
export async function maybeRunReview(minHoursSinceLast = 20): Promise<{ ran: boolean; review?: StrategyReviewResult }> {
  const last = await prisma.strategyReview.findFirst({ orderBy: { runAt: 'desc' } });
  if (last) {
    const ageHours = (Date.now() - new Date(last.runAt).getTime()) / 3600000;
    if (ageHours < minHoursSinceLast) return { ran: false };
  }
  const review = await runAndSaveReview();
  return { ran: true, review };
}

// Fetch the latest stored review for display.
export async function getLatestReview() {
  return prisma.strategyReview.findFirst({ orderBy: { runAt: 'desc' } });
}

// Day-by-day progress: one representative snapshot per calendar day (ET), most
// recent last. Powers the accuracy progress strip so the user can watch the
// win rate and dataset grow over time. Never rewrites history — just reads it.
export async function getReviewHistory(days = 21) {
  const rows = await prisma.strategyReview.findMany({
    orderBy: { runAt: 'desc' },
    take: 400,
    select: {
      runAt: true, datasetSize: true, intradayResolved: true,
      baselineWinRate: true, bestWinRate: true, bestWinRateLB: true,
    },
  });
  // Keep the latest snapshot for each ET calendar day.
  const seen = new Set<string>();
  const perDay: typeof rows = [];
  for (const r of rows) {
    const key = new Date(r.runAt).toLocaleDateString('en-US', { timeZone: 'America/New_York' });
    if (seen.has(key)) continue;
    seen.add(key);
    perDay.push(r);
    if (perDay.length >= days) break;
  }
  return perDay.reverse();
}
```

---

## FILE: code/lib/market-scanner.ts

```typescript
/**
 * In-app 5-minute market scanner.
 *
 * Starts a setInterval timer when first imported on the server. Every 5 minutes
 * during market hours it calls the local /api/agent/tick endpoint, producing the
 * same scan + alert cycle as the external daemon — but without any external
 * scheduling dependency.
 *
 * The existing hourly daemon at :30 continues as a reliable fallback. The
 * signal-recorder's duplicate-skip logic prevents double-recording when both
 * the daemon and this timer fire at the same minute.
 */

// 5 minutes — matches the 5m bar interval we analyse, so every scan reads a
// freshly completed bar. Scanning faster than the bar interval would read
// half-formed bars (distorted volume) and manufacture false setups.
const INTERVAL_MS = 5 * 60 * 1000; // 5 minutes

// ── Fast exit-monitor cadence (Task 2 — give-back fix) ─────────────────────
// The 5-minute tick above governs ENTRIES (it must read completed 5m bars).
// But OPEN positions need to be watched far more often, or a target/stop can
// be touched and given back before the next 5-minute check ever looks. This
// separate loop calls a monitor-ONLY endpoint (no entries, no scan, no signal
// recording) every 60 seconds so exits fire close to when price hits target.
// Reversible: set MONITOR_INTERVAL_MS = INTERVAL_MS (or remove the
// monitor loop wiring in ensureScannerStarted) to restore 5-minute exits.
const MONITOR_INTERVAL_MS = 60 * 1000; // 60 seconds

let started = false;
let ticking = false; // prevents overlapping ticks (boot-tick vs aligned-tick vs daemon)
let monitoring = false; // prevents overlapping fast monitor passes

// ── Heartbeat state (in-memory, zero-cost) ─────────────────────────────────
// Records the outcome of the most recent scanner tick so the dashboard can
// show a live "active/online" health badge without any extra polling or DB
// writes. These are plain module-level variables — reading them is free.
let lastTickAt: string | null = null;        // ISO time of last successful paper tick
let lastTickOk = false;                       // did the last tick return ok?
let lastTickError: string | null = null;      // last error message, if any
let scannerStartedAt: string | null = null;   // when the timer was first armed

export interface ScannerHealth {
  scannerStartedAt: string | null;
  lastTickAt: string | null;
  lastTickOk: boolean;
  lastTickError: string | null;
  marketOpen: boolean;
  serverTime: string;
}

export function getScannerHealth(): ScannerHealth {
  return {
    scannerStartedAt,
    lastTickAt,
    lastTickOk,
    lastTickError,
    marketOpen: isMarketWindow(),
    serverTime: new Date().toISOString(),
  };
}

function isMarketWindow(): boolean {
  const now = new Date();
  // Convert to ET
  const et = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const day = et.getDay(); // 0=Sun, 6=Sat
  if (day === 0 || day === 6) return false;
  const h = et.getHours();
  const m = et.getMinutes();
  const mins = h * 60 + m;
  // Market window: 9:30 ET to 16:00 ET (we scan 9:30–15:59)
  return mins >= 9 * 60 + 30 && mins < 16 * 60;
}

// fetch with a hard timeout so a slow/hung request can never stall the whole
// scan cycle (and, crucially, can never block the paper-trading call below).
async function fetchWithTimeout(url: string, secret: string, timeoutMs: number): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    return await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${secret}` },
      signal: ctrl.signal,
    });
  } finally {
    clearTimeout(t);
  }
}

async function tick() {
  if (!isMarketWindow()) return;
  if (ticking) { console.log('[market-scanner] skipping — previous tick still running'); return; }
  ticking = true;
  try {

  const secret = process.env.AGENT_SECRET;
  if (!secret) {
    console.error('[market-scanner] AGENT_SECRET not set, skipping tick');
    return;
  }

  // Use the runtime URL — in production this is the deployed hostname
  const baseUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000';

  // ── Architecture (8/24) ──────────────────────────────────────────────────
  // Two steps every 5 minutes during market hours:
  //   1. /api/paper/tick — entries + exit management (ultra-light, imports
  //      only paper-trader → alpaca + prisma).
  //   2. /api/agent/tick?mode=alert — reads recently-recorded signals from
  //      the DB and evaluates them against qualifying rules. Pure DB+rules,
  //      no full-universe scan. Restores prompt alerting.
  //
  // Full-universe 3,430-symbol scan stays in the external hourly daemon
  // (chunked, bash-driven, separate HTTP requests). NOT done here.
  // ────────────────────────────────────────────────────────────────────────

  // ── Step 1: Paper trading tick (entries + exits) ──────────────────────
  try {
    const res = await fetchWithTimeout(`${baseUrl}/api/paper/tick`, secret, 55000);
    const data = await res.json();
    const ts = new Date().toISOString();
    if (data.ok) {
      const entered = data.entries?.entered ?? 0;
      const skipped = data.entries?.skipped ?? 0;
      const exits = data.monitor?.closed ?? 0;
      const open = data.portfolio?.openTrades ?? 0;
      const errs = (data.entries?.errors ?? []).concat(data.monitor?.errors ?? []);
      lastTickAt = ts; lastTickOk = true; lastTickError = null;
      console.log(`[market-scanner] ${ts} paper OK — entered=${entered} skipped=${skipped} exits=${exits} open=${open}` + (errs.length ? ` errors=${JSON.stringify(errs).slice(0, 200)}` : ''));
    } else {
      lastTickAt = ts; lastTickOk = false; lastTickError = JSON.stringify(data).slice(0, 200);
      console.error(`[market-scanner] ${ts} paper tick responded but ok=false:`, JSON.stringify(data).slice(0, 200));
    }
  } catch (e: any) {
    lastTickAt = new Date().toISOString(); lastTickOk = false; lastTickError = e?.message || 'fetch failed';
    console.error(`[market-scanner] paper tick fetch failed:`, e?.message);
  }

  // ── Step 2: Lightweight alert check (DB + rules only, no universe scan) ─
  // Reads recently-recorded signals from the DB and evaluates them against
  // the latest strategy review's qualifying rules. This is the piece that
  // went missing when we moved the heavy scan to the external daemon — it
  // restores prompt 5-minute alerting without any memory-heavy work.
  try {
    const alertRes = await fetchWithTimeout(
      `${baseUrl}/api/agent/tick?mode=alert`, secret, 30000
    );
    if (alertRes.status === 429) {
      // Daemon is running a full scan — alerts will fire when it finishes.
      console.log('[market-scanner] alert check skipped (daemon tick in progress)');
    } else {
      const alertData = await alertRes.json();
      const sent = alertData?.alerts?.confirmed?.sent ?? 0;
      if (sent > 0) console.log(`[market-scanner] ✅ ${sent} alert(s) sent`);
    }
  } catch (e: any) {
    // Alert failure must never block the next tick cycle.
    console.error('[market-scanner] alert check failed:', e?.message);
  }

  } finally { ticking = false; } // outer guard
}

// Fast, lightweight exit-monitor pass. Calls /api/paper/tick?mode=monitor which
// only watches open positions for target/stop/trailing/EOD exits. Never runs
// while a full tick or another monitor pass is in flight (paper-trader also has
// its own monitorInFlight mutex as the hard guarantee).
async function monitorTick() {
  if (!isMarketWindow()) return;
  if (ticking || monitoring) return;
  monitoring = true;
  try {
    const secret = process.env.AGENT_SECRET;
    if (!secret) return;
    const baseUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000';
    const res = await fetchWithTimeout(`${baseUrl}/api/paper/tick?mode=monitor`, secret, 30000);
    const data = await res.json();
    const closed = data?.monitor?.closed ?? 0;
    if (closed > 0) console.log(`[market-scanner] fast-monitor exits=${closed}`);
  } catch (e: any) {
    console.error('[market-scanner] fast-monitor failed:', e?.message);
  } finally {
    monitoring = false;
  }
}

export function ensureScannerStarted() {
  if (started || typeof globalThis === 'undefined') return;
  // Only run server-side
  if (typeof window !== 'undefined') return;
  started = true;
  scannerStartedAt = new Date().toISOString();

  // Align the timer to real 5-minute boundaries (:00, :05, :10, ...) rather
  // than to whenever the server happened to boot. We wait out the remainder of
  // the current interval, then switch to a fixed 5-minute interval.
  const now = Date.now();
  const msIntoInterval = now % INTERVAL_MS;
  const msToNextBoundary = INTERVAL_MS - msIntoInterval;

  console.log(
    `[market-scanner] Starting 5-minute market scanner — first aligned tick in ${Math.round(
      msToNextBoundary / 1000
    )}s`
  );

  setTimeout(() => {
    tick();
    setInterval(tick, INTERVAL_MS);
  }, msToNextBoundary);

  // Also fire once shortly after boot so a mid-session restart doesn't leave a
  // gap until the next quarter-hour boundary.
  setTimeout(() => tick(), 5000);

  // Fast exit-monitor loop (Task 2). Independent 60-second cadence — watches
  // open positions for exits far more promptly than the 5-minute entry tick.
  console.log(`[market-scanner] Starting ${Math.round(MONITOR_INTERVAL_MS / 1000)}s fast exit-monitor loop`);
  setInterval(monitorTick, MONITOR_INTERVAL_MS);
  setTimeout(() => monitorTick(), 8000);
}

```

---

## FILE: code/lib/market-regime.ts

```typescript
// Market Regime — MarcoFlow's "is the tide coming in or going out?" engine.
//
// Success rates are meaningless without context. A 55% win rate on longs during a
// roaring bull market is unimpressive; the same rate during a brutal downtrend is
// gold. This module measures the overall market environment (via SPY, the S&P 500
// proxy, plus VIX for fear) so every recorded signal can be tagged with the
// conditions it happened in — and so accuracy can be judged fairly.

import { fetchDailyStockData } from './data-provider';

export interface MarketRegime {
  regime: 'bull' | 'bear' | 'neutral';
  label: string;              // human-readable, e.g. "Uptrend"
  spyPrice: number;
  spyChange1d: number;        // % trailing returns
  spyChange5d: number;        // ~1 week
  spyChange1mo: number;       // ~21 trading days
  spyChange3mo: number;       // ~63 trading days
  spyChange1y: number | null; // ~252 trading days (null if <1yr history)
  aboveSma50: boolean;
  aboveSma200: boolean;
  vix: number | null;         // volatility index level (fear gauge)
  vixLevel: 'calm' | 'normal' | 'elevated' | 'high' | null;
  asOf: string;
}

// Cache the regime for a short window so a single agent tick (which scans many
// symbols) computes it only once, and repeated site requests are cheap.
let cache: { value: MarketRegime; at: number } | null = null;
const CACHE_MS = 15 * 60 * 1000; // 15 minutes

function pctChange(closes: number[], lookback: number): number {
  if (closes.length <= lookback) return 0;
  const now = closes[closes.length - 1];
  const then = closes[closes.length - 1 - lookback];
  if (!then) return 0;
  return Math.round(((now - then) / then) * 1000) / 10; // 1 decimal %
}

function sma(closes: number[], period: number): number | null {
  if (closes.length < period) return null;
  const slice = closes.slice(closes.length - period);
  return slice.reduce((s, c) => s + c, 0) / period;
}

export async function getMarketRegime(force = false): Promise<MarketRegime> {
  if (!force && cache && Date.now() - cache.at < CACHE_MS) {
    return cache.value;
  }

  // Fetch SPY daily history (~1 year). Fall back gracefully if unavailable.
  let closes: number[] = [];
  try {
    const spy = await fetchDailyStockData('SPY');
    closes = (spy?.data || []).map(d => d.close).filter(c => c > 0);
  } catch {
    closes = [];
  }

  // VIX (^VIX) — optional. If it fails, we simply omit it.
  let vix: number | null = null;
  try {
    const v = await fetchDailyStockData('^VIX');
    const vc = (v?.data || []).map(d => d.close).filter(c => c > 0);
    if (vc.length) vix = Math.round(vc[vc.length - 1] * 10) / 10;
  } catch {
    vix = null;
  }

  const spyPrice = closes.length ? Math.round(closes[closes.length - 1] * 100) / 100 : 0;
  const change1d = pctChange(closes, 1);
  const change5d = pctChange(closes, 5);
  const change1mo = pctChange(closes, 21);
  const change3mo = pctChange(closes, 63);
  const change1y = closes.length > 252 ? pctChange(closes, 252) : null;
  const sma50 = sma(closes, 50);
  const sma200 = sma(closes, 200);
  const aboveSma50 = sma50 !== null && spyPrice > sma50;
  const aboveSma200 = sma200 !== null && spyPrice > sma200;

  // Regime classification — deliberately simple and robust:
  //  - Bull: price above the 50-day average AND positive 1-month trend
  //  - Bear: price below the 50-day average AND negative 1-month trend
  //  - Neutral: anything mixed (chop / transition)
  let regime: MarketRegime['regime'] = 'neutral';
  if (aboveSma50 && change1mo > 0) regime = 'bull';
  else if (!aboveSma50 && change1mo < 0) regime = 'bear';

  const label = regime === 'bull' ? 'Uptrend' : regime === 'bear' ? 'Downtrend' : 'Choppy / Sideways';

  let vixLevel: MarketRegime['vixLevel'] = null;
  if (vix !== null) {
    if (vix < 14) vixLevel = 'calm';
    else if (vix < 20) vixLevel = 'normal';
    else if (vix < 28) vixLevel = 'elevated';
    else vixLevel = 'high';
  }

  const value: MarketRegime = {
    regime,
    label,
    spyPrice,
    spyChange1d: change1d,
    spyChange5d: change5d,
    spyChange1mo: change1mo,
    spyChange3mo: change3mo,
    spyChange1y: change1y,
    aboveSma50,
    aboveSma200,
    vix,
    vixLevel,
    asOf: new Date().toISOString(),
  };

  cache = { value, at: Date.now() };
  return value;
}

```

---

## FILE: code/prisma/schema.prisma

```prisma
generator client {
    provider = "prisma-client-js"
    binaryTargets = ["native", "linux-musl-arm64-openssl-3.0.x"]
    output = "/home/ubuntu/trading_signals_app/nextjs_space/node_modules/.prisma/client"
}

datasource db {
    provider = "postgresql"
    url      = env("DATABASE_URL")
}

model User {
  id         String                  @id @default(cuid())
  name       String?
  email      String                  @unique
  password   String
  role       String                  @default("user")
  createdAt  DateTime                @default(now())
  updatedAt  DateTime                @updatedAt
  strategies StrategyConfiguration[]
  signals    TradingSignal[]
}

model TradingSignal {
  id         String   @id @default(cuid())
  symbol     String
  signalType String
  price      Float
  strength   Float
  strategy   String
  shortMA    Float?
  longMA     Float?
  createdAt  DateTime @default(now())
  userId     String?
  user       User?    @relation(fields: [userId], references: [id])

  @@index([symbol])
  @@index([createdAt])
}

model StrategyConfiguration {
  id          String   @id @default(cuid())
  name        String
  displayName String
  parameters  Json
  isActive    Boolean  @default(true)
  userId      String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  user        User?    @relation(fields: [userId], references: [id])

  @@unique([name, userId])
}

model SignalObservation {
  id               String    @id @default(cuid())
  symbol           String
  name             String?
  observedAt       DateTime  @default(now())
  interval         String    @default("5m")
  heat             Float
  direction        String
  entryPrice       Float
  rsi              Float?
  momentum         Float?
  volumeComp       Float?
  candlestick      Float?
  trendComp        Float?
  keyDrivers       Json?
  tradeType        String?
  status           String    @default("PENDING")
  horizonHours     Float     @default(4)
  targetPct        Float     @default(2)
  stopPct          Float     @default(1.5)
  resolvedAt       DateTime?
  exitPrice        Float?
  returnPct        Float?
  maxFavorablePct  Float?
  maxAdversePct    Float?
  outcomeNote      String?
  assetClass       String?
  category         String?
  dayOfWeek        Int?
  etHour           Int?
  marketRegime     String?
  sessionSlot      String?
  spyChange1mo     Float?
  spyChange5d      Float?
  vixLevel         String?
  source           String    @default("live")
  buyPressure      Float?
  volumeRatio      Float?
  vwapDistPct      Float?
  volumeSurge      Float?
  pathComplete     Boolean?
  alertedAt        DateTime?
  formingAlertedAt DateTime?
  rsiSlope         Float?
  atrPct           Float?
  vwapReclaim      Int?
  rsiShort         Float?
  livePrice        Float?
  livePriceAt      DateTime?
  livePriceDrift   Float?
  // v2.0.0 execution bookkeeping (E1/E3/F1) — execution-only, never affects alerts/grading
  deferCount       Int       @default(0)
  skipped          Boolean   @default(false)
  skipReason       String?

  @@index([symbol])
  @@index([status])
  @@index([observedAt])
  @@index([direction])
  @@index([marketRegime])
  @@index([assetClass])
}

model StockDataCache {
  id        String   @id @default(cuid())
  symbol    String
  dataType  String
  data      Json
  fetchedAt DateTime @default(now())
  expiresAt DateTime

  @@unique([symbol, dataType])
  @@index([symbol])
  @@index([expiresAt])
}

model StrategyReview {
  id                String   @id @default(cuid())
  runAt             DateTime @default(now())
  datasetSize       Int
  intradayResolved  Int
  baselineWinRate   Float
  bestWinRate       Float
  bestWinRateLB     Float
  bestRuleId        String
  bestRuleLabel     String
  bestRuleTrades    Int
  bestRuleSteps     Json
  recommendations   Json
  avoid             Json
  trend             String   @default("first")
  trendDelta        Float    @default(0)
  narrative         String?
  layerStats        Json?
  bestExitBasis     Int?
  bestExitReachRate Float?
  bestExitStopPct   Float?
  bestExitTargetPct Float?

  @@index([runAt])
}

model DailySimulation {
  id               String   @id @default(cuid())
  simDate          String   @unique
  createdAt        DateTime @default(now())
  dayIndex         Int
  playbookRuleId   String
  playbookLabel    String
  trades           Int
  wins             Int
  losses           Int
  winRate          Float
  grossPnlPct      Float
  avgPnlPct        Float
  cumulativePnlPct Float
  baselineWinRate  Float
  outcome          String
  summary          String
  why              String
  lesson           String
  tradesJson       Json?

  @@index([simDate])
  @@index([createdAt])
}

model PaperTrade {
  id              String    @id @default(cuid())
  createdAt       DateTime  @default(now())
  symbol          String
  direction       String    // LONG or SHORT
  portionIndex    Int       // which portion slot (0-based)
  entryPrice      Float
  entryTime       DateTime
  shares          Float     // fractional for longs
  dollarAmount    Float     // ~$40 per portion
  status          String    @default("OPEN")  // OPEN, CLOSED, CANCELLED
  exitPrice       Float?
  exitTime        DateTime?
  exitReason      String?   // trailing_stop, take_profit, stop_loss, time_exit, eod_close
  returnPct       Float?
  pnlDollars      Float?
  peakPrice       Float?    // best favorable price seen
  peakPct         Float?    // best favorable % from entry
  troughPrice     Float?    // worst adverse price seen
  troughPct       Float?    // worst adverse % from entry
  trailingActive  Boolean   @default(false)
  trailingStop    Float?    // current trailing stop price
  observationId   String?   // link to SignalObservation
  alpacaOrderId   String?   // Alpaca order ID for entry
  alpacaExitId    String?   // Alpaca order ID for exit
  sessionSlot     String?   // open/midday/power_hour
  etHour          Int?      // ET hour at entry
  heat            Float?    // heat at entry
  confidence      Float?    // Wilson LB of matching rule
  ruleName        String?   // label of qualifying rule
  notes           String?
  // v2.0.0 execution fields
  stopPct                Float?   // X2 ATR-calibrated hard stop (% of entry)
  atrPct                 Float?   // ATR % of price at entry (X2/X3 input)
  trailDistancePct       Float?   // X3 trail distance locked at activation
  conditionScore         Int?     // C1 0-3
  skipReason             String?
  timeExitTrailingActive Boolean  @default(false) // X4

  @@index([status])
  @@index([symbol])
  @@index([createdAt])
  @@index([portionIndex])
}

model GuardrailOverride {
  id         String   @id @default(cuid())
  key        String   @unique
  valueJson  Json
  updatedAt  DateTime @updatedAt
  updatedBy  String?
  proposalId String?

  @@index([key])
}

model OptimizerProposal {
  id            String    @id @default(cuid())
  createdAt     DateTime  @default(now())
  runDate       String    // ET date of the nightly run
  title         String
  category      String    @default("execution")
  leak          String    // problem/leak identified in the clean execution data
  changeSummary String    // exact one-line change proposed
  guardrailKey  String?   // which guardrail this override targets (null = informational)
  proposedValue Json?
  currentValue  Json?
  backtest      String?   // backtest / evidence summary
  metricJson    Json?
  status        String    @default("PENDING")  // PENDING, APPROVED, DECLINED
  decidedAt     DateTime?
  decidedBy     String?
  comment       String?
  applied       Boolean   @default(false)

  @@index([status])
  @@index([runDate])
  @@index([createdAt])
}

model ChangeLogEntry {
  id           String   @id @default(cuid())
  createdAt    DateTime @default(now())
  etDate       String   // ET date (YYYY-MM-DD) for day grouping
  type         String   // proposal_created | approved | declined | override_applied | override_reset | app_update
  title        String
  detail       String?
  guardrailKey String?
  fromValue    Json?
  toValue      Json?
  actor        String?  // optimizer | owner email | system
  proposalId   String?

  @@index([etDate])
  @@index([createdAt])
  @@index([type])
}

// Update 6.2 (9/21/26) — durable key/value state for the self-healing heartbeat
// and other agent orchestration that must survive serverless instance recycling.
// The in-app scan cursor, heartbeat lease lock, and "daily brief already sent
// today" marker all live here so a fleet of ephemeral instances stays consistent.
model AgentState {
  key       String   @id
  valueJson Json
  updatedAt DateTime @updatedAt
}

```
