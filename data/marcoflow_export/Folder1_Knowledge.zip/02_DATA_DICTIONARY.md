# 02 — Data Dictionary

All tables are in `data/marcoflow.sqlite` and as CSVs in `data/`. Column types are listed in `data/export_manifest.json`. Timestamps are UTC ISO strings. Percent columns are in **percent units** (1.5 = 1.5%) unless noted.

## Row counts (export 2026-10-02)

| Table | Rows | What it is |
|---|---|---|
| SignalObservation | 167,645 | Every recorded signal and its resolved outcome. The core research dataset. |
| PaperTrade | 2,714 | Every paper position (Alpaca paper account) with real fills |
| StrategyReview | 84 | Daily rule-mining runs (best rules, narratives, layer stats) |
| DailySimulation | 21 | Day-by-day playbook simulations with lessons |
| StrategyConfiguration | 88 | Saved Strategy Lab configurations (user id removed) |
| ChangeLogEntry | 8 | Audit trail of optimizer proposals, approvals and overrides |
| OptimizerProposal | 2 | Optimizer proposals and their decisions |
| AgentState | 4 | Internal state: heartbeat cursor and lease, Daily Brief last sent, trading-concluded flag |
| GuardrailOverride | 0 | Runtime guardrail overrides (none active at export) |
| rsi_runs | 1 | Optimizer run record |

## SignalObservation

One row per recorded signal (|heat| ≥ 30, deduped 90 min per symbol+direction).

| Column | Meaning |
|---|---|
| id, symbol, name | Identity |
| observedAt | When the signal was recorded (UTC) |
| interval | Bar interval used (mostly `5m`) |
| heat | Heat Score −100..+100 (sign = direction) |
| direction | `LONG` / `SHORT` |
| entryPrice | Price at observation |
| rsi, momentum, volumeComp, candlestick, trendComp | Heat components. `momentum` is the recent % move; ≥ +5 = rip, ≤ −5 = drop |
| keyDrivers | JSON text of drivers behind the score |
| tradeType | `intraday` / `short_swing` / `long_swing` |
| status | `PENDING` / `WIN` / `LOSS` / `EXPIRED` |
| horizonHours, targetPct, stopPct | Resolution rule for this row (classic default 4h / +2% / −1.5%) |
| resolvedAt, exitPrice, returnPct | Outcome at resolution |
| maxFavorablePct, maxAdversePct | Best and worst excursion during the horizon |
| outcomeNote | Free text (backfill rows prefixed `[backfill]`) |
| assetClass, category | `stock`/`etf`; sector/category |
| dayOfWeek, etHour, sessionSlot | ET context. Slots: open 9:30–11, midday 11–14, power_hour 14–16 |
| marketRegime, spyChange5d, spyChange1mo, vixLevel | Market backdrop (bull/neutral/bear; VIX calm/normal/elevated/high) |
| source | `live` or `backfill` (historical replay; no regime tags, no candlesticks) |
| buyPressure, volumeRatio, volumeSurge | Volume/flow features |
| vwapDistPct, vwapReclaim, atrPct, rsiSlope, rsiShort | Later-added features (RSI(5) = rsiShort) |
| pathComplete | Whether the full price path was evaluated |
| alertedAt, formingAlertedAt | When an alert / "forming" alert fired for this row (null = not alerted) |
| livePrice, livePriceAt, livePriceDrift | Live price check at alert/entry time |
| deferCount, skipped, skipReason | v7 entry handling (E3 defers; `stale_skip`, `momentum_conflict_skip`, `etf_divergence_skip`) |

**Important:** a `WIN` here means the *signal* hit its target under the tracker's rules. It does not mean a paper trade made money. Use `PaperTrade.observationId` to link.

## PaperTrade

| Column | Meaning |
|---|---|
| id, createdAt, symbol, direction | Identity |
| portionIndex | Position slot index within the fund |
| entryPrice, entryTime, shares, dollarAmount | Entry (real Alpaca fill) |
| status | `CLOSED` or open |
| exitPrice, exitTime, exitReason | Exit (real Alpaca fill since 8/28) |
| returnPct, pnlDollars | Outcome (percent units; dollars) |
| peakPrice, peakPct, troughPrice, troughPct | Best and worst move while held — basis for give-back analysis |
| trailingActive, trailingStop | Trailing-stop state |
| observationId | FK → SignalObservation.id |
| alpacaOrderId, alpacaExitId | Broker order ids |
| sessionSlot, etHour, heat, confidence, ruleName | Context; `ruleName` = the strategy-review rule that triggered the alert |
| notes | Free text (e.g. fill-slippage flags) |
| stopPct, atrPct, trailDistancePct, conditionScore, skipReason, timeExitTrailingActive | v7 fields (X2 stop, X3 trail, C1 sizing, X4 time-exit trail) |

**Exit reasons:** `take_profit`, `stop_loss`, `trailing_stop`, `time_exit`, `time_exit_trailing` (v7 X4), `eod_close` (3:55 PM flatten). (`giveback_lock` exists in code but never fired — that guard was never on in live trading.) 5 open trades have an empty exit reason.

## Other tables

- **StrategyReview:** `runAt`, dataset sizes, `baselineWinRate`, `bestWinRate`, `bestWinRateLB` (Wilson LB, the alert gate uses ≥ 60), `bestRuleId/Label/Trades/Steps`, `recommendations`, `avoid`, `trend`, `narrative`, `layerStats` (JSON), `bestExit*` (best exit basis/target/stop found).
- **DailySimulation:** one row per simulated day: rule used, trades, wins/losses, P&L %, `outcome`, `summary`, `why`, `lesson`, `tradesJson`.
- **OptimizerProposal / ChangeLogEntry / GuardrailOverride:** the optimizer's propose → approve → apply → reset trail. Both approved overrides were reset on 9/28.
- **AgentState:** keys `heartbeat_scan_cursor` {offset, universe}, `heartbeat_lease` {until}, `daily_brief_last_sent` {etDate}, `trading_concluded` {etDate}.

## Data eras and caveats (read before analysing)

1. **Pre-8/28 exit prices are partly corrupted.** A quote bug recorded some exits at prices never traded (false instant stop-outs). That is why the pre-3.0 era looks like 53.9% win. Use `entryTime >= '2026-08-28'` for execution analysis.
2. **Configuration changed often.** Compare like with like by era (boundaries in 03 and 01). Longs were benched 9/2 and later reopened only as "movers", so paper-level long data is thin and biased. Use SignalObservation for direction research.
3. **Missing days = system down, not "no setups".** No paper trades on 9/23 and 9/24 (scheduler orphaned), plus weekends and holidays. 9/22 is partial (683 observations). 10/2 is partial (export mid-session).
4. **Backfill vs live.** `source='backfill'` rows come from a historical replay with a simpler Heat Score (no candlesticks) and no regime tags. Do not mix them into live-performance claims without labelling.
5. **Two different "win rates".** Observation-level (signal right under target/stop/horizon) and paper-level (dollars captured after fills). The gap between them is MarcoFlow's main unsolved problem.
6. **Strategy-review win rates** use their own exit basis (`bestExit*`) on a stratified sample, so they will not match either of the above exactly.
7. **ET conversion.** Stats in 03 use ET = UTC − 4 (EDT). Correct for EST if you extend into November.
8. **Universe grew** from ~64 tracked symbols (backfill) → ~2,100 (mid-August) → ~3,437 (September). Raw counts are not comparable across those periods.
9. **Open/pending rows.** 5 paper trades were open and 1,061 observations PENDING at export.
