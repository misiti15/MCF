# 01 — System Overview and History

> Educational only — not financial advice.

## What MarcoFlow is

A web app (marcoflow.abacusai.app) that scans a large US equity/ETF universe intraday, scores each symbol with a composite **Heat Score** (−100 to +100), records every qualifying signal, measures how those signals actually play out, mines the history for high-confidence rule combinations, alerts on live setups that match those rules, and paper-trades them on an Alpaca paper account. Owner philosophy from day one: **conservative signals, quality over quantity, never inflate scores; data recording and accuracy matter more than anything else.**

## Pipeline (as of v7.0.0)

```
Universe (~3,437 symbols) ──► Scanner (5-min cadence, market hours)
        │                         └─ Heat Score per symbol (code/lib/heat-tracker.ts)
        ▼
Signal Recorder  ── records |heat| ≥ 30, 90-min dedupe per symbol+direction
        │            tags regime, session, VWAP/ATR/RSI-slope, volume features
        ▼
SignalObservation table ── later resolved WIN/LOSS/EXPIRED vs target/stop/horizon
        │
        ├──► Strategy Review (pre-market daily): stratified sample (≤120 rows/day,
        │     ~8.5k rows) → rule stacks ranked by Wilson lower bound (z=1.28)
        ▼
Alert Checker ── fires when a fresh signal matches a rule with Wilson-LB ≥ 60
        ▼
Paper Trader (Alpaca paper) ── guardrails → entry → monitor → exit
        │   $80k fund, $640 per portion (v7: $640 full / $320 half by condition score)
        ▼
PaperTrade table ── real Alpaca fills, peak/trough, exit reason
        ▼
Daily Brief email (one per day, after close) + /monitor + /changelog pages
```

### Data sources
- **Yahoo Finance** (free) for 5-minute bars used by scanning and Heat Score. About 15 minutes delayed; ~60 days of 5m history and ~7 days of 1m.
- **Alpaca** (paper account, IEX feed) for quotes, trades, 1-minute bars (v7 direction check), order placement and real fill prices. The IEX feed is roughly 2–3% of consolidated volume, which matters for any liquidity/ADV math.
- Market regime: SPY and VIX daily data → bull/neutral/bear plus VIX level.

### Heat Score ingredients
Volume (surge and ratio), momentum, RSI(14), price action, EMA9/EMA21 trend, MACD and 13 candlestick patterns, plus an alignment bonus when components agree. Implementation: `code/lib/heat-tracker.ts`. **The owner has said not to change the Heat Score calculation.**

### Scheduling / drivers
- **Hourly platform scheduled task** ("MarcoFlow Signal Tracker", weekdays 8–16 ET): calls `/api/agent/tick` (record, resolve, alert, review) and drives the post-close Daily Brief. It has repeatedly lost its next-run anchor ("orphaned") — see 05.
- **In-app 5-minute scanner** (`code/lib/market-scanner.ts`): during market hours runs the paper tick and the alert pass.
- **Heartbeat endpoint** (`/api/agent/heartbeat`, Update 6.2): self-orchestrating, idempotent, meant to be pinged every 1–2 minutes by an external cron. Persists a scan cursor and a lease in `AgentState`.

## Timeline

| Date (2026) | Milestone / Update | What changed |
|---|---|---|
| ~May–Jul | Milestones 1–6c | Dashboard, Heat Score, screener, Ask Marco AI, backtester (M5), Strategy Lab with plain-English strategies, provenance, rules readout (M6/6b/6c) |
| — | Milestone 7 | Outcome-tracking agent: `SignalObservation`, hourly tick, Live Accuracy. Owner's stated top priority. |
| — | Milestone 7b | Market regime engine, session tags, Top-5 strategy discovery by Wilson LB, `/monitor` live feed |
| — | Milestone 7c | Historical backfill: ~60 days of 5m bars replayed; rows tagged `source='backfill'` |
| 8/13–8/14 | Persistence test, cadence | Persistence filter tested and rejected (negative). Scan cadence cut 15 min → 5 min (the floor). Universe ~2,100 symbols at this time. |
| 8/20 | Paper trading starts | First paper trades on Alpaca paper |
| 8/24 | Milestones 10–11 | 5-min alerting restored; pre-market strategy review; review capped (memory). Stratified per-day sample restored strong rules (best LB 78.8). |
| 8/27 | **Update 3.0** | Exit-price accuracy fix: one-sided IEX quotes produced half-price "mids" and false instant stop-outs; exits now use the real Alpaca fill. **Clean execution data starts 8/28.** |
| 9/2 | Guardrail tasks 1–6 | Longs benched (later reopened in "movers" mode), skip entry hours 9 and 12 ET, knife guard (no shorts at RSI ≤ 30), liquidity gate (price ≥ $3, spread ≤ 4%) |
| 9/7 | **Update 3.5** (+ same-day correction) | Directional move gate: skip only shorts that fade a ≥ +5% rip; keep shorts that follow drops. Longs in "movers" mode. Stale-entry guard and fill-slippage flagging. ADV tooling (gate off). Daily Brief groundwork. |
| 9/10 | Daily Brief | Post-close emails consolidated to ONE concise brief |
| 9/11 | **Update 4.0** | `maxPositionsPerSymbol = 1` (duplicate-fill fix). ADV gate calibrated and held OFF (blocks ~93% of flow). Single-feature short vetoes built, backtested, held OFF (harmful). |
| 9/17 | **Update 5.0** | Marketable-limit exits (0.3% through the touch, market fallback) — core exit-slippage fix |
| 9/18 | **Updates 6.0 / 6.1** | Nightly execution optimizer (propose-only, owner approves) + runtime guardrail overrides; `/changelog` audit trail |
| 9/21 | **Update 6.2** | Self-healing heartbeat endpoint with persisted scan cursor and lease |
| 9/25 | External cron | Owner set up an external cron to ping the heartbeat (later found not firing consistently — see 05) |
| 9/28 | **Update 7.0 (v7.0.0)** | Execution/exit overhaul from the owner's spec (`specs/update_7.0_execution_spec.md`): E1 freshness (skip if price moved > 0.5% past trigger), E3 1-min direction confirmation (defer up to 2, then skip), X1 take-profit on bid/ask, X2 ATR/session stops, X3 session-aware trailing, X4 T−30 time-exit trail, F1 skip ETFs with RSI divergence, C1 condition-weighted sizing. Optimizer paused; both optimizer-approved overrides switched off. |
| 9/29 | First v7 session | — |
| 10/2 | This export | — |

Release notes as stored in the app: `code/lib/app-updates.ts`.

## Key code locations (in `code/`)

| Concern | File |
|---|---|
| Heat Score | `lib/heat-tracker.ts`, `lib/candlestick-patterns.ts` |
| Universe and scanning | `lib/stock-screener.ts`, `lib/universe-extra.ts`, `lib/market-scanner.ts` |
| Signal recording and resolution | `lib/signal-recorder.ts` |
| Rule mining (Wilson LB) | `lib/strategy-review.ts` |
| Alerts | `lib/alert-checker.ts` |
| Paper trading | `lib/paper-trader.ts`, `lib/execution-v2.ts` |
| Guardrails (all toggles, with rationale and backtest numbers in comments) | `lib/trading-guardrails.ts` |
| Broker client | `lib/alpaca.ts`, `lib/realtime-quotes.ts` |
| Regime | `lib/market-regime.ts` |
| Daily Brief, post-mortems, self-correction | `lib/daily-brief.ts`, `lib/trade-postmortem.ts`, `lib/self-correction.ts`, `lib/eod-*.ts` |
| Schema | `prisma/schema.prisma` |
| Orchestration | `api/agent/tick`, `api/agent/heartbeat`, `api/paper/tick` |
