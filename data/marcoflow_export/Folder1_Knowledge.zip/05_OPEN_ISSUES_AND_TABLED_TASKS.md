# 05 — Open Issues and Tabled Tasks

> Educational only — not financial advice. Status as of 2026-10-02.

## A. Reliability (highest impact on data completeness)

| Issue | Detail | Status |
|---|---|---|
| **Hourly scheduled task keeps orphaning** | The platform scheduled task that drives `/api/agent/tick` repeatedly lost its next-run anchor between sessions (9/18, 9/21, 9/23–9/24 fully down). It was re-anchored by hand each time. | Recurring. It did run 9/30–10/2 (Daily Brief last sent 10/1; trades recorded every day). |
| **External heartbeat cron not firing** | `AgentState.heartbeat_scan_cursor` was last updated **2026-09-29 15:11 UTC**. Nothing has pinged `/api/agent/heartbeat` since, so the owner's external cron is not working. | Open — owner's cron service needs checking. Until fixed, MarcoFlow depends on the orphan-prone hourly task. |
| **On-platform backstop never registered** | A backstop shell script exists but no scheduler runs it. | Open |
| **Lesson for any new system** | Use an always-on external scheduler, and check health by querying data counts per ET day, never by a log file. | — |

## B. Execution and data problems

| Issue | Detail | Status |
|---|---|---|
| Duplicate-entry fill race | Same-symbol re-entries < 60 s apart within one scan (−$1,095 marginal). No guardrail key can fix it; needs an app-side single-flight/dedupe on symbol. | Open |
| Give-back on winners | Trades peaking ≥ 1% keep about a third of the peak. Both optimizer fixes were switched off 9/28; v7 X3/X4 (session trailing, time-exit trail) is the current attempt. | Being measured under v7 |
| "Never worked" trades | 840 trades, −$3,956. Owner wants the *why* diagnosed. | Open (priority #2) |
| ADV / liquidity data | No consolidated average-dollar-volume series stored; IEX ADV is misleading. | Blocked on data |
| Data latency | Yahoo bars are ~15 min delayed. Persistence test put the cost of 15 min latency at ~14 win-rate points. | Open: real-time data on the short-list only is the recommended path |
| Update 7.0 validation | Live since 9/29; too few sessions to judge. | Measure |

## C. Tabled / deferred tasks (not started)

| Task | Origin | Note |
|---|---|---|
| Heat-score weighting backtest | Update 3.0 (8/27) | Needed clean exit data first; clean data now exists. Owner said not to change Heat Score during reviews — analysis only unless asked. |
| Direction-thesis review (shorting bounces after big moves) | Update 3.0 | Partly answered by the follow-drop / fade-rip work |
| Two-tick confirmation before a stop fires | Update 3.0 | Optional |
| Expand universe **together with** an ADV gate | Update 3.5 | Owner-prioritised milestone; needs real ADV data |
| Real-time quotes on short-listed symbols + Robinhood execution | August | Robinhood agentic trading is invite-only beta |
| Learning loop: feed live accuracy back into scoring | Original roadmap | Owner's stated top long-term interest |
| Optimizer revamp | 9/28 | Paused by the owner pending a redesign. Do not run the old one. |
| Tighter hard stop (0.8%) | Update 4.0 | Deferred — marginal evidence |
| Weekly email summary toggle | Original roadmap | Low priority |

## D. Hazards for anyone touching the MarcoFlow database

- Never run a schema push that drops tables (it wants to drop `rsi_runs`). Use additive SQL only.
- The database has a 5-second statement timeout and ~25 connections. Page large reads (keyset pagination). Full-table scans of SignalObservation can exhaust memory in production.
- The database is shared between MarcoFlow preview and production. Treat it as read-only from any other system. Use the API in 07 or this export instead of connecting directly.
