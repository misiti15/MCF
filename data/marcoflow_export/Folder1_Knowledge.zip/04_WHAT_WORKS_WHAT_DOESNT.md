# 04 — What Works, What Doesn't

> Educational only — not financial advice. "Win %" is labelled as either **signal-level** (SignalObservation, the tracker's own target/stop/horizon) or **paper-level** (PaperTrade, real fills). Clean window = 2026-08-28 onward unless stated. Figures marked *(recomputed 10/2)* were calculated from `data/marcoflow.sqlite` for this pack; others are the figures recorded at the time of the decision.

## The one-paragraph summary

MarcoFlow's **signals carry some edge** (alerted signals beat non-alerted ones; shorts that follow drops beat shorts that fade rips), but **paper trading has lost money in every clean era** (−$3,241 on 2,123 closed trades since 8/28, 32.4% paper win rate on shorts). The loss comes from two places: (1) **execution drag** — the same traded signals score 44.1% / −0.03% at signal level but 32.3% / −0.28% in paper; and (2) **trades that never work at all** — 840 trades never moved more than 0.15% in favour and lost −$3,956, more than the whole book. Winners also give back most of their peak. The owner's priorities follow directly: **#1 capture more of great moves (execution quality), #2 understand why bad alerts happen — without filtering or capping entries.**

---

## What works (or at least helps)

### 1. Alert gating by Wilson lower bound adds selection value
*(recomputed 10/2)* Live resolved observations since 8/28: **alerted 45.4% WIN (n=6,190)** vs **not alerted 34.2% (n=45,920)**. Rule stacks are mined daily on a stratified sample (≤120 rows per trading day) and only rules with Wilson-LB ≥ 60 fire alerts. The stratified sample matters: sampling only the most recent rows (8/24) left the review blind and killed all qualifying rules. Recent best rule LB: 78.2 (10/2 pre-market review).

### 2. Short the drop, don't fade the rip
- **At decision time (9/7):** short + momentum ≤ −5 = 668 obs, **75.7%** WIN, +0.17%; short + momentum ≥ +5 = 81 obs, 43.9%, −0.34%. This drove the directional gate (skip only rip-fades).
- *(recomputed 10/2, much larger sample, current resolution rules)*: follow-drop **56.1% (n=8,857, −0.044%)** vs fade-rip **46.7% (n=1,309, −0.024%)**. By era, follow-drop: 58.9% → 54.6% → 56.1%; fade-rip: 43.7% → 50.9% → 44.4%.
- **Honest read:** the direction of the effect has held for win rate, but the gap is far smaller than the 9/7 sample suggested and neither bucket is positive on average return at signal level. Treat 75.7% as a small-sample high-water mark, not the expected rate.

### 3. Real fills and marketable-limit exits
- Update 3.0 (8/27): recording the real Alpaca fill instead of a computed mid removed false instant stop-outs. Example verified against the broker: a recorded −7.27% loss was really about −0.2%.
- Update 5.0 (9/17): marketable-limit exits (0.3% through the touch, market fallback) improved stop-loss fills (average stop return −1.09% after vs −1.52% before, per optimizer notes).

### 4. Trailing stops and take-profits are the only profitable exit paths
*(clean window)* trailing_stop: 664 trades, 56.2% win, +$396. take_profit: 348, 46.6%, +$909. stop_loss: 608, −$3,841. time_exit: 486, −$710. (Full table in 03.)

### 5. Count-based one-position-per-symbol cap
`maxPositionsPerSymbol = 1` (9/11) closed a within-tick duplicate-fill hole. Duplicates are still the subject of an open race (see 05).

### 6. Liquidity basics
Minimum price $3 and maximum entry spread 4% at entry. Many legitimate skips come from this plus "not shortable" responses from Alpaca.

---

## What doesn't work (tested and rejected)

| Idea | Result | Status |
|---|---|---|
| **Persistence filter** (enter only if the signal persists 15 min) | In hindsight 53.2% vs 38.9%, but tradeable at t+15m it is 38.9% — no better than baseline. The 15-minute wait consumes the edge. | Rejected 8/14. Byproduct: ~14 points is the cost of 15 min latency — strongest argument for faster data. |
| **Scanning faster than 5 min** | 5 min matches the bar interval; faster reads half-formed bars and creates false setups. | 5 min is the floor |
| **buyPressure > 0 short veto** | Blocked shorts were still 59.3% / +0.063% — the veto removes profit | Built, OFF |
| **rsiSlope > 0 short veto** | Blocked shorts were *better* (61.9% / +0.096%) | Built, OFF. Owner rule: never hard-veto shorts on rising RSI alone; require multiple confirming factors. |
| **Blunt move-magnitude gate** (skip all shorts with |momentum| ≥ 5) | Removed the best population (drop-follows) | Corrected same day to skip rip-fades only |
| **Flat-chop floor for shorts** | Flat shorts were fine (81% at the time) | OFF |
| **ADV gate at $20M (IEX)** | Blocks ~93% of signal flow — IEX volume is only ~2–3% of the tape, so $20M IEX ≈ $700M–$1B consolidated | Built, OFF pending proper data/calibration |
| **Tighter hard stop (0.8% vs 1.25%)** | Marginal, path-order-approximate edge for shorts, none for longs | Deferred |
| **Resting short take-profit** (optimizer #1, approved 9/20) | Post-change TP exits still gave back ~2% of peak (n=26, regime-confounded) | Switched off 9/28 by owner |
| **Give-back lock** (exit when a ≥ 0.8% peak falls to ≤ 0.5%) | Backtest +$173, but ~2/3 of give-back was exit fill-slippage a tick-based lock can't fix; may cap runners | Never live; owner switched it off 9/28 |
| **AI-generated chart images** in Strategy Lab | Misleading for a trading tool | Rejected; all visuals are data-derived |
| **Robinhood as bulk data feed** | Invite-only beta, desktop/agent-bound, ~100 req/min class limits vs ~50 req/s needed for a full scan | Not usable for scanning; possible for execution / short-list quotes |
| **Unofficial broker API wrappers** | Account-suspension risk | Never use |

---

## Where the money is lost (clean window, from 03)

| Peak favourable move | Trades | Avg peak | Avg captured | Ended red | P&L |
|---|---|---|---|---|---|
| ≥ 1% | 390 | 1.78% | 0.59% | 149 | +$1,254 |
| 0.5–1% | 327 | 0.69% | 0.18% | 90 | +$281 |
| 0.15–0.5% | 566 | 0.31% | −0.27% | 376 | −$821 |
| < 0.15% ("never worked") | 840 | 0.02% | −0.87% | 818 | −$3,956 |

- **Give-back:** trades that reached ≥ 1% kept only about a third of the peak; 149 of 390 still closed red.
- **Never-worked trades** are the bulk of losses. Understanding *why* these alerts fail (wrong direction right after a big swing, regime mismatch, stale entry, illiquid names) is the owner's priority #2 — not filtering them out.
- **Execution drag** *(recomputed 10/2)*: for the 2,076 clean paper trades with a resolved source signal, signal-level 44.1% / −0.03% vs paper-level 32.3% / −0.28%: roughly 0.25 points lost per trade between signal and fill/exit.
- **Regime:** late September was hostile to the short book (weekly paper win rate 47.4 → 33.7 → 38.8 → 27.0 → 24.3 through 9/25). Always evaluate changes on cohorts, not the headline number.
- **Position duplication:** 111 symbol-days with ≥ 3 same-day entries; 450 extra entries cost about −$1,095; 98% were < 60 s apart with the same portion index (a fill race, not strategy).
- **Entry hours:** 9 and 12 ET are skipped for entries since 9/2 (data showed weak results). The owner has said not to change this.
- **Longs:** paper longs are thin and negative (167 trades, 25.1%, −$661). Signal-level long data is the better source.

## Update 7.0 — too early to judge
First session 9/29. 9/29–10/2: 307 trades, 33.6% win, −$373 (10/1 alone −$327 at 11.5% win). v7 skips so far: 23 stale, 21 direction-conflict, 14 ETF-divergence. Needs more sessions before any conclusion.
