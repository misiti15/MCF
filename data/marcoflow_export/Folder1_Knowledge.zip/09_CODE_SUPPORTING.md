# MarcoFlow supporting code (data, broker, reports, API routes)

Reference snapshot from MarcoFlow (2026-10-02). Read-only reference; not runnable on its own. Educational only — not financial advice.


---

## FILE: code/lib/alpaca.ts

```typescript
/**
 * Alpaca Markets REST client — paper-trading only.
 *
 * Provides typed wrappers around the Alpaca v2 API for:
 *   - Account info
 *   - Placing / cancelling orders (market & limit)
 *   - Listing / closing positions
 *   - Fetching latest quotes
 *
 * All calls hit the PAPER endpoint (paper-api.alpaca.markets).
 */

const BASE = 'https://paper-api.alpaca.markets';
const DATA_BASE = 'https://data.alpaca.markets';

function headers(): Record<string, string> {
  const keyId = process.env.ALPACA_API_KEY_ID;
  const secret = process.env.ALPACA_API_SECRET_KEY;
  if (!keyId || !secret) throw new Error('Alpaca API keys not configured');
  return {
    'APCA-API-KEY-ID': keyId,
    'APCA-API-SECRET-KEY': secret,
    'Content-Type': 'application/json',
  };
}

async function api<T>(path: string, opts?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, { ...opts, headers: { ...headers(), ...(opts?.headers || {}) } });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Alpaca ${opts?.method || 'GET'} ${path} ${res.status}: ${body.slice(0, 300)}`);
  }
  // DELETE /positions returns 200 with body or 204 no-content
  if (res.status === 204) return {} as T;
  return res.json() as Promise<T>;
}

async function dataApi<T>(path: string): Promise<T> {
  const res = await fetch(`${DATA_BASE}${path}`, { headers: headers() });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Alpaca data ${path} ${res.status}: ${body.slice(0, 300)}`);
  }
  return res.json() as Promise<T>;
}

// ---- Types ----
export interface AlpacaAccount {
  id: string;
  status: string;
  cash: string;
  equity: string;
  buying_power: string;
  portfolio_value: string;
  pattern_day_trader: boolean;
  daytrade_count: number;
}

export interface AlpacaOrder {
  id: string;
  client_order_id: string;
  symbol: string;
  side: 'buy' | 'sell';
  qty: string | null;
  notional: string | null;
  filled_qty: string;
  filled_avg_price: string | null;
  type: string;
  status: string;
  submitted_at: string;
  filled_at: string | null;
}

export interface AlpacaPosition {
  asset_id: string;
  symbol: string;
  qty: string;
  side: 'long' | 'short';
  avg_entry_price: string;
  current_price: string;
  market_value: string;
  unrealized_pl: string;
  unrealized_plpc: string;
}

export interface AlpacaQuote {
  symbol: string;
  ask_price: number;
  bid_price: number;
  last_price: number;
  timestamp: string;
}

// ---- Account ----
export async function getAccount(): Promise<AlpacaAccount> {
  return api<AlpacaAccount>('/v2/account');
}

// ---- Orders ----
export interface OrderRequest {
  symbol: string;
  side: 'buy' | 'sell';
  type?: 'market' | 'limit';
  time_in_force?: 'day' | 'gtc' | 'ioc';
  qty?: string;          // share count (shorts)
  notional?: string;     // dollar amount (longs)
  limit_price?: string;
}

export async function placeOrder(req: OrderRequest): Promise<AlpacaOrder> {
  return api<AlpacaOrder>('/v2/orders', {
    method: 'POST',
    body: JSON.stringify({
      symbol: req.symbol,
      side: req.side,
      type: req.type || 'market',
      time_in_force: req.time_in_force || 'day',
      ...(req.notional ? { notional: req.notional } : {}),
      ...(req.qty ? { qty: req.qty } : {}),
      ...(req.limit_price ? { limit_price: req.limit_price } : {}),
    }),
  });
}

export async function getOrder(orderId: string): Promise<AlpacaOrder> {
  return api<AlpacaOrder>(`/v2/orders/${orderId}`);
}

export async function cancelOrder(orderId: string): Promise<void> {
  await api<void>(`/v2/orders/${orderId}`, { method: 'DELETE' });
}

// ---- Positions ----
export async function getPositions(): Promise<AlpacaPosition[]> {
  return api<AlpacaPosition[]>('/v2/positions');
}

export async function getPosition(symbol: string): Promise<AlpacaPosition | null> {
  try {
    return await api<AlpacaPosition>(`/v2/positions/${encodeURIComponent(symbol)}`);
  } catch (e: any) {
    if (e?.message?.includes('404')) return null;
    throw e;
  }
}

export async function closePosition(symbol: string): Promise<AlpacaOrder> {
  return api<AlpacaOrder>(`/v2/positions/${encodeURIComponent(symbol)}`, { method: 'DELETE' });
}

// ---- Market data (latest quotes) ----
// A quote is only trusted for pricing/exit decisions when `valid` is true.
// This prevents false stop-losses from one-sided or stale IEX quotes (a
// missing bid/ask previously produced mid = price/2 — a garbage half-price).
export interface LivePrice { price: number; bid: number; ask: number; valid: boolean; source: string }

const MAX_SPREAD_PCT = 8;      // wider than this => quote too unreliable for a mid
const MID_TRADE_TOLERANCE = 0.25; // mid must be within 25% of last trade to be trusted

export async function getLatestTrades(symbols: string[]): Promise<Map<string, number>> {
  if (symbols.length === 0) return new Map();
  const qs = symbols.map(s => encodeURIComponent(s)).join(',');
  const out = new Map<string, number>();
  try {
    const data = await dataApi<any>(`/v2/stocks/trades/latest?symbols=${qs}&feed=iex`);
    for (const [sym, t] of Object.entries(data.trades || {})) {
      const px = (t as any)?.p;
      if (typeof px === 'number' && px > 0) out.set(sym.toUpperCase(), px);
    }
  } catch { /* trades are a best-effort fallback */ }
  return out;
}

export async function getLatestQuotes(symbols: string[]): Promise<Map<string, LivePrice>> {
  if (symbols.length === 0) return new Map();
  const qs = symbols.map(s => encodeURIComponent(s)).join(',');
  const [data, trades] = await Promise.all([
    dataApi<any>(`/v2/stocks/quotes/latest?symbols=${qs}&feed=iex`),
    getLatestTrades(symbols),
  ]);
  const result = new Map<string, LivePrice>();
  for (const [sym, q] of Object.entries(data.quotes || {})) {
    const quote = q as any;
    const bid = typeof quote.bp === 'number' ? quote.bp : 0;
    const ask = typeof quote.ap === 'number' ? quote.ap : 0;
    const last = trades.get(sym.toUpperCase()) || 0;

    let price = 0;
    let valid = false;
    let source = 'none';

    const twoSided = bid > 0 && ask > 0 && ask >= bid;
    if (twoSided) {
      const mid = (bid + ask) / 2;
      const spreadPct = ((ask - bid) / mid) * 100;
      const midSaneVsTrade = last <= 0 || (mid >= last * (1 - MID_TRADE_TOLERANCE) && mid <= last * (1 + MID_TRADE_TOLERANCE));
      if (spreadPct <= MAX_SPREAD_PCT && midSaneVsTrade) {
        price = mid; valid = true; source = 'mid';
      } else if (last > 0) {
        price = last; valid = true; source = 'trade';
      } else {
        price = mid; valid = false; source = 'wide_mid';
      }
    } else if (last > 0) {
      // One-sided or missing quote — never halve it; use the last trade instead.
      price = last; valid = true; source = 'trade';
    } else {
      price = ask || bid || 0; valid = false; source = 'one_sided';
    }

    result.set(sym.toUpperCase(), { price, bid, ask, valid, source });
  }
  // Symbols with a trade but no quote entry at all
  for (const [sym, last] of trades) {
    if (!result.has(sym) && last > 0) {
      result.set(sym, { price: last, bid: 0, ask: 0, valid: true, source: 'trade' });
    }
  }
  return result;
}

export function isAlpacaConfigured(): boolean {
  return !!(process.env.ALPACA_API_KEY_ID && process.env.ALPACA_API_SECRET_KEY);
}

// ---- Assets (tradability / shortability) ----
export interface AlpacaAsset {
  id: string;
  symbol: string;
  status: string;      // 'active' | 'inactive'
  tradable: boolean;
  shortable: boolean;
  fractionable: boolean;
  easy_to_borrow: boolean;
}

// Asset tradability/shortability is effectively static within a session, so we
// cache it per process. This stops us re-querying (and re-failing) the same
// non-shortable symbols on every 5-minute tick.
const assetCache = new Map<string, AlpacaAsset | null>();

export async function getAsset(symbol: string): Promise<AlpacaAsset | null> {
  const key = symbol.toUpperCase();
  if (assetCache.has(key)) return assetCache.get(key)!;
  try {
    const a = await api<AlpacaAsset>(`/v2/assets/${encodeURIComponent(key)}`);
    assetCache.set(key, a);
    return a;
  } catch (e: any) {
    if (e?.message?.includes('404')) { assetCache.set(key, null); return null; }
    throw e;
  }
}

// ---- v2.0.0 (E3): last N COMPLETED 1-minute bars, most recent first ----
// The still-forming bar for the current minute is excluded. Throws on API error
// so the caller can fall back gracefully (E3 allows execution when data is missing).
export async function getLast1MinBars(symbol: string, n = 2): Promise<Array<{ t: string; close: number }>> {
  const key = symbol.toUpperCase();
  const start = new Date(Date.now() - 20 * 60 * 1000).toISOString();
  const data = await dataApi<any>(
    `/v2/stocks/${encodeURIComponent(key)}/bars?timeframe=1Min&start=${encodeURIComponent(start)}&limit=30&feed=iex&adjustment=raw`
  );
  const minuteStart = Math.floor(Date.now() / 60000) * 60000;
  const bars = ((data?.bars || []) as any[])
    .filter(b => typeof b?.c === 'number' && b.c > 0 && new Date(b.t).getTime() < minuteStart)
    .map(b => ({ t: b.t as string, close: b.c as number }))
    .sort((a, b) => b.t.localeCompare(a.t));
  return bars.slice(0, n);
}

// ---- Daily bars / average dollar volume (ADV) — Update 3.5 liquidity gate ----
// ADV$ = average of (close * volume) over the last ~N trading days. Used as a
// liquidity prerequisite before real capital (borrow/locate + exit slippage on
// thin names). Cached per process for a session so we don't re-pull the same
// symbol on every tick. Returns null on any data hiccup so the caller can decide
// (the gate deliberately does NOT block on a missing value).
const advCache = new Map<string, number | null>();

export async function getAvgDollarVolume(symbol: string, days = 20): Promise<number | null> {
  const key = symbol.toUpperCase();
  if (advCache.has(key)) return advCache.get(key)!;
  try {
    // Pull a little more than `days` calendar-wise to cover weekends/holidays.
    const start = new Date(Date.now() - (days + 12) * 24 * 60 * 60 * 1000)
      .toISOString().slice(0, 10);
    const data = await dataApi<any>(
      `/v2/stocks/${encodeURIComponent(key)}/bars?timeframe=1Day&start=${start}&limit=${days + 12}&feed=iex&adjustment=raw`
    );
    const bars: any[] = data?.bars || [];
    if (bars.length === 0) { advCache.set(key, null); return null; }
    const recent = bars.slice(-days);
    let sum = 0;
    let n = 0;
    for (const b of recent) {
      const c = typeof b?.c === 'number' ? b.c : 0;
      const v = typeof b?.v === 'number' ? b.v : 0;
      if (c > 0 && v > 0) { sum += c * v; n++; }
    }
    const adv = n > 0 ? sum / n : null;
    advCache.set(key, adv);
    return adv;
  } catch {
    advCache.set(key, null); // don't hammer a failing symbol; treat as unknown
    return null;
  }
}

```

---

## FILE: code/lib/app-updates.ts

```typescript
// Curated list of notable app updates (release notes). These are the bigger,
// human-authored feature milestones that don't come from the nightly optimizer.
// Kept version-controlled here and merged into the change-log view alongside the
// DB-backed optimizer/override activity. Add a new entry at the TOP when a
// notable update ships.
export interface AppUpdate {
  etDate: string; // YYYY-MM-DD (ET)
  title: string;
  detail: string;
}

export const APP_UPDATES: AppUpdate[] = [
  {
    etDate: '2026-09-28',
    title: 'Update 7.0 — Execution & exit overhaul',
    detail:
      'v7.0.0 (2026-09-28): E1 freshness validation, E2 rolling execution, E3 direction confirmation, X1 TP logic fix, X2 ATR stops, X3 trailing activation, X4 time-exit safety net, F1 ETF divergence skip, C1 condition-weighted sizing. The nightly optimizer was paused (pending a future revamp) and both optimizer-approved edits were switched off. Educational only — not financial advice.',
  },
  {
    etDate: '2026-09-18',
    title: 'Update History / change log added',
    detail:
      'New Update History view: a dated, day-by-day record of every change — optimizer proposals created, approvals/declines, guardrail overrides applied or reset, and notable app updates like this one.',
  },
  {
    etDate: '2026-09-18',
    title: 'Nightly self-improving optimizer',
    detail:
      'A nightly optimizer now reviews clean execution data and proposes execution-only tweaks (fills, slippage, stops, exits, guardrail combos). Every proposal is propose-only and waits for your approval in the app before it can affect trading. Approved changes go live on the next tick and are fully reversible.',
  },
  {
    etDate: '2026-09-10',
    title: 'One concise Daily Brief email',
    detail:
      'Consolidated the post-close emails into a single, easy-to-read Daily Brief: how we did + how we should improve, plus any pending optimizer proposals to review. The old duplicate recap/self-correction emails were retired.',
  },
  {
    etDate: '2026-09-07',
    title: 'Move-magnitude gate, Lane A guards & liquidity tooling',
    detail:
      'Directional move-magnitude gate (skip fading big up-rips, keep following down-moves), stale-entry and fill-slippage guards, average-dollar-volume liquidity tooling, and the consolidated Daily Brief groundwork.',
  },
  {
    etDate: '2026-08-27',
    title: 'Exit-price accuracy fix',
    detail:
      'Fixed a quote-handling bug that recorded exits at prices the symbol never reached (false instant stop-outs). Exits now record the real Alpaca fill price, so stats match the broker.',
  },
  {
    etDate: '2026-08-24',
    title: 'Smarter strategy-review sampling',
    detail:
      'Strategy review now samples across all trading days instead of just the last few, so the best high-confidence setups are no longer missed.',
  },
];

```

---

## FILE: code/lib/backtester.ts

```typescript
// Backtesting Engine for MarcoFlow
// Runs HeatTracker algorithm against historical intraday data to measure signal accuracy
// Tests: Did the predicted move happen within the expected timeframe?

import { fetchIntradayData, IntradayDataPoint } from './data-provider';
import { calculateHeatTracker } from './heat-tracker';

export interface BacktestTrade {
  entryTime: string;
  exitTime: string;
  entryPrice: number;
  exitPrice: number;
  direction: 'LONG' | 'SHORT';
  heatAtEntry: number;
  rsiAtEntry: number;
  tradeType: 'intraday' | 'short_swing';
  holdBars: number; // how many bars the trade was held
  returnPct: number; // actual % return
  won: boolean; // did it move in the predicted direction?
  keyDrivers: string[];
  candlestickPatterns: string[];
  exitReason: string;
}

export interface BacktestResult {
  symbol: string;
  interval: string;
  totalBars: number;
  totalSignals: number;
  totalTrades: number;
  winRate: number; // 0-100%
  avgReturn: number; // average % return per trade
  avgWin: number; // average winning trade %
  avgLoss: number; // average losing trade %
  bestTrade: number;
  worstTrade: number;
  profitFactor: number; // gross profit / gross loss
  longTrades: number;
  shortTrades: number;
  longWinRate: number;
  shortWinRate: number;
  // Breakdown by heat range
  heatRangePerformance: {
    range: string;
    trades: number;
    winRate: number;
    avgReturn: number;
  }[];
  // Breakdown by trade type
  intradayStats: { trades: number; winRate: number; avgReturn: number };
  swingStats: { trades: number; winRate: number; avgReturn: number };
  // Individual trades for review
  trades: BacktestTrade[];
  // Suggested threshold adjustments
  suggestions: string[];
  timestamp: string;
}

// Configuration for the backtest
export interface BacktestConfig {
  // Minimum absolute heat to trigger a trade
  entryThreshold: number;
  // Exit when heat drops below this (absolute)
  exitHeatThreshold: number;
  // Max bars to hold before forced exit
  maxHoldBars: number;
  // Stop loss percentage
  stopLossPct: number;
  // Take profit percentage
  takeProfitPct: number;
  // Minimum bars between trades (cooldown)
  cooldownBars: number;
  // Restrict trade direction: 'long', 'short', or 'both' (default)
  directionBias?: 'long' | 'short' | 'both';
}

const DEFAULT_CONFIG: BacktestConfig = {
  entryThreshold: 20,
  exitHeatThreshold: 5,
  maxHoldBars: 48, // ~4 hours at 5m intervals
  stopLossPct: 2.0,
  takeProfitPct: 3.0,
  cooldownBars: 6, // 30 min cooldown at 5m
};

// Sliding window size for heat calculation
const WINDOW_SIZE = 50;

export async function runBacktest(
  symbol: string,
  interval: string = '5m',
  config: Partial<BacktestConfig> = {}
): Promise<BacktestResult> {
  // Fetch as much historical intraday data as possible
  // Yahoo gives ~60 days for 5m, ~7 days for 1m
  const allData = await fetchIntradayData(symbol, interval);
  return runBacktestOnData(allData, symbol, interval, config);
}

// Runs the backtest on already-fetched data. Lets callers (e.g. the Strategy
// Builder auto-tuner) fetch data once and evaluate many configs cheaply.
export function runBacktestOnData(
  allData: IntradayDataPoint[],
  symbol: string,
  interval: string = '5m',
  config: Partial<BacktestConfig> = {}
): BacktestResult {
  const cfg = { ...DEFAULT_CONFIG, ...config };
  const directionBias = cfg.directionBias || 'both';

  if (!allData || allData.length < WINDOW_SIZE + 20) {
    return emptyResult(symbol, interval, 'Insufficient historical data for backtesting');
  }

  const trades: BacktestTrade[] = [];
  let cooldownUntil = 0;

  // Slide the window through the data
  for (let i = WINDOW_SIZE; i < allData.length - 1; i++) {
    if (i < cooldownUntil) continue;

    // Calculate heat at this point using only data up to index i
    const windowData = allData.slice(Math.max(0, i - WINDOW_SIZE), i + 1);
    const heatResult = calculateHeatTracker(windowData);
    const absHeat = Math.abs(heatResult.heat);

    // Check if signal is strong enough to enter
    if (absHeat < cfg.entryThreshold) continue;

    const direction: 'LONG' | 'SHORT' = heatResult.heat > 0 ? 'LONG' : 'SHORT';

    // Respect direction bias (long-only / short-only strategies)
    if (directionBias === 'long' && direction === 'SHORT') continue;
    if (directionBias === 'short' && direction === 'LONG') continue;

    const entryPrice = allData[i + 1]?.open || allData[i].close; // enter at next bar open
    const entryTime = allData[i].date;
    const entryIdx = i + 1;

    if (entryIdx >= allData.length) break;

    // Determine trade type based on heat strength
    const tradeType = absHeat >= 50 ? 'intraday' : 'short_swing';

    // Simulate the trade forward
    let exitIdx = entryIdx;
    let exitPrice = entryPrice;
    let exitReason = 'max_hold';

    for (let j = entryIdx; j < Math.min(allData.length, entryIdx + cfg.maxHoldBars); j++) {
      const bar = allData[j];
      const barReturn = direction === 'LONG'
        ? ((bar.close - entryPrice) / entryPrice) * 100
        : ((entryPrice - bar.close) / entryPrice) * 100;

      // Check stop loss (use high/low for intrabar)
      const adversePrice = direction === 'LONG' ? bar.low : bar.high;
      const adverseReturn = direction === 'LONG'
        ? ((adversePrice - entryPrice) / entryPrice) * 100
        : ((entryPrice - adversePrice) / entryPrice) * 100;

      if (adverseReturn <= -cfg.stopLossPct) {
        exitIdx = j;
        exitPrice = direction === 'LONG'
          ? entryPrice * (1 - cfg.stopLossPct / 100)
          : entryPrice * (1 + cfg.stopLossPct / 100);
        exitReason = 'stop_loss';
        break;
      }

      // Check take profit
      const favorablePrice = direction === 'LONG' ? bar.high : bar.low;
      const favorableReturn = direction === 'LONG'
        ? ((favorablePrice - entryPrice) / entryPrice) * 100
        : ((entryPrice - favorablePrice) / entryPrice) * 100;

      if (favorableReturn >= cfg.takeProfitPct) {
        exitIdx = j;
        exitPrice = direction === 'LONG'
          ? entryPrice * (1 + cfg.takeProfitPct / 100)
          : entryPrice * (1 - cfg.takeProfitPct / 100);
        exitReason = 'take_profit';
        break;
      }

      // Check if heat reversed (exit on signal reversal)
      if (j >= entryIdx + 3 && j - entryIdx < cfg.maxHoldBars) {
        const exitWindow = allData.slice(Math.max(0, j - WINDOW_SIZE), j + 1);
        if (exitWindow.length >= 20) {
          const exitHeat = calculateHeatTracker(exitWindow);
          const exitAbsHeat = direction === 'LONG' ? exitHeat.heat : -exitHeat.heat;
          if (exitAbsHeat < cfg.exitHeatThreshold) {
            exitIdx = j;
            exitPrice = bar.close;
            exitReason = 'heat_reversal';
            break;
          }
        }
      }

      exitIdx = j;
      exitPrice = bar.close;
    }

    const holdBars = exitIdx - entryIdx;
    const returnPct = direction === 'LONG'
      ? ((exitPrice - entryPrice) / entryPrice) * 100
      : ((entryPrice - exitPrice) / entryPrice) * 100;

    trades.push({
      entryTime,
      exitTime: allData[exitIdx]?.date || entryTime,
      entryPrice: Math.round(entryPrice * 100) / 100,
      exitPrice: Math.round(exitPrice * 100) / 100,
      direction,
      heatAtEntry: heatResult.heat,
      rsiAtEntry: heatResult.indicators.rsi,
      tradeType,
      holdBars,
      returnPct: Math.round(returnPct * 100) / 100,
      won: returnPct > 0,
      keyDrivers: heatResult.keyDrivers.slice(0, 3),
      candlestickPatterns: (heatResult.candlestickPatterns || []).map(p => p.name).slice(0, 2),
      exitReason,
    });

    // Set cooldown
    cooldownUntil = exitIdx + cfg.cooldownBars;
    // Skip to after exit
    i = exitIdx;
  }

  return buildResult(symbol, interval, allData.length, trades, cfg);
}

function buildResult(
  symbol: string,
  interval: string,
  totalBars: number,
  trades: BacktestTrade[],
  config: BacktestConfig
): BacktestResult {
  const wins = trades.filter(t => t.won);
  const losses = trades.filter(t => !t.won);
  const longTrades = trades.filter(t => t.direction === 'LONG');
  const shortTrades = trades.filter(t => t.direction === 'SHORT');
  const intradayTrades = trades.filter(t => t.tradeType === 'intraday');
  const swingTrades = trades.filter(t => t.tradeType === 'short_swing');

  const avgReturn = trades.length > 0 ? trades.reduce((s, t) => s + t.returnPct, 0) / trades.length : 0;
  const avgWin = wins.length > 0 ? wins.reduce((s, t) => s + t.returnPct, 0) / wins.length : 0;
  const avgLoss = losses.length > 0 ? losses.reduce((s, t) => s + t.returnPct, 0) / losses.length : 0;
  const grossProfit = wins.reduce((s, t) => s + t.returnPct, 0);
  const grossLoss = Math.abs(losses.reduce((s, t) => s + t.returnPct, 0));

  // Heat range breakdown
  const ranges = [
    { range: '20-35', min: 20, max: 35 },
    { range: '35-50', min: 35, max: 50 },
    { range: '50-70', min: 50, max: 70 },
    { range: '70+', min: 70, max: 999 },
  ];

  const heatRangePerformance = ranges.map(r => {
    const rangeTrades = trades.filter(t => {
      const ah = Math.abs(t.heatAtEntry);
      return ah >= r.min && ah < r.max;
    });
    return {
      range: r.range,
      trades: rangeTrades.length,
      winRate: rangeTrades.length > 0
        ? Math.round((rangeTrades.filter(t => t.won).length / rangeTrades.length) * 100)
        : 0,
      avgReturn: rangeTrades.length > 0
        ? Math.round((rangeTrades.reduce((s, t) => s + t.returnPct, 0) / rangeTrades.length) * 100) / 100
        : 0,
    };
  });

  // Generate suggestions based on results
  const suggestions: string[] = [];

  if (trades.length < 5) {
    suggestions.push('Very few trades generated. Consider lowering the entry threshold to capture more opportunities.');
  }

  const winRate = trades.length > 0 ? (wins.length / trades.length) * 100 : 0;

  if (winRate < 45) {
    suggestions.push('Win rate below 45%. Consider tightening entry requirements (higher heat threshold) for better accuracy.');
  } else if (winRate > 65) {
    suggestions.push('Strong win rate! Could potentially lower entry threshold slightly to capture more opportunities without sacrificing too much accuracy.');
  }

  // Check which heat ranges perform best
  const bestRange = heatRangePerformance
    .filter(r => r.trades >= 3)
    .sort((a, b) => b.winRate - a.winRate)[0];
  if (bestRange) {
    suggestions.push(`Best performance in heat range ${bestRange.range} (${bestRange.winRate}% win rate). Focus entries here.`);
  }

  // Check long vs short performance
  const longWinRate = longTrades.length > 0 ? (longTrades.filter(t => t.won).length / longTrades.length) * 100 : 0;
  const shortWinRate = shortTrades.length > 0 ? (shortTrades.filter(t => t.won).length / shortTrades.length) * 100 : 0;

  if (longWinRate > shortWinRate + 15 && shortTrades.length >= 3) {
    suggestions.push('Long trades significantly outperform shorts. Consider higher threshold for short entries.');
  } else if (shortWinRate > longWinRate + 15 && longTrades.length >= 3) {
    suggestions.push('Short trades significantly outperform longs. Consider higher threshold for long entries.');
  }

  // Check stop loss effectiveness
  const stopLossExits = trades.filter(t => t.exitReason === 'stop_loss').length;
  if (stopLossExits > trades.length * 0.4) {
    suggestions.push(`${Math.round((stopLossExits / trades.length) * 100)}% of trades hit stop loss. Consider widening stop or tightening entry criteria.`);
  }

  const calcSubStats = (arr: BacktestTrade[]) => ({
    trades: arr.length,
    winRate: arr.length > 0 ? Math.round((arr.filter(t => t.won).length / arr.length) * 100) : 0,
    avgReturn: arr.length > 0 ? Math.round((arr.reduce((s, t) => s + t.returnPct, 0) / arr.length) * 100) / 100 : 0,
  });

  return {
    symbol,
    interval,
    totalBars,
    totalSignals: trades.length, // signals that met threshold
    totalTrades: trades.length,
    winRate: Math.round(winRate * 10) / 10,
    avgReturn: Math.round(avgReturn * 100) / 100,
    avgWin: Math.round(avgWin * 100) / 100,
    avgLoss: Math.round(avgLoss * 100) / 100,
    bestTrade: trades.length > 0 ? Math.round(Math.max(...trades.map(t => t.returnPct)) * 100) / 100 : 0,
    worstTrade: trades.length > 0 ? Math.round(Math.min(...trades.map(t => t.returnPct)) * 100) / 100 : 0,
    profitFactor: grossLoss > 0 ? Math.round((grossProfit / grossLoss) * 100) / 100 : grossProfit > 0 ? 999 : 0,
    longTrades: longTrades.length,
    shortTrades: shortTrades.length,
    longWinRate: Math.round(longWinRate * 10) / 10,
    shortWinRate: Math.round(shortWinRate * 10) / 10,
    heatRangePerformance,
    intradayStats: calcSubStats(intradayTrades),
    swingStats: calcSubStats(swingTrades),
    trades: trades.slice(-50), // Last 50 trades for UI
    suggestions,
    timestamp: new Date().toISOString(),
  };
}

function emptyResult(symbol: string, interval: string, reason: string): BacktestResult {
  return {
    symbol, interval, totalBars: 0, totalSignals: 0, totalTrades: 0,
    winRate: 0, avgReturn: 0, avgWin: 0, avgLoss: 0,
    bestTrade: 0, worstTrade: 0, profitFactor: 0,
    longTrades: 0, shortTrades: 0, longWinRate: 0, shortWinRate: 0,
    heatRangePerformance: [],
    intradayStats: { trades: 0, winRate: 0, avgReturn: 0 },
    swingStats: { trades: 0, winRate: 0, avgReturn: 0 },
    trades: [],
    suggestions: [reason],
    timestamp: new Date().toISOString(),
  };
}

```

---

## FILE: code/lib/candlestick-patterns.ts

```typescript
// Candlestick Pattern Detection
// Identifies common candlestick patterns from OHLCV data for intraday analysis

import { IntradayDataPoint } from './data-provider';

export interface CandlestickPattern {
  name: string;
  type: 'bullish' | 'bearish' | 'neutral';
  strength: number; // 1-3 (1=weak, 2=moderate, 3=strong)
  description: string;
  index: number; // Where in the data the pattern was detected
}

function bodySize(candle: IntradayDataPoint): number {
  return Math.abs(candle.close - candle.open);
}

function upperWick(candle: IntradayDataPoint): number {
  return candle.high - Math.max(candle.open, candle.close);
}

function lowerWick(candle: IntradayDataPoint): number {
  return Math.min(candle.open, candle.close) - candle.low;
}

function totalRange(candle: IntradayDataPoint): number {
  return candle.high - candle.low;
}

function isBullish(candle: IntradayDataPoint): boolean {
  return candle.close > candle.open;
}

function isBearish(candle: IntradayDataPoint): boolean {
  return candle.close < candle.open;
}

function isDoji(candle: IntradayDataPoint): boolean {
  const range = totalRange(candle);
  if (range === 0) return true;
  return bodySize(candle) / range < 0.1;
}

function isHammer(candle: IntradayDataPoint): boolean {
  const body = bodySize(candle);
  const lower = lowerWick(candle);
  const upper = upperWick(candle);
  const range = totalRange(candle);
  if (range === 0 || body === 0) return false;
  return lower >= body * 2 && upper < body * 0.5;
}

function isInvertedHammer(candle: IntradayDataPoint): boolean {
  const body = bodySize(candle);
  const lower = lowerWick(candle);
  const upper = upperWick(candle);
  const range = totalRange(candle);
  if (range === 0 || body === 0) return false;
  return upper >= body * 2 && lower < body * 0.5;
}

function isMarubozu(candle: IntradayDataPoint): boolean {
  const body = bodySize(candle);
  const range = totalRange(candle);
  if (range === 0) return false;
  return body / range > 0.9;
}

export function detectCandlestickPatterns(data: IntradayDataPoint[]): CandlestickPattern[] {
  const patterns: CandlestickPattern[] = [];
  if (data.length < 3) return patterns;

  // Analyze only the last 20 candles for relevance
  const recent = data.slice(-20);
  const avgBody = recent.reduce((s, d) => s + bodySize(d), 0) / recent.length;

  for (let i = 2; i < recent.length; i++) {
    const curr = recent[i];
    const prev = recent[i - 1];
    const prev2 = recent[i - 2];
    const idx = data.length - recent.length + i;

    // 1. Doji (indecision)
    if (isDoji(curr) && totalRange(curr) > avgBody * 0.5) {
      patterns.push({
        name: 'Doji',
        type: 'neutral',
        strength: 1,
        description: 'Indecision candle - trend may reverse',
        index: idx,
      });
    }

    // 2. Hammer (bullish reversal after downtrend)
    if (isHammer(curr) && isBearish(prev) && isBearish(prev2)) {
      patterns.push({
        name: 'Hammer',
        type: 'bullish',
        strength: 2,
        description: 'Bullish reversal signal after downtrend',
        index: idx,
      });
    }

    // 3. Inverted Hammer (potential bullish reversal)
    if (isInvertedHammer(curr) && isBearish(prev) && isBearish(prev2)) {
      patterns.push({
        name: 'Inverted Hammer',
        type: 'bullish',
        strength: 1,
        description: 'Potential bullish reversal - watch for confirmation',
        index: idx,
      });
    }

    // 4. Hanging Man (bearish reversal after uptrend)
    if (isHammer(curr) && isBullish(prev) && isBullish(prev2)) {
      patterns.push({
        name: 'Hanging Man',
        type: 'bearish',
        strength: 2,
        description: 'Bearish reversal signal after uptrend',
        index: idx,
      });
    }

    // 5. Shooting Star (bearish reversal)
    if (isInvertedHammer(curr) && isBullish(prev) && isBullish(prev2)) {
      patterns.push({
        name: 'Shooting Star',
        type: 'bearish',
        strength: 2,
        description: 'Bearish reversal - selling pressure at highs',
        index: idx,
      });
    }

    // 6. Bullish Engulfing
    if (isBearish(prev) && isBullish(curr) &&
        curr.open <= prev.close && curr.close >= prev.open &&
        bodySize(curr) > bodySize(prev) * 1.2) {
      patterns.push({
        name: 'Bullish Engulfing',
        type: 'bullish',
        strength: 3,
        description: 'Strong bullish reversal - buyers overwhelm sellers',
        index: idx,
      });
    }

    // 7. Bearish Engulfing
    if (isBullish(prev) && isBearish(curr) &&
        curr.open >= prev.close && curr.close <= prev.open &&
        bodySize(curr) > bodySize(prev) * 1.2) {
      patterns.push({
        name: 'Bearish Engulfing',
        type: 'bearish',
        strength: 3,
        description: 'Strong bearish reversal - sellers overwhelm buyers',
        index: idx,
      });
    }

    // 8. Morning Star (3-candle bullish reversal)
    if (i >= 2 && isBearish(prev2) && isDoji(prev) && isBullish(curr) &&
        curr.close > (prev2.open + prev2.close) / 2) {
      patterns.push({
        name: 'Morning Star',
        type: 'bullish',
        strength: 3,
        description: 'Strong bullish reversal - indecision followed by recovery',
        index: idx,
      });
    }

    // 9. Evening Star (3-candle bearish reversal)
    if (i >= 2 && isBullish(prev2) && isDoji(prev) && isBearish(curr) &&
        curr.close < (prev2.open + prev2.close) / 2) {
      patterns.push({
        name: 'Evening Star',
        type: 'bearish',
        strength: 3,
        description: 'Strong bearish reversal - rally exhaustion',
        index: idx,
      });
    }

    // 10. Bullish Marubozu (strong momentum)
    if (isMarubozu(curr) && isBullish(curr) && bodySize(curr) > avgBody * 1.5) {
      patterns.push({
        name: 'Bullish Marubozu',
        type: 'bullish',
        strength: 2,
        description: 'Strong buying pressure - no wicks',
        index: idx,
      });
    }

    // 11. Bearish Marubozu
    if (isMarubozu(curr) && isBearish(curr) && bodySize(curr) > avgBody * 1.5) {
      patterns.push({
        name: 'Bearish Marubozu',
        type: 'bearish',
        strength: 2,
        description: 'Strong selling pressure - no wicks',
        index: idx,
      });
    }

    // 12. Three White Soldiers (strong bullish continuation)
    if (i >= 2 && isBullish(prev2) && isBullish(prev) && isBullish(curr) &&
        prev.close > prev2.close && curr.close > prev.close &&
        bodySize(prev) > avgBody * 0.7 && bodySize(curr) > avgBody * 0.7) {
      patterns.push({
        name: 'Three White Soldiers',
        type: 'bullish',
        strength: 3,
        description: 'Strong bullish continuation - consistent buying',
        index: idx,
      });
    }

    // 13. Three Black Crows (strong bearish continuation)
    if (i >= 2 && isBearish(prev2) && isBearish(prev) && isBearish(curr) &&
        prev.close < prev2.close && curr.close < prev.close &&
        bodySize(prev) > avgBody * 0.7 && bodySize(curr) > avgBody * 0.7) {
      patterns.push({
        name: 'Three Black Crows',
        type: 'bearish',
        strength: 3,
        description: 'Strong bearish continuation - consistent selling',
        index: idx,
      });
    }
  }

  // Return only the most recent patterns (last 5 candles), deduplicated
  const recentPatterns = patterns.filter(p => p.index >= data.length - 5);
  const unique = new Map<string, CandlestickPattern>();
  for (const p of recentPatterns) {
    const existing = unique.get(p.name);
    if (!existing || p.strength > existing.strength) {
      unique.set(p.name, p);
    }
  }
  return Array.from(unique.values()).sort((a, b) => b.strength - a.strength);
}

// Compute a heat contribution from detected patterns
export function candlestickHeatContribution(patterns: CandlestickPattern[]): {
  heat: number;
  drivers: string[];
} {
  let heat = 0;
  const drivers: string[] = [];

  for (const p of patterns) {
    const contribution = p.strength * 5 * (p.type === 'bullish' ? 1 : p.type === 'bearish' ? -1 : 0);
    heat += contribution;

    if (p.strength >= 2) {
      const emoji = p.type === 'bullish' ? '🕯️📈' : p.type === 'bearish' ? '🕯️📉' : '🕯️';
      drivers.push(`${emoji} ${p.name}`);
    }
  }

  // Clamp to ±15
  heat = Math.min(15, Math.max(-15, heat));
  return { heat, drivers };
}

```

---

## FILE: code/lib/changelog.ts

```typescript
import { prisma } from '@/lib/db';

// ET date string (YYYY-MM-DD) used to group change-log entries by trading day.
export function etDateStr(d: Date = new Date()): string {
  return d.toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
}

export type ChangeType =
  | 'proposal_created'
  | 'approved'
  | 'declined'
  | 'override_applied'
  | 'override_reset'
  | 'app_update';

export interface LogChangeInput {
  type: ChangeType;
  title: string;
  detail?: string | null;
  guardrailKey?: string | null;
  fromValue?: any;
  toValue?: any;
  actor?: string | null;
  proposalId?: string | null;
}

// Append-only writer. Best-effort: a logging failure must never break the
// primary mutation (proposal decision, override reset, etc.), so callers wrap
// this in try/catch or await it defensively.
export async function logChange(input: LogChangeInput): Promise<void> {
  try {
    await prisma.changeLogEntry.create({
      data: {
        etDate: etDateStr(),
        type: input.type,
        title: input.title.slice(0, 300),
        detail: input.detail ? String(input.detail).slice(0, 4000) : null,
        guardrailKey: input.guardrailKey ?? null,
        fromValue: input.fromValue ?? undefined,
        toValue: input.toValue ?? undefined,
        actor: input.actor ?? null,
        proposalId: input.proposalId ?? null,
      },
    });
  } catch (e: any) {
    console.error('[changelog logChange]', e?.message);
  }
}

```

---

## FILE: code/lib/daily-brief.ts

```typescript
// Consolidated Daily Brief — the SINGLE post-close email.
// Combines "how we did" (EOD scoreboard + post-mortem split) with "how we should
// improve" (the reconciled self-correction action slate) into ONE concise,
// thought-provoking summary. Replaces the three separate post-close emails
// (Daily Brief dump + 6:15 eod-recap + 7:45 self-correction). Report-only, zero
// trading risk; nothing here changes live strategy.
//
// Framing rule (enforced project-wide): losses are explained by SYSTEM / SETUP
// failure mode — never by naming “frequent loser” tickers.

import { getEodLossReport, EodLossReport } from '@/lib/eod-losses';
import { getPostmortemReport, PostmortemReport } from '@/lib/trade-postmortem';
import { buildSelfCorrectionReport, type SelfCorrectionReport } from '@/lib/self-correction';
import { prisma } from '@/lib/db';
import { etDateStr } from '@/lib/changelog';

// Once-per-day guard key (AgentState). Ensures the ONE consolidated Daily Brief
// is emailed a single time per ET day no matter how many callers fire it (the
// self-healing heartbeat AND the legacy hourly task can both trigger it).
const DAILY_BRIEF_SENT_KEY = 'daily_brief_last_sent';

export const DAILY_BRIEF_RECIPIENT = 'misiti15@gmail.com';

// Proposals produced by the nightly optimizer (a separate scheduled task). They
// are handed to the app at send time over HTTPS and folded into THIS single
// email — propose-only, nothing changes until the owner approves.
export type OptimizerProposal = {
  rank: number;
  severity: string;
  title: string;
  detail: string;
  edit: string;
  evidence?: string;
};

function sevColor(s: string): string {
  return s === 'suspend' ? '#c0392b' : s === 'reenable' ? '#0a7d33' : '#8a6d3b';
}

// ---- Combined render ------------------------------------------------------
// Concise by design: a scoreboard, a short “how we did” read, a ranked “how to
// improve” slate, and a one-line give-back note. No giant per-trade tables —
// the full data still lives in the app; this email is the easy-to-read digest.
export function renderDailyBrief(
  eod: EodLossReport,
  pm: PostmortemReport,
  sc?: SelfCorrectionReport | null,
  optimizerProposals?: OptimizerProposal[] | null,
  panelUrl?: string | null,
): string {
  const etNow = new Date().toLocaleString('en-US', { timeZone: 'America/New_York', dateStyle: 'medium', timeStyle: 'short' });
  const dateEt = eod.dateEt;

  // --- Scoreboard: one line, the whole day at a glance ---
  const scoreboard = `
    <div style="padding:14px 20px;background:#f8f9fa;border-bottom:1px solid #eee;font-size:13px;line-height:1.6;">
      <strong>${dateEt}:</strong> ${eod.dayClosed} closed · ${eod.dayWins}W / ${eod.dayLosses}L · win rate ${eod.dayWinRate}% ·
      net P&amp;L <span style="color:${eod.dayNetPnl < 0 ? '#dc2626' : '#16a34a'};font-weight:700;">$${eod.dayNetPnl}</span>
      &nbsp;—&nbsp;
      of ${pm.dayLosers} losers: <span style="color:#166534;font-weight:700;">${pm.fixableCount} fixable</span> ($${pm.fixablePnl}) ·
      <span style="color:#991b1b;font-weight:700;">${pm.falseCount} false</span> ($${pm.falsePnl})
    </div>`;

  // --- How we did: the 3 sharpest takeaways + LONG vs SHORT read ---
  const topTakeaways = pm.summary.slice(0, 3);
  const takeawaysHtml = topTakeaways.length
    ? topTakeaways.map(s => `<li style="margin:0 0 6px;line-height:1.5;">${s}</li>`).join('')
    : '<li style="color:#888;">No losing trades to diagnose today.</li>';

  const dirHtml = sc && sc.byDirection.length
    ? sc.byDirection
        .filter(c => c.n > 0)
        .map(c => {
          const col = c.pnl >= 0 ? '#16a34a' : '#dc2626';
          return `<span style="display:inline-block;margin-right:16px;"><b>${c.label}</b>: ${c.n} trades · ${c.winRate}% win · <span style="color:${col};font-weight:700;">$${c.pnl}</span></span>`;
        })
        .join('')
    : '';
  const dirLine = dirHtml
    ? `<p style="font-size:12px;color:#444;margin:10px 0 0;padding-top:8px;border-top:1px dashed #e5e5e5;">Since ${sc!.windowStart} — ${dirHtml}</p>`
    : '';

  const howWeDid = `
    <div style="padding:16px 20px;">
      <h2 style="font-size:15px;margin:0 0 8px;">How we did</h2>
      <ul style="font-size:13px;color:#333;padding-left:18px;margin:0;">${takeawaysHtml}</ul>
      ${dirLine}
    </div>`;

  // --- How to improve: the reconciled, ranked action slate (top few) ---
  let improveInner: string;
  if (sc && sc.reconciliation.slate.length) {
    const top = sc.reconciliation.slate.slice(0, 4);
    improveInner = top.map(p => `
      <div style="border-left:4px solid ${sevColor(p.severity)};padding:8px 12px;margin:8px 0;background:#fafafa;border-radius:0 6px 6px 0;">
        <div style="font-size:13px;"><b style="color:${sevColor(p.severity)};">#${p.rank} · [${p.severity.toUpperCase()}]</b> ${p.title}
          <span style="color:#999;font-size:11px;">(${p.source}, evidence ${p.score.toFixed(0)})</span></div>
        <div style="font-size:12px;color:#555;margin:3px 0;line-height:1.45;">${p.detail}</div>
        <code style="font-size:11px;color:#333;">${p.edit}</code>
      </div>`).join('');
  } else if (sc) {
    improveInner = '<p style="font-size:13px;color:#0a7d33;margin:0;">No changes proposed — every cohort is within tolerance. Stay the course and keep collecting data.</p>';
  } else {
    improveInner = '<p style="font-size:12px;color:#888;margin:0;">Improvement analysis unavailable for this run.</p>';
  }
  // --- Nightly optimizer proposals (passed in at send time) ---
  // Rendered ABOVE the self-correction slate, styled identically. Propose-only —
  // nothing changes until you approve it.
  let optimizerBlock = '';
  if (optimizerProposals && optimizerProposals.length) {
    const items = optimizerProposals.map(p => `
      <div style="border-left:4px solid ${sevColor(p.severity)};padding:8px 12px;margin:8px 0;background:#fafafa;border-radius:0 6px 6px 0;">
        <div style="font-size:13px;"><b style="color:${sevColor(p.severity)};">#${p.rank} · [${(p.severity || '').toUpperCase()}]</b> ${p.title}</div>
        <div style="font-size:12px;color:#555;margin:3px 0;line-height:1.45;">${p.detail}</div>
        <code style="font-size:11px;color:#333;">${p.edit}</code>
        ${p.evidence ? `<div style="font-size:11px;color:#999;margin-top:3px;">(evidence: ${p.evidence})</div>` : ''}
      </div>`).join('');
    const cta = panelUrl
      ? `<div style="margin:6px 0 2px;"><a href="${panelUrl}" style="display:inline-block;background:#4CBB17;color:#fff;text-decoration:none;font-size:12px;font-weight:600;padding:8px 14px;border-radius:8px;">Review &amp; approve in the app →</a><div style="font-size:11px;color:#999;margin-top:4px;">Opens the Live Data Monitor · Nightly optimizer panel, where you can Approve, Decline or comment on each item.</div></div>`
      : '';
    optimizerBlock = `
      <h3 style="font-size:13px;margin:8px 0 2px;color:#404040;">Nightly optimizer</h3>
      <p style="font-size:11px;color:#888;margin:0 0 4px;">Proposals from the overnight optimizer — propose-only, nothing changes until you approve it.</p>
      ${items}
      ${cta}`;
  }

  const improve = `
    <div style="padding:4px 20px 16px;">
      <h2 style="font-size:15px;margin:8px 0 4px;">How we should improve</h2>
      ${optimizerBlock}
      <p style="font-size:11px;color:#888;margin:0 0 4px;">Reconciled across ${sc && sc.reconciliation.sources.length ? sc.reconciliation.sources.join(' + ') : 'all sources'} — propose-only, nothing changes until you approve it.</p>
      ${improveInner}
    </div>`;

  const gaveBack = pm.gaveBackWinners > 0
    ? `<div style="padding:0 20px 14px;"><p style="font-size:12px;color:#7c2d12;background:#fff7ed;border-left:3px solid #d97706;padding:8px 10px;margin:0;line-height:1.5;">${pm.gaveBackWinners} winners (${pm.gaveBackWinnersPct}%) gave back ≥ half their peak — exit leakage on trades that were working. Give-back lock is built and ready to arm once fills are verified clean.</p></div>`
    : '';

  return `
  <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:640px;margin:0 auto;color:#333;">
    <div style="background:#404040;padding:16px 20px;border-radius:12px 12px 0 0;">
      <h1 style="margin:0;font-size:20px;color:#4CBB17;">MarcoFlow — Daily Brief</h1>
      <p style="margin:4px 0 0;font-size:12px;color:#ccc;">${dateEt} · generated ${etNow} ET · how we did + how to improve, in one place</p>
    </div>
    ${scoreboard}
    ${howWeDid}
    ${improve}
    ${gaveBack}
    <div style="padding:14px 20px;font-size:11px;color:#999;border-top:1px solid #eee;">
      <p style="margin:0 0 4px;">Losses are analyzed by <b>system / setup failure mode</b> (timing, exit handling, the book, the session) — never by blaming a ticker. “Fixable” = something we control; “false” = the signal was wrong. Full per-trade detail lives in the app; this email is the digest.</p>
      <p style="margin:0;"><strong>Educational only — not financial advice.</strong></p>
    </div>
  </div>`;
}

// ---- Send -----------------------------------------------------------------
export async function sendDailyBrief(
  dateEt?: string,
  optimizerProposals?: OptimizerProposal[] | null,
): Promise<{ ok: boolean; dateEt: string; losers: number; skipped?: boolean }> {
  // Idempotency guard: when sending "today's" brief (no explicit date), only send
  // once per ET day. A specific back-dated date always sends (manual/backfill).
  if (!dateEt) {
    try {
      const todayEt = etDateStr();
      const row = await prisma.agentState.findUnique({ where: { key: DAILY_BRIEF_SENT_KEY } });
      const last = (row?.valueJson as any)?.etDate;
      if (last === todayEt) {
        return { ok: true, dateEt: todayEt, losers: 0, skipped: true };
      }
    } catch (e: any) {
      console.error('Daily Brief guard check failed (continuing to send):', e?.message);
    }
  }
  const [eod, pm] = await Promise.all([
    getEodLossReport(dateEt),
    getPostmortemReport(dateEt),
  ]);
  // Fold in the self-correction improvement slate. Best-effort: it runs the
  // heavy strategy review, so if it fails/OOMs we still send the brief without
  // the “how to improve” section rather than dropping the whole email.
  let sc: SelfCorrectionReport | null = null;
  try {
    sc = await buildSelfCorrectionReport();
  } catch (e: any) {
    console.error('Daily Brief self-correction build failed (sending without improve section):', e?.message);
  }
  // Pull PENDING optimizer proposals straight from the DB so the email and the
  // in-app approvals panel always show the SAME list. An explicit argument (e.g.
  // a preview) still wins. Best-effort — a DB hiccup never blocks the email.
  let proposals: OptimizerProposal[] | null = optimizerProposals ?? null;
  if (proposals == null) {
    try {
      const rows = await prisma.optimizerProposal.findMany({
        where: { status: 'PENDING' },
        orderBy: { createdAt: 'desc' },
      });
      proposals = rows.map((r, i) => ({
        rank: i + 1,
        severity: 'propose',
        title: r.title,
        detail: r.leak,
        edit: r.guardrailKey
          ? `${r.changeSummary} (${r.guardrailKey}: ${JSON.stringify(r.currentValue)} → ${JSON.stringify(r.proposedValue)})`
          : r.changeSummary,
        evidence: r.backtest || undefined,
      }));
    } catch (e: any) {
      console.error('Daily Brief: could not load optimizer proposals from DB:', e?.message);
    }
  }
  const appUrl = process.env.NEXTAUTH_URL || '';
  const panelUrl = appUrl ? `${appUrl.replace(/\/$/, '')}/monitor` : null;
  const html = renderDailyBrief(eod, pm, sc, proposals, panelUrl);
  const optimizerCount = proposals ? proposals.length : 0;
  const improveCount = (sc ? sc.reconciliation.slate.length : 0) + optimizerCount;
  try {
    const response = await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_TRADE_SIGNAL_ALERT,
        subject: `📋 MarcoFlow Daily Brief — ${eod.dateEt} · ${eod.dayWins}W/${eod.dayLosses}L · net $${eod.dayNetPnl} · ${improveCount} to improve`,
        body: html,
        is_html: true,
        recipient_email: DAILY_BRIEF_RECIPIENT,
        sender_email: appUrl ? `noreply@${new URL(appUrl).hostname}` : undefined,
        sender_alias: 'MarcoFlow',
      }),
    });
    const res = await response.json();
    if (!res.success && !res.notification_disabled) {
      console.error('Daily Brief email failed:', res);
      return { ok: false, dateEt: eod.dateEt, losers: pm.dayLosers };
    }
    // Mark today's brief as sent so redundant callers become no-ops.
    if (!dateEt) {
      try {
        const todayEt = etDateStr();
        await prisma.agentState.upsert({
          where: { key: DAILY_BRIEF_SENT_KEY },
          create: { key: DAILY_BRIEF_SENT_KEY, valueJson: { etDate: todayEt, at: new Date().toISOString() } },
          update: { valueJson: { etDate: todayEt, at: new Date().toISOString() } },
        });
      } catch (e: any) {
        console.error('Daily Brief: could not persist sent marker:', e?.message);
      }
    }
    return { ok: true, dateEt: eod.dateEt, losers: pm.dayLosers };
  } catch (e: any) {
    console.error('Daily Brief email error:', e?.message);
    return { ok: false, dateEt: eod.dateEt, losers: pm.dayLosers };
  }
}

```

---

## FILE: code/lib/daily-sim.ts

```typescript
import { prisma } from '@/lib/db';
import { isIntradayExecutable } from '@/lib/signal-recorder';
import { getRulePredicate, type ReviewRow } from '@/lib/strategy-review';

// ---------------------------------------------------------------------------
// FRESH-TRADER DAILY SIMULATION (no LLM, purely data-driven)
//
// After each market close the agent role-plays a disciplined "fresh trader"
// whose only playbook is the tool's CURRENT best rule. It replays THAT day's
// real resolved signals that qualified for the playbook, and writes an honest
// recap: was the day a success or failure, WHY, and what to be careful about
// the next trading day. Because the playbook is always the tool's latest best
// rule, the trader automatically "learns" and improves as the tool improves.
//
// Every number is taken from trades the tool actually recorded and resolved
// (their real status + returnPct). Nothing is re-derived or inflated. A day
// with no qualifying setups is an honest, valid outcome ("capital preserved").
// ---------------------------------------------------------------------------

const DEFAULT_HORIZON_HOURS = 4;

type SimRow = ReviewRow & {
  id: string;
  symbol: string;
  status: string;
  targetPct: number | null;
  stopPct: number | null;
};

export type SimTradeDetail = {
  symbol: string;
  direction: string;
  assetClass: string | null;
  sessionSlot: string | null;
  status: string;
  returnPct: number;
};

// ET calendar date key (YYYY-MM-DD) for a given instant.
function etDateKey(d: Date): string {
  // en-CA gives YYYY-MM-DD formatting.
  return d.toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
}

// Current hour (0-23) in US Eastern time.
function etHourNow(d: Date = new Date()): number {
  const et = new Date(d.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  return et.getHours();
}

const SLOT_LABELS: Record<string, string> = {
  open: 'the opening hours (9:30-11 ET)',
  midday: 'the midday lull (11-2 ET)',
  power_hour: 'the power hour (2-4 ET)',
};

function slotLabel(slot: string | null): string {
  if (!slot) return 'the session';
  return SLOT_LABELS[slot] || slot;
}

function fmtPct(n: number): string {
  const r = Math.round(n * 100) / 100;
  return `${r >= 0 ? '+' : ''}${r}%`;
}

// Find the dominant trait among a set of trades across a few dimensions, so the
// "why" reads like a trader reflecting on what actually drove the day.
function dominantTrait(rows: SimTradeDetail[]): string | null {
  if (rows.length === 0) return null;
  const tally = (pick: (r: SimTradeDetail) => string | null) => {
    const m = new Map<string, number>();
    for (const r of rows) {
      const k = pick(r);
      if (!k) continue;
      m.set(k, (m.get(k) || 0) + 1);
    }
    let best: string | null = null; let bestN = 0;
    for (const [k, v] of m) if (v > bestN) { best = k; bestN = v; }
    return best && bestN >= Math.max(2, Math.ceil(rows.length / 2)) ? best : null;
  };
  const dir = tally(r => r.direction);
  if (dir) return dir === 'LONG' ? 'long (bullish) entries' : 'short (bearish) entries';
  const asset = tally(r => r.assetClass);
  if (asset) return asset === 'etf' ? 'ETF trades' : 'individual-stock trades';
  const slot = tally(r => r.sessionSlot);
  if (slot) return slotLabel(slot);
  return null;
}

// Worst-performing segment (by win rate, min 2 trades) — the thing to be
// careful about next session. Checks a few natural dimensions.
function worstSegment(rows: SimTradeDetail[]): { label: string; wins: number; total: number } | null {
  const dims: { name: (k: string) => string; pick: (r: SimTradeDetail) => string | null }[] = [
    { name: k => (k === 'LONG' ? 'long entries' : 'short entries'), pick: r => r.direction },
    { name: k => (k === 'etf' ? 'ETF trades' : 'individual-stock trades'), pick: r => r.assetClass },
    { name: k => slotLabel(k), pick: r => r.sessionSlot },
  ];
  let worst: { label: string; wins: number; total: number; rate: number } | null = null;
  for (const dim of dims) {
    const groups = new Map<string, SimTradeDetail[]>();
    for (const r of rows) {
      const k = dim.pick(r);
      if (!k) continue;
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k)!.push(r);
    }
    for (const [k, g] of groups) {
      if (g.length < 2) continue;
      const wins = g.filter(r => r.returnPct > 0).length;
      const rate = wins / g.length;
      if (worst === null || rate < worst.rate) {
        worst = { label: dim.name(k), wins, total: g.length, rate };
      }
    }
  }
  if (!worst) return null;
  return { label: worst.label, wins: worst.wins, total: worst.total };
}

export type DailySimResult = {
  simDate: string;
  dayIndex: number;
  outcome: string;
  trades: number;
};

// Run (or re-run) the simulation for a specific ET date key. Idempotent: if a
// record already exists for that date it is returned unchanged unless force.
export async function runDailySimulation(dateKey?: string, force = false): Promise<DailySimResult | null> {
  const review = await prisma.strategyReview.findFirst({ orderBy: { runAt: 'desc' } });
  if (!review) return null; // no playbook yet — nothing to simulate

  const simDate = dateKey || etDateKey(new Date());

  const existing = await prisma.dailySimulation.findUnique({ where: { simDate } });
  if (existing && !force) {
    return { simDate, dayIndex: existing.dayIndex, outcome: existing.outcome, trades: existing.trades };
  }

  // Pull that ET day's resolved signals. We over-fetch a UTC window covering the
  // ET day and then filter precisely by ET date key.
  const dayStart = new Date(`${simDate}T00:00:00-04:00`);
  const lo = new Date(dayStart.getTime() - 6 * 3600 * 1000);
  const hi = new Date(dayStart.getTime() + 30 * 3600 * 1000);

  const raw = await prisma.signalObservation.findMany({
    where: { status: { not: 'PENDING' }, returnPct: { not: null }, observedAt: { gte: lo, lte: hi } },
    select: {
      id: true, symbol: true, status: true, direction: true, heat: true, returnPct: true,
      tradeType: true, assetClass: true, sessionSlot: true, marketRegime: true, rsi: true,
      volumeRatio: true, volumeSurge: true, buyPressure: true, vwapDistPct: true, maxFavorablePct: true,
      rsiSlope: true, atrPct: true, vwapReclaim: true, rsiShort: true,
      maxAdversePct: true, pathComplete: true, observedAt: true, horizonHours: true,
      targetPct: true, stopPct: true,
    },
    take: 5000,
  });

  const dayRows: SimRow[] = raw.filter(r => etDateKey(r.observedAt) === simDate) as unknown as SimRow[];

  // The trader only takes setups that (a) are cleanly intraday-executable and
  // (b) match the tool's current best rule (the playbook).
  const predicate = getRulePredicate(review.bestRuleId);
  const matched = dayRows.filter(
    r => isIntradayExecutable(r.observedAt, r.horizonHours ?? DEFAULT_HORIZON_HOURS) && predicate(r as unknown as ReviewRow),
  );

  const details: SimTradeDetail[] = matched.map(r => ({
    symbol: r.symbol,
    direction: r.direction,
    assetClass: r.assetClass,
    sessionSlot: r.sessionSlot,
    status: r.status,
    returnPct: Math.round(((r.returnPct as number) ?? 0) * 100) / 100,
  }));

  const trades = details.length;
  const wins = details.filter(d => d.returnPct > 0).length;
  const losses = details.filter(d => d.returnPct <= 0).length;
  const winRate = trades ? Math.round((wins / trades) * 1000) / 10 : 0;
  const grossPnlPct = Math.round(details.reduce((s, d) => s + d.returnPct, 0) * 100) / 100;
  const avgPnlPct = trades ? Math.round((grossPnlPct / trades) * 100) / 100 : 0;
  const baselineWinRate = review.baselineWinRate;

  // Running totals from the previous day journaled.
  const prevSim = await prisma.dailySimulation.findFirst({
    where: { simDate: { lt: simDate } },
    orderBy: { simDate: 'desc' },
  });
  const priorCount = await prisma.dailySimulation.count({ where: { simDate: { lt: simDate } } });
  const dayIndex = priorCount + 1;
  const cumulativePnlPct = Math.round(((prevSim?.cumulativePnlPct ?? 0) + grossPnlPct) * 100) / 100;

  // ---- Outcome, summary, why, lesson (all data-derived) ----
  let outcome: string;
  let summary: string;
  let why: string;
  let lesson: string;

  const exitNote =
    review.bestExitTargetPct != null && review.bestExitStopPct != null
      ? ` Plan for the day: hold for +${review.bestExitTargetPct}%, cut losses by -${review.bestExitStopPct}%.`
      : '';

  if (trades === 0) {
    outcome = 'no_trade';
    summary = `No setups met the playbook today, so the trader stayed in cash and preserved capital.`;
    why = `The playbook only takes ${review.bestRuleLabel.replace(/^Only /, '')}. Nothing on the board qualified today, so there was nothing worth risking money on.`;
    lesson = `A no-trade day is a win for discipline. Wait for the setup tomorrow rather than forcing a trade.`;
  } else {
    const targetHits = matched.filter(r => r.status === 'WIN').length;
    const stopOuts = matched.filter(r => r.status === 'LOSS').length;
    const expired = matched.filter(r => r.status === 'EXPIRED').length;
    const winnerTrait = dominantTrait(details.filter(d => d.returnPct > 0));
    const loserTrait = dominantTrait(details.filter(d => d.returnPct <= 0));

    if (grossPnlPct > 0 && winRate >= baselineWinRate) outcome = 'success';
    else if (grossPnlPct > 0) outcome = 'mixed';
    else outcome = 'failure';

    const outcomeWord =
      outcome === 'success' ? 'A solid, profitable day' : outcome === 'mixed' ? 'A choppy but green day' : 'A losing day';
    summary = `${outcomeWord}: ${wins} winner${wins === 1 ? '' : 's'} and ${losses} loser${losses === 1 ? '' : 's'} across ${trades} trade${trades === 1 ? '' : 's'}, ${fmtPct(grossPnlPct)} on the day (${winRate}% win rate vs a ${baselineWinRate}% baseline).${exitNote}`;

    const whyBits: string[] = [];
    whyBits.push(`${targetHits} trade${targetHits === 1 ? '' : 's'} hit target, ${stopOuts} stopped out${expired ? `, ${expired} timed out` : ''}.`);
    if (outcome !== 'failure' && winnerTrait) whyBits.push(`The gains came mostly from ${winnerTrait}.`);
    if (outcome === 'failure' && loserTrait) whyBits.push(`The damage came mostly from ${loserTrait}.`);
    else if (loserTrait && losses > 0) whyBits.push(`Most of the losers were ${loserTrait}.`);
    why = whyBits.join(' ');

    if (wins === trades) {
      lesson = `Clean sweep — every trade worked. Keep following the playbook exactly; don't get greedy and widen the rules.`;
    } else {
      const worst = worstSegment(details);
      if (worst && worst.wins / worst.total < 0.5) {
        lesson = `Be cautious with ${worst.label} tomorrow — only ${worst.wins} of ${worst.total} worked today. Everything else held up better.`;
      } else if (outcome === 'failure') {
        lesson = `The playbook lost money today. Trade smaller and demand cleaner setups tomorrow until the edge reasserts itself.`;
      } else {
        lesson = `Solid day overall. Stay patient and keep taking only the setups the playbook signals.`;
      }
    }
  }

  const data = {
    simDate,
    dayIndex,
    playbookRuleId: review.bestRuleId,
    playbookLabel: review.bestRuleLabel,
    trades,
    wins,
    losses,
    winRate,
    grossPnlPct,
    avgPnlPct,
    cumulativePnlPct,
    baselineWinRate,
    outcome,
    summary,
    why,
    lesson,
    tradesJson: details as any,
  };

  await prisma.dailySimulation.upsert({
    where: { simDate },
    update: data,
    create: data,
  });

  return { simDate, dayIndex, outcome, trades };
}

// Keep the journal current: judge the newest COMPLETED session and back-fill any
// missed days. Safe to call on every agent tick.
export async function maybeRunDailySim(force = false): Promise<{ ran: boolean; result?: DailySimResult | null }> {
  // The journal may only judge a day that is FULLY over, otherwise the day's
  // later trades have not resolved yet. Today counts as over once the close has
  // passed (>= 16:00 ET); before that, the newest completed day is yesterday.
  //
  // This used to simply bail out whenever the clock read before 16:00 ET, which
  // silently killed the journal: the scanner's last run of the day fires at
  // 3:30 PM ET, so the >= 16:00 gate was never once satisfied and no entry was
  // ever written again. Anchoring to the newest COMPLETED day instead means the
  // journal keeps up regardless of what time the scanner happens to tick.
  const now = new Date();
  const newestComplete = etHourNow(now) >= 16 ? now : new Date(now.getTime() - 24 * 3600 * 1000);

  // Walk back over the recent past and fill in every day that is missing an
  // entry, so a stretch of downtime is caught up instead of lost forever.
  const CATCH_UP_DAYS = 10;
  let ran = false;
  let lastResult: DailySimResult | null = null;

  for (let back = 0; back < CATCH_UP_DAYS; back++) {
    const target = new Date(newestComplete.getTime() - back * 24 * 3600 * 1000);
    const simDate = etDateKey(target);

    // Skip weekends — there is no session to journal.
    const dow = new Date(target.toLocaleString('en-US', { timeZone: 'America/New_York' })).getDay();
    if (dow === 0 || dow === 6) continue;

    const existing = await prisma.dailySimulation.findUnique({ where: { simDate } });
    if (existing && !force) continue;

    const result = await runDailySimulation(simDate, force);
    if (result) {
      ran = true;
      if (back === 0 || !lastResult) lastResult = result;
    }
    // Only the newest day is re-simulated when forcing, to keep a manual
    // force cheap and predictable.
    if (force) break;
  }

  return { ran, result: lastResult };
}

// Most-recent-first list of journaled days for the UI.
export async function getSimulations(limit = 40) {
  const sims = await prisma.dailySimulation.findMany({
    orderBy: { simDate: 'desc' },
    take: limit,
  });

  // Cumulative header stats + a "recurring lessons" aggregate (the segment that
  // shows up most often as a caution across recent days).
  const daysTraded = sims.filter(s => s.outcome !== 'no_trade').length;
  const latestCumulative = sims.length ? sims[0].cumulativePnlPct : 0;
  const wins = sims.filter(s => s.outcome === 'success').length;
  const losses = sims.filter(s => s.outcome === 'failure').length;

  return {
    sims,
    header: {
      totalDays: sims.length,
      daysTraded,
      cumulativePnlPct: latestCumulative,
      successDays: wins,
      failureDays: losses,
    },
  };
}

```

---

## FILE: code/lib/data-provider.ts

```typescript
// Modular Data Provider - Easy to switch between Yahoo, Finnhub, Alpha Vantage
// Set DATA_PROVIDER env var to: 'yahoo' | 'finnhub' | 'alphavantage'

export interface StockDataPoint {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface IntradayDataPoint extends StockDataPoint {
  timestamp: number;
}

export interface StockDataResponse {
  symbol: string;
  lastRefreshed: string;
  data: StockDataPoint[];
}

export interface QuoteResponse {
  symbol: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  avgVolume: number;
  high: number;
  low: number;
  open: number;
  previousClose: number;
}

const DATA_PROVIDER = process.env.DATA_PROVIDER || 'yahoo';

// ============ YAHOO FINANCE (Default - Free, No API Key) ============
async function fetchYahooDaily(symbol: string): Promise<StockDataResponse> {
  const endDate = Math.floor(Date.now() / 1000);
  const startDate = endDate - (365 * 24 * 60 * 60); // 1 year
  
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?period1=${startDate}&period2=${endDate}&interval=1d`;
  
  const response = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  const json = await response.json();
  
  if (json.chart?.error) {
    throw new Error(json.chart.error.description || `Invalid symbol: ${symbol}`);
  }
  
  const result = json.chart?.result?.[0];
  if (!result) {
    throw new Error(`No data found for symbol: ${symbol}`);
  }
  
  const timestamps = result.timestamp || [];
  const quotes = result.indicators?.quote?.[0] || {};
  
  const data: StockDataPoint[] = timestamps.map((ts: number, i: number) => ({
    date: new Date(ts * 1000).toISOString().split('T')[0],
    open: quotes.open?.[i] || 0,
    high: quotes.high?.[i] || 0,
    low: quotes.low?.[i] || 0,
    close: quotes.close?.[i] || 0,
    volume: quotes.volume?.[i] || 0,
  })).filter((d: StockDataPoint) => d.close > 0);
  
  return {
    symbol: symbol.toUpperCase(),
    lastRefreshed: new Date().toISOString(),
    data,
  };
}

async function fetchYahooIntraday(symbol: string, interval: string = '5m'): Promise<IntradayDataPoint[]> {
  // Yahoo supports: 1m, 2m, 5m, 15m, 30m, 60m, 90m, 1h
  const range = interval === '1m' ? '1d' : interval === '5m' ? '5d' : '5d';
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?range=${range}&interval=${interval}`;
  
  const response = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  const json = await response.json();
  
  if (json.chart?.error) {
    throw new Error(json.chart.error.description || `Invalid symbol: ${symbol}`);
  }
  
  const result = json.chart?.result?.[0];
  if (!result) {
    throw new Error(`No intraday data for: ${symbol}`);
  }
  
  const timestamps = result.timestamp || [];
  const quotes = result.indicators?.quote?.[0] || {};
  
  return timestamps.map((ts: number, i: number) => ({
    timestamp: ts * 1000,
    date: new Date(ts * 1000).toISOString(),
    open: quotes.open?.[i] || 0,
    high: quotes.high?.[i] || 0,
    low: quotes.low?.[i] || 0,
    close: quotes.close?.[i] || 0,
    volume: quotes.volume?.[i] || 0,
  })).filter((d: IntradayDataPoint) => d.close > 0);
}

async function fetchYahooQuote(symbol: string): Promise<QuoteResponse> {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=1d&range=2d`;
  
  const response = await fetch(url, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });
  const json = await response.json();
  
  const result = json.chart?.result?.[0];
  const meta = result?.meta || {};
  const quotes = result?.indicators?.quote?.[0] || {};
  const len = quotes.close?.length || 0;
  
  const currentPrice = meta.regularMarketPrice || quotes.close?.[len - 1] || 0;
  const previousClose = meta.previousClose || meta.chartPreviousClose || quotes.close?.[len - 2] || currentPrice;
  
  return {
    symbol: symbol.toUpperCase(),
    price: currentPrice,
    change: currentPrice - previousClose,
    changePercent: previousClose > 0 ? ((currentPrice - previousClose) / previousClose) * 100 : 0,
    volume: meta.regularMarketVolume || quotes.volume?.[len - 1] || 0,
    avgVolume: meta.averageDailyVolume10Day || 0,
    high: meta.regularMarketDayHigh || quotes.high?.[len - 1] || 0,
    low: meta.regularMarketDayLow || quotes.low?.[len - 1] || 0,
    open: meta.regularMarketOpen || quotes.open?.[len - 1] || 0,
    previousClose,
  };
}

// ============ ALPHA VANTAGE (Premium - Set API Key) ============
async function fetchAlphaVantageDaily(symbol: string): Promise<StockDataResponse> {
  const apiKey = process.env.ALPHA_VANTAGE_API_KEY;
  if (!apiKey) throw new Error('ALPHA_VANTAGE_API_KEY not configured');
  
  const url = `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${symbol}&apikey=${apiKey}&outputsize=compact`;
  const response = await fetch(url);
  const json = await response.json();
  
  if (json['Error Message']) throw new Error(`Invalid symbol: ${symbol}`);
  if (json['Note'] || json['Information']) throw new Error('API rate limit reached');
  
  const timeSeries = json['Time Series (Daily)'];
  if (!timeSeries) throw new Error('Unable to fetch stock data');
  
  const data: StockDataPoint[] = Object.entries(timeSeries)
    .map(([date, values]: [string, any]) => ({
      date,
      open: parseFloat(values['1. open']),
      high: parseFloat(values['2. high']),
      low: parseFloat(values['3. low']),
      close: parseFloat(values['4. close']),
      volume: parseInt(values['5. volume']),
    }))
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  return { symbol: symbol.toUpperCase(), lastRefreshed: new Date().toISOString(), data };
}

// ============ EXPORTED FUNCTIONS (Auto-switch based on provider) ============
export async function fetchDailyStockData(symbol: string): Promise<StockDataResponse> {
  switch (DATA_PROVIDER) {
    case 'alphavantage':
      return fetchAlphaVantageDaily(symbol);
    case 'yahoo':
    default:
      return fetchYahooDaily(symbol);
  }
}

export async function fetchIntradayData(symbol: string, interval: string = '5m'): Promise<IntradayDataPoint[]> {
  // Currently only Yahoo supports intraday in free tier
  return fetchYahooIntraday(symbol, interval);
}

export async function fetchQuote(symbol: string): Promise<QuoteResponse> {
  return fetchYahooQuote(symbol);
}

export function getDataProvider(): string {
  return DATA_PROVIDER;
}

```

---

## FILE: code/lib/earnings-calendar.ts

```typescript
// Earnings Calendar Integration
// Fetches upcoming earnings dates from Yahoo Finance

export interface EarningsInfo {
  symbol: string;
  earningsDate: string | null; // ISO date string
  daysUntilEarnings: number | null;
  isEarningsSoon: boolean; // within 7 days
  earningsWarning: string | null; // Warning message if relevant
}

// Cache earnings data for 6 hours to reduce API calls
const earningsCache = new Map<string, { data: EarningsInfo; fetchedAt: number }>();
const CACHE_TTL = 6 * 60 * 60 * 1000; // 6 hours

export async function fetchEarningsInfo(symbol: string): Promise<EarningsInfo> {
  // Check cache
  const cached = earningsCache.get(symbol.toUpperCase());
  if (cached && Date.now() - cached.fetchedAt < CACHE_TTL) {
    return cached.data;
  }

  try {
    // Use Yahoo Finance v8 to get earnings date from calendar events
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=1d&range=1d&includePrePost=false`;
    const response = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });
    const json = await response.json();
    const result = json.chart?.result?.[0];

    // Try to get earnings date from events
    let earningsTimestamp: number | null = null;
    const events = result?.events?.earnings;
    if (events) {
      // events is an object with timestamps as keys
      const upcoming = Object.values(events)
        .map((e: any) => e.date)
        .filter((ts: number) => ts * 1000 > Date.now())
        .sort((a: number, b: number) => a - b);
      if (upcoming.length > 0) {
        earningsTimestamp = upcoming[0] as number;
      }
    }

    // If chart API doesn't have earnings, try quoteSummary as fallback
    if (!earningsTimestamp) {
      try {
        const summaryUrl = `https://query1.finance.yahoo.com/v10/finance/quoteSummary/${symbol}?modules=calendarEvents`;
        const summaryRes = await fetch(summaryUrl, {
          headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const summaryJson = await summaryRes.json();
        const calendar = summaryJson.quoteSummary?.result?.[0]?.calendarEvents;
        const earningsDates = calendar?.earnings?.earningsDate;
        if (earningsDates && earningsDates.length > 0) {
          const upcoming = earningsDates
            .map((d: any) => d.raw)
            .filter((ts: number) => ts * 1000 > Date.now())
            .sort((a: number, b: number) => a - b);
          if (upcoming.length > 0) {
            earningsTimestamp = upcoming[0];
          }
        }
      } catch {
        // fallback failed, continue without earnings
      }
    }

    const info = buildEarningsInfo(symbol, earningsTimestamp);
    earningsCache.set(symbol.toUpperCase(), { data: info, fetchedAt: Date.now() });
    return info;
  } catch (error) {
    console.error(`Failed to fetch earnings for ${symbol}:`, error);
    const fallback: EarningsInfo = {
      symbol: symbol.toUpperCase(),
      earningsDate: null,
      daysUntilEarnings: null,
      isEarningsSoon: false,
      earningsWarning: null,
    };
    earningsCache.set(symbol.toUpperCase(), { data: fallback, fetchedAt: Date.now() });
    return fallback;
  }
}

function buildEarningsInfo(symbol: string, earningsTimestamp: number | null): EarningsInfo {
  if (!earningsTimestamp) {
    return {
      symbol: symbol.toUpperCase(),
      earningsDate: null,
      daysUntilEarnings: null,
      isEarningsSoon: false,
      earningsWarning: null,
    };
  }

  const earningsDate = new Date(earningsTimestamp * 1000);
  const now = new Date();
  const diffMs = earningsDate.getTime() - now.getTime();
  const daysUntil = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  const isEarningsSoon = daysUntil >= 0 && daysUntil <= 7;

  let earningsWarning: string | null = null;
  if (daysUntil <= 0) {
    earningsWarning = `⚠️ Earnings reported today/recently - high volatility expected`;
  } else if (daysUntil <= 2) {
    earningsWarning = `🚨 Earnings in ${daysUntil} day${daysUntil === 1 ? '' : 's'} - extreme caution: gap risk`;
  } else if (daysUntil <= 5) {
    earningsWarning = `⚠️ Earnings in ${daysUntil} days - swing trades may be affected`;
  } else if (daysUntil <= 14) {
    earningsWarning = `📅 Earnings in ${daysUntil} days - factor into trade duration`;
  }

  return {
    symbol: symbol.toUpperCase(),
    earningsDate: earningsDate.toISOString().split('T')[0],
    daysUntilEarnings: daysUntil,
    isEarningsSoon,
    earningsWarning,
  };
}

// Generate a trade-specific earnings warning based on ROI timeline
export function getEarningsTradeWarning(
  earnings: EarningsInfo,
  tradeType: 'intraday' | 'short_swing' | 'long_swing'
): string | null {
  if (!earnings.daysUntilEarnings || earnings.daysUntilEarnings < 0) return null;

  const days = earnings.daysUntilEarnings;

  if (tradeType === 'intraday') {
    if (days === 0) return '🚨 EARNINGS TODAY - Expect extreme volatility. Intraday trades very risky.';
    if (days === 1) return '⚠️ Earnings tomorrow - After-hours move could gap against you.';
    return null; // Intraday shouldn't be affected by earnings >1 day out
  }

  if (tradeType === 'short_swing') {
    if (days <= 5) return `🚨 Earnings in ${days}d - Your 1-5 day swing overlaps with earnings. High gap risk.`;
    if (days <= 7) return `⚠️ Earnings in ${days}d - Close to your swing window. Consider exiting before.`;
    return null;
  }

  if (tradeType === 'long_swing') {
    if (days <= 14) return `⚠️ Earnings in ${days}d - Falls within your 1-4 week window. Plan exit before or after earnings.`;
    if (days <= 21) return `📅 Earnings in ${days}d - Approaching your trade window. Monitor closely.`;
    return null;
  }

  return null;
}

```

---

## FILE: code/lib/eod-losses.ts

```typescript
import { prisma } from './db';
import type { RawLever } from './lever-reconciliation';

// ---------------------------------------------------------------------------
// EOD Worst-20 Paper-Loss Report
//
// Read-only. Pulls the 20 worst CLOSED paper trades (by returnPct) for a given
// ET day in the exact detail Phillip asks for: ticker, direction (bought/short),
// entry price, exit price, entry time, exit time, loss %, P&L, exit reason.
//
// It then runs a data-driven "trim the fat" analysis over the clean-data window
// (Update 3.0, since 8/28) to surface WHERE the recurring losses come from and
// concrete, evidence-based ways to reduce them. Every number is measured from
// the PaperTrade table; nothing is fabricated.
// ---------------------------------------------------------------------------

const CLEAN_WINDOW_START_ET = '2026-08-28'; // first Update 3.0 clean-fills day
export const EOD_RECIPIENT = 'misiti15@gmail.com';

// ---- ET helpers (Aug–early Nov = EDT, UTC-4) ------------------------------
export function etDayKey(d: Date): string {
  return d.toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
}
function etDayBounds(dateEt: string): { start: Date; end: Date } {
  const start = new Date(`${dateEt}T00:00:00-04:00`);
  const end = new Date(start.getTime() + 24 * 60 * 60 * 1000);
  return { start, end };
}
function fmtEtTime(d: Date | null): string {
  if (!d) return '—';
  return d.toLocaleTimeString('en-US', { timeZone: 'America/New_York', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
}
function round2(n: number): number { return Math.round(n * 100) / 100; }
function round1(n: number): number { return Math.round(n * 10) / 10; }

// ---- Types ----------------------------------------------------------------
export interface LossRow {
  symbol: string;
  direction: string;       // LONG | SHORT
  entryPrice: number;
  exitPrice: number | null;
  entryEt: string;
  exitEt: string;
  returnPct: number | null;
  pnlDollars: number | null;
  exitReason: string | null;
  peakPct: number | null;
  troughPct: number | null;
  heat: number | null;
  holdMin: number | null;
  cleanFill: boolean;
}

export interface TrimInsight {
  windowStartEt: string;
  losers: number;
  totalClosed: number;
  worstSymbols: { symbol: string; losses: number; avgLossPct: number; netPnl: number }[];
  greenThenLost: number;         // peakPct >= 0.3 then closed a loser
  greenThenLostPct: number;
  quickStops: number;            // stop_loss within 10 min
  quickStopsPct: number;
  byExitReason: { reason: string; count: number; avgPct: number }[];
  bySlot: { slot: string; losses: number; avgPct: number }[];
  longLossRate: number | null;
  shortLossRate: number | null;
  suggestions: string[];
}

export interface EodLossReport {
  dateEt: string;
  generatedAt: string;
  dayClosed: number;
  dayWins: number;
  dayLosses: number;
  dayWinRate: number;
  dayNetPnl: number;
  worst: LossRow[];
  trim: TrimInsight;
}

interface RawTrade {
  symbol: string; direction: string; entryPrice: number; entryTime: Date;
  exitPrice: number | null; exitTime: Date | null; exitReason: string | null;
  returnPct: number | null; pnlDollars: number | null; peakPct: number | null;
  troughPct: number | null; heat: number | null; sessionSlot: string | null;
  alpacaExitId: string | null;
}

const TRADE_SELECT = {
  symbol: true, direction: true, entryPrice: true, entryTime: true,
  exitPrice: true, exitTime: true, exitReason: true, returnPct: true,
  pnlDollars: true, peakPct: true, troughPct: true, heat: true,
  sessionSlot: true, alpacaExitId: true,
} as const;

function holdMinutes(t: RawTrade): number | null {
  if (!t.exitTime) return null;
  return Math.round((t.exitTime.getTime() - t.entryTime.getTime()) / 60000);
}

function toLossRow(t: RawTrade): LossRow {
  return {
    symbol: t.symbol,
    direction: t.direction,
    entryPrice: t.entryPrice,
    exitPrice: t.exitPrice,
    entryEt: fmtEtTime(t.entryTime),
    exitEt: fmtEtTime(t.exitTime),
    returnPct: t.returnPct !== null ? round2(t.returnPct) : null,
    pnlDollars: t.pnlDollars !== null ? round2(t.pnlDollars) : null,
    exitReason: t.exitReason,
    peakPct: t.peakPct !== null ? round2(t.peakPct) : null,
    troughPct: t.troughPct !== null ? round2(t.troughPct) : null,
    heat: t.heat !== null ? round1(t.heat) : null,
    holdMin: holdMinutes(t),
    cleanFill: !!(t.alpacaExitId && t.alpacaExitId.length > 0),
  };
}

const REASON_LABEL: Record<string, string> = {
  stop_loss: 'Stop-loss',
  take_profit: 'Take-profit',
  trailing_stop: 'Trailing stop',
  time_exit: 'Time exit',
  eod_close: 'EOD close',
};
function reasonLabel(r: string | null): string { return r ? (REASON_LABEL[r] || r) : '—'; }

// ---- Trim-the-fat analysis over the clean window --------------------------
function buildTrim(all: RawTrade[]): TrimInsight {
  const closed = all.filter(t => t.returnPct !== null);
  const losers = closed.filter(t => (t.returnPct as number) <= 0);

  // Frequently-lost symbols
  const bySym = new Map<string, { losses: number; sumPct: number; netPnl: number }>();
  for (const t of losers) {
    const e = bySym.get(t.symbol) || { losses: 0, sumPct: 0, netPnl: 0 };
    e.losses++; e.sumPct += (t.returnPct as number); e.netPnl += (t.pnlDollars ?? 0);
    bySym.set(t.symbol, e);
  }
  const worstSymbols = [...bySym.entries()]
    .map(([symbol, e]) => ({ symbol, losses: e.losses, avgLossPct: round2(e.sumPct / e.losses), netPnl: round2(e.netPnl) }))
    .sort((a, b) => b.losses - a.losses || a.netPnl - b.netPnl)
    .slice(0, 8);

  // Green-then-lost (peak >= 0.3% favorable, still closed red) => trailing/partial candidate
  const greenThenLost = losers.filter(t => t.peakPct !== null && (t.peakPct as number) >= 0.3).length;
  // Quick stop-outs (stop_loss within 10 min)
  const quickStops = losers.filter(t => t.exitReason === 'stop_loss' && (holdMinutes(t) ?? 999) <= 10).length;

  // By exit reason
  const byReasonMap = new Map<string, { count: number; sumPct: number }>();
  for (const t of losers) {
    const k = t.exitReason || 'unknown';
    const e = byReasonMap.get(k) || { count: 0, sumPct: 0 };
    e.count++; e.sumPct += (t.returnPct as number);
    byReasonMap.set(k, e);
  }
  const byExitReason = [...byReasonMap.entries()]
    .map(([reason, e]) => ({ reason: reasonLabel(reason), count: e.count, avgPct: round2(e.sumPct / e.count) }))
    .sort((a, b) => b.count - a.count);

  // By session slot
  const bySlotMap = new Map<string, { losses: number; sumPct: number }>();
  for (const t of losers) {
    const k = t.sessionSlot || 'unknown';
    const e = bySlotMap.get(k) || { losses: 0, sumPct: 0 };
    e.losses++; e.sumPct += (t.returnPct as number);
    bySlotMap.set(k, e);
  }
  const bySlot = [...bySlotMap.entries()]
    .map(([slot, e]) => ({ slot, losses: e.losses, avgPct: round2(e.sumPct / e.losses) }))
    .sort((a, b) => b.losses - a.losses);

  // Long vs short loss rate
  const longs = closed.filter(t => t.direction.toUpperCase() === 'LONG');
  const shorts = closed.filter(t => t.direction.toUpperCase() === 'SHORT');
  const longLossRate = longs.length ? round1(100 * longs.filter(t => (t.returnPct as number) <= 0).length / longs.length) : null;
  const shortLossRate = shorts.length ? round1(100 * shorts.filter(t => (t.returnPct as number) <= 0).length / shorts.length) : null;

  const suggestions: string[] = [];
  if (losers.length > 0) {
    if (greenThenLost > 0) {
      const pct = round1(100 * greenThenLost / losers.length);
      suggestions.push(`${greenThenLost} of ${losers.length} losers (${pct}%) were at least +0.3% in our favor before reversing red. A tighter trailing-stop activation or a partial profit-take at ~+0.3–0.5% would have salvaged part of these — the single highest-value lever to test.`);
    }
    if (quickStops > 0) {
      const pct = round1(100 * quickStops / losers.length);
      suggestions.push(`${quickStops} losers (${pct}%) stopped out within 10 minutes of entry — fast reversals right after entry. A 1–2 tick / short confirmation delay before committing, or skipping entries in the first minutes of a fresh move, could cut these.`);
    }
    // NOTE: we deliberately do NOT surface “frequent loser tickers” here. Per the
    // owner's directive (9/3): if we're losing, it's OUR system to fix, not a
    // continuously unpredictable ticker or market. Loss analysis is framed around
    // SYSTEM / SETUP failure modes (timing, exit handling, the book, the session),
    // never around blaming symbols.
    if (longLossRate !== null && shortLossRate !== null && longLossRate - shortLossRate >= 12) {
      suggestions.push(`Longs lose ${longLossRate}% of the time vs shorts ${shortLossRate}% — the long side is the weaker book. Raising the long-entry bar (higher heat / RSI confirmation) or trimming long exposure would lift overall win rate.`);
    }
    const worstSlot = bySlot[0];
    if (worstSlot && worstSlot.losses >= 3) {
      suggestions.push(`The "${worstSlot.slot}" window holds the most losers (${worstSlot.losses}, avg ${worstSlot.avgPct}%). If this persists, a session filter for that window is worth an A/B test.`);
    }
  }

  return {
    windowStartEt: CLEAN_WINDOW_START_ET,
    losers: losers.length,
    totalClosed: closed.length,
    worstSymbols,
    greenThenLost,
    greenThenLostPct: losers.length ? round1(100 * greenThenLost / losers.length) : 0,
    quickStops,
    quickStopsPct: losers.length ? round1(100 * quickStops / losers.length) : 0,
    byExitReason,
    bySlot,
    longLossRate,
    shortLossRate,
    suggestions,
  };
}

// ---- Main entry -----------------------------------------------------------
export async function getEodLossReport(dateEt?: string): Promise<EodLossReport> {
  const targetDate = dateEt || etDayKey(new Date());
  const { start, end } = etDayBounds(targetDate);
  const cleanStart = etDayBounds(CLEAN_WINDOW_START_ET).start;

  const [dayRaw, cleanRaw] = await Promise.all([
    prisma.paperTrade.findMany({
      where: { status: 'CLOSED', exitTime: { gte: start, lt: end } },
      select: TRADE_SELECT,
      orderBy: { returnPct: 'asc' },
    }) as Promise<RawTrade[]>,
    prisma.paperTrade.findMany({
      where: { status: 'CLOSED', exitTime: { gte: cleanStart } },
      select: TRADE_SELECT,
    }) as Promise<RawTrade[]>,
  ]);

  const closed = dayRaw.filter(t => t.returnPct !== null);
  const wins = closed.filter(t => (t.returnPct as number) > 0).length;
  const losses = closed.length - wins;
  const netPnl = round2(closed.reduce((s, t) => s + (t.pnlDollars ?? 0), 0));

  return {
    dateEt: targetDate,
    generatedAt: new Date().toISOString(),
    dayClosed: closed.length,
    dayWins: wins,
    dayLosses: losses,
    dayWinRate: closed.length ? round1(100 * wins / closed.length) : 0,
    dayNetPnl: netPnl,
    worst: dayRaw.slice(0, 20).map(toLossRow),
    trim: buildTrim(cleanRaw),
  };
}

// ---- Structured levers for cross-source reconciliation (EL#5-A) -----------
// Turns the trim analysis into structured levers so the nightly self-correction
// job can reconcile them against its own proposals (overlaps folded, conflicts
// resolved). Framed by SYSTEM failure mode — never by ticker.
export function trimToLevers(trim: TrimInsight): RawLever[] {
  const levers: RawLever[] = [];
  if (trim.losers === 0) return levers;

  if (trim.greenThenLost > 0) {
    levers.push({
      source: 'eod-losses',
      severity: 'watch',
      target: 'exit_giveback',
      direction: 'tighten',
      title: `${trim.greenThenLostPct}% of losers went ≥+0.3% green then reversed`,
      detail: `${trim.greenThenLost} of ${trim.losers} losers were in profit before closing red — an exit-handling failure. Tighter trailing activation or a partial take-profit would salvage part of these.`,
      edit: 'Test tighter trailing activation / partial take-profit (exit handling)',
      score: 40 + trim.greenThenLostPct,
    });
  }
  if (trim.quickStops > 0) {
    levers.push({
      source: 'eod-losses',
      severity: 'watch',
      target: 'entry_timing',
      direction: 'tighten',
      title: `${trim.quickStopsPct}% of losers stopped out ≤10 min`,
      detail: `${trim.quickStops} losers reversed within 10 minutes of entry — an entry-timing failure. A short confirmation delay before committing could cut these.`,
      edit: 'Test 1–2 tick / short confirmation delay before entry',
      score: 30 + trim.quickStopsPct,
    });
  }
  if (trim.longLossRate !== null && trim.shortLossRate !== null && trim.longLossRate - trim.shortLossRate >= 12) {
    levers.push({
      source: 'eod-losses',
      severity: 'watch',
      target: 'longsEnabled',
      direction: 'tighten',
      title: `Long book loses ${trim.longLossRate}% vs shorts ${trim.shortLossRate}%`,
      detail: `The long side is the weaker book — a detector failure. Keep longs benched / raise the long-entry bar until the long detector is rebuilt.`,
      edit: 'trading-guardrails.ts → keep longsEnabled:false / raise longMinLB',
      score: 25 + (trim.longLossRate - trim.shortLossRate),
    });
  }
  const worstSlot = trim.bySlot[0];
  if (worstSlot && worstSlot.losses >= 3) {
    levers.push({
      source: 'eod-losses',
      severity: 'watch',
      target: `session:${worstSlot.slot}`,
      direction: 'tighten',
      title: `“${worstSlot.slot}” session holds the most losers (${worstSlot.losses})`,
      detail: `Avg ${worstSlot.avgPct}% across ${worstSlot.losses} losers in this session window — a timing failure worth an A/B before any filter.`,
      edit: `A/B test a session filter for “${worstSlot.slot}”`,
      score: 15 + worstSlot.losses,
    });
  }
  return levers;
}

// Convenience: compute EOD levers over the clean window directly.
export async function getEodLevers(): Promise<RawLever[]> {
  const cleanStart = etDayBounds(CLEAN_WINDOW_START_ET).start;
  const cleanRaw = await prisma.paperTrade.findMany({
    where: { status: 'CLOSED', exitTime: { gte: cleanStart } },
    select: TRADE_SELECT,
  }) as RawTrade[];
  return trimToLevers(buildTrim(cleanRaw));
}

// ---- Email rendering ------------------------------------------------------
function dirTag(dir: string): { label: string; color: string } {
  return dir.toUpperCase() === 'LONG'
    ? { label: 'Bought', color: '#16a34a' }
    : { label: 'Short', color: '#ef4444' };
}

export function renderEodLossEmail(r: EodLossReport): string {
  const etNow = new Date().toLocaleString('en-US', { timeZone: 'America/New_York', dateStyle: 'medium', timeStyle: 'short' });

  const rowsHtml = r.worst.length === 0
    ? `<tr><td colspan="8" style="padding:14px;text-align:center;color:#888;">No closed paper trades for ${r.dateEt}.</td></tr>`
    : r.worst.map((t, i) => {
        const d = dirTag(t.direction);
        const flag = t.cleanFill ? '' : ' <span title="quote-derived exit" style="color:#d97706;">⚠</span>';
        return `<tr style="border-bottom:1px solid #eee;">
          <td style="padding:7px 8px;color:#555;">${i + 1}</td>
          <td style="padding:7px 8px;font-weight:700;">${t.symbol}${flag}</td>
          <td style="padding:7px 8px;color:${d.color};font-weight:600;">${d.label}</td>
          <td style="padding:7px 8px;text-align:right;">$${t.entryPrice}</td>
          <td style="padding:7px 8px;text-align:right;">${t.exitPrice !== null ? '$' + t.exitPrice : '—'}</td>
          <td style="padding:7px 8px;text-align:center;color:#666;">${t.entryEt}</td>
          <td style="padding:7px 8px;text-align:center;color:#666;">${t.exitEt}</td>
          <td style="padding:7px 8px;text-align:right;font-weight:700;color:${(t.returnPct ?? 0) < 0 ? '#dc2626' : '#16a34a'};">${t.returnPct !== null ? t.returnPct + '%' : '—'}</td>
        </tr>`;
      }).join('');

  const suggestionsHtml = r.trim.suggestions.length
    ? r.trim.suggestions.map(s => `<li style="margin:0 0 8px;line-height:1.5;">${s}</li>`).join('')
    : '<li>No recurring loss pattern strong enough to flag yet — keep accumulating clean days.</li>';

  return `
  <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:640px;margin:0 auto;color:#333;">
    <div style="background:#404040;padding:16px 20px;border-radius:12px 12px 0 0;">
      <h1 style="margin:0;font-size:20px;color:#4CBB17;">MarcoFlow — EOD Worst-20</h1>
      <p style="margin:4px 0 0;font-size:12px;color:#ccc;">${r.dateEt} · generated ${etNow} ET</p>
    </div>
    <div style="padding:14px 20px;background:#f8f9fa;border-bottom:1px solid #eee;font-size:13px;">
      <strong>Today:</strong> ${r.dayClosed} closed · ${r.dayWins}W / ${r.dayLosses}L · win rate ${r.dayWinRate}% · net P&L <span style="color:${r.dayNetPnl < 0 ? '#dc2626' : '#16a34a'};font-weight:700;">$${r.dayNetPnl}</span>
    </div>
    <div style="padding:16px 20px;">
      <h2 style="font-size:15px;margin:0 0 10px;">20 Worst Trades — by loss %</h2>
      <table style="width:100%;border-collapse:collapse;font-size:12px;">
        <thead><tr style="background:#f1f5f9;text-align:left;">
          <th style="padding:7px 8px;">#</th><th style="padding:7px 8px;">Ticker</th><th style="padding:7px 8px;">Side</th>
          <th style="padding:7px 8px;text-align:right;">Entry</th><th style="padding:7px 8px;text-align:right;">Exit</th>
          <th style="padding:7px 8px;text-align:center;">In (ET)</th><th style="padding:7px 8px;text-align:center;">Out (ET)</th>
          <th style="padding:7px 8px;text-align:right;">Loss %</th>
        </tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>
      <p style="font-size:11px;color:#999;margin:6px 0 0;">⚠ = exit price was quote-derived (no confirmed broker fill).</p>
    </div>
    <div style="padding:4px 20px 16px;">
      <h2 style="font-size:15px;margin:14px 0 10px;">✂️ Trim the fat — recurring losses since ${r.trim.windowStartEt}</h2>
      <p style="font-size:12px;color:#555;margin:0 0 10px;">${r.trim.losers} losers of ${r.trim.totalClosed} closed trades in the clean-data window.</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin:0 0 12px;">
        <div style="flex:1;min-width:150px;background:#fef2f2;border-radius:8px;padding:10px;"><div style="font-size:20px;font-weight:800;color:#dc2626;">${r.trim.greenThenLost}</div><div style="font-size:11px;color:#7f1d1d;">went ≥+0.3% green then lost (${r.trim.greenThenLostPct}%) — trailing/partial candidates</div></div>
        <div style="flex:1;min-width:150px;background:#fff7ed;border-radius:8px;padding:10px;"><div style="font-size:20px;font-weight:800;color:#d97706;">${r.trim.quickStops}</div><div style="font-size:11px;color:#7c2d12;">stopped out ≤10 min (${r.trim.quickStopsPct}%) — fast reversals</div></div>
      </div>
      <p style="font-size:11px;color:#666;background:#f8fafc;border-left:3px solid #94a3b8;padding:8px 10px;margin:12px 0;line-height:1.5;">Losses are analyzed by <b>system / setup failure mode</b> (timing, exit handling, the book, the session) — not by ticker. If we're losing, it's the system to fix, not an unpredictable symbol or market.</p>
      <h3 style="font-size:13px;margin:14px 0 6px;">Suggested levers (evidence-based, test before adopting)</h3>
      <ul style="font-size:12px;color:#333;padding-left:18px;margin:0;">${suggestionsHtml}</ul>
    </div>
    <div style="padding:14px 20px;font-size:11px;color:#999;border-top:1px solid #eee;">
      <p style="margin:0 0 4px;">These are historical, data-derived observations to guide testing — not automatic changes. Nothing here alters live strategy until you approve it.</p>
      <p style="margin:0;"><strong>Educational only — not financial advice.</strong></p>
    </div>
  </div>`;
}

// ---- Send -----------------------------------------------------------------
export async function sendEodLossReport(dateEt?: string): Promise<{ ok: boolean; count: number; dateEt: string }> {
  const report = await getEodLossReport(dateEt);
  const html = renderEodLossEmail(report);
  const appUrl = process.env.NEXTAUTH_URL || '';
  try {
    const response = await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_TRADE_SIGNAL_ALERT,
        subject: `📉 MarcoFlow EOD — Worst 20 (${report.dateEt}) · ${report.dayLosses}L / ${report.dayClosed} · net $${report.dayNetPnl}`,
        body: html,
        is_html: true,
        recipient_email: EOD_RECIPIENT,
        sender_email: appUrl ? `noreply@${new URL(appUrl).hostname}` : undefined,
        sender_alias: 'MarcoFlow',
      }),
    });
    const res = await response.json();
    if (!res.success && !res.notification_disabled) {
      console.error('EOD loss email failed:', res);
      return { ok: false, count: report.worst.length, dateEt: report.dateEt };
    }
    return { ok: true, count: report.worst.length, dateEt: report.dateEt };
  } catch (e: any) {
    console.error('EOD loss email error:', e?.message);
    return { ok: false, count: report.worst.length, dateEt: report.dateEt };
  }
}

```

---

## FILE: code/lib/eod-recap.ts

```typescript
import { prisma } from './db';

// ---------------------------------------------------------------------------
// EOD Recap engine
//
// Read-only. Summarizes "act now" alerts (SignalObservation.alertedAt != null)
// for a given ET day, plus the clean-data evaluation window (8/17+) and all
// time. For failing (resolved, non-profitable) trades it derives "what could
// have been done differently" using the recorded price-path fields
// (maxFavorablePct / maxAdversePct). Every number is measured from the DB;
// nothing is fabricated.
//
// Win definition (project standard): returnPct > 0.
// ---------------------------------------------------------------------------

const CLEAN_WINDOW_START_ET = '2026-08-17'; // Monday, first clean-data day

// ---- ET helpers (August = EDT, UTC-4) ------------------------------------
export function etDayKey(d: Date): string {
  return d.toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
}
function etDayBounds(dateEt: string): { start: Date; end: Date } {
  const start = new Date(`${dateEt}T00:00:00-04:00`);
  const end = new Date(start.getTime() + 24 * 60 * 60 * 1000);
  return { start, end };
}

// ---- Types ----------------------------------------------------------------
export interface AlertRecapRow {
  symbol: string;
  name: string | null;
  direction: string;
  tradeType: string | null;
  sessionSlot: string | null;
  alertedAt: string | null;
  heat: number;
  entryPrice: number;
  targetPct: number;
  stopPct: number;
  status: string;
  returnPct: number | null;
  exitPrice: number | null;
  maxFavorablePct: number | null;
  maxAdversePct: number | null;
  resolvedAt: string | null;
}

export interface RecapTotals {
  alerts: number;
  resolved: number;
  pending: number;
  wins: number;
  losses: number;
  winRate: number;       // % of resolved that were profitable
  avgReturn: number;     // avg returnPct across resolved
  grossReturn: number;   // sum of returnPct across resolved
  longAlerts: number;
  shortAlerts: number;
  longWinRate: number;
  shortWinRate: number;
  bestReturn: number | null;
  worstReturn: number | null;
}

export interface FailingTradeInsight {
  losers: number;
  reachedTakeableGreen: number;   // went >= 0.3% green then reversed to a loss
  stoppedThenKeptFalling: number; // adverse move >= stop; stop did its job
  smallDriftFlat: number;         // timed out roughly flat (|returnPct| < 0.25)
  avgMaxFavorableOnLosers: number | null;
  avgMaxAdverseOnLosers: number | null;
  worstLosers: { symbol: string; direction: string; returnPct: number; maxFavorablePct: number | null; maxAdversePct: number | null }[];
  suggestions: string[];
}

export interface WindowRecap {
  totals: RecapTotals;
  failing: FailingTradeInsight;
}

export interface EodRecap {
  dateEt: string;
  generatedAt: string;
  // `complete` is true only when every act-now alert for the day has resolved
  // (no PENDING rows left within their 4-hour horizon). The EOD report consumer
  // uses this to decide whether the day's results are all in yet.
  today: WindowRecap & { rows: AlertRecapRow[]; caveats: string[]; complete: boolean };
  cleanWindow: WindowRecap & { startEt: string };
  allTime: WindowRecap;
}

// ---- Row shape pulled from DB --------------------------------------------
interface RawRow {
  symbol: string;
  name: string | null;
  direction: string;
  tradeType: string | null;
  sessionSlot: string | null;
  alertedAt: Date | null;
  heat: number;
  entryPrice: number;
  targetPct: number;
  stopPct: number;
  status: string;
  returnPct: number | null;
  exitPrice: number | null;
  maxFavorablePct: number | null;
  maxAdversePct: number | null;
  resolvedAt: Date | null;
}

const ROW_SELECT = {
  symbol: true, name: true, direction: true, tradeType: true, sessionSlot: true,
  alertedAt: true, heat: true, entryPrice: true, targetPct: true, stopPct: true,
  status: true, returnPct: true, exitPrice: true, maxFavorablePct: true,
  maxAdversePct: true, resolvedAt: true,
} as const;

// ---- Math helpers ---------------------------------------------------------
function round1(n: number): number { return Math.round(n * 10) / 10; }
function round2(n: number): number { return Math.round(n * 100) / 100; }

function computeTotals(rows: RawRow[]): RecapTotals {
  const resolved = rows.filter(r => r.status !== 'PENDING' && r.returnPct !== null);
  const pending = rows.length - resolved.length;
  const wins = resolved.filter(r => (r.returnPct as number) > 0);
  const losses = resolved.filter(r => (r.returnPct as number) <= 0);
  const longs = rows.filter(r => r.direction.toLowerCase() === 'long');
  const shorts = rows.filter(r => r.direction.toLowerCase() === 'short');
  const longResolved = longs.filter(r => r.status !== 'PENDING' && r.returnPct !== null);
  const shortResolved = shorts.filter(r => r.status !== 'PENDING' && r.returnPct !== null);
  const returns = resolved.map(r => r.returnPct as number);
  return {
    alerts: rows.length,
    resolved: resolved.length,
    pending,
    wins: wins.length,
    losses: losses.length,
    winRate: resolved.length ? round1((wins.length / resolved.length) * 100) : 0,
    avgReturn: resolved.length ? round2(returns.reduce((s, r) => s + r, 0) / resolved.length) : 0,
    grossReturn: resolved.length ? round2(returns.reduce((s, r) => s + r, 0)) : 0,
    longAlerts: longs.length,
    shortAlerts: shorts.length,
    longWinRate: longResolved.length ? round1((longResolved.filter(r => (r.returnPct as number) > 0).length / longResolved.length) * 100) : 0,
    shortWinRate: shortResolved.length ? round1((shortResolved.filter(r => (r.returnPct as number) > 0).length / shortResolved.length) * 100) : 0,
    bestReturn: returns.length ? round2(Math.max(...returns)) : null,
    worstReturn: returns.length ? round2(Math.min(...returns)) : null,
  };
}

function computeFailing(rows: RawRow[]): FailingTradeInsight {
  const losers = rows.filter(r => r.status !== 'PENDING' && r.returnPct !== null && (r.returnPct as number) <= 0);
  const GREEN_TAKEABLE = 0.3;   // % in favor that was realistically capturable
  const SMALL_DRIFT = 0.25;     // |returnPct| below this ~ timed out flat

  let reachedTakeableGreen = 0;
  let stoppedThenKeptFalling = 0;
  let smallDriftFlat = 0;
  const favs: number[] = [];
  const advs: number[] = [];

  for (const r of losers) {
    const fav = r.maxFavorablePct;
    const adv = r.maxAdversePct;
    if (fav !== null) favs.push(fav);
    if (adv !== null) advs.push(adv);
    if (fav !== null && fav >= GREEN_TAKEABLE) reachedTakeableGreen++;
    if (adv !== null && Math.abs(adv) >= r.stopPct) stoppedThenKeptFalling++;
    if (Math.abs(r.returnPct as number) < SMALL_DRIFT) smallDriftFlat++;
  }

  const worstLosers = [...losers]
    .sort((a, b) => (a.returnPct as number) - (b.returnPct as number))
    .slice(0, 5)
    .map(r => ({
      symbol: r.symbol,
      direction: r.direction,
      returnPct: round2(r.returnPct as number),
      maxFavorablePct: r.maxFavorablePct !== null ? round2(r.maxFavorablePct) : null,
      maxAdversePct: r.maxAdversePct !== null ? round2(r.maxAdversePct) : null,
    }));

  const suggestions: string[] = [];
  if (losers.length > 0) {
    if (reachedTakeableGreen > 0) {
      const pct = round1((reachedTakeableGreen / losers.length) * 100);
      suggestions.push(`${reachedTakeableGreen} of ${losers.length} losing trades (${pct}%) went at least ${GREEN_TAKEABLE}% in our favor before reversing into a loss. A trailing stop or a partial profit-take could have salvaged some of these — worth A/B testing after the freeze.`);
    }
    if (stoppedThenKeptFalling > 0) {
      const pct = round1((stoppedThenKeptFalling / losers.length) * 100);
      suggestions.push(`${stoppedThenKeptFalling} of ${losers.length} losers (${pct}%) moved against us by at least the stop distance — the stop did its job containing the loss. Tightening the stop further risks cutting winners early, consistent with the earlier tight-stop simulation.`);
    }
    if (smallDriftFlat > 0) {
      const pct = round1((smallDriftFlat / losers.length) * 100);
      suggestions.push(`${smallDriftFlat} of ${losers.length} losers (${pct}%) essentially timed out flat (small drift). These are candidates for an earlier time-based exit or a stricter entry filter so capital is not tied up in non-movers.`);
    }
  }

  return {
    losers: losers.length,
    reachedTakeableGreen,
    stoppedThenKeptFalling,
    smallDriftFlat,
    avgMaxFavorableOnLosers: favs.length ? round2(favs.reduce((s, x) => s + x, 0) / favs.length) : null,
    avgMaxAdverseOnLosers: advs.length ? round2(advs.reduce((s, x) => s + x, 0) / advs.length) : null,
    worstLosers,
    suggestions,
  };
}

function toRecapRow(r: RawRow): AlertRecapRow {
  return {
    symbol: r.symbol,
    name: r.name,
    direction: r.direction,
    tradeType: r.tradeType,
    sessionSlot: r.sessionSlot,
    alertedAt: r.alertedAt ? r.alertedAt.toISOString() : null,
    heat: round1(r.heat),
    entryPrice: r.entryPrice,
    targetPct: r.targetPct,
    stopPct: r.stopPct,
    status: r.status,
    returnPct: r.returnPct !== null ? round2(r.returnPct) : null,
    exitPrice: r.exitPrice,
    maxFavorablePct: r.maxFavorablePct !== null ? round2(r.maxFavorablePct) : null,
    maxAdversePct: r.maxAdversePct !== null ? round2(r.maxAdversePct) : null,
    resolvedAt: r.resolvedAt ? r.resolvedAt.toISOString() : null,
  };
}

// ---- Main entry -----------------------------------------------------------
export async function getEodRecap(dateEt?: string): Promise<EodRecap> {
  const targetDate = dateEt || etDayKey(new Date());
  const { start, end } = etDayBounds(targetDate);
  const cleanStart = etDayBounds(CLEAN_WINDOW_START_ET).start;

  const [todayRaw, cleanRaw, allRaw] = await Promise.all([
    prisma.signalObservation.findMany({
      where: { alertedAt: { gte: start, lt: end } },
      select: ROW_SELECT,
      orderBy: { alertedAt: 'asc' },
    }) as Promise<RawRow[]>,
    prisma.signalObservation.findMany({
      where: { alertedAt: { gte: cleanStart } },
      select: ROW_SELECT,
    }) as Promise<RawRow[]>,
    prisma.signalObservation.findMany({
      where: { alertedAt: { not: null } },
      select: ROW_SELECT,
    }) as Promise<RawRow[]>,
  ]);

  const caveats: string[] = [];
  const todayTotals = computeTotals(todayRaw);
  if (todayTotals.pending > 0) {
    caveats.push(`${todayTotals.pending} of today's ${todayTotals.alerts} alerts are still within their 4-hour horizon and not yet resolved; their outcomes will finalize after the horizon elapses.`);
  }
  if (todayTotals.longAlerts > 0 && todayTotals.longAlerts < 5) {
    caveats.push(`Today's long-side sample is small (${todayTotals.longAlerts} alerts) because long coverage came online mid-morning; treat long stats as partial for today.`);
  }

  return {
    dateEt: targetDate,
    generatedAt: new Date().toISOString(),
    today: {
      rows: todayRaw.map(toRecapRow),
      totals: todayTotals,
      failing: computeFailing(todayRaw),
      caveats,
      complete: todayTotals.alerts > 0 && todayTotals.pending === 0,
    },
    cleanWindow: {
      startEt: CLEAN_WINDOW_START_ET,
      totals: computeTotals(cleanRaw),
      failing: computeFailing(cleanRaw),
    },
    allTime: {
      totals: computeTotals(allRaw),
      failing: computeFailing(allRaw),
    },
  };
}

```

---

## FILE: code/lib/lever-reconciliation.ts

```typescript
/**
 * MarcoFlow lever reconciliation (EL#5-A, 9/3/26).
 *
 * PROBLEM (raised by owner): the EOD suggestions + nightly self-correction each
 * emit a rich set of "levers" to pull. Some OVERLAP (two sources proposing the
 * same fix) and some CONTRADICT (one wants to loosen the long book, another to
 * tighten it). Presented raw, they cancel each other out and create decision
 * paralysis. We can't ignore them — but we must reconcile them into ONE coherent,
 * ranked slate before showing them.
 *
 * This module is pure/report-only. It changes NO live parameter. It takes the
 * structured levers from every source, groups them by the knob they target,
 * resolves conflicts by evidence score, folds overlaps, and returns a single
 * ranked slate + an audit of what was superseded and why.
 */

export type LeverDirection = 'tighten' | 'loosen' | 'neutral';
export type LeverSeverity = 'suspend' | 'reenable' | 'watch';

export interface RawLever {
  source: string;          // 'self-correct' | 'eod-losses'
  severity: LeverSeverity;
  target: string;          // the knob/behaviour this touches, e.g. 'longsEnabled', 'exit_giveback', 'skipEntryHours:10'
  direction: LeverDirection; // does it RESTRICT (tighten) or OPEN UP (loosen) trading?
  title: string;
  detail: string;
  edit: string;            // the concrete one-line change (or 'no change')
  score: number;           // evidence strength / expected value — higher wins
}

export interface ReconciledLever extends RawLever {
  rank: number;                 // 1-based position in the primary slate (0 for superseded)
  status: 'primary' | 'superseded';
  supersededReason?: string;
}

export interface ConflictNote {
  target: string;
  kept: string;                 // title of the lever we kept
  keptDirection: LeverDirection;
  dropped: { title: string; direction: LeverDirection }[];
  kind: 'contradiction' | 'overlap';
  reason: string;
}

export interface ReconciliationResult {
  slate: ReconciledLever[];       // primary levers, ranked by score desc
  superseded: ReconciledLever[];  // folded/overruled levers, kept for audit
  conflicts: ConflictNote[];      // human-readable resolution log
  sources: string[];              // which sources contributed
}

/**
 * Reconcile a flat list of levers from any number of sources into one slate.
 * - Levers are grouped by `target` (the knob they touch).
 * - Within a group the highest-score lever becomes PRIMARY.
 * - A lower-score lever with the OPPOSITE direction is a CONTRADICTION -> superseded.
 * - A lower-score lever with the SAME direction is an OVERLAP -> folded (superseded).
 * - Neutral levers never contradict; they only fold if a same-target primary exists.
 */
export function reconcileLevers(raw: RawLever[]): ReconciliationResult {
  const sources = Array.from(new Set(raw.map(l => l.source))).sort();
  const groups = new Map<string, RawLever[]>();
  for (const lev of raw) {
    const g = groups.get(lev.target) || [];
    g.push(lev);
    groups.set(lev.target, g);
  }

  const primaries: ReconciledLever[] = [];
  const superseded: ReconciledLever[] = [];
  const conflicts: ConflictNote[] = [];

  for (const [target, levers] of groups.entries()) {
    levers.sort((a, b) => b.score - a.score);
    const [top, ...rest] = levers;
    primaries.push({ ...top, rank: 0, status: 'primary' });

    if (rest.length === 0) continue;

    const contradicting = rest.filter(l => isOpposite(l.direction, top.direction));
    const overlapping = rest.filter(l => !isOpposite(l.direction, top.direction));

    for (const l of rest) {
      const opposite = isOpposite(l.direction, top.direction);
      superseded.push({
        ...l,
        rank: 0,
        status: 'superseded',
        supersededReason: opposite
          ? `Contradicts the stronger \u201c${top.title}\u201d (${top.direction} vs ${l.direction}); kept the higher-evidence lever.`
          : `Overlaps \u201c${top.title}\u201d — same objective, folded into it.`,
      });
    }

    if (contradicting.length > 0) {
      conflicts.push({
        target,
        kept: top.title,
        keptDirection: top.direction,
        dropped: contradicting.map(l => ({ title: l.title, direction: l.direction })),
        kind: 'contradiction',
        reason: `Two sources pulled this knob in opposite directions. Resolved to the higher-evidence side (score ${top.score.toFixed(0)}).`,
      });
    } else if (overlapping.length > 0) {
      conflicts.push({
        target,
        kept: top.title,
        keptDirection: top.direction,
        dropped: overlapping.map(l => ({ title: l.title, direction: l.direction })),
        kind: 'overlap',
        reason: `Multiple sources proposed the same objective. Folded into one to avoid double-counting.`,
      });
    }
  }

  // Rank the primary slate by score desc, then by severity weight.
  const sevWeight: Record<LeverSeverity, number> = { suspend: 2, reenable: 1, watch: 0 };
  primaries.sort((a, b) => b.score - a.score || sevWeight[b.severity] - sevWeight[a.severity]);
  primaries.forEach((p, i) => { p.rank = i + 1; });

  return { slate: primaries, superseded, conflicts, sources };
}

function isOpposite(a: LeverDirection, b: LeverDirection): boolean {
  return (a === 'tighten' && b === 'loosen') || (a === 'loosen' && b === 'tighten');
}

```

---

## FILE: code/lib/realtime-quotes.ts

```typescript
/**
 * Real-time quote layer (Alpaca "Basic" free tier).
 *
 * WHY THIS EXISTS
 * ---------------
 * Our bulk scan runs on Yahoo, which is free and gives CONSOLIDATED volume
 * across every US venue — that matters, because the heat formula leans heavily
 * on volumeRatio / volumeSurge / buyPressure, and all 60 days of validated
 * history were built on consolidated volume. The cost is a ~15 minute delay.
 *
 * The persistence test measured what that delay costs: setups worth 53.2% at
 * the moment they formed were worth 38.9% fifteen minutes later. ~14 points of
 * edge, destroyed purely by latency.
 *
 * Alpaca's free tier gives REAL-TIME prices, but only from the IEX venue —
 * roughly a low single-digit share of US volume. Prices track the consolidated
 * tape closely; VOLUME does not. So we deliberately use Alpaca for PRICE ONLY
 * and never let it touch a volume-derived indicator. Swapping the scan wholesale
 * onto IEX volume would quietly corrupt the very indicators our win rates were
 * measured on.
 *
 * COST: $0. Free tier, no credit card. 200 requests/minute.
 * We batch 100 symbols per request, so even the full 2,100-symbol universe is
 * ~21 requests — a fraction of the budget. In practice we only ever ask for the
 * handful of symbols that already passed the gate.
 *
 * Degrades silently: with no keys configured, every function returns empty and
 * the app behaves exactly as it did before.
 */

const DATA_URL = 'https://data.alpaca.markets/v2/stocks/snapshots';
const BATCH_SIZE = 100;

export interface LiveQuote {
  symbol: string;
  price: number;
  at: Date;
}

export function isRealtimeConfigured(): boolean {
  return Boolean(process.env.ALPACA_API_KEY_ID && process.env.ALPACA_API_SECRET_KEY);
}

function authHeaders(): Record<string, string> {
  return {
    'APCA-API-KEY-ID': process.env.ALPACA_API_KEY_ID || '',
    'APCA-API-SECRET-KEY': process.env.ALPACA_API_SECRET_KEY || '',
    accept: 'application/json',
  };
}

/**
 * Pull the freshest available price for each symbol.
 *
 * Preference order per symbol: latest trade > latest quote midpoint > minute
 * bar close. A trade is an actual execution, so it is the truest "what is this
 * worth right now". The midpoint is the fallback when a name has not printed
 * recently.
 */
export async function getRealtimeQuotes(symbols: string[]): Promise<Map<string, LiveQuote>> {
  const out = new Map<string, LiveQuote>();
  if (!isRealtimeConfigured() || symbols.length === 0) return out;

  const unique = Array.from(new Set(symbols.map(s => s.toUpperCase())));

  for (let i = 0; i < unique.length; i += BATCH_SIZE) {
    const batch = unique.slice(i, i + BATCH_SIZE);
    const url = `${DATA_URL}?symbols=${encodeURIComponent(batch.join(','))}&feed=iex`;

    try {
      const res = await fetch(url, { headers: authHeaders(), cache: 'no-store' });
      if (!res.ok) {
        console.error(`[realtime] Alpaca ${res.status} for batch of ${batch.length}`);
        continue;
      }
      const json = await res.json();
      const snapshots = json?.snapshots || json || {};

      for (const sym of batch) {
        const snap = snapshots[sym];
        if (!snap) continue;

        let price = 0;
        let at: string | undefined;

        const trade = snap.latestTrade;
        if (trade && typeof trade.p === 'number' && trade.p > 0) {
          price = trade.p;
          at = trade.t;
        } else {
          const q = snap.latestQuote;
          const bid = q?.bp;
          const ask = q?.ap;
          if (typeof bid === 'number' && typeof ask === 'number' && bid > 0 && ask > 0) {
            price = (bid + ask) / 2;
            at = q.t;
          } else {
            const bar = snap.minuteBar || snap.dailyBar;
            if (bar && typeof bar.c === 'number' && bar.c > 0) {
              price = bar.c;
              at = bar.t;
            }
          }
        }

        if (price > 0) {
          const ts = at ? new Date(at) : new Date();
          out.set(sym, { symbol: sym, price, at: isNaN(ts.getTime()) ? new Date() : ts });
        }
      }
    } catch (err) {
      console.error('[realtime] Alpaca fetch failed:', err);
    }
  }

  return out;
}

/** Signed % difference of the live price from the delayed price we scanned on. */
export function driftPct(delayedPrice: number, livePrice: number): number {
  if (!delayedPrice) return 0;
  return Math.round(((livePrice - delayedPrice) / delayedPrice) * 10000) / 100;
}

/**
 * Has the setup already run away from us while the delayed data caught up?
 *
 * A LONG whose price has already jumped past the entry has given up part of the
 * move and now sits closer to its stop — the reward/risk we validated is no
 * longer the reward/risk on offer. Same in reverse for a SHORT. This is exactly
 * the decay the persistence test measured, so we surface it rather than quietly
 * alerting on a price that no longer exists.
 */
export function hasRunAway(direction: string, delayedPrice: number, livePrice: number, maxDriftPct: number): boolean {
  const drift = driftPct(delayedPrice, livePrice);
  return direction === 'LONG' ? drift > maxDriftPct : drift < -maxDriftPct;
}

```

---

## FILE: code/lib/self-correction.ts

```typescript
/**
 * MarcoFlow nightly self-correction job (task 7, 9/2/26).
 *
 * PHILOSOPHY: self-correcting, NOT self-improving. It never free-form rewrites
 * the strategy. Each night it (1) refreshes the strategy review, (2) re-measures
 * every guardrail cohort on the clean data window, and (3) emails the owner a
 * report of what is working, what is breaching a pre-defined threshold, and what
 * it PROPOSES to change — with the exact one-line edit to lib/trading-guardrails.ts.
 * It applies NO live parameter change on its own, so it can never disrupt results
 * unattended. The owner approves each proposal.
 */

import { prisma } from '@/lib/db';
import { GUARDRAILS } from '@/lib/trading-guardrails';
import { runAndSaveReview } from '@/lib/strategy-review';
import { getEodLevers } from '@/lib/eod-losses';
import { reconcileLevers, type RawLever, type ReconciliationResult } from '@/lib/lever-reconciliation';
import { getPostmortemLevers } from '@/lib/trade-postmortem';

export const SELF_CORRECT_RECIPIENT = 'misiti15@gmail.com';
const CLEAN_WINDOW_START = '2026-08-28'; // Update 3.0 exit-accuracy cutoff

// Guardrail thresholds for raising a proposal. Conservative on purpose — a cohort
// must be both statistically meaningful (min sample) AND clearly losing.
const MIN_COHORT_N = 20;
const SUSPEND_WINRATE = 40;   // propose suspending a cohort below this win rate
const SUSPEND_PNL = -100;     // ...or below this net $ over the window
const REENABLE_WINRATE = 50;  // propose re-enabling a benched cohort above this

interface Cohort { label: string; n: number; winRate: number; avgRet: number; pnl: number; }
interface Proposal {
  severity: 'suspend' | 'reenable' | 'watch';
  title: string;
  detail: string;
  edit: string;
  target: string;                 // knob this touches, for reconciliation
  direction: 'tighten' | 'loosen' | 'neutral';
  score: number;                  // evidence strength for ranking / conflict resolution
}

export interface SelfCorrectionReport {
  runAtEt: string;
  windowStart: string;
  totalTrades: number;
  overall: Cohort;
  byDirection: Cohort[];
  byHour: Cohort[];
  knife: Cohort | null;
  giveBackRate: number;  // % of trades that peaked >= +0.75% then closed <= 0
  reviewBestRule: string;
  reviewBestLB: number;
  proposals: Proposal[];
  reconciliation: ReconciliationResult;  // EL#5-A: one coherent, de-conflicted slate
  guardrailsActive: string[];
}

function agg(rows: { returnPct: number | null; pnlDollars: number | null }[], label: string): Cohort {
  const n = rows.length;
  if (n === 0) return { label, n: 0, winRate: 0, avgRet: 0, pnl: 0 };
  const wins = rows.filter(r => (r.returnPct || 0) > 0).length;
  const avgRet = rows.reduce((s, r) => s + (r.returnPct || 0), 0) / n;
  const pnl = rows.reduce((s, r) => s + (r.pnlDollars || 0), 0);
  return { label, n, winRate: Math.round((100 * wins) / n * 10) / 10, avgRet: Math.round(avgRet * 1000) / 1000, pnl: Math.round(pnl * 100) / 100 };
}

export async function buildSelfCorrectionReport(): Promise<SelfCorrectionReport> {
  // Refresh the strategy review first (best-effort — report still builds if it fails).
  let reviewBestRule = 'n/a';
  let reviewBestLB = 0;
  try {
    const rev = await runAndSaveReview();
    reviewBestRule = rev.bestRuleLabel;
    reviewBestLB = rev.bestWinRateLB;
  } catch (e: any) {
    console.warn('[self-correct] review refresh failed:', e?.message?.slice(0, 120));
  }

  const trades = await prisma.paperTrade.findMany({
    where: { status: 'CLOSED', entryTime: { gte: new Date(CLEAN_WINDOW_START) } },
    select: { direction: true, returnPct: true, pnlDollars: true, peakPct: true, etHour: true },
  });

  const overall = agg(trades, 'ALL');
  const byDirection = ['LONG', 'SHORT'].map(d => agg(trades.filter(t => t.direction === d), d));
  const hours = Array.from(new Set(trades.map(t => t.etHour).filter((h): h is number => h != null))).sort((a, b) => a - b);
  const byHour = hours.map(h => agg(trades.filter(t => t.etHour === h), `hour ${h}:00`));

  // Knife cohort needs RSI — join via observation for shorts only.
  const shortObs = await prisma.paperTrade.findMany({
    where: { status: 'CLOSED', direction: 'SHORT', entryTime: { gte: new Date(CLEAN_WINDOW_START) }, observationId: { not: null } },
    select: { returnPct: true, pnlDollars: true, observationId: true },
  });
  const obsIds = shortObs.map(s => s.observationId!).filter(Boolean);
  const obs = await prisma.signalObservation.findMany({ where: { id: { in: obsIds } }, select: { id: true, rsi: true } });
  const rsiById = new Map(obs.map(o => [o.id, o.rsi]));
  const knifeRows = shortObs.filter(s => {
    const rsi = rsiById.get(s.observationId!);
    return rsi != null && rsi <= GUARDRAILS.knifeMinRsi;
  });
  const knife = knifeRows.length > 0 ? agg(knifeRows, `SHORT & RSI<=${GUARDRAILS.knifeMinRsi}`) : null;

  const peaked = trades.filter(t => (t.peakPct || 0) >= 0.75);
  const gaveBack = peaked.filter(t => (t.returnPct || 0) <= 0);
  const giveBackRate = peaked.length > 0 ? Math.round((100 * gaveBack.length) / peaked.length * 10) / 10 : 0;

  // ---- Build proposals (email-only; never auto-applied) ----
  const proposals: Proposal[] = [];

  // Emergent losing hour NOT already skipped
  for (const c of byHour) {
    const hour = parseInt(c.label.split(' ')[1]);
    if (GUARDRAILS.skipEntryHours.includes(hour)) continue;
    if (c.n >= MIN_COHORT_N && (c.winRate < SUSPEND_WINRATE || c.pnl < SUSPEND_PNL)) {
      proposals.push({
        severity: 'suspend',
        title: `Hour ${hour}:00 is now a losing cohort`,
        detail: `${c.n} trades, ${c.winRate}% win, $${c.pnl}. Below the suspend threshold.`,
        edit: `trading-guardrails.ts → skipEntryHours: add ${hour}`,
        target: `skipEntryHours:${hour}`,
        direction: 'tighten',
        score: 50 + Math.min(c.n, 100) / 2 + Math.abs(Math.min(c.pnl, 0)) / 20,
      });
    }
  }
  // A currently-skipped hour that has recovered (only judgeable if it were traded;
  // flagged as watch since we no longer collect trades there)
  for (const hour of GUARDRAILS.skipEntryHours) {
    proposals.push({
      severity: 'watch',
      title: `Hour ${hour}:00 is currently skipped`,
      detail: `No new trades collected here. Re-enable temporarily if you want fresh data to re-test it.`,
      edit: `trading-guardrails.ts → skipEntryHours: remove ${hour} (to re-test)`,
      target: `skipEntryHours:${hour}`,
      direction: 'loosen',
      score: 12,
    });
  }
  // Longs: benched — check if the recorded (untraded) long signals would now win.
  if (!GUARDRAILS.longsEnabled) {
    const longObs = await prisma.signalObservation.findMany({
      where: { direction: 'LONG', source: 'live', status: { in: ['WIN', 'LOSS', 'EXPIRED'] }, observedAt: { gte: new Date(CLEAN_WINDOW_START) }, returnPct: { not: null } },
      select: { returnPct: true },
      take: 2000,
    });
    if (longObs.length >= MIN_COHORT_N) {
      const lw = Math.round((100 * longObs.filter(o => (o.returnPct || 0) > 0).length) / longObs.length * 10) / 10;
      if (lw >= REENABLE_WINRATE) {
        proposals.push({
          severity: 'reenable',
          title: `Long signals may be recovering (${lw}% win on ${longObs.length} recorded)`,
          detail: `Longs are benched but recent recorded long signals cleared ${REENABLE_WINRATE}% win. Consider a small re-enable test.`,
          edit: `trading-guardrails.ts → longsEnabled: true (start with longMinLB high)`,
          target: 'longsEnabled',
          direction: 'loosen',
          score: 30 + (lw - REENABLE_WINRATE) * 2 + Math.min(longObs.length, 500) / 50,
        });
      } else {
        proposals.push({ severity: 'watch', title: `Longs remain benched (${lw}% win on recorded signals)`, detail: `Still below the ${REENABLE_WINRATE}% re-enable bar. Keep benched.`, edit: 'no change', target: 'longsEnabled', direction: 'neutral', score: 8 });
      }
    }
  }
  // Give-back / task-1 signal
  if (giveBackRate >= 20) {
    proposals.push({
      severity: 'watch',
      title: `${giveBackRate}% of winners gave back their peak (>= +0.75%)`,
      detail: `Tick-cadence exit lag. The resting short take-profit limit (restingShortTpEnabled) is designed to fix this — enable when ready for a supervised session.`,
      edit: `trading-guardrails.ts → restingShortTpEnabled: true (supervised)`,
      target: 'exit_giveback',
      direction: 'tighten',
      score: 40 + giveBackRate,
    });
  }

  const guardrailsActive: string[] = [];
  if (!GUARDRAILS.longsEnabled) guardrailsActive.push('longs benched');
  if (GUARDRAILS.skipEntryHours.length) guardrailsActive.push(`skip hours ${GUARDRAILS.skipEntryHours.join(',')}`);
  if (GUARDRAILS.knifeGuardEnabled) guardrailsActive.push(`knife guard RSI<=${GUARDRAILS.knifeMinRsi}`);
  if (GUARDRAILS.liquidityGateEnabled) guardrailsActive.push(`liquidity min $${GUARDRAILS.minEntryPrice}/spread<=${GUARDRAILS.maxEntrySpreadPct}%`);

  // ---- EL#5-A: reconcile ALL levers (self-correction + EOD) into one slate ----
  // Overlapping proposals are folded; contradictory ones are resolved to the
  // higher-evidence side, so the owner sees a single coherent set of moves
  // instead of knobs that cancel each other out.
  const selfLevers: RawLever[] = proposals
    .filter(p => p.edit !== 'no change')
    .map(p => ({
      source: 'self-correct',
      severity: p.severity,
      target: p.target,
      direction: p.direction,
      title: p.title,
      detail: p.detail,
      edit: p.edit,
      score: p.score,
    }));
  let eodLevers: RawLever[] = [];
  try {
    eodLevers = await getEodLevers();
  } catch (e: any) {
    console.warn('[self-correct] EOD lever fetch failed:', e?.message?.slice(0, 120));
  }
  // EL#3: the per-trade post-mortem is the learning-loop evidence source — its
  // fixable-vs-false levers (incl. exclusion candidates) join the same slate.
  let pmLevers: RawLever[] = [];
  try {
    pmLevers = await getPostmortemLevers();
  } catch (e: any) {
    console.warn('[self-correct] post-mortem lever fetch failed:', e?.message?.slice(0, 120));
  }
  const reconciliation = reconcileLevers([...selfLevers, ...eodLevers, ...pmLevers]);

  const runAtEt = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', dateStyle: 'medium', timeStyle: 'short' }).format(new Date());

  return {
    runAtEt, windowStart: CLEAN_WINDOW_START, totalTrades: trades.length,
    overall, byDirection, byHour, knife, giveBackRate,
    reviewBestRule, reviewBestLB, proposals, reconciliation, guardrailsActive,
  };
}

function renderEmail(r: SelfCorrectionReport): string {
  const cohortRow = (c: Cohort) => `<tr><td style="padding:4px 10px">${c.label}</td><td style="padding:4px 10px;text-align:right">${c.n}</td><td style="padding:4px 10px;text-align:right">${c.winRate}%</td><td style="padding:4px 10px;text-align:right">${c.avgRet}%</td><td style="padding:4px 10px;text-align:right;color:${c.pnl>=0?'#0a7d33':'#c0392b'}">$${c.pnl}</td></tr>`;
  const sevColor = (s: string) => s === 'suspend' ? '#c0392b' : s === 'reenable' ? '#0a7d33' : '#8a6d3b';
  const rec = r.reconciliation;
  // EL#5-A: one coherent, de-conflicted slate (EOD + self-correction levers merged, overlaps folded, contradictions resolved by evidence).
  const slateRows = rec.slate.length
    ? rec.slate.map(p => `<div style="border-left:4px solid ${sevColor(p.severity)};padding:6px 12px;margin:8px 0;background:#fafafa"><b style="color:${sevColor(p.severity)}">#${p.rank} · [${p.severity.toUpperCase()}]</b> ${p.title} <span style="color:#999;font-size:12px">(${p.source}, evidence ${p.score.toFixed(0)})</span><br><span style="color:#555">${p.detail}</span><br><code style="font-size:12px;color:#333">${p.edit}</code></div>`).join('')
    : '<p style="color:#0a7d33">No changes proposed — all cohorts within tolerance.</p>';
  const conflictRows = rec.conflicts.length
    ? `<h3 style="margin-bottom:4px">Conflicts resolved</h3>` + rec.conflicts.map(c => `<div style="border-left:4px solid #8a6d3b;padding:6px 12px;margin:8px 0;background:#fdf9f0"><b>${c.kind === 'contradiction' ? '⚖️ Contradiction' : '🔗 Overlap'}</b> on <code>${c.target}</code><br><span style="color:#555">Kept <b>${c.kept}</b> (${c.keptDirection}); set aside ${c.dropped.map(d => `“${d.title}” (${d.direction})`).join(', ')}.</span><br><span style="color:#777;font-size:12px">${c.reason}</span></div>`).join('')
    : '';
  const supersededRows = rec.superseded.length
    ? `<details style="margin:8px 0"><summary style="cursor:pointer;color:#777;font-size:13px">Superseded levers (${rec.superseded.length}) — audit trail</summary>` + rec.superseded.map(p => `<div style="padding:4px 12px;margin:4px 0;color:#999;font-size:12px"><s>${p.title}</s> — ${p.supersededReason || ''}</div>`).join('') + `</details>`
    : '';
  return `
  <div style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:640px;margin:0 auto;color:#222">
    <h2 style="margin-bottom:2px">🧠 MarcoFlow Nightly Self-Correction</h2>
    <p style="color:#777;margin-top:0">${r.runAtEt} ET · clean window since ${r.windowStart} · ${r.totalTrades} closed trades</p>
    <p style="margin:6px 0"><b>Active guardrails:</b> ${r.guardrailsActive.join(' · ')}</p>
    <p style="margin:6px 0"><b>Best rule (review):</b> ${r.reviewBestRule} (LB ${r.reviewBestLB})</p>
    <h3 style="margin-bottom:4px">Action slate <span style="color:#999;font-size:13px;font-weight:normal">(reconciled across ${rec.sources.join(' + ') || 'self-correction'})</span></h3>
    ${slateRows}
    ${conflictRows}
    ${supersededRows}
    <h3 style="margin-bottom:4px">Cohort scoreboard</h3>
    <table style="border-collapse:collapse;width:100%;font-size:14px">
      <tr style="background:#f0f0f0"><th style="padding:4px 10px;text-align:left">cohort</th><th style="padding:4px 10px;text-align:right">n</th><th style="padding:4px 10px;text-align:right">win%</th><th style="padding:4px 10px;text-align:right">avg%</th><th style="padding:4px 10px;text-align:right">P&L</th></tr>
      ${cohortRow(r.overall)}
      ${r.byDirection.map(cohortRow).join('')}
      ${r.knife ? cohortRow(r.knife) : ''}
      ${r.byHour.map(cohortRow).join('')}
    </table>
    <p style="margin-top:10px;color:#777;font-size:13px">Give-back rate (winners that peaked ≥+0.75% then closed ≤0): <b>${r.giveBackRate}%</b></p>
    <p style="color:#999;font-size:12px;margin-top:16px">This job proposes only. No live parameter was changed. Educational only — not financial advice.</p>
  </div>`;
}

export async function sendSelfCorrectionReport(): Promise<{ ok: boolean; proposals: number }> {
  const report = await buildSelfCorrectionReport();
  const html = renderEmail(report);
  const appUrl = process.env.NEXTAUTH_URL || '';
  const suspends = report.proposals.filter(p => p.severity === 'suspend').length;
  try {
    const response = await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_TRADE_SIGNAL_ALERT,
        subject: `🧠 MarcoFlow Self-Correction · ${report.proposals.length} proposal(s)${suspends ? ` · ${suspends} suspend` : ''}`,
        body: html,
        is_html: true,
        recipient_email: SELF_CORRECT_RECIPIENT,
        sender_email: appUrl ? `noreply@${new URL(appUrl).hostname}` : undefined,
        sender_alias: 'MarcoFlow',
      }),
    });
    const res = await response.json();
    if (!res.success && !res.notification_disabled) {
      console.error('[self-correct] email failed:', res);
      return { ok: false, proposals: report.proposals.length };
    }
    return { ok: true, proposals: report.proposals.length };
  } catch (e: any) {
    console.error('[self-correct] email error:', e?.message);
    return { ok: false, proposals: report.proposals.length };
  }
}

```

---

## FILE: code/lib/stock-screener.ts

```typescript
// Stock Screener - Find top buy/sell opportunities across markets
// Enhanced with trade type classification and earnings integration

import { fetchIntradayData, fetchQuote, IntradayDataPoint } from './data-provider';
import { calculateHeatTracker, HeatTrackerResult } from './heat-tracker';
import { fetchEarningsInfo, getEarningsTradeWarning, EarningsInfo } from './earnings-calendar';
import { CandlestickPattern } from './candlestick-patterns';
import { UNIVERSE_EXTRA } from './universe-extra'; // Update 4.0 ADV-vetted expansion

export type TradeType = 'intraday' | 'short_swing' | 'long_swing';

export interface TradeClassification {
  tradeType: TradeType;
  label: string;
  roiTimeline: string;
  expectedHoldTime: string;
  whyThisCategory: string[];
  exitStrategy: string;
}

export interface ScreenerResult {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  heat: number;
  mode: 'BUY' | 'SELL' | 'NEUTRAL';
  isRedline: boolean;
  rsi: number;
  volumeRatio: number;
  keyDrivers: string[];
  candlestickPatterns: CandlestickPattern[];
  recommendation: {
    action: string;
    timeframe: string;
    confidence: 'HIGH' | 'MEDIUM' | 'LOW';
    reason: string;
  };
  // New: trade classification
  tradeClassification: TradeClassification;
  // New: earnings info
  earnings: EarningsInfo | null;
  earningsTradeWarning: string | null;
}

// Comprehensive stock and ETF lists organized by category
// Auto-generated trading universe.
// Source: US-listed symbols (Nasdaq/NYSE/AMEX), screened for live 5-minute data,
// minimum price and real intraday range, then ranked by average dollar volume.
// Includes all current S&P 500 members plus the most liquid ETFs and equities.
// Regenerate when refreshing the universe.

export const STOCK_CATEGORIES = {
  communication: [
    { symbol: "GOOGL", name: "Alphabet Inc. - Class A Common Stock" },
    { symbol: "GOOG", name: "Alphabet Inc. - Class C Capital Stock" },
    { symbol: "APP", name: "Applovin Corporation - Class A Common Stock" },
    { symbol: "T", name: "AT&T Inc." },
    { symbol: "CHTR", name: "Charter Communications, Inc. - Class A Common Stock" },
    { symbol: "CMCSA", name: "Comcast Corporation - Class A Common Stock" },
    { symbol: "ECHO", name: "EchoStar Corporation - Common stock" },
    { symbol: "FOXA", name: "Fox Corporation - Class A Common Stock" },
    { symbol: "FOX", name: "Fox Corporation - Class B Common Stock" },
    { symbol: "LYV", name: "Live Nation Entertainment, Inc. Common Stock" },
    { symbol: "META", name: "Meta Platforms, Inc. - Class A Common Stock" },
    { symbol: "NFLX", name: "Netflix, Inc. - Common Stock" },
    { symbol: "NWSA", name: "News Corporation - Class A Common Stock" },
    { symbol: "NWS", name: "News Corporation - Class B Common Stock" },
    { symbol: "OMC", name: "Omnicom Group Inc. Common Stock" },
    { symbol: "PSKY", name: "Paramount Skydance Corporation - Class B Common Stock" },
    { symbol: "TMUS", name: "T-Mobile US, Inc. - Common Stock" },
    { symbol: "TTWO", name: "Take-Two Interactive Software, Inc. - Common Stock" },
    { symbol: "TKO", name: "TKO Group Holdings, Inc. Class A Common Stock" },
    { symbol: "TTD", name: "The Trade Desk, Inc. - Class A Common Stock" },
    { symbol: "VZ", name: "Verizon Communications Inc. Common Stock" },
    { symbol: "DIS", name: "Walt Disney Company (The) Common Stock" },
    { symbol: "WBD", name: "Warner Bros. Discovery, Inc. - Series A Common Stock" },
  ],
  consumer_disc: [
    { symbol: "ABNB", name: "Airbnb, Inc. - Class A Common Stock" },
    { symbol: "AMZN", name: "Amazon.com, Inc. - Common Stock" },
    { symbol: "APTV", name: "Aptiv PLC Ordinary Shares" },
    { symbol: "AZO", name: "AutoZone, Inc. Common Stock" },
    { symbol: "BBY", name: "Best Buy Co., Inc. Common Stock" },
    { symbol: "BKNG", name: "Booking Holdings Inc. - Common Stock" },
    { symbol: "CCL", name: "Carnival Corporation Ltd. Common Shares" },
    { symbol: "CVNA", name: "Carvana Co. Class A Common Stock" },
    { symbol: "CMG", name: "Chipotle Mexican Grill, Inc. Common Stock" },
    { symbol: "DRI", name: "Darden Restaurants, Inc. Common Stock" },
    { symbol: "DECK", name: "Deckers Outdoor Corporation Common Stock" },
    { symbol: "DPZ", name: "Domino's Pizza Inc - Common Stock" },
    { symbol: "DASH", name: "DoorDash, Inc. - Common Stock" },
    { symbol: "DHI", name: "D.R. Horton, Inc. Common Stock" },
    { symbol: "EBAY", name: "eBay Inc. - Common Stock" },
    { symbol: "EXPE", name: "Expedia Group, Inc. - Common Stock" },
    { symbol: "F", name: "Ford Motor Company Common Stock" },
    { symbol: "GRMN", name: "Garmin Ltd. Common Stock (Switzerland)" },
    { symbol: "GM", name: "General Motors Company Common Stock" },
    { symbol: "GPC", name: "Genuine Parts Company Common Stock" },
    { symbol: "HAS", name: "Hasbro, Inc. - Common Stock" },
    { symbol: "HLT", name: "Hilton Worldwide Holdings Inc. Common Stock" },
    { symbol: "HD", name: "Home Depot, Inc. (The) Common Stock" },
    { symbol: "LVS", name: "Las Vegas Sands Corp. Common Stock" },
    { symbol: "LEN", name: "Lennar Corporation Class A Common Stock" },
    { symbol: "LOW", name: "Lowe's Companies, Inc. Common Stock" },
    { symbol: "LULU", name: "lululemon athletica inc. - Common Stock" },
    { symbol: "MAR", name: "Marriott International - Class A Common Stock" },
    { symbol: "MCD", name: "McDonald's Corporation Common Stock" },
    { symbol: "MGM", name: "MGM Resorts International Common Stock" },
    { symbol: "NKE", name: "Nike, Inc. Common Stock" },
    { symbol: "NCLH", name: "Norwegian Cruise Line Holdings Ltd. Ordinary Shares" },
    { symbol: "NVR", name: "NVR, Inc. Common Stock" },
    { symbol: "ORLY", name: "O'Reilly Automotive, Inc. - Common Stock" },
    { symbol: "PHM", name: "PulteGroup, Inc. Common Stock" },
    { symbol: "RL", name: "Ralph Lauren Corporation Common Stock" },
    { symbol: "ROST", name: "Ross Stores, Inc. - Common Stock" },
    { symbol: "RCL", name: "Royal Caribbean Cruises Ltd. Common Stock" },
    { symbol: "SBUX", name: "Starbucks Corporation - Common Stock" },
    { symbol: "TPR", name: "Tapestry, Inc. Common Stock" },
    { symbol: "TSLA", name: "Tesla, Inc. - Common Stock" },
    { symbol: "TJX", name: "TJX Companies, Inc. (The) Common Stock" },
    { symbol: "TSCO", name: "Tractor Supply Company - Common Stock" },
    { symbol: "ULTA", name: "Ulta Beauty, Inc. - Common Stock" },
    { symbol: "WSM", name: "Williams-Sonoma, Inc. Common Stock (DE)" },
    { symbol: "WYNN", name: "Wynn Resorts, Limited - Common Stock" },
    { symbol: "YUM", name: "Yum! Brands, Inc." },
  ],
  consumer_staples: [
    { symbol: "MO", name: "Altria Group, Inc." },
    { symbol: "ADM", name: "Archer-Daniels-Midland Company Common Stock" },
    { symbol: "BF-B", name: "Brown Forman Inc Class B Common Stock" },
    { symbol: "BG", name: "Bunge Limited Common Shares" },
    { symbol: "CASY", name: "Caseys General Stores, Inc. - Common Stock" },
    { symbol: "CHD", name: "Church & Dwight Company, Inc. Common Stock" },
    { symbol: "CLX", name: "Clorox Company (The) Common Stock" },
    { symbol: "KO", name: "Coca-Cola Company (The) Common Stock" },
    { symbol: "CL", name: "Colgate-Palmolive Company Common Stock" },
    { symbol: "STZ", name: "Constellation Brands, Inc. Common Stock" },
    { symbol: "COST", name: "Costco Wholesale Corporation - Common Stock" },
    { symbol: "DG", name: "Dollar General Corporation Common Stock" },
    { symbol: "DLTR", name: "Dollar Tree, Inc. - Common Stock" },
    { symbol: "EL", name: "Estee Lauder Companies, Inc. (The) Common Stock" },
    { symbol: "GIS", name: "General Mills, Inc. Common Stock" },
    { symbol: "HSY", name: "The Hershey Company Common Stock" },
    { symbol: "HRL", name: "Hormel Foods Corporation Common Stock" },
    { symbol: "KVUE", name: "Kenvue Inc. Common Stock" },
    { symbol: "KDP", name: "Keurig Dr Pepper Inc. - Common Stock" },
    { symbol: "KMB", name: "Kimberly-Clark Corporation - Common Stock" },
    { symbol: "KHC", name: "The Kraft Heinz Company - Common Stock" },
    { symbol: "KR", name: "Kroger Company (The) Common Stock" },
    { symbol: "MKC", name: "McCormick & Company, Incorporated Common Stock" },
    { symbol: "TAP", name: "Molson Coors Beverage Company Class B Common Stock" },
    { symbol: "MDLZ", name: "Mondelez International, Inc. - Class A Common Stock" },
    { symbol: "MNST", name: "Monster Beverage Corporation - Common Stock" },
    { symbol: "PEP", name: "PepsiCo, Inc. - Common Stock" },
    { symbol: "PM", name: "Philip Morris International Inc Common Stock" },
    { symbol: "PG", name: "Procter & Gamble Company (The) Common Stock" },
    { symbol: "SJM", name: "The J.M. Smucker Company Common Stock" },
    { symbol: "SYY", name: "Sysco Corporation Common Stock" },
    { symbol: "TGT", name: "Target Corporation Common Stock" },
    { symbol: "TSN", name: "Tyson Foods, Inc. Common Stock" },
    { symbol: "WMT", name: "Walmart Inc. - Common Stock" },
  ],
  etfs: [
    { symbol: "SPY", name: "State Street SPDR S&P 500 ETF Trust" },
    { symbol: "QQQ", name: "Invesco QQQ Trust, Series 1" },
    { symbol: "SMH", name: "VanEck Semiconductor ETF" },
    { symbol: "IWM", name: "iShares Russell 2000 Index Fund" },
    { symbol: "SOXX", name: "iShares PHLX SOX Semiconductor Sector Index Fund" },
    { symbol: "TQQQ", name: "ProShares UltraPro QQQ" },
    { symbol: "EWY", name: "iShares MSCI South Korea ETF" },
    { symbol: "DRAM", name: "Roundhill Memory ETF" },
    { symbol: "VOO", name: "Vanguard S&P 500 ETF" },
    { symbol: "IVV", name: "iShares Core S&P 500 ETF" },
    { symbol: "GLD", name: "SPDR Gold Shares" },
    { symbol: "LQD", name: "iShares iBoxx $ Investment Grade Corporate Bond ETF" },
    { symbol: "HYG", name: "iShares iBoxx $ High Yield Corporate Bond ETF" },
    { symbol: "TLT", name: "iShares 20+ Year Treasury Bond ETF" },
    { symbol: "DIA", name: "State Street SPDR Dow Jones Industrial Average ETF Trust" },
    { symbol: "GDX", name: "VanEck Gold Miners ETF" },
    { symbol: "XLF", name: "State Street Financial Select Sector SPDR ETF" },
    { symbol: "BITO", name: "ProShares Bitcoin ETF" },
    { symbol: "RSP", name: "Invesco S&P 500 Equal Weight ETF" },
    { symbol: "XLE", name: "State Street Energy Select Sector SPDR ETF" },
    { symbol: "XLK", name: "State Street Technology Select Sector SPDR ETF" },
    { symbol: "XLV", name: "State Street Health Care Select Sector SPDR ETF" },
    { symbol: "EEM", name: "iShares MSCI Emerging Index Fund" },
    { symbol: "IGV", name: "iShares Expanded Tech-Software Sector ETF" },
    { symbol: "IBIT", name: "iShares Bitcoin Trust ETF" },
    { symbol: "XBI", name: "State Street SPDR S&P Biotech ETF" },
    { symbol: "XLI", name: "State Street Industrial Select Sector SPDR ETF" },
    { symbol: "VTI", name: "Vanguard Morningstar Total Stock Market ETF" },
    { symbol: "EFA", name: "iShares MSCI EAFE ETF" },
    { symbol: "QQQM", name: "Invesco NASDAQ 100 ETF" },
    { symbol: "KRE", name: "State Street SPDR S&P Regional Banking ETF" },
    { symbol: "IEMG", name: "iShares Core MSCI Emerging Markets ETF" },
    { symbol: "XLP", name: "State Street Consumer Staples Select Sector SPDR ETF" },
    { symbol: "SPYM", name: "State Street SPDR Portfolio S&P 500 ETF" },
    { symbol: "SLV", name: "iShares Silver Trust" },
    { symbol: "XLY", name: "State Street Consumer Discretionary Select Sector SPDR ETF" },
    { symbol: "XLU", name: "State Street Utilities Select Sector SPDR ETF" },
    { symbol: "USO", name: "United States Oil Fund" },
    { symbol: "AGG", name: "iShares Core U.S. Aggregate Bond ETF" },
    { symbol: "IEFA", name: "iShares Core MSCI EAFE ETF" },
    { symbol: "SCHD", name: "Schwab US Dividend Equity ETF" },
    { symbol: "VEA", name: "Vanguard FTSE Developed Markets ETF" },
    { symbol: "FXI", name: "iShares China Large-Cap ETF" },
    { symbol: "IEF", name: "iShares 7-10 Year Treasury Bond ETF" },
    { symbol: "XLC", name: "State Street Communication Services Select Sector SPDR ETF" },
    { symbol: "EWZ", name: "iShares MSCI Brazil ETF" },
    { symbol: "VTV", name: "Vanguard Morningstar Value ETF" },
    { symbol: "VCIT", name: "Vanguard Intermediate-Term Corporate Bond ETF" },
    { symbol: "EWT", name: "iShares MSCI Taiwan ETF" },
    { symbol: "VUG", name: "Vanguard Morningstar Growth ETF" },
    { symbol: "MTUM", name: "iShares MSCI USA Momentum Factor ETF" },
    { symbol: "XLB", name: "State Street Materials Select Sector SPDR ETF" },
    { symbol: "GDXJ", name: "VanEck Junior Gold Miners ETF" },
    { symbol: "KWEB", name: "KraneShares CSI China Internet ETF" },
    { symbol: "IYR", name: "iShares U.S. Real Estate ETF" },
    { symbol: "BND", name: "Vanguard Total Bond Market ETF" },
    { symbol: "IWF", name: "iShares Russell 1000 Growth Fund" },
    { symbol: "XOP", name: "State Street SPDR S&P Oil & Gas Exploration & Production ETF" },
    { symbol: "VGT", name: "Vanguard Information Tech ETF" },
    { symbol: "EMB", name: "iShares J.P. Morgan USD Emerging Markets Bond ETF" },
    { symbol: "IJR", name: "iShares Core S&P Small-Cap ETF" },
    { symbol: "IJH", name: "iShares Core S&P Mid-Cap ETF" },
    { symbol: "MUB", name: "iShares National Muni Bond ETF" },
    { symbol: "VWO", name: "Vanguard FTSE Emerging Markets ETF" },
    { symbol: "USHY", name: "iShares Broad USD High Yield Corporate Bond ETF" },
    { symbol: "IWD", name: "iShares Russell 1000 Value ETF" },
    { symbol: "IAU", name: "iShares Gold Trust Shares" },
    { symbol: "JEPQ", name: "JPMorgan Nasdaq Equity Premium Income ETF" },
    { symbol: "VXUS", name: "Vanguard Total International Stock ETF" },
    { symbol: "MDY", name: "State Street SPDR S&P MIDCAP 400 ETF Trust" },
    { symbol: "VT", name: "Vanguard Total World Stock Index ETF" },
    { symbol: "ACWI", name: "iShares MSCI ACWI ETF" },
    { symbol: "ETHA", name: "iShares Ethereum Trust ETF" },
    { symbol: "EWJ", name: "iShares MSCI Japan Index Fund" },
    { symbol: "XRT", name: "State Street SPDR S&P Retail ETF" },
    { symbol: "ARKK", name: "ARK Innovation ETF" },
    { symbol: "VTEB", name: "Vanguard Tax-Exempt Bond ETF" },
    { symbol: "SPMO", name: "Invesco S&P 500 Momentum ETF" },
    { symbol: "GLDM", name: "SPDR Gold MiniShares Trust" },
    { symbol: "UPRO", name: "ProShares UltraPro S&P 500" },
    { symbol: "SPYG", name: "State Street SPDR Portfolio S&P 500 Growth ETF" },
    { symbol: "QQQI", name: "NEOS Nasdaq 100 High Income ETF" },
    { symbol: "MAGS", name: "Roundhill Magnificent Seven ETF" },
    { symbol: "VO", name: "Vanguard Morningstar Mid-Cap ETF" },
    { symbol: "INDA", name: "iShares MSCI India ETF" },
    { symbol: "VNQ", name: "Vanguard Real Estate ETF" },
    { symbol: "IBB", name: "iShares Biotechnology ETF" },
    { symbol: "JEPI", name: "JPMorgan Equity Premium Income ETF" },
    { symbol: "ITOT", name: "iShares Core S&P Total U.S. Stock Market ETF" },
    { symbol: "SCHX", name: "Schwab U.S. Large-Cap ETF" },
    { symbol: "JNK", name: "State Street SPDR Bloomberg High Yield Bond ETF" },
    { symbol: "SCHG", name: "Schwab U.S. Large-Cap Growth ETF" },
    { symbol: "VIG", name: "Vanguard Div Appreciation ETF" },
    { symbol: "EFV", name: "iShares MSCI EAFE Value ETF" },
    { symbol: "VCLT", name: "Vanguard Long-Term Corporate Bond ETF" },
    { symbol: "EMXC", name: "iShares MSCI Emerging Markets ex China ETF" },
    { symbol: "VEU", name: "Vanguard FTSE All World Ex US ETF" },
    { symbol: "IWR", name: "iShares Russell Mid-Cap ETF" },
    { symbol: "XME", name: "State Street SPDR S&P Metals & Mining ETF" },
    { symbol: "USMV", name: "iShares MSCI USA Min Vol Factor ETF" },
    { symbol: "QID", name: "ProShares UltraShort QQQ" },
    { symbol: "COPX", name: "Global X Copper Miners ETF" },
    { symbol: "XHB", name: "State Street SPDR S&P Homebuilders ETF" },
    { symbol: "XLRE", name: "State Street Real Estate Select Sector SPDR ETF" },
    { symbol: "IWB", name: "iShares Russell 1000 ETF" },
    { symbol: "QUAL", name: "iShares MSCI USA Quality Factor ETF" },
    { symbol: "SCHF", name: "Schwab International Equity ETF" },
    { symbol: "SOXQ", name: "Invesco PHLX Semiconductor ETF" },
    { symbol: "SCHB", name: "Schwab U.S. Broad Market ETF" },
    { symbol: "SPIB", name: "State Street SPDR Portfolio Intermediate Term Corporate Bond" },
    { symbol: "CGDV", name: "Capital Group Dividend Value ETF" },
    { symbol: "VYM", name: "Vanguard High Dividend Yield ETF" },
    { symbol: "MBB", name: "iShares MBS ETF" },
    { symbol: "TIP", name: "iShares TIPS Bond ETF" },
    { symbol: "SPHY", name: "State Street SPDR Portfolio High Yield Bond ETF" },
    { symbol: "IVW", name: "iShares S&P 500 Growth ETF" },
    { symbol: "VTWO", name: "Vanguard Russell 2000 ETF" },
    { symbol: "VGK", name: "Vanguard FTSEEuropean ETF" },
    { symbol: "AVEM", name: "Avantis Emerging Markets Equity ETF" },
    { symbol: "ITB", name: "iShares U.S. Home Construction ETF" },
    { symbol: "DYNF", name: "iShares U.S. Equity Factor Rotation Active ETF" },
    { symbol: "BAI", name: "iShares A.I. Innovation and Tech Active ETF" },
    { symbol: "BNDX", name: "Vanguard Total International Bond ETF" },
    { symbol: "FBTC", name: "Fidelity Wise Origin Bitcoin Fund" },
    { symbol: "HDV", name: "iShares Core High Dividend ETF" },
    { symbol: "KBWB", name: "Invesco KBW Bank ETF" },
    { symbol: "IHI", name: "iShares U.S. Medical Devices ETF" },
    { symbol: "PSLV", name: "Sprott Physical Silver Trust ETV" },
    { symbol: "IXUS", name: "iShares Core MSCI Total International Stock ETF" },
    { symbol: "PDBC", name: "Invesco Optimum Yield Diversified Commodity Strategy No K-1 " },
    { symbol: "SPLV", name: "Invesco S&P 500 Low Volatility ETF" },
    { symbol: "GOVT", name: "iShares U.S. Treasury Bond ETF" },
    { symbol: "FBND", name: "Fidelity Total Bond ETF" },
    { symbol: "ITA", name: "iShares U.S. Aerospace & Defense ETF" },
    { symbol: "IEI", name: "iShares 3-7 Year Treasury Bond ETF" },
    { symbol: "IWO", name: "iShares Russell 2000 Growth Fund" },
    { symbol: "AVUV", name: "Avantis U.S. Small Cap Value ETF" },
    { symbol: "VLUE", name: "iShares MSCI USA Value Factor ETF" },
    { symbol: "VGIT", name: "Vanguard Intermediate-Term Treasury ETF" },
    { symbol: "IVE", name: "iShares S&P 500 Value ETF" },
    { symbol: "IUSB", name: "iShares Core Universal USD Bond ETF" },
    { symbol: "ACWX", name: "iShares MSCI ACWI ex U.S. ETF" },
    { symbol: "BBJP", name: "JPMorgan BetaBuilders Japan ETF" },
    { symbol: "CIBR", name: "First Trust NASDAQ Cybersecurity ETF" },
    { symbol: "SPYI", name: "NEOS S&P 500 High Income ETF" },
    { symbol: "MCHI", name: "iShares MSCI China ETF" },
    { symbol: "URA", name: "Global X Uranium ETF" },
    { symbol: "ASHR", name: "Xtrackers Harvest CSI 300 China A-Shares ETF" },
    { symbol: "VONG", name: "Vanguard Russell 1000 Growth ETF" },
    { symbol: "SCHH", name: "Schwab U.S. REIT ETF" },
    { symbol: "SPDW", name: "State Street SPDR Portfolio Developed World ex-US ETF" },
    { symbol: "SPYV", name: "State Street SPDR Portfolio S&P 500 Value ETF" },
    { symbol: "SDS", name: "ProShares UltraShort S&P500" },
    { symbol: "IYW", name: "iShares U.S. Technology ETF" },
    { symbol: "IWN", name: "iShares Russell 2000 Value ETF" },
    { symbol: "VB", name: "Vanguard Morningstar Small-Cap ETF" },
    { symbol: "PHYS", name: "Sprott Physical Gold Trust ETV" },
    { symbol: "SPTL", name: "State Street SPDR Portfolio Long Term Treasury ETF" },
    { symbol: "SCHV", name: "Schwab U.S. Large-Cap Value ETF" },
    { symbol: "BIV", name: "Vanguard Intermediate-Term Bond ETF" },
    { symbol: "SPHQ", name: "Invesco S&P 500 Quality ETF" },
    { symbol: "GRID", name: "First Trust NASDAQ Clean Edge Smart Grid Infrastructure Inde" },
    { symbol: "CGGR", name: "Capital Group Growth ETF" },
    { symbol: "ICLN", name: "iShares Global Clean Energy ETF" },
    { symbol: "MGK", name: "Vanguard Morningstar Mega Cap Growth ETF" },
    { symbol: "UDOW", name: "ProShares UltraPro Dow30" },
    { symbol: "IDEV", name: "iShares Core MSCI International Developed Markets ETF" },
    { symbol: "IWY", name: "iShares Russell Top 200 Growth ETF" },
    { symbol: "FDN", name: "First Trust DJ Internet Index Fund" },
    { symbol: "SCHE", name: "Schwab Emerging Markets Equity ETF" },
    { symbol: "SCHP", name: "Schwab U.S. TIPS ETF" },
    { symbol: "IGIB", name: "iShares 5-10 Year Investment Grade Corporate Bond ETF" },
    { symbol: "AIQ", name: "Global X Artificial Intelligence & Technology ETF" },
    { symbol: "VOOG", name: "Vanguard S&P 500 Growth ETF" },
    { symbol: "PAVE", name: "Global X U.S. Infrastructure Development ETF" },
    { symbol: "SCZ", name: "iShares MSCI EAFE Small-Cap ETF" },
    { symbol: "SCO", name: "ProShares UltraShort Bloomberg Crude Oil" },
    { symbol: "SILJ", name: "Amplify Junior Silver Miners ETF" },
    { symbol: "ARKG", name: "ARK Genomic Revolution ETF" },
    { symbol: "TLH", name: "iShares 10-20 Year Treasury Bond ETF" },
    { symbol: "DGRO", name: "iShares Core Dividend Growth ETF" },
    { symbol: "PVAL", name: "Putnam Focused Large Cap Value ETF" },
    { symbol: "DFAC", name: "Dimensional U.S. Core Equity 2 ETF" },
    { symbol: "VGLT", name: "Vanguard Long-Term Treasury ETF" },
    { symbol: "IWP", name: "iShares Russell Midcap Growth ETF" },
    { symbol: "SPEM", name: "State Street SPDR Portfolio Emerging Markets ETF" },
    { symbol: "AVLV", name: "Avantis U.S. Large Cap Value ETF" },
    { symbol: "BNO", name: "United States Brent Oil Fund, LP ETV" },
    { symbol: "OIH", name: "VanEck Oil Services ETF" },
    { symbol: "EWC", name: "iShares MSCI Canada Index Fund" },
    { symbol: "SIL", name: "Global X Silver Miners ETF" },
    { symbol: "URTH", name: "iShares MSCI World ETF" },
    { symbol: "USIG", name: "iShares Broad USD Investment Grade Corporate Bond ETF" },
    { symbol: "IGLB", name: "iShares 10 Year Investment Grade Corporate Bond ETF" },
    { symbol: "SPMD", name: "State Street SPDR Portfolio S&P 400 Mid Cap ETF" },
    { symbol: "IUSG", name: "iShares Core S&P U.S. Growth ETF" },
    { symbol: "VXF", name: "Vanguard Extended Market ETF" },
    { symbol: "PYLD", name: "PIMCO Multisector Bond Active Exchange-Traded Fund" },
    { symbol: "KBE", name: "State Street SPDR S&P Bank ETF" },
    { symbol: "OEF", name: "iShares S&P 100 Fund" },
    { symbol: "VFLO", name: "VictoryShares Free Cash Flow ETF" },
    { symbol: "EWW", name: "iShares MSCI Mexico ETF" },
    { symbol: "SPSM", name: "State Street SPDR Portfolio S&P 600 Small Cap ETF" },
    { symbol: "FTEC", name: "Fidelity MSCI Information Technology Index ETF" },
    { symbol: "FTXL", name: "First Trust Nasdaq Semiconductor ETF" },
    { symbol: "IAUM", name: "iShares Gold Trust Micro Shares" },
    { symbol: "AVDE", name: "Avantis International Equity ETF" },
    { symbol: "AVDV", name: "Avantis International Small Cap Value ETF" },
    { symbol: "VV", name: "Vanguard Morningstar Large-Cap ETF" },
    { symbol: "IWS", name: "iShares Russell Mid-Cap Value ETF" },
    { symbol: "UNG", name: "United States Natural Gas Fund LP" },
    { symbol: "ILF", name: "iShares Latin America 40 ETF" },
    { symbol: "RDVY", name: "First Trust Rising Dividend Achievers ETF" },
    { symbol: "VONV", name: "Vanguard Russell 1000 Value ETF" },
    { symbol: "SGOL", name: "abrdn Physical Gold Shares ETF" },
    { symbol: "GPIQ", name: "Goldman Sachs Nasdaq-100 Premium Income ETF" },
    { symbol: "IWV", name: "iShares Russell 3000 Fund" },
    { symbol: "EFG", name: "iShares MSCI EAFE Growth ETF" },
    { symbol: "JETS", name: "U.S. Global Jets ETF" },
    { symbol: "AIRR", name: "First Trust RBA American Industrial Renaissance ETF" },
    { symbol: "REET", name: "iShares Global REIT ETF" },
    { symbol: "DFAI", name: "Dimensional International Core Equity Market ETF" },
    { symbol: "VYMI", name: "Vanguard International High Dividend Yield ETF" },
    { symbol: "QTEC", name: "First Trust NASDAQ-100-Technology Sector Index Fund" },
    { symbol: "FNDF", name: "Schwab Fundamental International Equity ETF" },
    { symbol: "EDV", name: "Vanguard Extended Duration Treasury ETF" },
    { symbol: "FNDX", name: "Schwab Fundamental U.S. Large Company ETF" },
    { symbol: "IQLT", name: "iShares MSCI Intl Quality Factor ETF" },
    { symbol: "JCPB", name: "JPMorgan Core Plus Bond ETF" },
    { symbol: "SCHA", name: "Schwab U.S. Small-Cap ETF" },
    { symbol: "GBTC", name: "Grayscale Bitcoin Trust (BTC)" },
    { symbol: "SPAB", name: "State Street SPDR Portfolio Aggregate Bond ETF" },
    { symbol: "VDE", name: "Vanguard Energy ETF" },
    { symbol: "MOAT", name: "VanEck Morningstar Wide Moat ETF" },
    { symbol: "FLTW", name: "Franklin FTSE Taiwan ETF" },
    { symbol: "DVY", name: "iShares Select Dividend ETF" },
    { symbol: "KIE", name: "State Street SPDR S&P Insurance ETF" },
    { symbol: "RING", name: "iShares MSCI Global Gold Miners ETF" },
    { symbol: "DFIV", name: "Dimensional International Value ETF" },
    { symbol: "CWB", name: "State Street SPDR Bloomberg Convertible Securities ETF" },
    { symbol: "BWET", name: "Breakwave Tanker Shipping ETF" },
    { symbol: "DBMF", name: "iMGP DBi Managed Futures Strategy ETF" },
    { symbol: "DFIC", name: "Dimensional International Core Equity 2 ETF" },
    { symbol: "SHLD", name: "Global X Defense Tech ETF" },
    { symbol: "VBK", name: "Vanguard Morningstar Small-Cap Growth ETF" },
    { symbol: "NOBL", name: "ProShares S&P 500 Dividend Aristocrats ETF" },
    { symbol: "PSI", name: "Invesco Semiconductors ETF" },
    { symbol: "COWZ", name: "Pacer US Cash Cows 100 ETF" },
    { symbol: "ICVT", name: "iShares Convertible Bond ETF" },
    { symbol: "EWH", name: "iShares MSCI Hong Kong Index Fund" },
    { symbol: "JGRO", name: "JPMorgan Active Growth ETF" },
    { symbol: "VHT", name: "Vanguard Health Care ETF" },
    { symbol: "AMLP", name: "Alerian MLP ETF" },
    { symbol: "ESGU", name: "iShares ESG Aware MSCI USA ETF" },
    { symbol: "SIVR", name: "abrdn Physical Silver Shares ETF" },
    { symbol: "QTUM", name: "Defiance Quantum ETF" },
    { symbol: "DFAR", name: "Dimensional US Real Estate ETF" },
    { symbol: "IEUR", name: "iShares Core MSCI Europe ETF" },
    { symbol: "GPIX", name: "Goldman Sachs S&P 500 Premium Income ETF" },
    { symbol: "CGBL", name: "Capital Group Core Balanced ETF" },
    { symbol: "IYH", name: "iShares U.S. Healthcare ETF" },
    { symbol: "IYF", name: "iShares U.S. Financial ETF" },
    { symbol: "XMMO", name: "Invesco S&P MidCap Momentum ETF" },
    { symbol: "SCHR", name: "Schwab Intermediate-Term U.S. Treasury ETF" },
    { symbol: "DXJ", name: "WisdomTree Japan Hedged Equity Fund" },
    { symbol: "VBR", name: "Vanguard Morningstar Small-Cap Value ETF" },
    { symbol: "SHYG", name: "iShares 0-5 Year High Yield Corporate Bond ETF" },
    { symbol: "VFH", name: "Vanguard Financials ETF" },
    { symbol: "GSLC", name: "Goldman Sachs ActiveBeta U.S. Large Cap Equity ETF" },
    { symbol: "IGF", name: "iShares Global Infrastructure ETF" },
    { symbol: "TAN", name: "Invesco Solar ETF" },
    { symbol: "KOLD", name: "ProShares UltraShort Bloomberg Natural Gas" },
    { symbol: "BUG", name: "Global X Cybersecurity ETF" },
    { symbol: "AIA", name: "iShares Asia 50 ETF" },
    { symbol: "VOT", name: "Vanguard Morningstar Mid-Cap Growth ETF" },
    { symbol: "SRLN", name: "State Street Blackstone Senior Loan ETF" },
    { symbol: "XLG", name: "Invesco S&P 500 Top 50 ETF" },
    { symbol: "EUFN", name: "iShares MSCI Europe Financials ETF" },
    { symbol: "IUSV", name: "iShares Core S&P U.S. Value ETF" },
    { symbol: "VMBS", name: "Vanguard Mortgage-Backed Securities ETF" },
    { symbol: "BCI", name: "abrdn Bloomberg All Commodity Strategy K-1 Free ETF" },
    { symbol: "DGRW", name: "WisdomTree U.S. Quality Dividend Growth Fund" },
    { symbol: "EWU", name: "iShares MSCI United Kingdom ETF" },
    { symbol: "EFAV", name: "iShares MSCI EAFE Min Vol Factor ETF" },
    { symbol: "XAR", name: "State Street SPDR S&P Aerospace & Defense ETF" },
    { symbol: "CHAT", name: "Roundhill Generative AI & Technology ETF" },
    { symbol: "FENI", name: "Fidelity Enhanced International ETF" },
    { symbol: "DFUS", name: "Dimensional U.S. Equity Market ETF" },
    { symbol: "JMUB", name: "JPMorgan Municipal ETF" },
    { symbol: "HGER", name: "Harbor Commodity All-Weather Strategy ETF" },
    { symbol: "UUP", name: "Invesco DB USD Index Bullish Fund ETF" },
    { symbol: "IGM", name: "iShares Expanded Tech Sector ETF" },
    { symbol: "IXN", name: "iShares Global Tech ETF" },
    { symbol: "VOE", name: "Vanguard Morningstar Mid-Cap Value ETF" },
    { symbol: "FEZ", name: "State Street SPDR EURO STOXX 50 ETF" },
    { symbol: "EZU", name: "iShares MSCI Eurozone ETF" },
    { symbol: "SPTI", name: "State Street SPDR Portfolio Intermediate Term Treasury ETF" },
    { symbol: "CGGO", name: "Capital Group Global Growth Equity ETF" },
    { symbol: "SPLB", name: "State Street SPDR Portfolio Long Term Corporate Bond ETF" },
    { symbol: "FLKR", name: "Franklin FTSE South Korea ETF" },
    { symbol: "EWA", name: "iShares MSCI Australia Index Fund" },
    { symbol: "SPHB", name: "Invesco S&P 500 High Beta ETF" },
    { symbol: "VOX", name: "Vanguard Communication Services ETF" },
    { symbol: "IWX", name: "iShares Russell Top 200 Value ETF" },
    { symbol: "SKYY", name: "First Trust Cloud Computing ETF" },
    { symbol: "BOND", name: "PIMCO Active Bond Exchange-Traded Fund Exchange-Traded Fund" },
    { symbol: "SPYD", name: "State Street SPDR Portfolio S&P 500 High Dividend ETF" },
    { symbol: "DFAE", name: "Dimensional Emerging Core Equity Market ETF" },
    { symbol: "FDVV", name: "Fidelity High Dividend ETF" },
    { symbol: "BLV", name: "Vanguard Long-Term Bond ETF" },
    { symbol: "ZSL", name: "ProShares UltraShort Silver" },
    { symbol: "IYT", name: "iShares U.S. Transportation ETF" },
    { symbol: "FTCS", name: "First Trust Capital Strength ETF" },
    { symbol: "CGUS", name: "Capital Group Core Equity ETF" },
    { symbol: "VPU", name: "Vanguard Utilities ETF" },
    { symbol: "BUFR", name: "FT Vest Laddered Buffer ETF" },
    { symbol: "AAXJ", name: "iShares MSCI All Country Asia ex Japan ETF" },
    { symbol: "DFCF", name: "Dimensional Core Fixed Income ETF" },
    { symbol: "AAAU", name: "Goldman Sachs Physical Gold ETF Shares" },
    { symbol: "CHPY", name: "YieldMax Semiconductor Portfolio Option Income ETF" },
    { symbol: "NLR", name: "VanEck Uranium and Nuclear ETF" },
    { symbol: "XSD", name: "State Street SPDR S&P Semiconductor ETF" },
    { symbol: "CQQQ", name: "Invesco China Technology ETF" },
    { symbol: "RPG", name: "Invesco S&P 500 Pure Growth ETF" },
    { symbol: "PICK", name: "iShares MSCI Global Select Metals & Mining Producers Fund" },
    { symbol: "BFLX", name: "iShares Flexible Equity Active ETF" },
    { symbol: "FDL", name: "First Trust Morningstar ETF" },
    { symbol: "RWR", name: "State Street SPDR Dow Jones REIT ETF" },
    { symbol: "HYD", name: "VanEck High Yield Muni ETF" },
    { symbol: "IOO", name: "iShares Global 100 ETF" },
    { symbol: "RSPT", name: "Invesco S&P 500 Equal Weight Technology ETF" },
    { symbol: "NASA", name: "Tema Space Innovators ETF" },
    { symbol: "IYZ", name: "iShares U.S. Telecommunications ETF" },
    { symbol: "FESM", name: "Fidelity Enhanced Small Cap Core ETF" },
    { symbol: "FENY", name: "Fidelity MSCI Energy Index ETF" },
    { symbol: "IYE", name: "iShares U.S. Energy ETF" },
    { symbol: "ESGE", name: "iShares ESG Aware MSCI EM ETF" },
    { symbol: "FWD", name: "AB Disruptors ETF" },
    { symbol: "GLL", name: "ProShares UltraShort Gold" },
    { symbol: "JBND", name: "JPMorgan Active Bond ETF" },
    { symbol: "FMDE", name: "Fidelity Enhanced Mid Cap Core ETF" },
    { symbol: "IXC", name: "iShares Global Energy ETF" },
    { symbol: "DFEM", name: "Dimensional Emerging Markets Core Equity 2 ETF" },
    { symbol: "VPL", name: "Vanguard FTSE Pacific ETF" },
  ],
  etfs_leveraged: [
    { symbol: "SOXL", name: "Direxion Daily Semiconductor Bull 3X ETF" },
    { symbol: "SOXS", name: "Direxion Daily Semiconductor Bear 3X ETF" },
    { symbol: "SQQQ", name: "ProShares UltraPro Short QQQ" },
    { symbol: "SNXX", name: "Tradr 2X Long SNDK Daily ETF" },
    { symbol: "MUU", name: "Direxion Daily MU Bull 2X ETF" },
    { symbol: "KORU", name: "Direxion Daily South Korea Bull 3X ETF" },
    { symbol: "TSLL", name: "Direxion Daily TSLA Bull 2X ETF" },
    { symbol: "SPXL", name: "Direxion Daily S&P 500 Bull 3X ETF" },
    { symbol: "NVDL", name: "GraniteShares 2x Long NVDA Daily ETF" },
    { symbol: "QLD", name: "ProShares Ultra QQQ" },
    { symbol: "SNDQ", name: "Tradr 2X Short SNDK Daily ETF" },
    { symbol: "SPDN", name: "Direxion Daily S&P 500 Bear 1X ETF" },
    { symbol: "SNDU", name: "T-REX 2X Long SNDK Daily Target ETF" },
    { symbol: "SPCH", name: "Leverage Shares 2X Long SPCX Daily ETF" },
    { symbol: "NVD", name: "GraniteShares 2x Short NVDA Daily ETF" },
    { symbol: "RWM", name: "ProShares Short Russell2000" },
    { symbol: "TNA", name: "Direxion Small Cap Bull 3X ETF" },
    { symbol: "MSFU", name: "Direxion Daily MSFT Bull 2X ETF" },
    { symbol: "SKUU", name: "GraniteShares 2x Long SK Hynix Daily ETF" },
    { symbol: "SPXS", name: "Direxion Daily S&P 500 Bear 3X ETF" },
    { symbol: "SPXU", name: "ProShares UltraPro Short S&P500" },
    { symbol: "SH", name: "ProShares Short S&P500" },
    { symbol: "PSQ", name: "ProShares Short QQQ" },
    { symbol: "BSV", name: "Vanguard Short-Term Bond ETF" },
    { symbol: "MSTU", name: "T-Rex 2X Long MSTR Daily Target ETF" },
    { symbol: "SSO", name: "ProShares Ultra S&P500" },
    { symbol: "SSPC", name: "Leverage Shares 2X Short SPCX Daily ETF" },
    { symbol: "PLTD", name: "Direxion Daily PLTR Bear 1X ETF" },
    { symbol: "MULL", name: "GraniteShares 2x Long MU Daily ETF" },
    { symbol: "RAM", name: "Roundhill T-REX 2X Long DRAM Daily Target ETF" },
    { symbol: "GDXU", name: "MicroSectors Gold Miners 3X Leveraged ETN" },
    { symbol: "GGLL", name: "Direxion Daily GOOGL Bull 2X ETF" },
    { symbol: "TZA", name: "Direxion Small Cap Bear 3X ETF" },
    { symbol: "AMDL", name: "GraniteShares 2x Long AMD Daily ETF" },
    { symbol: "TECL", name: "Direxion Daily Technology Bull 3X ETF" },
    { symbol: "AGQ", name: "ProShares Ultra Silver" },
    { symbol: "NBIL", name: "GraniteShares 2x Long NBIS Daily ETF" },
    { symbol: "AAOX", name: "Tradr 2X Long AAOI Daily ETF" },
    { symbol: "PLTU", name: "Direxion Daily PLTR Bull 2X ETF" },
    { symbol: "UVXY", name: "ProShares Ultra VIX Short Term Futures ETF" },
    { symbol: "INTW", name: "GraniteShares 2x Long INTC Daily ETF" },
    { symbol: "TSLG", name: "Leverage Shares 2X Long TSLA Daily ETF" },
    { symbol: "FNGU", name: "MicroSectors FANG+ 3X Leveraged ETNs" },
    { symbol: "TMF", name: "Direxion Daily 20-Yr Treasury Bull 3x Shrs" },
    { symbol: "MUD", name: "Direxion Daily MU Bear 1X ETF" },
    { symbol: "MUZ", name: "Defiance Daily Target 2X Short MU ETF" },
    { symbol: "SKDD", name: "GraniteShares 2x Short SK Hynix Daily ETF" },
    { symbol: "NEBX", name: "Tradr 2X Long NBIS Daily ETF" },
    { symbol: "NVDX", name: "T-Rex 2X Long NVIDIA Daily Target ETF" },
    { symbol: "AAPD", name: "Direxion Daily AAPL Bear 1X ETF" },
    { symbol: "AMZU", name: "Direxion Daily AMZN Bull 2X ETF" },
    { symbol: "UCO", name: "ProShares Ultra Bloomberg Crude Oil" },
    { symbol: "NOWL", name: "GraniteShares 2x Long NOW Daily ETF" },
    { symbol: "TSDD", name: "GraniteShares 2x Short TSLA Daily ETF" },
    { symbol: "TSLQ", name: "Tradr 2X Short TSLA Daily ETF" },
    { symbol: "SMCX", name: "Defiance Daily Target 2X Long SMCI ETF" },
    { symbol: "AXTX", name: "Tradr 2X Long AXTI Daily ETF" },
    { symbol: "AMZD", name: "Direxion Daily AMZN Bear 1X ETF" },
    { symbol: "IRE", name: "Defiance Daily Target 2X Long IREN ETF" },
    { symbol: "LITX", name: "Tradr 2X Long LITE Daily ETF" },
    { symbol: "SKHX", name: "Leverage Shares 2X Long SK Hynix Daily ETF" },
    { symbol: "AVS", name: "Direxion Daily AVGO Bear 1X ETF" },
    { symbol: "LABU", name: "Direxion Daily S&P Biotech Bull 3X ETF" },
    { symbol: "METU", name: "Direxion Daily META Bull 2X ETF" },
    { symbol: "PTIR", name: "GraniteShares 2x Long PLTR Daily ETF" },
    { symbol: "NUGT", name: "Direxion Daily Gold Miners Index Bull 2X ETF" },
    { symbol: "UGL", name: "ProShares Ultra Gold" },
    { symbol: "MSTZ", name: "T-Rex 2X Inverse MSTR Daily Target ETF" },
    { symbol: "DAMD", name: "Defiance Daily Target 2X Short AMD ETF" },
    { symbol: "BTCZ", name: "T-Rex 2X Inverse Bitcoin Daily Target ETF" },
    { symbol: "ORCX", name: "Defiance Daily Target 2X Long ORCL ETF" },
    { symbol: "SVXY", name: "ProShares Short VIX Short Term Futures ETF" },
    { symbol: "BITX", name: "2x Bitcoin ETF" },
    { symbol: "MVLL", name: "GraniteShares 2x Long MRVL Daily ETF" },
    { symbol: "BEX", name: "Tradr 2X Long BE Daily ETF" },
    { symbol: "SDOW", name: "UltraPro Short Dow30" },
    { symbol: "AAPU", name: "Direxion Daily AAPL Bull 2X ETF" },
    { symbol: "BOIL", name: "ProShares Ultra Bloomberg Natural Gas" },
    { symbol: "LABD", name: "Direxion Daily S&P Biotech Bear 3X ETF" },
    { symbol: "ASTX", name: "Tradr 2X Long ASTS Daily ETF" },
    { symbol: "CONL", name: "GraniteShares 2x Long COIN Daily ETF" },
    { symbol: "UVIX", name: "2x Long VIX Futures ETF" },
    { symbol: "NBIG", name: "Leverage Shares 2X Long NBIS Daily ETF" },
    { symbol: "ETHU", name: "2x Ether ETF" },
    { symbol: "FAS", name: "Direxion Financial Bull 3X ETF" },
    { symbol: "RKLX", name: "Defiance Daily Target 2X Long RKLB ETF" },
    { symbol: "USD", name: "ProShares Ultra Semiconductors" },
    { symbol: "SJNK", name: "State Street SPDR Bloomberg Short Term High Yield Bond ETF" },
    { symbol: "TSMX", name: "Direxion Daily TSM Bull 2X ETF" },
    { symbol: "SVIX", name: "-1x Short VIX Futures ETF" },
    { symbol: "SPCF", name: "ProShares Ultra SpaceX" },
    { symbol: "CBRG", name: "Leverage Shares 2X Long CBRS Daily ETF" },
    { symbol: "MSTX", name: "Defiance Daily Target 2x Long MSTR ETF" },
    { symbol: "CRWG", name: "Leverage Shares 2X Long CRWV Daily ETF" },
    { symbol: "SNDG", name: "Leverage Shares 2X Long SNDK Daily ETF" },
    { symbol: "ORCU", name: "Direxion Daily ORCL Bull 2X ETF" },
    { symbol: "NVDU", name: "Direxion Daily NVDA Bull 2X ETF" },
    { symbol: "CRWU", name: "T-REX 2X Long CRWV Daily Target ETF" },
    { symbol: "SNK", name: "GraniteShares 2x Short SpaceX Daily ETF" },
    { symbol: "NAIL", name: "Direxion Daily Homebuilders & Supplies Bull 3X ETF" },
    { symbol: "JNUG", name: "Direxion Daily Junior Gold Miners Index Bull 2X ETF" },
    { symbol: "DOG", name: "ProShares Short Dow30" },
    { symbol: "VIXY", name: "VIX Short-Term Futures ETF" },
    { symbol: "SKHU", name: "ProShares Ultra SK hynix" },
    { symbol: "OKLL", name: "Defiance Daily Target 2x Long OKLO ETF" },
    { symbol: "WDCX", name: "Tradr 2X Long WDC Daily ETF" },
  ],
  ev_energy: [
    { symbol: "APA", name: "APA Corporation - Common Stock" },
    { symbol: "BKR", name: "Baker Hughes Company - Common Stock" },
    { symbol: "CVX", name: "Chevron Corporation Common Stock" },
    { symbol: "COP", name: "ConocoPhillips Common Stock" },
    { symbol: "DVN", name: "Devon Energy Corporation Common Stock" },
    { symbol: "FANG", name: "Diamondback Energy, Inc. - Common Stock" },
    { symbol: "EOG", name: "EOG Resources, Inc. Common Stock" },
    { symbol: "EQT", name: "EQT Corporation Common Stock" },
    { symbol: "EXE", name: "Expand Energy Corporation - Common Stock" },
    { symbol: "XOM", name: "ExxonMobil Holdings Corporation Common Stock" },
    { symbol: "HAL", name: "Halliburton Company Common Stock" },
    { symbol: "KMI", name: "Kinder Morgan, Inc. Common Stock" },
    { symbol: "MPC", name: "Marathon Petroleum Corporation Common Stock" },
    { symbol: "OXY", name: "Occidental Petroleum Corporation Common Stock" },
    { symbol: "OKE", name: "ONEOK, Inc. Common Stock" },
    { symbol: "PSX", name: "Phillips 66 Common Stock" },
    { symbol: "SLB", name: "SLB Limited Common Shares" },
    { symbol: "TRGP", name: "Targa Resources, Inc. Common Stock" },
    { symbol: "TPL", name: "Texas Pacific Land Corporation Common Stock" },
    { symbol: "VLO", name: "Valero Energy Corporation Common Stock" },
    { symbol: "WMB", name: "Williams Companies, Inc. (The) Common Stock" },
  ],
  finance: [
    { symbol: "AFL", name: "AFLAC Incorporated Common Stock" },
    { symbol: "ALL", name: "Allstate Corporation (The) Common Stock" },
    { symbol: "AXP", name: "American Express Company Common Stock" },
    { symbol: "AIG", name: "American International Group, Inc. New Common Stock" },
    { symbol: "AMP", name: "Ameriprise Financial, Inc. Common Stock" },
    { symbol: "AON", name: "Aon plc Class A Ordinary Shares (Ireland)" },
    { symbol: "APO", name: "Apollo Global Management, Inc. (New) Common Stock" },
    { symbol: "ACGL", name: "Arch Capital Group Ltd. - Common Stock" },
    { symbol: "ARES", name: "Ares Management Corporation Class A Common Stock" },
    { symbol: "AJG", name: "Arthur J. Gallagher & Co. Common Stock" },
    { symbol: "AIZ", name: "Assurant, Inc. Common Stock" },
    { symbol: "BAC", name: "Bank of America Corporation Common Stock" },
    { symbol: "BRK-B", name: "Berkshire Hathaway Inc. New Common Stock" },
    { symbol: "BLK", name: "BlackRock, Inc. Common Stock" },
    { symbol: "BX", name: "Blackstone Inc. Common Stock" },
    { symbol: "XYZ", name: "Block, Inc. Class A Common Stock," },
    { symbol: "BNY", name: "The Bank of New York Mellon Corporation Common Stock" },
    { symbol: "BRO", name: "Brown & Brown, Inc. Common Stock" },
    { symbol: "COF", name: "Capital One Financial Corporation Common Stock" },
    { symbol: "CBOE", name: "Cboe Global Markets, Inc. Common Stock" },
    { symbol: "SCHW", name: "Charles Schwab Corporation (The) Common Stock" },
    { symbol: "CB", name: "Chubb Limited Common Stock" },
    { symbol: "CINF", name: "Cincinnati Financial Corporation - Common Stock" },
    { symbol: "C", name: "Citigroup, Inc. Common Stock" },
    { symbol: "CFG", name: "Citizens Financial Group, Inc. Common Stock" },
    { symbol: "CME", name: "CME Group Inc. - Class A Common Stock" },
    { symbol: "COIN", name: "Coinbase Global, Inc. - Class A Common Stock" },
    { symbol: "CPAY", name: "Corpay, Inc. Common Stock" },
    { symbol: "ERIE", name: "Erie Indemnity Company - Class A Common Stock" },
    { symbol: "EG", name: "Everest Group, Ltd. Common Stock" },
    { symbol: "FDS", name: "FactSet Research Systems Inc. Common Stock" },
    { symbol: "FIS", name: "Fidelity National Information Services, Inc. Common Stock" },
    { symbol: "FITB", name: "Fifth Third Bancorp Common Stock" },
    { symbol: "FISV", name: "Fiserv, Inc. - Common Stock" },
    { symbol: "BEN", name: "Franklin Resources, Inc. Common Stock" },
    { symbol: "GPN", name: "Global Payments Inc. Common Stock" },
    { symbol: "GL", name: "Globe Life Inc. Common Stock" },
    { symbol: "GS", name: "Goldman Sachs Group, Inc. (The) Common Stock" },
    { symbol: "HIG", name: "The Hartford Insurance Group, Inc. Common Stock" },
    { symbol: "HBAN", name: "Huntington Bancshares Incorporated - Common Stock" },
    { symbol: "IBKR", name: "Interactive Brokers Group, Inc. - Class A Common Stock" },
    { symbol: "ICE", name: "Intercontinental Exchange Inc. Common Stock" },
    { symbol: "IVZ", name: "Invesco Ltd Common Stock" },
    { symbol: "JKHY", name: "Jack Henry & Associates, Inc. - Common Stock" },
    { symbol: "JPM", name: "JP Morgan Chase & Co. Common Stock" },
    { symbol: "KEY", name: "KeyCorp Common Stock" },
    { symbol: "KKR", name: "KKR & Co. Inc. Common Stock" },
    { symbol: "L", name: "Loews Corporation Common Stock" },
    { symbol: "MTB", name: "M&T Bank Corporation Common Stock" },
    { symbol: "MRSH", name: "Marsh Common Stock" },
    { symbol: "MA", name: "Mastercard Incorporated Common Stock" },
    { symbol: "MET", name: "MetLife, Inc. Common Stock" },
    { symbol: "MCO", name: "Moody's Corporation Common Stock" },
    { symbol: "MS", name: "Morgan Stanley Common Stock" },
    { symbol: "MSCI", name: "MSCI Inc. Common Stock" },
    { symbol: "NDAQ", name: "Nasdaq, Inc. - Common Stock" },
    { symbol: "NTRS", name: "Northern Trust Corporation - Common Stock" },
    { symbol: "PYPL", name: "PayPal Holdings, Inc. - Common Stock" },
    { symbol: "PNC", name: "PNC Financial Services Group, Inc. (The) Common Stock" },
    { symbol: "PFG", name: "Principal Financial Group Inc - Common Stock" },
    { symbol: "PGR", name: "Progressive Corporation (The) Common Stock" },
    { symbol: "PRU", name: "Prudential Financial, Inc. Common Stock" },
    { symbol: "RJF", name: "Raymond James Financial, Inc. Common Stock" },
    { symbol: "RF", name: "Regions Financial Corporation Common Stock" },
    { symbol: "HOOD", name: "Robinhood Markets, Inc. - Class A Common Stock" },
    { symbol: "SPGI", name: "S&P Global Inc. Common Stock" },
    { symbol: "STT", name: "State Street Corporation Common Stock" },
    { symbol: "SYF", name: "Synchrony Financial Common Stock" },
    { symbol: "TROW", name: "T. Rowe Price Group, Inc. - Common Stock" },
    { symbol: "TRV", name: "The Travelers Companies, Inc. Common Stock" },
    { symbol: "TFC", name: "Truist Financial Corporation Common Stock" },
    { symbol: "USB", name: "U.S. Bancorp Common Stock" },
    { symbol: "V", name: "Visa Inc." },
    { symbol: "WRB", name: "W.R. Berkley Corporation Common Stock" },
    { symbol: "WFC", name: "Wells Fargo & Company Common Stock" },
    { symbol: "WTW", name: "Willis Towers Watson Public Limited Company - Ordinary Share" },
  ],
  healthcare: [
    { symbol: "ABT", name: "Abbott Laboratories Common Stock" },
    { symbol: "ABBV", name: "AbbVie Inc. Common Stock" },
    { symbol: "A", name: "Agilent Technologies, Inc. Common Stock" },
    { symbol: "ALGN", name: "Align Technology, Inc. - Common Stock" },
    { symbol: "AMGN", name: "Amgen Inc. - Common Stock" },
    { symbol: "BAX", name: "Baxter International Inc. Common Stock" },
    { symbol: "BDX", name: "Becton, Dickinson and Company Common Stock" },
    { symbol: "TECH", name: "Bio-Techne Corp - Common Stock" },
    { symbol: "BIIB", name: "Biogen Inc. - Common Stock" },
    { symbol: "BSX", name: "Boston Scientific Corporation Common Stock" },
    { symbol: "BMY", name: "Bristol-Myers Squibb Company Common Stock" },
    { symbol: "CAH", name: "Cardinal Health, Inc. Common Stock" },
    { symbol: "COR", name: "Cencora, Inc. Common Stock" },
    { symbol: "CNC", name: "Centene Corporation Common Stock" },
    { symbol: "CRL", name: "Charles River Laboratories International, Inc. Common Stock" },
    { symbol: "CI", name: "The Cigna Group Common Stock" },
    { symbol: "COO", name: "The Cooper Companies, Inc. - Common Stock" },
    { symbol: "CVS", name: "CVS Health Corporation Common Stock" },
    { symbol: "DHR", name: "Danaher Corporation Common Stock" },
    { symbol: "DVA", name: "DaVita Inc. Common Stock" },
    { symbol: "DXCM", name: "DexCom, Inc. - Common Stock" },
    { symbol: "EW", name: "Edwards Lifesciences Corporation Common Stock" },
    { symbol: "ELV", name: "Elevance Health, Inc. Common Stock" },
    { symbol: "GEHC", name: "GE HealthCare Technologies Inc. - Common Stock" },
    { symbol: "GILD", name: "Gilead Sciences, Inc. - Common Stock" },
    { symbol: "HCA", name: "HCA Healthcare, Inc. Common Stock" },
    { symbol: "HSIC", name: "Henry Schein, Inc. - Common Stock" },
    { symbol: "HUM", name: "Humana Inc. Common Stock" },
    { symbol: "IDXX", name: "IDEXX Laboratories, Inc. - Common Stock" },
    { symbol: "INCY", name: "Incyte Corporation - Common Stock" },
    { symbol: "PODD", name: "Insulet Corporation - Common Stock" },
    { symbol: "ISRG", name: "Intuitive Surgical, Inc. - Common Stock" },
    { symbol: "IQV", name: "IQVIA Holdings, Inc. Common Stock" },
    { symbol: "JNJ", name: "Johnson & Johnson Common Stock" },
    { symbol: "LH", name: "Labcorp Holdings Inc. Common Stock" },
    { symbol: "LLY", name: "Eli Lilly and Company Common Stock" },
    { symbol: "MCK", name: "McKesson Corporation Common Stock" },
    { symbol: "MDT", name: "Medtronic plc. Ordinary Shares" },
    { symbol: "MRK", name: "Merck & Company, Inc. Common Stock (new)" },
    { symbol: "MTD", name: "Mettler-Toledo International, Inc. Common Stock" },
    { symbol: "MRNA", name: "Moderna, Inc. - Common Stock" },
    { symbol: "PFE", name: "Pfizer, Inc. Common Stock" },
    { symbol: "DGX", name: "Quest Diagnostics Incorporated Common Stock" },
    { symbol: "REGN", name: "Regeneron Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "RMD", name: "ResMed Inc. Common Stock" },
    { symbol: "RVTY", name: "Revvity, Inc. Common Stock" },
    { symbol: "SOLV", name: "Solventum Corporation Common Stock" },
    { symbol: "STE", name: "STERIS plc (Ireland) Ordinary Shares" },
    { symbol: "SYK", name: "Stryker Corporation Common Stock" },
    { symbol: "TMO", name: "Thermo Fisher Scientific Inc Common Stock" },
    { symbol: "UNH", name: "UnitedHealth Group Incorporated Common Stock (DE)" },
    { symbol: "UHS", name: "Universal Health Services, Inc. Common Stock" },
    { symbol: "VEEV", name: "Veeva Systems Inc. Class A Common Stock" },
    { symbol: "VRTX", name: "Vertex Pharmaceuticals Incorporated - Common Stock" },
    { symbol: "VTRS", name: "Viatris Inc. - Common Stock" },
    { symbol: "WAT", name: "Waters Corporation Common Stock" },
    { symbol: "WST", name: "West Pharmaceutical Services, Inc. Common Stock" },
    { symbol: "ZBH", name: "Zimmer Biomet Holdings, Inc. Common Stock" },
    { symbol: "ZTS", name: "Zoetis Inc. Class A Common Stock" },
  ],
  industrials: [
    { symbol: "MMM", name: "3M Company Common Stock" },
    { symbol: "AOS", name: "A.O. Smith Corporation Common Stock" },
    { symbol: "ALLE", name: "Allegion plc Ordinary Shares" },
    { symbol: "AME", name: "AMETEK, Inc." },
    { symbol: "ADP", name: "Automatic Data Processing, Inc. - Common Stock" },
    { symbol: "AXON", name: "Axon Enterprise, Inc. - Common Stock" },
    { symbol: "BA", name: "Boeing Company (The) Common Stock" },
    { symbol: "BR", name: "Broadridge Financial Solutions, Inc. Common Stock" },
    { symbol: "BLDR", name: "Builders FirstSource, Inc. Common Stock" },
    { symbol: "CHRW", name: "C.H. Robinson Worldwide, Inc. - Common Stock" },
    { symbol: "CARR", name: "Carrier Global Corporation Common Stock" },
    { symbol: "CAT", name: "Caterpillar, Inc. Common Stock" },
    { symbol: "CTAS", name: "Cintas Corporation - Common Stock" },
    { symbol: "FIX", name: "Comfort Systems USA, Inc. Common Stock" },
    { symbol: "CPRT", name: "Copart, Inc. - Common Stock" },
    { symbol: "CSX", name: "CSX Corporation - Common Stock" },
    { symbol: "CMI", name: "Cummins Inc. Common Stock" },
    { symbol: "DE", name: "Deere & Company Common Stock" },
    { symbol: "DAL", name: "Delta Air Lines, Inc. Common Stock" },
    { symbol: "DOV", name: "Dover Corporation Common Stock" },
    { symbol: "DD", name: "DuPont de Nemours, Inc. Common Stock" },
    { symbol: "ETN", name: "Eaton Corporation, PLC Ordinary Shares" },
    { symbol: "EME", name: "EMCOR Group, Inc. Common Stock" },
    { symbol: "EMR", name: "Emerson Electric Company Common Stock" },
    { symbol: "EFX", name: "Equifax, Inc. Common Stock" },
    { symbol: "EXPD", name: "Expeditors International of Washington, Inc. Common Stock" },
    { symbol: "FAST", name: "Fastenal Company - Common Stock" },
    { symbol: "FDX", name: "FedEx Corporation Common Stock" },
    { symbol: "FDXF", name: "FedEx Freight Holding Company, Inc. Common Stock" },
    { symbol: "FERG", name: "Ferguson Enterprises Inc. Common Stock" },
    { symbol: "FTV", name: "Fortive Corporation Common Stock" },
    { symbol: "GE", name: "GE Aerospace Common Stock" },
    { symbol: "GEV", name: "GE Vernova Inc. Common Stock" },
    { symbol: "GNRC", name: "Generac Holdlings Inc. Common Stock" },
    { symbol: "GD", name: "General Dynamics Corporation Common Stock" },
    { symbol: "HONA", name: "Honeywell Aerospace Inc. - Common Stock" },
    { symbol: "HON", name: "Honeywell International Inc. - Common Stock" },
    { symbol: "HWM", name: "Howmet Aerospace Inc. Common Stock" },
    { symbol: "HUBB", name: "Hubbell Inc Common Stock" },
    { symbol: "HII", name: "Huntington Ingalls Industries, Inc. Common Stock" },
    { symbol: "IEX", name: "IDEX Corporation Common Stock" },
    { symbol: "ITW", name: "Illinois Tool Works Inc. Common Stock" },
    { symbol: "IR", name: "Ingersoll Rand Inc. Common Stock" },
    { symbol: "JBHT", name: "J.B. Hunt Transport Services, Inc. - Common Stock" },
    { symbol: "J", name: "Jacobs Solutions Inc. Common Stock" },
    { symbol: "JCI", name: "Johnson Controls International plc Ordinary Share" },
    { symbol: "LHX", name: "L3Harris Technologies, Inc. Common Stock" },
    { symbol: "LDOS", name: "Leidos Holdings, Inc. Common Stock" },
    { symbol: "LII", name: "Lennox International, Inc. Common Stock" },
    { symbol: "LMT", name: "Lockheed Martin Corporation Common Stock" },
    { symbol: "MAS", name: "Masco Corporation Common Stock" },
    { symbol: "NDSN", name: "Nordson Corporation - Common Stock" },
    { symbol: "NSC", name: "Norfolk Southern Corporation Common Stock" },
    { symbol: "NOC", name: "Northrop Grumman Corporation Common Stock" },
    { symbol: "ODFL", name: "Old Dominion Freight Line, Inc. - Common Stock" },
    { symbol: "OTIS", name: "Otis Worldwide Corporation Common Stock" },
    { symbol: "PCAR", name: "PACCAR Inc. - Common Stock" },
    { symbol: "PH", name: "Parker-Hannifin Corporation Common Stock" },
    { symbol: "PAYX", name: "Paychex, Inc. - Common Stock" },
    { symbol: "PNR", name: "Pentair plc. Ordinary Share" },
    { symbol: "PWR", name: "Quanta Services, Inc. Common Stock" },
    { symbol: "RTX", name: "RTX Corporation Common Stock" },
    { symbol: "RSG", name: "Republic Services, Inc. Common Stock" },
    { symbol: "ROK", name: "Rockwell Automation, Inc. Common Stock" },
    { symbol: "ROL", name: "Rollins, Inc. Common Stock" },
    { symbol: "SNA", name: "Snap-On Incorporated Common Stock" },
    { symbol: "LUV", name: "Southwest Airlines Company Common Stock" },
    { symbol: "SWK", name: "Stanley Black & Decker, Inc. Common Stock" },
    { symbol: "TXT", name: "Textron Inc. Common Stock" },
    { symbol: "TT", name: "Trane Technologies plc" },
    { symbol: "TDG", name: "Transdigm Group Incorporated Common Stock" },
    { symbol: "UBER", name: "Uber Technologies, Inc. Common Stock" },
    { symbol: "UNP", name: "Union Pacific Corporation Common Stock" },
    { symbol: "UAL", name: "United Airlines Holdings, Inc. - Common Stock" },
    { symbol: "UPS", name: "United Parcel Service, Inc. Common Stock" },
    { symbol: "URI", name: "United Rentals, Inc. Common Stock" },
    { symbol: "VLTO", name: "Veralto Corp Common Stock" },
    { symbol: "VRSK", name: "Verisk Analytics, Inc. - Common Stock" },
    { symbol: "VRT", name: "Vertiv Holdings, LLC Class A Common Stock" },
    { symbol: "GWW", name: "W.W. Grainger, Inc. Common Stock" },
    { symbol: "WAB", name: "Westinghouse Air Brake Technologies Corporation Common Stock" },
    { symbol: "WM", name: "Waste Management, Inc. Common Stock" },
    { symbol: "XYL", name: "Xylem Inc. Common Stock New" },
  ],
  liquid_large: [
    { symbol: "SMR", name: "NuScale Power Corporation Class A Common Stock" },
    { symbol: "SU", name: "Suncor Energy Inc. Common Stock" },
    { symbol: "RBRK", name: "Rubrik, Inc. Class A Common Stock" },
    { symbol: "UMC", name: "United Microelectronics Corporation (NEW) Common Stock" },
    { symbol: "TD", name: "Toronto Dominion Bank (The) Common Stock" },
    { symbol: "CLF", name: "Cleveland-Cliffs Inc. Common Stock" },
    { symbol: "ACHR", name: "Archer Aviation Inc. Class A Common Stock" },
    { symbol: "CLSK", name: "CleanSpark, Inc. - Common Stock" },
    { symbol: "RY", name: "Royal Bank Of Canada Common Stock" },
    { symbol: "KNX", name: "Knight-Swift Transportation Holdings Inc." },
    { symbol: "SMTC", name: "Semtech Corporation - Common Stock" },
    { symbol: "CAVA", name: "CAVA Group, Inc. Common Stock" },
    { symbol: "MOH", name: "Molina Healthcare Inc Common Stock" },
    { symbol: "MXL", name: "MaxLinear, Inc - Common Stock" },
    { symbol: "SOUN", name: "SoundHound AI, Inc. - Class A Common Stock" },
    { symbol: "EAT", name: "Brinker International, Inc. Common Stock" },
    { symbol: "DINO", name: "HF Sinclair Corporation Common Stock" },
    { symbol: "ZETA", name: "Zeta Global Holdings Corp. Class A Common Stock" },
    { symbol: "AA", name: "Alcoa Corporation Common Stock" },
    { symbol: "BTSG", name: "BrightSpring Health Services, Inc. - Common Stock" },
    { symbol: "CHYM", name: "Chime Financial, Inc. - Class A Common Stock" },
    { symbol: "PINS", name: "Pinterest, Inc. Class A Common Stock" },
    { symbol: "DT", name: "Dynatrace, Inc. Common Stock" },
    { symbol: "LPLA", name: "LPL Financial Holdings Inc. - Common Stock" },
    { symbol: "USFD", name: "US Foods Holding Corp. Common Stock" },
    { symbol: "TEM", name: "Tempus AI, Inc. - Class A Common Stock" },
    { symbol: "RMBS", name: "Rambus, Inc. - Common Stock" },
    { symbol: "TLN", name: "Talen Energy Corporation - Common Stock" },
    { symbol: "CP", name: "Canadian Pacific Kansas City Limited Common Shares" },
    { symbol: "PBR", name: "Petroleo Brasileiro S.A. Petrobras ADS" },
    { symbol: "OWL", name: "Blue Owl Capital Inc. Class A Common Stock" },
    { symbol: "CORZ", name: "Core Scientific, Inc. - Common Stock" },
    { symbol: "RIO", name: "Rio Tinto Plc Common Stock" },
    { symbol: "AFRM", name: "Affirm Holdings, Inc. - Class A Common Stock" },
    { symbol: "NVS", name: "Novartis AG Common Stock" },
    { symbol: "DKS", name: "Dick's Sporting Goods Inc Common Stock" },
    { symbol: "MDLN", name: "Medline Inc. - Class A common stock" },
    { symbol: "LSCC", name: "Lattice Semiconductor Corporation - Common Stock" },
    { symbol: "CRNX", name: "Crinetics Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "WCC", name: "WESCO International, Inc. Common Stock" },
    { symbol: "PBF", name: "PBF Energy Inc. Class A Common Stock" },
    { symbol: "FTI", name: "TechnipFMC plc Ordinary Share" },
    { symbol: "FIVE", name: "Five Below, Inc. - Common Stock" },
    { symbol: "KTOS", name: "Kratos Defense & Security Solutions, Inc. - Common Stock" },
    { symbol: "UTHR", name: "United Therapeutics Corporation - Common Stock" },
    { symbol: "RIG", name: "Transocean Ltd (Switzerland) Common Stock" },
    { symbol: "TRI", name: "Thomson Reuters Corp - Common Shares" },
    { symbol: "AU", name: "AngloGold Ashanti PLC Ordinary Shares" },
    { symbol: "BTI", name: "British American Tobacco Industries, p.l.c. Common Stock ADR" },
    { symbol: "AVAV", name: "AeroVironment, Inc. - Common Stock" },
    { symbol: "WPM", name: "Wheaton Precious Metals Corp Common Shares (Canada)" },
    { symbol: "ETSY", name: "Etsy, Inc. Common Stock" },
    { symbol: "KRMN", name: "Karman Holdings Inc. Common Stock" },
    { symbol: "ELF", name: "e.l.f. Beauty, Inc. Common Stock" },
    { symbol: "PCOR", name: "Procore Technologies, Inc. Common Stock" },
    { symbol: "GFS", name: "GlobalFoundries Inc. - Ordinary Share" },
    { symbol: "BURL", name: "Burlington Stores, Inc. Common Stock" },
    { symbol: "OPEN", name: "Opendoor Technologies Inc - Common Stock" },
    { symbol: "JHX", name: "James Hardie Industries plc. Ordinary Shares" },
    { symbol: "AEIS", name: "Advanced Energy Industries, Inc. - Common Stock" },
    { symbol: "NVMI", name: "Nova Ltd. - Ordinary Shares" },
    { symbol: "WWD", name: "Woodward, Inc. - Common Stock" },
    { symbol: "GWRE", name: "Guidewire Software, Inc. Common Stock" },
    { symbol: "ENB", name: "Enbridge Inc Common Stock" },
    { symbol: "SEI", name: "Solaris Energy Infrastructure, Inc. Class A Common Stock" },
    { symbol: "HALO", name: "Halozyme Therapeutics, Inc. - Common Stock" },
    { symbol: "VIAV", name: "Viavi Solutions Inc. - Common Stock" },
    { symbol: "FROG", name: "JFrog Ltd. - Ordinary shares" },
    { symbol: "AGNC", name: "AGNC Investment Corp. - Common Stock" },
    { symbol: "IOT", name: "Samsara Inc. Class A Common Stock" },
    { symbol: "CVE", name: "Cenovus Energy Inc Common Stock" },
    { symbol: "PAYC", name: "Paycom Software, Inc. Common Stock" },
    { symbol: "CCEP", name: "Coca-Cola Europacific Partners plc - Ordinary Shares" },
    { symbol: "CAG", name: "ConAgra Brands, Inc. Common Stock" },
    { symbol: "WCN", name: "Waste Connections, Inc. Common Shares" },
    { symbol: "ONON", name: "On Holding AG Class A Ordinary Shares" },
    { symbol: "OVV", name: "Ovintiv Inc. (DE)" },
    { symbol: "LYFT", name: "Lyft, Inc. - Class A Common Stock" },
    { symbol: "TECK", name: "Teck Resources Ltd Ordinary Shares" },
    { symbol: "USAR", name: "USA Rare Earth, Inc. - Common Stock" },
    { symbol: "SCCO", name: "Southern Copper Corporation Common Stock" },
    { symbol: "ITT", name: "ITT Inc. Common Stock" },
    { symbol: "RGEN", name: "Repligen Corporation - Common Stock" },
    { symbol: "CAKE", name: "The Cheesecake Factory Incorporated - Common Stock" },
    { symbol: "TE", name: "T1 Energy Inc. Common Stock" },
    { symbol: "VG", name: "Venture Global, Inc. Class A common stock" },
    { symbol: "RRX", name: "Regal Rexnord Corporation Common Stock" },
    { symbol: "KGC", name: "Kinross Gold Corporation Common Stock" },
    { symbol: "SNAP", name: "Snap Inc. Class A Common Stock" },
    { symbol: "SUI", name: "Sun Communities, Inc. Common Stock" },
    { symbol: "NBIX", name: "Neurocrine Biosciences, Inc. - Common Stock" },
    { symbol: "XPO", name: "XPO, Inc. Common Stock" },
    { symbol: "CART", name: "Maplebear Inc. - Common Stock" },
    { symbol: "JBLU", name: "JetBlue Airways Corporation - Common Stock" },
    { symbol: "FWONK", name: "Liberty Media Corporation - Series C Liberty Formula One Com" },
    { symbol: "CNI", name: "Canadian National Railway Company Common Stock" },
    { symbol: "SOLS", name: "Solstice Advanced Materials Inc. - Common Stock" },
    { symbol: "MEDP", name: "Medpace Holdings, Inc. - Common Stock" },
    { symbol: "HDB", name: "HDFC Bank Limited Common Stock" },
    { symbol: "CACI", name: "CACI International, Inc. Class A Common Stock" },
    { symbol: "BNS", name: "Bank Nova Scotia Halifax Pfd 3 Ordinary Shares" },
    { symbol: "RACE", name: "Ferrari N.V. Common Shares" },
    { symbol: "SAIA", name: "Saia, Inc. - Common Stock" },
    { symbol: "VIK", name: "Viking Holdings Ltd Ordinary Shares" },
    { symbol: "VICR", name: "Vicor Corporation - Common Stock" },
    { symbol: "NVTS", name: "Navitas Semiconductor Corporation - Common Stock" },
    { symbol: "DOCU", name: "DocuSign, Inc. - Common Stock" },
    { symbol: "AG", name: "First Majestic Silver Corp. Ordinary Shares (Canada)" },
    { symbol: "BN", name: "Brookfield Corporation Class A Limited Voting Shares" },
    { symbol: "FSLY", name: "Fastly, Inc. - Class A Common Stock" },
    { symbol: "KRYS", name: "Krystal Biotech, Inc. - Common Stock" },
    { symbol: "TWST", name: "Twist Bioscience Corporation - Common Stock" },
    { symbol: "JAZZ", name: "Jazz Pharmaceuticals plc - Ordinary Shares" },
    { symbol: "CG", name: "The Carlyle Group Inc. - Common Stock" },
    { symbol: "MANH", name: "Manhattan Associates, Inc. - Common Stock" },
    { symbol: "DOCS", name: "Doximity, Inc. Class A Common Stock" },
    { symbol: "PAAS", name: "Pan American Silver Corp. Common Stock" },
    { symbol: "MDGL", name: "Madrigal Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "FCEL", name: "FuelCell Energy, Inc. - Common Stock" },
    { symbol: "PFGC", name: "Performance Food Group Company Common Stock" },
    { symbol: "BROS", name: "Dutch Bros Inc. Class A Common Stock" },
    { symbol: "TXG", name: "10x Genomics, Inc. - Common Stock" },
    { symbol: "PENG", name: "Penguin Solutions, Inc. - Common Stock" },
    { symbol: "ESI", name: "Element Solutions Inc. Common Stock" },
    { symbol: "ENPH", name: "Enphase Energy, Inc. - Common Stock" },
    { symbol: "PR", name: "Permian Resources Corporation Class A Common Stock" },
    { symbol: "GTLB", name: "GitLab Inc. - Class A Common Stock" },
    { symbol: "DUOL", name: "Duolingo, Inc. - Class A Common Stock" },
    { symbol: "ITGR", name: "Integer Holdings Corporation Common Stock" },
    { symbol: "TXRH", name: "Texas Roadhouse, Inc. - Common Stock" },
    { symbol: "ROIV", name: "Roivant Sciences Ltd. - Common Shares" },
    { symbol: "QSR", name: "Restaurant Brands International Inc. Common Shares" },
    { symbol: "FNV", name: "Franco-Nevada Corporation" },
    { symbol: "FORM", name: "FormFactor, Inc. - Common Stock" },
    { symbol: "CHKP", name: "Check Point Software Technologies Ltd. - Ordinary Shares" },
    { symbol: "BAH", name: "Booz Allen Hamilton Holding Corporation Common Stock" },
    { symbol: "TW", name: "Tradeweb Markets Inc. - Class A Common Stock" },
    { symbol: "MGY", name: "Magnolia Oil & Gas Corporation Class A Common Stock" },
    { symbol: "TRU", name: "TransUnion Common Stock" },
    { symbol: "VSAT", name: "ViaSat, Inc. - Common Stock" },
    { symbol: "LUNR", name: "Intuitive Machines, Inc. - Class A Common Stock" },
    { symbol: "VSH", name: "Vishay Intertechnology, Inc. Common Stock" },
    { symbol: "IBN", name: "ICICI Bank Limited Common Stock" },
    { symbol: "EQX", name: "Equinox Gold Corp. Common Shares" },
    { symbol: "CSL", name: "Carlisle Companies Incorporated Common Stock" },
    { symbol: "EVR", name: "Evercore Inc. Class A Common Stock" },
    { symbol: "ELAN", name: "Elanco Animal Health Incorporated Common Stock" },
    { symbol: "NLY", name: "Annaly Capital Management Inc. Common Stock" },
    { symbol: "EPAM", name: "EPAM Systems, Inc. Common Stock" },
    { symbol: "MNDY", name: "monday.com Ltd. - Ordinary Shares" },
    { symbol: "POOL", name: "Pool Corporation - Common Stock" },
    { symbol: "SAN", name: "Banco Santander, S.A. Sponsored ADR (Spain)" },
    { symbol: "AGX", name: "Argan, Inc. Common Stock" },
    { symbol: "AVTR", name: "Avantor, Inc. Common Stock" },
    { symbol: "PL", name: "Planet Labs PBC Class A Common Stock" },
    { symbol: "SGI", name: "Somnigroup International Inc. Common Stock" },
    { symbol: "SFM", name: "Sprouts Farmers Market, Inc. - Common Stock" },
    { symbol: "SANM", name: "Sanmina Corporation - Common Stock" },
    { symbol: "GRAB", name: "Grab Holdings Limited - Class A Ordinary Shares" },
    { symbol: "RNG", name: "RingCentral, Inc. Class A Common Stock" },
    { symbol: "FHN", name: "First Horizon Corporation Common Stock" },
    { symbol: "IONS", name: "Ionis Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "RPRX", name: "Royalty Pharma plc - Class A Ordinary Shares" },
    { symbol: "NTNX", name: "Nutanix, Inc. - Class A Common Stock" },
    { symbol: "DY", name: "Dycom Industries, Inc. Common Stock" },
    { symbol: "WSO", name: "Watsco, Inc. Common Stock" },
    { symbol: "ARWR", name: "Arrowhead Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "LNTH", name: "Lantheus Holdings, Inc. - Common Stock" },
    { symbol: "SNX", name: "TD SYNNEX Corporation Common Stock" },
    { symbol: "ARMK", name: "Aramark Common Stock" },
    { symbol: "AUR", name: "Aurora Innovation, Inc. - Class A Common Stock" },
    { symbol: "ALC", name: "Alcon Inc. Ordinary Shares" },
    { symbol: "AR", name: "Antero Resources Corporation Common Stock" },
    { symbol: "BBIO", name: "BridgeBio Pharma, Inc. - Common Stock" },
    { symbol: "CHWY", name: "Chewy, Inc. Class A Common Stock" },
    { symbol: "WEX", name: "WEX Inc. common stock" },
    { symbol: "MUSA", name: "Murphy USA Inc. Common Stock" },
    { symbol: "OSCR", name: "Oscar Health, Inc. Class A Common Stock" },
    { symbol: "FCNCA", name: "First Citizens BancShares, Inc. - Class A Common Stock" },
    { symbol: "GKOS", name: "Glaukos Corporation Common Stock" },
    { symbol: "RGLD", name: "Royal Gold, Inc. - Common Stock" },
    { symbol: "LFUS", name: "Littelfuse, Inc. - Common Stock" },
    { symbol: "S", name: "SentinelOne, Inc. Class A Common Stock" },
    { symbol: "NTR", name: "Nutrien Ltd. Common Shares" },
    { symbol: "SSNC", name: "SS&C Technologies Holdings, Inc. - Common Stock" },
    { symbol: "SHAZ", name: "SharonAI Holdings, Inc. - Class A Common Stock" },
    { symbol: "DAVE", name: "Dave Inc. - Class A Common Stock" },
    { symbol: "ESTC", name: "Elastic N.V. Ordinary Shares" },
    { symbol: "POWL", name: "Powell Industries, Inc. - Common Stock" },
    { symbol: "ROAD", name: "Construction Partners, Inc. - Common Stock" },
    { symbol: "H", name: "Hyatt Hotels Corporation Class A Common Stock" },
    { symbol: "QLYS", name: "Qualys, Inc. - Common Stock" },
    { symbol: "DBX", name: "Dropbox, Inc. - Class A Common Stock" },
    { symbol: "COMP", name: "Compass, Inc. Class A Common Stock" },
    { symbol: "AGI", name: "Alamos Gold Inc. Class A Common Shares" },
    { symbol: "TRP", name: "TC Energy Corporation Common Stock" },
    { symbol: "AXSM", name: "Axsome Therapeutics, Inc. - Common Stock" },
    { symbol: "HEI", name: "Heico Corporation Common Stock" },
    { symbol: "CRBG", name: "Corebridge Financial Inc. Common Stock" },
    { symbol: "BWA", name: "BorgWarner Inc. Common Stock" },
    { symbol: "IESC", name: "IES Holdings, Inc. - Common Stock" },
    { symbol: "EQH", name: "Equitable Holdings, Inc. Common Stock" },
    { symbol: "CLH", name: "Clean Harbors, Inc. Common Stock" },
    { symbol: "VXX", name: "iPath Series B S&P 500 VIX Short-Term Futures ETN" },
    { symbol: "BWXT", name: "BWX Technologies, Inc. Common Stock" },
    { symbol: "AMBA", name: "Ambarella, Inc. - Ordinary Shares" },
    { symbol: "AMRZ", name: "Amrize Ltd Ordinary Shares" },
    { symbol: "VSXY", name: "Victorias Secret & Co. Common Stock" },
    { symbol: "LCID", name: "Lucid Group, Inc. - Common Stock" },
    { symbol: "HNGE", name: "Hinge Health, Inc. Class A Common Stock" },
    { symbol: "FLS", name: "Flowserve Corporation Common Stock" },
    { symbol: "QS", name: "QuantumScape Corporation - Common Stock" },
    { symbol: "SUNB", name: "Sunbelt Rentals Holdings, Inc. Common Stock" },
    { symbol: "AER", name: "AerCap Holdings N.V. Ordinary Shares" },
    { symbol: "FND", name: "Floor & Decor Holdings, Inc. Common Stock" },
    { symbol: "TPG", name: "TPG Inc. - Class A Common Stock" },
    { symbol: "CNH", name: "CNH Industrial N.V. Common Shares" },
    { symbol: "SHAK", name: "Shake Shack, Inc. Class A Common Stock" },
    { symbol: "OUST", name: "Ouster, Inc. - Common Stock" },
    { symbol: "EQNR", name: "Equinor ASA" },
    { symbol: "WING", name: "Wingstop Inc. - Common Stock" },
    { symbol: "FRSH", name: "Freshworks Inc. - Class A Common Stock" },
    { symbol: "PRAX", name: "Praxis Precision Medicines, Inc. - Common Stock" },
    { symbol: "KMX", name: "CarMax Inc" },
    { symbol: "BMRN", name: "BioMarin Pharmaceutical Inc. - Common Stock" },
    { symbol: "TENB", name: "Tenable Holdings, Inc. - Common Stock" },
    { symbol: "AS", name: "Amer Sports, Inc. Ordinary Shares" },
    { symbol: "ALLY", name: "Ally Financial Inc. Common Stock" },
    { symbol: "BUD", name: "Anheuser-Busch Inbev SA Sponsored ADR (Belgium)" },
    { symbol: "HSBC", name: "HSBC Holdings, plc. Common Stock" },
    { symbol: "BCS", name: "Barclays PLC Common Stock" },
    { symbol: "TTE", name: "TotalEnergies SE Ordinary Shares" },
    { symbol: "CORT", name: "Corcept Therapeutics Incorporated - Common Stock" },
    { symbol: "RS", name: "Reliance, Inc. Common Stock" },
    { symbol: "BB", name: "BlackBerry Limited Common Stock" },
    { symbol: "OSK", name: "Oshkosh Corporation (Holding Company)Common Stock" },
    { symbol: "BJ", name: "BJ's Wholesale Club Holdings, Inc. Common Stock" },
    { symbol: "OC", name: "Owens Corning Inc Common Stock New" },
    { symbol: "DAR", name: "Darling Ingredients Inc. Common Stock" },
    { symbol: "BRKR", name: "Bruker Corporation - Common Stock" },
    { symbol: "CGNX", name: "Cognex Corporation - Common Stock" },
    { symbol: "NYT", name: "New York Times Company (The) Common Stock" },
    { symbol: "GMED", name: "Globus Medical, Inc. Class A Common Stock" },
    { symbol: "ICLR", name: "ICON plc - Ordinary Shares" },
    { symbol: "FLR", name: "Fluor Corporation Common Stock" },
    { symbol: "Z", name: "Zillow Group, Inc. - Class C Capital Stock" },
    { symbol: "BAM", name: "Brookfield Asset Management Inc Class A Limited Voting Share" },
    { symbol: "LAD", name: "Lithia Motors, Inc. Common Stock" },
    { symbol: "TIGO", name: "Millicom International Cellular S.A. - Common Stock" },
    { symbol: "GLXY", name: "Galaxy Digital Inc. - Class A common stock" },
    { symbol: "MHK", name: "Mohawk Industries, Inc. Common Stock" },
    { symbol: "UNM", name: "Unum Group Common Stock" },
    { symbol: "CELC", name: "Celcuity Inc. - Common Stock" },
    { symbol: "JLL", name: "Jones Lang LaSalle Incorporated Common Stock" },
    { symbol: "HBM", name: "Hudbay Minerals Inc. Ordinary Shares (Canada)" },
    { symbol: "PLUG", name: "Plug Power, Inc. - Common Stock" },
    { symbol: "WOLF", name: "Wolfspeed, Inc. Common Stock New" },
    { symbol: "SPHR", name: "Sphere Entertainment Co. Class A Common Stock" },
    { symbol: "PNFP", name: "Pinnacle Financial Partners, Inc. Common stock" },
    { symbol: "CROX", name: "Crocs, Inc. - Common Stock" },
    { symbol: "WIX", name: "Wix.com Ltd. - Ordinary Shares" },
    { symbol: "RBC", name: "RBC Bearings Incorporated Common Stock" },
    { symbol: "ALK", name: "Alaska Air Group, Inc. Common Stock" },
    { symbol: "CYTK", name: "Cytokinetics, Incorporated - Common Stock" },
    { symbol: "LTH", name: "Life Time Group Holdings, Inc. Common Stock" },
    { symbol: "FRMI", name: "Fermi Inc. - Common Stock" },
    { symbol: "RH", name: "RH Common Stock" },
    { symbol: "UPST", name: "Upstart Holdings, Inc. - Common stock" },
    { symbol: "HLI", name: "Houlihan Lokey, Inc. Class A Common Stock" },
    { symbol: "BMO", name: "Bank Of Montreal Common Stock" },
    { symbol: "EXEL", name: "Exelixis, Inc. - Common Stock" },
    { symbol: "ATAI", name: "AtaiBeckley Inc. - Common Stock" },
    { symbol: "INIO", name: "INNIO N.V. - Ordinary Shares" },
    { symbol: "RBA", name: "RB Global, Inc. Common Stock" },
    { symbol: "TTAN", name: "ServiceTitan, Inc. - Class A Common Stock" },
    { symbol: "ASND", name: "Ascendis Pharma A/S - Ordinary Share" },
    { symbol: "AHR", name: "American Healthcare REIT, Inc. Common Stock" },
    { symbol: "CCK", name: "Crown Holdings, Inc." },
    { symbol: "HRB", name: "H&R Block, Inc. Common Stock" },
    { symbol: "LEU", name: "Centrus Energy Corp. Class A Common Stock" },
    { symbol: "UCTT", name: "Ultra Clean Holdings, Inc. - Common Stock" },
    { symbol: "IOVA", name: "Iovance Biotherapeutics, Inc. - Common Stock" },
    { symbol: "RAL", name: "Ralliant Corporation Common Stock" },
    { symbol: "XE", name: "X-Energy, Inc. - Class A Common Stock" },
    { symbol: "NEU", name: "NewMarket Corp Common Stock" },
    { symbol: "DEO", name: "Diageo plc Common Stock" },
    { symbol: "LOGI", name: "Logitech International S.A. - Registered Shares" },
    { symbol: "CPB", name: "The Campbell's Company - Common Stock" },
    { symbol: "TOL", name: "Toll Brothers, Inc. Common Stock" },
    { symbol: "BILL", name: "BILL Holdings, Inc. Common Stock" },
    { symbol: "ONB", name: "Old National Bancorp - Common Stock" },
    { symbol: "MOG-A", name: "Moog Inc. Class A Common Stock" },
    { symbol: "PCTY", name: "Paylocity Holding Corporation - Common Stock" },
    { symbol: "ACI", name: "Albertsons Companies, Inc. Class A Common Stock" },
    { symbol: "TKR", name: "Timken Company (The) Common Stock" },
    { symbol: "VFC", name: "V.F. Corporation Common Stock" },
    { symbol: "PEN", name: "Penumbra, Inc. Common Stock" },
    { symbol: "EPD", name: "Enterprise Products Partners L.P. Common Stock" },
    { symbol: "LBRT", name: "Liberty Energy Inc. Class A common stock" },
    { symbol: "GVA", name: "Granite Construction Incorporated Common Stock" },
    { symbol: "TREX", name: "Trex Company, Inc. Common Stock" },
    { symbol: "QRVO", name: "Qorvo, Inc. - Common Stock" },
    { symbol: "GAP", name: "Gap, Inc. (The) Common Stock" },
    { symbol: "ACM", name: "AECOM Common Stock" },
    { symbol: "CZR", name: "Caesars Entertainment, Inc. - Common Stock" },
    { symbol: "RRC", name: "Range Resources Corporation Common Stock" },
    { symbol: "APG", name: "APi Group Corporation Common Stock" },
    { symbol: "BOOT", name: "Boot Barn Holdings, Inc. Common Stock" },
    { symbol: "GGG", name: "Graco Inc. Common Stock" },
    { symbol: "INFQ", name: "Infleqtion, Inc. Common Stock" },
    { symbol: "BTG", name: "B2Gold Corp Common shares (Canada)" },
    { symbol: "KVYO", name: "Klaviyo, Inc. Series A Common Stock" },
    { symbol: "ARW", name: "Arrow Electronics, Inc. Common Stock" },
    { symbol: "RPM", name: "RPM International Inc. Common Stock" },
    { symbol: "LECO", name: "Lincoln Electric Holdings, Inc. - Common Shares" },
    { symbol: "CLBK", name: "Columbia Financial, Inc. - Common Stock" },
    { symbol: "KNSL", name: "Kinsale Capital Group, Inc. Common Stock" },
    { symbol: "FIVN", name: "Five9, Inc. - Common Stock" },
    { symbol: "MKL", name: "Markel Group Inc. Common Stock" },
    { symbol: "PEGA", name: "Pegasystems Inc. - Common Stock" },
    { symbol: "POET", name: "POET Technologies Inc. - Common Shares" },
    { symbol: "EHC", name: "Encompass Health Corporation Common Stock" },
    { symbol: "ZION", name: "Zions Bancorporation N.A. - Common Stock" },
    { symbol: "DTM", name: "DT Midstream, Inc. Common Stock" },
    { symbol: "ATKR", name: "Atkore Inc. Common Stock" },
    { symbol: "WFRD", name: "Weatherford International plc - Ordinary shares" },
    { symbol: "WTFC", name: "Wintrust Financial Corporation - Common Stock" },
    { symbol: "AMC", name: "AMC Entertainment Holdings, Inc. Class A Common Stock" },
    { symbol: "SPXC", name: "SPX Technologies, Inc. Common Stock" },
    { symbol: "SM", name: "SM Energy Company Common Stock" },
    { symbol: "PAG", name: "Penske Automotive Group, Inc. Common Stock" },
    { symbol: "EOSE", name: "Eos Energy Enterprises, Inc. - Common Stock" },
    { symbol: "SIRI", name: "SiriusXM Holdings Inc. - Common Stock" },
    { symbol: "FBIN", name: "Fortune Brands Innovations, Inc. Common Stock" },
    { symbol: "OLLI", name: "Ollie's Bargain Outlet Holdings, Inc. - Common Stock" },
    { symbol: "MTCH", name: "Match Group, Inc. - Common Stock" },
    { symbol: "STLA", name: "Stellantis N.V. Common Shares" },
    { symbol: "CM", name: "Canadian Imperial Bank of Commerce Common Stock" },
    { symbol: "REPL", name: "Replimune Group, Inc. - Common Stock" },
    { symbol: "AVT", name: "Avnet, Inc. - Common Stock" },
    { symbol: "GME", name: "GameStop Corporation Common Stock" },
    { symbol: "LQDA", name: "Liquidia Corporation - Common Stock" },
    { symbol: "PRIM", name: "Primoris Services Corporation Common Stock" },
    { symbol: "SEDG", name: "SolarEdge Technologies, Inc. - Common Stock" },
    { symbol: "HTZ", name: "Hertz Global Holdings, Inc - Common Stock" },
    { symbol: "QGEN", name: "Qiagen N.V. Common Shares" },
    { symbol: "TGTX", name: "TG Therapeutics, Inc. - Common Stock" },
    { symbol: "HXL", name: "Hexcel Corporation Common Stock" },
    { symbol: "M", name: "Macy's Inc Common Stock" },
    { symbol: "AAON", name: "AAON, Inc. - Common Stock" },
    { symbol: "ITRI", name: "Itron, Inc. - Common Stock" },
    { symbol: "BIO", name: "Bio-Rad Laboratories, Inc. Class A Common Stock" },
    { symbol: "REXR", name: "Rexford Industrial Realty, Inc. Common Stock" },
    { symbol: "FIGR", name: "Figure Technology Solutions, Inc. - Class A Common Stock" },
    { symbol: "FNB", name: "F.N.B. Corporation Common Stock" },
    { symbol: "PLNT", name: "Planet Fitness, Inc. Common Stock" },
    { symbol: "ACA", name: "Arcosa, Inc. Common Stock" },
    { symbol: "ANF", name: "Abercrombie & Fitch Company Common Stock" },
    { symbol: "CR", name: "Crane Company Common Stock" },
    { symbol: "MTDR", name: "Matador Resources Company Common Stock" },
    { symbol: "MTRN", name: "Materion Corporation" },
    { symbol: "MT", name: "Arcelor Mittal NY Registry Shares NEW" },
    { symbol: "SEZL", name: "Sezzle Inc. - Common Stock" },
    { symbol: "BSP", name: "Bending Spoons S.p.A. - Ordinary Shares" },
    { symbol: "VLY", name: "Valley National Bancorp - Common Stock" },
    { symbol: "ELS", name: "Equity Lifestyle Properties, Inc. Common Stock" },
    { symbol: "JEF", name: "Jefferies Financial Group Inc. Common Stock" },
    { symbol: "EXP", name: "Eagle Materials Inc Common Stock" },
    { symbol: "EGP", name: "EastGroup Properties, Inc. Common Stock" },
    { symbol: "KGS", name: "Kodiak Gas Services, Inc. Common Stock" },
    { symbol: "CBZ", name: "CBIZ, Inc. Common Stock" },
    { symbol: "FLNC", name: "Fluence Energy, Inc. - Class A Common Stock" },
    { symbol: "VMI", name: "Valmont Industries, Inc. Common Stock" },
    { symbol: "LAMR", name: "Lamar Advertising Company - Class A Common Stock" },
    { symbol: "CNK", name: "Cinemark Holdings Inc Cinemark Holdings, Inc. Common Stock" },
    { symbol: "CFR", name: "Cullen/Frost Bankers, Inc. Common Stock" },
    { symbol: "CVLT", name: "Commvault Systems, Inc. - Common Stock" },
    { symbol: "KEEL", name: "Keel Infrastructure Corp. - Common Stock" },
    { symbol: "CHRD", name: "Chord Energy Corporation - Common Stock" },
    { symbol: "BSY", name: "Bentley Systems, Incorporated - Class B Common Stock" },
    { symbol: "LW", name: "Lamb Weston Holdings, Inc. Common Stock" },
    { symbol: "WH", name: "Wyndham Hotels & Resorts, Inc. Common Stock" },
    { symbol: "CAI", name: "Caris Life Sciences, Inc. - Common Stock" },
    { symbol: "UUUU", name: "Energy Fuels Inc Ordinary Shares (Canada)" },
    { symbol: "IAG", name: "Iamgold Corporation Ordinary Shares" },
    { symbol: "RHI", name: "Robert Half Inc. Common Stock" },
    { symbol: "LSTR", name: "Landstar System, Inc. - Common Stock" },
    { symbol: "TTEK", name: "Tetra Tech, Inc. - Common Stock" },
    { symbol: "RHP", name: "Ryman Hospitality Properties, Inc. (REIT)" },
    { symbol: "WMS", name: "Advanced Drainage Systems, Inc. Common Stock" },
    { symbol: "BAP", name: "Credicorp Ltd. Common Stock" },
    { symbol: "BTDR", name: "Bitdeer Technologies Group - Ordinary Shares" },
    { symbol: "ALSN", name: "Allison Transmission Holdings, Inc. Common Stock" },
    { symbol: "AWI", name: "Armstrong World Industries Inc Common Stock" },
    { symbol: "QNT", name: "Quantinuum Inc. - Class A Common Stock" },
    { symbol: "ARX", name: "Accelerant Holdings Class A Common Shares" },
    { symbol: "RNR", name: "RenaissanceRe Holdings Ltd. Common Stock" },
    { symbol: "SSRM", name: "SSR Mining Inc. - Common Stock" },
    { symbol: "SSB", name: "SouthState Bank Corporation Common Stock" },
    { symbol: "ORA", name: "Ormat Technologies, Inc. Common Stock" },
    { symbol: "BOX", name: "Box, Inc. Class A Common Stock" },
    { symbol: "FER", name: "Ferrovial N.V. - Ordinary Shares" },
    { symbol: "UBS", name: "UBS Group AG Registered Ordinary Shares" },
  ],
  liquid_mega: [
    { symbol: "SPCX", name: "Space Exploration Technologies Corp. - Class A Common Stock" },
    { symbol: "NBIS", name: "Nebius Group N.V. - Class A Ordinary Shares" },
    { symbol: "TSM", name: "Taiwan Semiconductor Manufacturing Company Ltd." },
    { symbol: "BE", name: "Bloom Energy Corporation Class A Common Stock" },
    { symbol: "ASML", name: "ASML Holding N.V. - New York Registry Shares" },
    { symbol: "CRWV", name: "CoreWeave, Inc. - Class A Common Stock" },
    { symbol: "IREN", name: "IREN Limited - Ordinary Shares" },
    { symbol: "SHOP", name: "Shopify Inc. - Class A Subordinate Voting Shares" },
    { symbol: "SNOW", name: "Snowflake Inc. Common Stock" },
    { symbol: "RKLB", name: "Rocket Lab Corporation - Common Stock" },
    { symbol: "ALAB", name: "Astera Labs, Inc. - Common Stock" },
    { symbol: "MSTR", name: "Strategy Inc - Class A Common Stock" },
    { symbol: "AAOI", name: "Applied Optoelectronics, Inc. - Common Stock" },
    { symbol: "CRDO", name: "Credo Technology Group Holding Ltd - Ordinary Shares" },
    { symbol: "CBRS", name: "Cerebras Systems Inc. - Class A Common Stock" },
    { symbol: "SOFI", name: "SoFi Technologies, Inc. - Common Stock" },
    { symbol: "PATH", name: "UiPath, Inc. Class A Common Stock" },
    { symbol: "AAL", name: "American Airlines Group, Inc. - Common Stock" },
    { symbol: "NET", name: "Cloudflare, Inc. Class A Common Stock" },
    { symbol: "NU", name: "Nu Holdings Ltd. Class A Ordinary Shares" },
    { symbol: "ASTS", name: "AST SpaceMobile, Inc. - Class A Common Stock" },
    { symbol: "CLS", name: "Celestica, Inc. Common Stock" },
    { symbol: "SPOT", name: "Spotify Technology S.A. Ordinary Shares" },
    { symbol: "IONQ", name: "IonQ, Inc. Common Stock" },
    { symbol: "ONDS", name: "Ondas Inc - Common Stock" },
    { symbol: "AXTI", name: "AXT Inc - Common Stock" },
    { symbol: "RDDT", name: "Reddit, Inc. Class A Common Stock" },
    { symbol: "CRCL", name: "Circle Internet Group, Inc. Class A Common Stock" },
    { symbol: "TEAM", name: "Atlassian Corporation - Class A Common Stock" },
    { symbol: "MELI", name: "MercadoLibre, Inc. - Common Stock" },
    { symbol: "HL", name: "Hecla Mining Company Common Stock" },
    { symbol: "SAP", name: "SAP SE ADS" },
    { symbol: "MDB", name: "MongoDB, Inc. - Class A Common Stock" },
    { symbol: "CDE", name: "Coeur Mining, Inc. Common Stock" },
    { symbol: "FIG", name: "Figma, Inc. Class A Common Stock" },
    { symbol: "APLD", name: "Applied Digital Corporation - Common Stock" },
    { symbol: "STM", name: "STMicroelectronics N.V. Common Stock" },
    { symbol: "BMNR", name: "BitMine Immersion Technologies, Inc. Common Stock" },
    { symbol: "AZN", name: "AstraZeneca PLC Ordinary Shares" },
    { symbol: "TWLO", name: "Twilio Inc. Class A Common Stock" },
    { symbol: "NVO", name: "Novo Nordisk A/S Common Stock" },
    { symbol: "TSEM", name: "Tower Semiconductor Ltd. - Ordinary Shares" },
    { symbol: "WULF", name: "TeraWulf Inc. - Common Stock" },
    { symbol: "CIFR", name: "Cipher Digital Inc. - Common Stock" },
    { symbol: "RBLX", name: "Roblox Corporation Class A Common Stock" },
    { symbol: "HUBS", name: "HubSpot, Inc. Common Stock" },
    { symbol: "AEM", name: "Agnico Eagle Mines Limited Common Stock" },
    { symbol: "U", name: "Unity Software Inc. Common Stock" },
    { symbol: "ALNY", name: "Alnylam Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "MTSI", name: "MACOM Technology Solutions Holdings, Inc. - Common Stock" },
    { symbol: "STRL", name: "Sterling Infrastructure, Inc. - Common Stock" },
    { symbol: "DOCN", name: "DigitalOcean Holdings, Inc. Common Stock" },
    { symbol: "RKT", name: "Rocket Companies, Inc. Class A Common Stock" },
    { symbol: "ENTG", name: "Entegris, Inc. - Common Stock" },
    { symbol: "MKSI", name: "MKS Inc. - Common Stock" },
    { symbol: "LNG", name: "Cheniere Energy, Inc. Common Stock" },
    { symbol: "MTZ", name: "MasTec, Inc. Common Stock" },
    { symbol: "OKLO", name: "Oklo Inc. Class A common stock" },
    { symbol: "FN", name: "Fabrinet Ordinary Shares" },
    { symbol: "HIMS", name: "Hims & Hers Health, Inc. Class A Common Stock" },
    { symbol: "MARA", name: "MARA Holdings, Inc. - Common Stock" },
    { symbol: "RIOT", name: "Riot Platforms, Inc. - Common Stock" },
    { symbol: "ZS", name: "Zscaler, Inc. - Common Stock" },
    { symbol: "AEHR", name: "Aehr Test Systems - Common Stock" },
    { symbol: "TTMI", name: "TTM Technologies, Inc. - Common Stock" },
    { symbol: "OKTA", name: "Okta, Inc. - Class A Common Stock" },
    { symbol: "B", name: "Barrick Mining Corporation Common Shares" },
    { symbol: "ROKU", name: "Roku, Inc. - Class A Common Stock" },
    { symbol: "ONTO", name: "Onto Innovation Inc. Common Stock" },
    { symbol: "RGTI", name: "Rigetti Computing, Inc. - Common stock" },
    { symbol: "W", name: "Wayfair Inc. Class A Common Stock" },
    { symbol: "HUT", name: "Hut 8 Corp. - Common Stock" },
    { symbol: "INSM", name: "Insmed Incorporated - Common Stock" },
    { symbol: "NTRA", name: "Natera, Inc. - Common Stock" },
    { symbol: "QBTS", name: "D-Wave Quantum Inc. - Common Stock" },
    { symbol: "MP", name: "MP Materials Corp. Common Stock" },
    { symbol: "RIVN", name: "Rivian Automotive, Inc. - Class A Common Stock" },
    { symbol: "FTAI", name: "FTAI Aviation Ltd. - Common Stock" },
    { symbol: "JOBY", name: "Joby Aviation, Inc. Common Stock" },
    { symbol: "ILMN", name: "Illumina, Inc. - Common Stock" },
    { symbol: "CRS", name: "Carpenter Technology Corporation Common Stock" },
    { symbol: "WBS", name: "Webster Financial Corporation Common Stock" },
    { symbol: "RVMD", name: "Revolution Medicines, Inc. - Common Stock" },
    { symbol: "ATI", name: "ATI Inc. Common Stock" },
    { symbol: "THC", name: "Tenet Healthcare Corporation Common Stock" },
    { symbol: "NVT", name: "nVent Electric plc Ordinary Shares" },
    { symbol: "TOST", name: "Toast, Inc. Class A Common Stock" },
    { symbol: "CCJ", name: "Cameco Corporation Common Stock" },
    { symbol: "DKNG", name: "DraftKings Inc. - Class A Common Stock" },
    { symbol: "SITM", name: "SiTime Corporation - Common Stock" },
    { symbol: "ZM", name: "Zoom Communications, Inc. - Class A Common Stock" },
    { symbol: "FLUT", name: "Flutter Entertainment plc Ordinary Shares" },
    { symbol: "SXTC", name: "China SXT Pharmaceuticals, Inc. - Class A Ordinary Shares" },
    { symbol: "AMKR", name: "Amkor Technology, Inc. - Common Stock" },
    { symbol: "SN", name: "SharkNinja, Inc. Ordinary Shares" },
    { symbol: "CELH", name: "Celsius Holdings, Inc. - Common Stock" },
    { symbol: "CPNG", name: "Coupang, Inc. Class A Common Stock" },
    { symbol: "FPS", name: "Forgent Power Solutions, Inc. Class A Common Stock" },
    { symbol: "NXT", name: "Nextpower Inc. - Class A Common Stock" },
    { symbol: "BP", name: "BP p.l.c. Common Stock" },
    { symbol: "P", name: "Everpure, Inc. Class A common stock" },
    { symbol: "CNQ", name: "Canadian Natural Resources Limited Common Stock" },
    { symbol: "GH", name: "Guardant Health, Inc. - Common Stock" },
    { symbol: "MOD", name: "Modine Manufacturing Company Common Stock" },
    { symbol: "QXO", name: "QXO, Inc. Common Stock" },
  ],
  liquid_mid: [
    { symbol: "VOYA", name: "Voya Financial, Inc. Common Stock" },
    { symbol: "MYRG", name: "MYR Group, Inc. - Common Stock" },
    { symbol: "UMAC", name: "Unusual Machines, Inc. Common Stock" },
    { symbol: "TVTX", name: "Travere Therapeutics, Inc. - Common Stock" },
    { symbol: "AYI", name: "Acuity Inc. Common Stock" },
    { symbol: "TPC", name: "Tutor Perini Corporation Common Stock" },
    { symbol: "SCI", name: "Service Corporation International Common Stock" },
    { symbol: "VSEC", name: "VSE Corporation - Common Stock" },
    { symbol: "MMSI", name: "Merit Medical Systems, Inc. - Common Stock" },
    { symbol: "WHR", name: "Whirlpool Corporation Common Stock" },
    { symbol: "COLB", name: "Columbia Banking System, Inc. - Common Stock" },
    { symbol: "CAMT", name: "Camtek Ltd. - Ordinary Shares" },
    { symbol: "LRN", name: "Stride, Inc. Common Stock" },
    { symbol: "SYRE", name: "Spyre Therapeutics, Inc. - Common Stock" },
    { symbol: "ALGM", name: "Allegro MicroSystems, Inc. - Common Stock" },
    { symbol: "IBP", name: "Installed Building Products, Inc. Common Stock" },
    { symbol: "WU", name: "Western Union Company (The) Common Stock" },
    { symbol: "CUBE", name: "CubeSmart Common Shares" },
    { symbol: "FRPT", name: "Freshpet, Inc. - Common Stock" },
    { symbol: "SF", name: "Stifel Financial Corporation Common Stock" },
    { symbol: "FCFS", name: "FirstCash Holdings, Inc. - Common Stock" },
    { symbol: "AIT", name: "Applied Industrial Technologies, Inc. Common Stock" },
    { symbol: "MANE", name: "Veradermics, Incorporated Common Stock" },
    { symbol: "PTEN", name: "Patterson-UTI Energy, Inc. - Common Stock" },
    { symbol: "EWBC", name: "East West Bancorp, Inc. - Common Stock" },
    { symbol: "BCE", name: "BCE, Inc. Common Stock" },
    { symbol: "KLIC", name: "Kulicke and Soffa Industries, Inc. - Common Stock" },
    { symbol: "GFL", name: "GFL Environmental Inc. Subordinate voting shares, no par val" },
    { symbol: "CENX", name: "Century Aluminum Company - Common Stock" },
    { symbol: "EGO", name: "Eldorado Gold Corporation Ordinary Shares" },
    { symbol: "FLY", name: "Firefly Aerospace Inc. - Common Stock" },
    { symbol: "PRMB", name: "Primo Brands Corporation Class A Common Stock" },
    { symbol: "SARO", name: "StandardAero, Inc. Common Stock" },
    { symbol: "CRUS", name: "Cirrus Logic, Inc. - Common Stock" },
    { symbol: "RUN", name: "Sunrun Inc. - Common Stock" },
    { symbol: "LNC", name: "Lincoln National Corporation Common Stock" },
    { symbol: "AMG", name: "Affiliated Managers Group, Inc. Common Stock" },
    { symbol: "FFAI", name: "Faraday Future Intelligent Electric Inc. - Class A Common St" },
    { symbol: "RYAN", name: "Ryan Specialty Holdings, Inc. Class A Common Stock" },
    { symbol: "ARCC", name: "Ares Capital Corporation - Closed End Fund" },
    { symbol: "WPC", name: "W. P. Carey Inc. REIT" },
    { symbol: "GLPI", name: "Gaming and Leisure Properties, Inc. - Common Stock" },
    { symbol: "LGN", name: "Legence Corp. - Class A Common stock" },
    { symbol: "SKM", name: "SK Telecom Co., Ltd. Common Stock" },
    { symbol: "ENS", name: "EnerSys Common Stock" },
    { symbol: "ORKA", name: "Oruka Therapeutics, Inc. - Common Stock" },
    { symbol: "UMBF", name: "UMB Financial Corporation - Common Stock" },
    { symbol: "CHE", name: "Chemed Corp" },
    { symbol: "APPF", name: "AppFolio, Inc. - Class A Common Stock" },
    { symbol: "ALM", name: "Almonty Industries Inc. - Common Shares" },
    { symbol: "ADC", name: "Agree Realty Corporation Common Stock" },
    { symbol: "PTCT", name: "PTC Therapeutics, Inc. - Common Stock" },
    { symbol: "ABCL", name: "AbCellera Biologics Inc. - Common Shares" },
    { symbol: "MBGL", name: "Mobility Global Inc. Common Stock" },
    { symbol: "LPX", name: "Louisiana-Pacific Corporation Common Stock" },
    { symbol: "COKE", name: "Coca-Cola Consolidated, Inc. - Common Stock" },
    { symbol: "DFTX", name: "Definium Therapeutics, Inc. - Common Shares" },
    { symbol: "AN", name: "AutoNation, Inc. Common Stock" },
    { symbol: "R", name: "Ryder System, Inc. Common Stock" },
    { symbol: "DNTH", name: "Dianthus Therapeutics, Inc. - Common Stock" },
    { symbol: "MGA", name: "Magna International, Inc. Common Stock" },
    { symbol: "TDC", name: "Teradata Corporation Common Stock" },
    { symbol: "MAC", name: "Macerich Company (The) Common Stock" },
    { symbol: "MTN", name: "Vail Resorts, Inc. Common Stock" },
    { symbol: "CHDN", name: "Churchill Downs, Incorporated - Common Stock" },
    { symbol: "RGA", name: "Reinsurance Group of America, Incorporated Common Stock" },
    { symbol: "RCAT", name: "Red Cat Holdings, Inc. - Common Stock" },
    { symbol: "PSN", name: "Parsons Corporation Common Stock" },
    { symbol: "SITE", name: "SiteOne Landscape Supply, Inc. Common Stock" },
    { symbol: "VRNS", name: "Varonis Systems, Inc. - Common Stock" },
    { symbol: "PARR", name: "Par Pacific Holdings, Inc. Common Stock" },
    { symbol: "EXLS", name: "ExlService Holdings, Inc. - Common Stock" },
    { symbol: "TU", name: "Telus Corporation Ordinary Shares" },
    { symbol: "BBWI", name: "Bath & Body Works, Inc." },
    { symbol: "MLI", name: "Mueller Industries, Inc. Common Stock" },
    { symbol: "EMBJ", name: "Embraer S.A. Common Stock" },
    { symbol: "WLK", name: "Westlake Corporation Common Stock" },
    { symbol: "CE", name: "Celanese Corporation Common Stock" },
    { symbol: "TEX", name: "Terex Corporation Common Stock" },
    { symbol: "MFC", name: "Manulife Financial Corporation Common Stock" },
    { symbol: "EMN", name: "Eastman Chemical Company Common Stock" },
    { symbol: "GIL", name: "Gildan Activewear, Inc. Class A Sub. Vot. Common Stock" },
    { symbol: "UEC", name: "Uranium Energy Corp. Common Stock" },
    { symbol: "OHI", name: "Omega Healthcare Investors, Inc. Common Stock" },
    { symbol: "HRI", name: "Herc Holdings Inc. Common Stock" },
    { symbol: "TMDX", name: "TransMedics Group, Inc. - Common Stock" },
    { symbol: "IMAX", name: "Imax Corporation Common Stock" },
    { symbol: "INDV", name: "Indivior Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "ALV", name: "Autoliv, Inc. Common Stock" },
    { symbol: "LEA", name: "Lear Corporation Common Stock" },
    { symbol: "DK", name: "Delek US Holdings, Inc. Common Stock" },
    { symbol: "GSAT", name: "Globalstar, Inc. - Common Stock" },
    { symbol: "IDCC", name: "InterDigital, Inc. - Common Stock" },
    { symbol: "LKQ", name: "LKQ Corporation - Common Stock" },
    { symbol: "MAN", name: "ManpowerGroup Common Stock" },
    { symbol: "NAVN", name: "Navan, Inc. - Class A Common Stock" },
    { symbol: "PI", name: "Impinj, Inc. - Common Stock" },
    { symbol: "VAL", name: "Valaris Limited Common Shares" },
    { symbol: "INOD", name: "Innodata Inc. - Common Stock" },
    { symbol: "AGCO", name: "AGCO Corporation Common Stock" },
    { symbol: "ALKS", name: "Alkermes plc - Ordinary Shares" },
    { symbol: "AAP", name: "Advance Auto Parts Inc." },
    { symbol: "ING", name: "ING Group, N.V. Common Stock" },
    { symbol: "WEN", name: "Wendy's Company (The) - Common Stock" },
    { symbol: "KEX", name: "Kirby Corporation Common Stock" },
    { symbol: "NVST", name: "Envista Holdings Corporation Common Stock" },
    { symbol: "CNM", name: "Core & Main, Inc. Class A Common Stock" },
    { symbol: "MAIR", name: "Madison Air Solutions Corporation Class A Common Stock" },
    { symbol: "BYD", name: "Boyd Gaming Corporation Common Stock" },
    { symbol: "WTRG", name: "Essential Utilities, Inc. Common Stock" },
    { symbol: "DDS", name: "Dillard's, Inc. Common Stock" },
    { symbol: "LUMN", name: "Lumen Technologies, Inc. Common Stock" },
    { symbol: "BBAI", name: "BigBear.ai, Inc. Common Stock" },
    { symbol: "CTRE", name: "CareTrust REIT, Inc. Common Stock" },
    { symbol: "ACHC", name: "Acadia Healthcare Company, Inc. - Common Stock" },
    { symbol: "VISN", name: "Vistance Networks, Inc. - Common Stock" },
    { symbol: "PLXS", name: "Plexus Corp. - Common Stock" },
    { symbol: "RYTM", name: "Rhythm Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "CX", name: "Cemex, S.A.B. de C.V. Sponsored ADR" },
    { symbol: "HLNE", name: "Hamilton Lane Incorporated - Class A Common Stock" },
    { symbol: "ECG", name: "Everus Construction Group, Inc. Common Stock" },
    { symbol: "POST", name: "Post Holdings, Inc. Common Stock" },
    { symbol: "RELY", name: "Remitly Global, Inc. - Common stock" },
    { symbol: "PTGX", name: "Protagonist Therapeutics, Inc. - Common Stock" },
    { symbol: "LMND", name: "Lemonade, Inc. Common Stock" },
    { symbol: "JXN", name: "Jackson Financial Inc. Class A Common Stock" },
    { symbol: "SEIC", name: "SEI Investments Company - Common Stock" },
    { symbol: "PJT", name: "PJT Partners Inc. Class A Common Stock" },
    { symbol: "LAZ", name: "Lazard, Inc. Common Stock" },
    { symbol: "MORN", name: "Morningstar, Inc. - Common Stock" },
    { symbol: "ACMR", name: "ACM Research, Inc. - Class A Common Stock" },
    { symbol: "CRSP", name: "CRISPR Therapeutics AG - Common Shares" },
    { symbol: "ENSG", name: "The Ensign Group, Inc. - Common Stock" },
    { symbol: "MSM", name: "MSC Industrial Direct Company, Inc. Common Stock" },
    { symbol: "GXO", name: "GXO Logistics, Inc. Common Stock" },
    { symbol: "IRTC", name: "iRhythm Holdings, Inc. - Common Stock" },
    { symbol: "MSGS", name: "Madison Square Garden Sports Corp. Class A Common Stock (New" },
    { symbol: "BPOP", name: "Popular, Inc. - Common Stock" },
    { symbol: "DX", name: "Dynex Capital, Inc. Common Stock" },
    { symbol: "WAL", name: "Western Alliance Bancorporation Common Stock (DE)" },
    { symbol: "XMTR", name: "Xometry, Inc. - Class A Common Stock" },
    { symbol: "SLS", name: "SELLAS Life Sciences Group, Inc. - Common Stock" },
    { symbol: "CMC", name: "Commercial Metals Company Common Stock" },
    { symbol: "DOX", name: "Amdocs Limited - Ordinary Shares" },
    { symbol: "CALM", name: "Cal-Maine Foods, Inc. - Common Stock" },
    { symbol: "YUMC", name: "Yum China Holdings, Inc. Common Stock" },
    { symbol: "TM", name: "Toyota Motor Corporation Common Stock" },
    { symbol: "ULS", name: "UL Solutions Inc. Class A Common Stock" },
    { symbol: "NTSK", name: "Netskope, Inc. - Class A Common Stock" },
    { symbol: "QUBT", name: "Quantum Computing Inc. - Common Stock" },
    { symbol: "FNF", name: "Fidelity National Financial, Inc. Common Stock" },
    { symbol: "BLLN", name: "BillionToOne, Inc. - Class A common stock" },
    { symbol: "ERAS", name: "Erasca, Inc. - Common Stock" },
    { symbol: "VOYG", name: "Voyager Technologies, Inc. Class A Common Stock" },
    { symbol: "CECO", name: "CECO Environmental Corp. - Common Stock" },
    { symbol: "WTS", name: "Watts Water Technologies, Inc. Class A Common Stock" },
    { symbol: "KRG", name: "Kite Realty Group Trust Common Stock" },
    { symbol: "CHEF", name: "The Chefs' Warehouse, Inc. - Common Stock" },
    { symbol: "AXS", name: "Axis Capital Holdings Limited Common Stock" },
    { symbol: "SLM", name: "SLM Corporation - Common Stock" },
    { symbol: "HQY", name: "HealthEquity, Inc. - Common Stock" },
    { symbol: "JBS", name: "JBS N.V. Class A Common Shares" },
    { symbol: "MUFG", name: "Mitsubishi UFJ Financial Group, Inc. Common Stock" },
    { symbol: "FRO", name: "Frontline Plc Ordinary Shares" },
    { symbol: "WAY", name: "Waystar Holding Corp. - Common Stock" },
    { symbol: "ALHC", name: "Alignment Healthcare, Inc. - Common Stock" },
    { symbol: "DNN", name: "Denison Mines Corp Ordinary Shares (Canada)" },
    { symbol: "EXK", name: "Endeavour Silver Corporation Ordinary Shares (Canada)" },
    { symbol: "TFX", name: "Teleflex Incorporated Common Stock" },
    { symbol: "STEP", name: "StepStone Group Inc. - Class A Common Stock" },
    { symbol: "CACC", name: "Credit Acceptance Corporation - Common Stock" },
    { symbol: "HR", name: "Healthcare Realty Trust Incorporated Common Stock" },
    { symbol: "STWD", name: "STARWOOD PROPERTY TRUST, INC. Starwood Property Trust Inc." },
    { symbol: "ST", name: "Sensata Technologies Holding plc Ordinary Shares" },
    { symbol: "AMH", name: "American Homes 4 Rent Common Shares of Beneficial Interest" },
    { symbol: "COCO", name: "The Vita Coco Company, Inc. - Common Stock" },
    { symbol: "VVV", name: "Valvoline Inc. Common Stock" },
    { symbol: "NOVT", name: "Novanta Inc. - Common Shares" },
    { symbol: "SNEX", name: "StoneX Group Inc. - Common Stock" },
    { symbol: "URBN", name: "Urban Outfitters, Inc. - Common Stock" },
    { symbol: "FOUR", name: "Shift4 Payments, Inc. Class A Common Stock" },
    { symbol: "BANC", name: "Banc of California, Inc. Common Stock" },
    { symbol: "NESR", name: "National Energy Services Reunited Corp - Ordinary Shares" },
    { symbol: "BEPC", name: "Brookfield Renewable Corporation Brookfield Renewable Corpor" },
    { symbol: "SYNA", name: "Synaptics Incorporated - Common Stock" },
    { symbol: "G", name: "Genpact Limited Common Stock" },
    { symbol: "AMPX", name: "Amprius Technologies, Inc. Common Stock" },
    { symbol: "RSI", name: "Rush Street Interactive, Inc. Class A Common Stock" },
    { symbol: "BDC", name: "Belden Inc Common Stock" },
    { symbol: "EQPT", name: "EquipmentShare.com Inc - Class A Common Stock" },
    { symbol: "NPO", name: "Enpro Inc. Common Stock" },
    { symbol: "WRBY", name: "Warby Parker Inc. Class A Common Stock" },
    { symbol: "BH", name: "Biglari Holdings Inc. Class B Common Stock" },
    { symbol: "BTE", name: "Baytex Energy Corp Common Shares" },
    { symbol: "THG", name: "Hanover Insurance Group Inc" },
    { symbol: "VSNT", name: "Versant Media Group, Inc. - Class A Common Stock" },
    { symbol: "NOV", name: "NOV Inc. Common Stock" },
    { symbol: "HOG", name: "Harley-Davidson, Inc. Common Stock" },
    { symbol: "MIRM", name: "Mirum Pharmaceuticals, Inc. - common stock" },
    { symbol: "JBTM", name: "JBT Marel Corporation Common Stock" },
    { symbol: "NE", name: "Noble Corporation plc A Ordinary Shares" },
    { symbol: "SQM", name: "Sociedad Quimica y Minera S.A. Common Stock" },
    { symbol: "NSIT", name: "Insight Enterprises, Inc. - Common Stock" },
    { symbol: "INGR", name: "Ingredion Incorporated Common Stock" },
    { symbol: "AEO", name: "American Eagle Outfitters, Inc. Common Stock" },
    { symbol: "COGT", name: "Cogent Biosciences, Inc. - Common Stock" },
    { symbol: "SAIL", name: "SailPoint, Inc. - Common Stock" },
    { symbol: "ICHR", name: "Ichor Holdings - Ordinary Shares" },
    { symbol: "BULL", name: "Webull Corporation - Class A Ordinary Shares" },
    { symbol: "PB", name: "Prosperity Bancshares, Inc. Common Stock" },
    { symbol: "CRGY", name: "Crescent Energy Company Class A Common Stock" },
    { symbol: "MWH", name: "SOLV Energy, Inc. - Class A common stock" },
    { symbol: "BIRK", name: "Birkenstock Holding plc Ordinary Shares" },
    { symbol: "GLOB", name: "Globant S.A. Common Shares" },
    { symbol: "DB", name: "Deutsche Bank AG Common Stock" },
    { symbol: "GLBE", name: "Global-E Online Ltd. - ordinary shares" },
    { symbol: "CCC", name: "CCC Intelligent Solutions Holdings Inc. - Common Stock" },
    { symbol: "HWC", name: "Hancock Whitney Corporation - Common Stock" },
    { symbol: "PVH", name: "PVH Corp. Common Stock" },
    { symbol: "SXT", name: "Sensient Technologies Corporation Common Stock" },
    { symbol: "VCTR", name: "Victory Capital Holdings, Inc. - Common Stock" },
    { symbol: "AMIX", name: "Autonomix Medical, Inc. - Common Stock" },
    { symbol: "VVX", name: "V2X, Inc. Common Stock" },
    { symbol: "YETI", name: "YETI Holdings, Inc. Common Stock" },
    { symbol: "BRX", name: "Brixmor Property Group Inc. Common Stock" },
    { symbol: "BKD", name: "Brookdale Senior Living Inc. Common Stock" },
    { symbol: "IDA", name: "IDACORP, Inc. Common Stock" },
    { symbol: "OLED", name: "Universal Display Corporation - Common Stock" },
    { symbol: "MATX", name: "Matson, Inc. Common Stock" },
    { symbol: "WGS", name: "GeneDx Holdings Corp. - Class A Common Stock" },
    { symbol: "FR", name: "First Industrial Realty Trust, Inc. Common Stock" },
    { symbol: "DYN", name: "Dyne Therapeutics, Inc. - Common Stock" },
    { symbol: "KLAR", name: "Klarna Group plc Ordinary Shares" },
    { symbol: "BFLY", name: "Butterfly Network, Inc. Class A Common Stock" },
    { symbol: "SYM", name: "Symbotic Inc. - Class A Common Stock" },
    { symbol: "ARR", name: "ARMOUR Residential REIT, Inc." },
    { symbol: "BCO", name: "Brinks Company (The) Common Stock" },
    { symbol: "IRDM", name: "Iridium Communications Inc - Common Stock" },
    { symbol: "SMG", name: "Scotts Miracle-Gro Company (The) Common Stock" },
    { symbol: "CAR", name: "Avis Budget Group, Inc. - Common Stock" },
    { symbol: "GGB", name: "Gerdau S.A. Common Stock" },
    { symbol: "TARS", name: "Tarsus Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "MIDD", name: "The Middleby Corporation - Common Stock" },
    { symbol: "MC", name: "Moelis & Company Class A Common Stock" },
    { symbol: "VNO", name: "Vornado Realty Trust Common Stock" },
    { symbol: "YOU", name: "Clear Secure, Inc. Class A Common Stock" },
    { symbol: "BMI", name: "Badger Meter, Inc. Common Stock" },
    { symbol: "UFPT", name: "UFP Technologies, Inc. - Common Stock" },
    { symbol: "SON", name: "Sonoco Products Company Common Stock" },
    { symbol: "BAND", name: "Bandwidth Inc. - Class A Common Stock" },
    { symbol: "OMF", name: "OneMain Holdings, Inc. Common Stock" },
    { symbol: "CBSH", name: "Commerce Bancshares, Inc. - Common Stock" },
    { symbol: "IBRX", name: "ImmunityBio, Inc. - Common Stock" },
    { symbol: "HAE", name: "Haemonetics Corporation Common Stock" },
    { symbol: "FHB", name: "First Hawaiian, Inc. - Common Stock" },
    { symbol: "MIR", name: "Mirion Technologies, Inc. Class A Common Stock" },
    { symbol: "MAT", name: "Mattel, Inc. - Common Stock" },
    { symbol: "GLNG", name: "Golar LNG Limited - Common Shares" },
    { symbol: "VNOM", name: "Viper Energy, Inc. - Class A Common Stock" },
    { symbol: "SLGN", name: "Silgan Holdings Inc. Common Stock" },
    { symbol: "ATR", name: "AptarGroup, Inc. Common Stock" },
    { symbol: "QTWO", name: "Q2 Holdings, Inc. Common Stock" },
    { symbol: "ADPT", name: "Adaptive Biotechnologies Corporation - Common Stock" },
    { symbol: "LASR", name: "nLIGHT, Inc. - Common Stock" },
    { symbol: "NNN", name: "NNN REIT, Inc. Common Stock" },
    { symbol: "CLMT", name: "Calumet, Inc - Common Stock" },
    { symbol: "CGON", name: "CG Oncology, Inc. - Common stock" },
    { symbol: "STAG", name: "Stag Industrial, Inc. Common Stock" },
    { symbol: "OGE", name: "OGE Energy Corp Common Stock" },
    { symbol: "RITM", name: "Rithm Capital Corp. Common Stock" },
    { symbol: "MGNI", name: "Magnite, Inc. - Common Stock" },
    { symbol: "PGY", name: "Pagaya Technologies Ltd. - Class A Ordinary Shares" },
    { symbol: "LBRDK", name: "Liberty Broadband Corporation - Class C Common Stock" },
    { symbol: "MTH", name: "Meritage Homes Corporation Common Stock" },
    { symbol: "VIRT", name: "Virtu Financial, Inc. Class A Common Stock" },
    { symbol: "MRCY", name: "Mercury Systems Inc - Common Stock" },
    { symbol: "MBLY", name: "Mobileye Global Inc. - Class A Common Stock" },
    { symbol: "IMO", name: "Imperial Oil Limited Common Stock" },
    { symbol: "QURE", name: "uniQure N.V. - Ordinary Shares" },
    { symbol: "DCI", name: "Donaldson Company, Inc. Common Stock" },
    { symbol: "AUGO", name: "Aura Minerals Inc. - Common Shares" },
    { symbol: "BRZE", name: "Braze, Inc. - Class A Common Stock" },
    { symbol: "ESLT", name: "Elbit Systems Ltd. - Ordinary Shares" },
    { symbol: "CDNA", name: "CareDx, Inc. - Common Stock" },
    { symbol: "EBC", name: "Eastern Bankshares, Inc. - Common Stock" },
    { symbol: "SKY", name: "Champion Homes, Inc. Common Stock" },
    { symbol: "BFH", name: "Bread Financial Holdings, Inc. Common Stock" },
    { symbol: "KYMR", name: "Kymera Therapeutics, Inc. - Common Stock" },
    { symbol: "KBR", name: "KBR, Inc. Common Stock" },
    { symbol: "NXST", name: "Nexstar Media Group, Inc. - Common Stock" },
    { symbol: "GTX", name: "Garrett Motion Inc. - Common Stock" },
    { symbol: "FCN", name: "FTI Consulting, Inc. Common Stock" },
    { symbol: "NN", name: "NextNav Inc. - Common stock" },
    { symbol: "HCC", name: "Warrior Met Coal, Inc. Common Stock" },
    { symbol: "TNL", name: "Travel Leisure Co. Common Stock" },
    { symbol: "NOG", name: "Northern Oil and Gas, Inc. Common Stock" },
    { symbol: "SBRA", name: "Sabra Health Care REIT, Inc. - Common Stock" },
    { symbol: "KD", name: "Kyndryl Holdings, Inc. Common Stock" },
    { symbol: "ICUI", name: "ICU Medical, Inc. - Common Stock" },
    { symbol: "WHD", name: "Cactus, Inc. Class A Common Stock" },
    { symbol: "FLG", name: "Flagstar Bank, N.A. Common Stock" },
    { symbol: "ACIW", name: "ACI Worldwide, Inc. - Common Stock" },
    { symbol: "OPCH", name: "Option Care Health, Inc. - Common Stock" },
    { symbol: "PK", name: "Park Hotels & Resorts Inc. Common Stock" },
    { symbol: "NWL", name: "Newell Brands Inc. - Common Stock" },
    { symbol: "VKTX", name: "Viking Therapeutics, Inc. - Common Stock" },
    { symbol: "AIR", name: "AAR Corp. Common Stock" },
    { symbol: "KSS", name: "Kohl's Corporation Common Stock" },
    { symbol: "WSC", name: "WillScot Holdings Corporation - Class A Common Stock" },
    { symbol: "WYFI", name: "WhiteFiber, Inc. - Ordinary Shares" },
    { symbol: "COHU", name: "Cohu, Inc. - Common Stock" },
    { symbol: "CPRI", name: "Capri Holdings Limited Ordinary Shares" },
    { symbol: "XRAY", name: "DENTSPLY SIRONA Inc. - Common Stock" },
    { symbol: "RDNT", name: "RadNet, Inc. - Common Stock" },
    { symbol: "COLD", name: "Americold Realty Trust, Inc. Common Stock" },
    { symbol: "KTB", name: "Kontoor Brands, Inc. Common Stock" },
    { symbol: "OLN", name: "Olin Corporation Common Stock" },
    { symbol: "AXTA", name: "Axalta Coating Systems Ltd. Common Shares" },
    { symbol: "ACLS", name: "Axcelis Technologies, Inc. - Common Stock" },
    { symbol: "CSW", name: "CSW Industrials, Inc. Common Stock" },
    { symbol: "SLG", name: "SL Green Realty Corp Common Stock" },
    { symbol: "VAC", name: "Marriott Vacations Worldwide Corporation Common Stock" },
    { symbol: "ADT", name: "ADT Inc. Common Stock" },
    { symbol: "PSNL", name: "Personalis, Inc. - Common Stock" },
    { symbol: "SIG", name: "Signet Jewelers Limited Common Shares" },
    { symbol: "OZK", name: "Bank OZK - Common Stock" },
    { symbol: "GBCI", name: "Glacier Bancorp, Inc. Common Stock" },
    { symbol: "CWST", name: "Casella Waste Systems, Inc. - Class A Common Stock" },
    { symbol: "TDW", name: "Tidewater Inc. Common Stock" },
    { symbol: "ASH", name: "Ashland Inc. Common Stock" },
    { symbol: "CHH", name: "Choice Hotels International, Inc. Common Stock" },
    { symbol: "ESE", name: "ESCO Technologies Inc. Common Stock" },
    { symbol: "BC", name: "Brunswick Corporation Common Stock" },
    { symbol: "WK", name: "Workiva Inc. Class A Common Stock" },
    { symbol: "FMX", name: "Fomento Economico Mexicano S.A.B. de C.V. Common Stock" },
    { symbol: "RYN", name: "Rayonier Inc. REIT Common Stock" },
    { symbol: "GPK", name: "Graphic Packaging Holding Company" },
    { symbol: "BLZE", name: "Backblaze, Inc. - Common Stock" },
    { symbol: "HEI-A", name: "Heico Corporation Common Stock" },
    { symbol: "SRPT", name: "Sarepta Therapeutics, Inc. - Common Stock" },
    { symbol: "FSM", name: "Fortuna Mining Corp. Common Shares" },
    { symbol: "TNGX", name: "Tango Therapeutics, Inc. - Common Stock" },
    { symbol: "BTU", name: "Peabody Energy Corporation Common Stock" },
    { symbol: "FRVO", name: "Fervo Energy Company - Class A common stock" },
    { symbol: "DCO", name: "Ducommun Incorporated Common Stock" },
    { symbol: "RXRX", name: "Recursion Pharmaceuticals, Inc. - Class A Common Stock" },
    { symbol: "PRM", name: "Perimeter Solutions, SA Common Stock" },
    { symbol: "GNTX", name: "Gentex Corporation - Common Stock" },
    { symbol: "LIVN", name: "LivaNova PLC - Ordinary Shares" },
    { symbol: "MUR", name: "Murphy Oil Corporation Common Stock" },
    { symbol: "DLB", name: "Dolby Laboratories Common Stock" },
    { symbol: "GT", name: "The Goodyear Tire & Rubber Company - Common Stock" },
    { symbol: "ASB", name: "Associated Banc-Corp Common Stock" },
    { symbol: "WT", name: "WisdomTree, Inc. Common Stock" },
    { symbol: "SHC", name: "Sotera Health Company - Common Stock" },
    { symbol: "FA", name: "First Advantage Corporation - Common Stock" },
    { symbol: "LXP", name: "LXP Industrial Trust Common Stock (Maryland REIT)" },
    { symbol: "PCVX", name: "Vaxcyte, Inc. - Common Stock" },
    { symbol: "PII", name: "Polaris Inc. Common Stock" },
    { symbol: "GTES", name: "Gates Industrial Corporation Ltd. Common Shares" },
    { symbol: "CNX", name: "CNX Resources Corporation Common Stock" },
    { symbol: "ELVN", name: "Enliven Therapeutics, Inc. - Common Stock" },
    { symbol: "HURN", name: "Huron Consulting Group Inc. - Common Stock" },
    { symbol: "ATRO", name: "Astronics Corporation - Common Stock" },
    { symbol: "AROC", name: "Archrock, Inc. Common Stock" },
    { symbol: "VCYT", name: "Veracyte, Inc. - Common Stock" },
    { symbol: "BH-A", name: "Biglari Holdings Inc. Class A Common Stock" },
    { symbol: "NFG", name: "National Fuel Gas Company Common Stock" },
    { symbol: "GENI", name: "Genius Sports Limited Ordinary Shares" },
    { symbol: "XP", name: "XP Inc. - Class A Common Stock" },
    { symbol: "ARCB", name: "ArcBest Corporation - Common Stock" },
    { symbol: "OII", name: "Oceaneering International, Inc. Common Stock" },
    { symbol: "RLI", name: "RLI Corp. Common Stock (DE)" },
    { symbol: "MSA", name: "MSA Safety Incorporated Common Stock" },
    { symbol: "DV", name: "DoubleVerify Holdings, Inc. Common Stock" },
    { symbol: "BKH", name: "Black Hills Corporation Common Stock" },
    { symbol: "STNG", name: "Scorpio Tankers Inc. Common Shares" },
    { symbol: "HOMB", name: "Home BancShares, Inc. Common Stock" },
    { symbol: "FSS", name: "Federal Signal Corporation Common Stock" },
    { symbol: "FAF", name: "First American Corporation (New) Common Stock" },
    { symbol: "GPOR", name: "Gulfport Energy Corporation Common Shares" },
    { symbol: "KBH", name: "KB Home Common Stock" },
    { symbol: "PRI", name: "Primerica, Inc. Common Stock" },
    { symbol: "MTG", name: "MGIC Investment Corporation Common Stock" },
    { symbol: "WMG", name: "Warner Music Group Corp. - Class A Common Stock" },
    { symbol: "SRRK", name: "Scholar Rock Holding Corporation - Common Stock" },
    { symbol: "GPI", name: "Group 1 Automotive, Inc. Common Stock" },
    { symbol: "SAM", name: "Boston Beer Company, Inc. (The) Common Stock" },
    { symbol: "MIAX", name: "Miami International Holdings, Inc. Common Stock" },
    { symbol: "FGI", name: "FGI Industries Ltd. - Ordinary Shares" },
    { symbol: "AFG", name: "American Financial Group, Inc. Common Stock" },
    { symbol: "ASO", name: "Academy Sports and Outdoors, Inc. - Common Stock" },
    { symbol: "VERA", name: "Vera Therapeutics, Inc. - Class A Common Stock" },
    { symbol: "PFSI", name: "PennyMac Financial Services, Inc. Common Stock" },
    { symbol: "ESAB", name: "ESAB Corporation Common Stock" },
    { symbol: "KNSA", name: "Kiniksa Pharmaceuticals International, plc - Class A Ordinar" },
    { symbol: "SLF", name: "Sun Life Financial Inc. Common Stock" },
    { symbol: "SSD", name: "Simpson Manufacturing Company, Inc. Common Stock" },
    { symbol: "TGB", name: "Trekor Metals Limited Common Shares" },
    { symbol: "HP", name: "Helmerich & Payne, Inc. Common Stock" },
    { symbol: "POR", name: "Portland General Electric Co Common Stock" },
    { symbol: "SMMT", name: "Summit Therapeutics Inc. - Common Stock" },
    { symbol: "SAIC", name: "Science Applications International Corporation - Common Stoc" },
    { symbol: "SNN", name: "Smith & Nephew SNATS, Inc. Common Stock" },
    { symbol: "PURR", name: "Hyperliquid Strategies Inc - Common Stock" },
    { symbol: "HMY", name: "Harmony Gold Mining Company Limited" },
    { symbol: "DHT", name: "DHT Holdings, Inc." },
    { symbol: "WERN", name: "Werner Enterprises, Inc. - Common Stock" },
    { symbol: "WKC", name: "World Kinect Corporation Common Stock" },
    { symbol: "ASAN", name: "Asana, Inc. Class A Common Stock" },
    { symbol: "EEFT", name: "Euronet Worldwide, Inc. - Common Stock" },
    { symbol: "OUT", name: "OUTFRONT Media Inc. Common Stock" },
    { symbol: "TFII", name: "TFI International Inc. Common Shares" },
    { symbol: "SIGI", name: "Selective Insurance Group, Inc. - Common Stock" },
    { symbol: "MDA", name: "MDA Space Ltd. Common Shares" },
    { symbol: "RCI", name: "Rogers Communication, Inc. Common Stock" },
    { symbol: "AXGN", name: "Axogen, Inc. - Common Stock" },
    { symbol: "DIOD", name: "Diodes Incorporated - Common Stock" },
    { symbol: "CNR", name: "Core Natural Resources, Inc. Common Stock" },
    { symbol: "HGV", name: "Hilton Grand Vacations Inc. Common Stock" },
    { symbol: "CALX", name: "Calix, Inc Common Stock" },
    { symbol: "RXO", name: "RXO, Inc. Common Stock" },
    { symbol: "OBDC", name: "Blue Owl Capital Corporation Common Stock" },
    { symbol: "ORI", name: "Old Republic International Corporation Common Stock" },
    { symbol: "KNTK", name: "Kinetik Holdings Inc. Class A Common Stock" },
    { symbol: "PENN", name: "PENN Entertainment, Inc. - Common Stock" },
    { symbol: "SBSW", name: "D/B/A Sibanye-Stillwater Limited ADS" },
    { symbol: "ZWS", name: "Zurn Elkay Water Solutions Corporation Common Stock" },
    { symbol: "FIGS", name: "FIGS, Inc. Class A Common Stock" },
    { symbol: "VNT", name: "Vontier Corporation Common Stock" },
    { symbol: "NKTR", name: "Nektar Therapeutics - Common Stock" },
    { symbol: "DPC", name: "DPC Holdings PLC Ordinary Shares" },
    { symbol: "TRNO", name: "Terreno Realty Corporation Common Stock" },
    { symbol: "TNDM", name: "Tandem Diabetes Care, Inc. - Common Stock" },
    { symbol: "AI", name: "C3.ai, Inc. Class A Common Stock" },
    { symbol: "TTC", name: "Toro Company (The) Common Stock" },
    { symbol: "MRX", name: "Marex Group Limited - Ordinary Shares" },
    { symbol: "EWTX", name: "Edgewise Therapeutics, Inc. - Common Stock" },
    { symbol: "ARXS", name: "Arxis, Inc. - Class A Common Stock" },
    { symbol: "APPS", name: "Digital Turbine, Inc. - Common Stock" },
    { symbol: "CBRL", name: "Cracker Barrel Old Country Store, Inc. - Common Stock" },
    { symbol: "DBRG", name: "DigitalBridge Group, Inc." },
    { symbol: "BLFS", name: "BioLife Solutions, Inc. - Common Stock" },
    { symbol: "VECO", name: "Veeco Instruments Inc. - Common Stock" },
    { symbol: "VC", name: "Visteon Corporation - Common Stock" },
    { symbol: "SPSC", name: "SPS Commerce, Inc. - Common Stock" },
    { symbol: "CUZ", name: "Cousins Properties Incorporated Common Stock" },
    { symbol: "ZG", name: "Zillow Group, Inc. - Class A Common Stock" },
    { symbol: "RARE", name: "Ultragenyx Pharmaceutical Inc. - Common Stock" },
    { symbol: "CTRI", name: "Centuri Holdings, Inc. Common Stock" },
    { symbol: "IRT", name: "Independence Realty Trust, Inc. Common Stock" },
    { symbol: "PTON", name: "Peloton Interactive, Inc. - Common Stock" },
    { symbol: "APLE", name: "Apple Hospitality REIT, Inc. Common Shares" },
    { symbol: "EDU", name: "New Oriental Education & Technology Group, Inc. Sponsored AD" },
    { symbol: "PAY", name: "Paymentus Holdings, Inc. Class A Common Stock" },
    { symbol: "FIBK", name: "First Interstate BancSystem, Inc. - Common Stock" },
    { symbol: "UI", name: "Ubiquiti Inc. Common Stock" },
    { symbol: "CVSA", name: "Covista Inc. Common Shares" },
    { symbol: "AM", name: "Antero Midstream Corporation Common Stock" },
    { symbol: "BEAM", name: "Beam Therapeutics Inc. - Common Stock" },
    { symbol: "MEOH", name: "Methanex Corporation - Common Stock" },
    { symbol: "GEO", name: "Geo Group Inc (The) REIT" },
    { symbol: "KSPI", name: "Joint Stock Company Kaspi.kz - American Depository Shares" },
    { symbol: "SHLS", name: "Shoals Technologies Group, Inc. - Class A Common Stock" },
    { symbol: "KRC", name: "Kilroy Realty Corporation Common Stock" },
    { symbol: "MMYT", name: "MakeMyTrip Limited - Ordinary Shares" },
    { symbol: "UGI", name: "UGI Corporation Common Stock" },
    { symbol: "PLPC", name: "Preformed Line Products Company - Common Stock" },
    { symbol: "TXNM", name: "TXNM Energy, Inc. Common Stock" },
    { symbol: "NEO", name: "NeoGenomics, Inc. - Common Stock" },
    { symbol: "SBET", name: "Sharplink, Inc. - Common Stock" },
    { symbol: "ACAD", name: "ACADIA Pharmaceuticals Inc. - Common Stock" },
    { symbol: "CSTM", name: "Constellium SE Ordinary Shares (France)" },
    { symbol: "SHOO", name: "Steven Madden, Ltd. - Common Stock" },
    { symbol: "LEVI", name: "Levi Strauss & Co Class A Common Stock" },
    { symbol: "SKYW", name: "SkyWest, Inc. - Common Stock" },
    { symbol: "STUB", name: "StubHub Holdings, Inc. Class A Common Stock" },
    { symbol: "CMPS", name: "COMPASS Pathways Plc - American Depository Shares" },
    { symbol: "INSW", name: "International Seaways, Inc. Common Stock" },
    { symbol: "INSP", name: "Inspire Medical Systems, Inc. Common Stock" },
    { symbol: "QMCO", name: "Quantum Corporation - Common Stock" },
    { symbol: "PUMP", name: "ProPetro Holding Corp. Common Stock" },
    { symbol: "BZ", name: "KANZHUN LIMITED - American Depository Shares" },
    { symbol: "HAYW", name: "Hayward Holdings, Inc. Common Stock" },
    { symbol: "NXE", name: "Nexgen Energy Ltd. Common Shares" },
    { symbol: "UAA", name: "Under Armour, Inc. Class A Common Stock" },
    { symbol: "CSQR", name: "Csquare, Inc. Common Stock" },
    { symbol: "LFST", name: "LifeStance Health Group, Inc. - Common Stock" },
    { symbol: "HUBG", name: "Hub Group, Inc. - Class A Common Stock" },
    { symbol: "THO", name: "Thor Industries, Inc. Common Stock" },
    { symbol: "NXTC", name: "NextCure, Inc. - Common Stock" },
    { symbol: "TCBI", name: "Texas Capital Bancshares, Inc. - Common Stock" },
    { symbol: "UBSI", name: "United Bankshares, Inc. - Common Stock" },
    { symbol: "AEG", name: "Aegon Ltd. New York Registry Shares" },
    { symbol: "KNF", name: "Knife Riv Holding Co. Common Stock" },
    { symbol: "SXI", name: "Standex International Corporation Common Stock" },
    { symbol: "PATK", name: "Patrick Industries, Inc. - Common Stock" },
    { symbol: "BIPC", name: "Brookfield Infrastructure Corporation Brookfield Infrastruct" },
    { symbol: "EPRT", name: "Essential Properties Realty Trust, Inc. Common Stock" },
    { symbol: "AMR", name: "Alpha Metallurgical Resources, Inc. Common Stock" },
    { symbol: "SUPN", name: "Supernus Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "RRR", name: "Red Rock Resorts, Inc. - Class A Common Stock" },
    { symbol: "FTS", name: "Fortis Inc. Common Shares" },
    { symbol: "FBP", name: "First BanCorp. New Common Stock" },
    { symbol: "LOAR", name: "Loar Holdings Inc. Common Stock" },
    { symbol: "BRBR", name: "BellRing Brands, Inc. Common Stock" },
    { symbol: "BBVA", name: "Banco Bilbao Vizcaya Argentaria S.A. Common Stock" },
    { symbol: "EPR", name: "EPR Properties Common Stock" },
    { symbol: "CCXI", name: "Churchill Capital Corp XI - Class A Ordinary Shares" },
    { symbol: "XENE", name: "Xenon Pharmaceuticals Inc. - Common Shares" },
    { symbol: "HIW", name: "Highwoods Properties, Inc. Common Stock" },
    { symbol: "CC", name: "Chemours Company (The) Common Stock" },
    { symbol: "OTEX", name: "Open Text Corporation - Common Shares" },
    { symbol: "EXTR", name: "Extreme Networks, Inc. - Common Stock" },
    { symbol: "BKU", name: "BankUnited, Inc. Common Stock" },
    { symbol: "AMTM", name: "Amentum Holdings, Inc. Common Stock" },
    { symbol: "BNL", name: "Broadstone Net Lease, Inc. Common Stock" },
    { symbol: "VGNT", name: "Versigent PLC Ordinary Shares" },
    { symbol: "JAN", name: "Janus Living, Inc. Class A-1 Common Stock" },
    { symbol: "AMLX", name: "Amylyx Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "LINE", name: "Lineage, Inc. - Common Stock" },
    { symbol: "GRAL", name: "GRAIL, Inc. - Common Stock" },
    { symbol: "AUB", name: "Atlantic Union Bankshares Corporation Common Stock" },
    { symbol: "FULT", name: "Fulton Financial Corporation - Common Stock" },
    { symbol: "LIF", name: "Life360, Inc. - Common Stock" },
    { symbol: "NTLA", name: "Intellia Therapeutics, Inc. - Common Stock" },
    { symbol: "FTDR", name: "Frontdoor, Inc. - Common Stock" },
    { symbol: "NNE", name: "Nano Nuclear Energy Inc. - common stock" },
    { symbol: "NG", name: "Novagold Resources Inc." },
    { symbol: "SG", name: "Sweetgreen, Inc. Class A Common Stock" },
    { symbol: "PIPR", name: "Piper Sandler Companies Common Stock" },
    { symbol: "DXC", name: "DXC Technology Company Common Stock" },
    { symbol: "PPC", name: "Pilgrim's Pride Corporation - Common Stock" },
    { symbol: "UFPI", name: "UFP Industries, Inc. - Common Stock" },
    { symbol: "SWX", name: "Southwest Gas Holdings, Inc. Common Stock (DE)" },
    { symbol: "AESI", name: "Atlas Energy Solutions Inc. Common Stock" },
    { symbol: "BHF", name: "Brighthouse Financial, Inc. - Common Stock" },
    { symbol: "RLAY", name: "Relay Therapeutics, Inc. - Common Stock" },
    { symbol: "LIFE", name: "Ethos Technologies Inc. - Class A Common Stock" },
    { symbol: "PACS", name: "PACS Group, Inc. Common Stock" },
    { symbol: "POWI", name: "Power Integrations, Inc. - Common Stock" },
    { symbol: "URGN", name: "UroGen Pharma Ltd. - Ordinary Shares" },
    { symbol: "PTRN", name: "Pattern Group Inc. - Series A Common Stock" },
    { symbol: "HYMC", name: "Hycroft Mining Holding Corporation - Class A Common Stock" },
    { symbol: "DNOW", name: "DNOW Inc. Common Stock" },
    { symbol: "UNF", name: "Unifirst Corporation Common Stock" },
    { symbol: "DNLI", name: "Denali Therapeutics Inc. - Common Stock" },
    { symbol: "XHLD", name: "TEN Holdings, Inc. - Common Stock" },
    { symbol: "WTM", name: "White Mountains Insurance Group, Ltd. Common Stock" },
    { symbol: "RUSHA", name: "Rush Enterprises, Inc. - Class A Common Stock" },
    { symbol: "NCNO", name: "nCino, Inc. - Common Stock" },
    { symbol: "BRUN", name: "Boost Run Inc. - Class A Common Stock" },
    { symbol: "HIVE", name: "HIVE Digital Technologies Ltd - Common Shares" },
    { symbol: "HESM", name: "Hess Midstream LP Class A Representing Limited Partner Inter" },
    { symbol: "IMVT", name: "Immunovant, Inc. - Common Stock" },
    { symbol: "BW", name: "Babcock & Wilcox Enterprises, Inc. Common Stock" },
    { symbol: "ALGT", name: "Allegiant Travel Company - Common Stock" },
    { symbol: "DJT", name: "Trump Media & Technology Group Corp. - Common Stock" },
    { symbol: "ESTA", name: "Establishment Labs Holdings Inc. - Common Shares" },
    { symbol: "WSBC", name: "WesBanco, Inc. - Common Stock" },
    { symbol: "PBA", name: "Pembina Pipeline Corp. Ordinary Shares (Canada)" },
    { symbol: "VPG", name: "Vishay Precision Group, Inc. Common Stock" },
    { symbol: "CRC", name: "California Resources Corporation Common Stock" },
    { symbol: "PEB", name: "Pebblebrook Hotel Trust Common Shares of Beneficial Interest" },
    { symbol: "CLDX", name: "Celldex Therapeutics, Inc. - Common Stock" },
    { symbol: "APAM", name: "Artisan Partners Asset Management Inc. Class A Common Stock" },
    { symbol: "BETA", name: "Beta Technologies, Inc. Class A Common Stock" },
    { symbol: "MBX", name: "MBX Biosciences, Inc. - Common Stock" },
    { symbol: "BXSL", name: "Blackstone Secured Lending Fund Common Shares of Beneficial " },
    { symbol: "PRCT", name: "PROCEPT BioRobotics Corporation - Common Stock" },
    { symbol: "PDI", name: "PIMCO Dynamic Income Fund Common Stock" },
    { symbol: "TDS", name: "Telephone and Data Systems, Inc. Common Shares" },
    { symbol: "FLYW", name: "Flywire Corporation - Voting Common Stock" },
    { symbol: "AEVA", name: "Aeva Technologies, Inc. - Common Stock" },
    { symbol: "DAN", name: "Dana Incorporated Common Stock" },
    { symbol: "OGS", name: "ONE Gas, Inc. Common Stock" },
    { symbol: "VRDN", name: "Viridian Therapeutics, Inc. - Common Stock" },
    { symbol: "CRI", name: "Carter's, Inc. Common Stock" },
    { symbol: "CWEN", name: "Clearway Energy, Inc. Class C Common Stock" },
    { symbol: "FUN", name: "Six Flags Entertainment Corporation Common Stock New" },
    { symbol: "CPA", name: "Copa Holdings, S.A. Class A Common Stock" },
    { symbol: "AGIO", name: "Agios Pharmaceuticals, Inc. - Common Stock" },
    { symbol: "EYE", name: "National Vision Holdings, Inc. - Common Stock" },
    { symbol: "AVEX", name: "AEVEX Corp. Class A Common Stock" },
    { symbol: "PPLI", name: "People Incorporated - Common Stock" },
    { symbol: "COLM", name: "Columbia Sportswear Company - Common Stock" },
    { symbol: "LAUR", name: "Laureate Education, Inc. - Common Stock" },
    { symbol: "KMT", name: "Kennametal Inc. Common Stock" },
    { symbol: "TWO", name: "Two Harbors Investment Corp" },
    { symbol: "COUR", name: "Coursera, Inc. Common Stock" },
    { symbol: "CBT", name: "Cabot Corporation Common Stock" },
  ],
  liquid_small: [
    { symbol: "ABCB", name: "Ameris Bancorp Common Stock" },
    { symbol: "TDOC", name: "Teladoc Health, Inc. Common Stock" },
    { symbol: "CXW", name: "CoreCivic, Inc. Common Stock" },
    { symbol: "BLSH", name: "Bullish Ordinary Shares" },
    { symbol: "MFG", name: "Mizuho Financial Group, Inc. Sponosred ADR (Japan)" },
    { symbol: "AZZ", name: "AZZ Inc." },
    { symbol: "WTTR", name: "Select Water Solutions, Inc. Class A common stock" },
    { symbol: "ERO", name: "Ero Copper Corp. Common Shares" },
    { symbol: "PZZA", name: "Papa John's International, Inc. - Common Stock" },
    { symbol: "TRVI", name: "Trevi Therapeutics, Inc. - Common Stock" },
    { symbol: "ARI", name: "Apollo Commercial Real Estate Finance, Inc" },
    { symbol: "SRAD", name: "Sportradar Group AG - Class A Ordinary Shares" },
    { symbol: "CRML", name: "Critical Metals Corp. - Ordinary Shares" },
    { symbol: "GATX", name: "GATX Corporation Common Stock" },
    { symbol: "ALOY", name: "REalloys Inc. - Common Stock" },
    { symbol: "FUL", name: "H. B. Fuller Company Common Stock" },
    { symbol: "MFP", name: "Midera Food Processing, Inc. - Common Stock" },
    { symbol: "AVNT", name: "Avient Corporation Common Stock" },
    { symbol: "GCT", name: "GigaCloud Technology Inc - Class A Ordinary Shares" },
    { symbol: "CURB", name: "Curbline Properties Corp. Common Stock" },
    { symbol: "UTI", name: "Universal Technical Institute Inc Common Stock" },
    { symbol: "OMDA", name: "Omada Health, Inc. - Common Stock" },
    { symbol: "DRS", name: "Leonardo DRS, Inc. - Common Stock" },
    { symbol: "HZO", name: "MarineMax, Inc. (FL) Common Stock" },
    { symbol: "CARG", name: "CarGurus, Inc. - Class A Common Stock" },
    { symbol: "BWIN", name: "The Baldwin Insurance Group, Inc. - Class A Common Stock" },
    { symbol: "GSHD", name: "Goosehead Insurance, Inc. - Class A Common Stock" },
    { symbol: "ATRC", name: "AtriCure, Inc. - Common Stock" },
    { symbol: "MAIN", name: "Main Street Capital Corporation Common Stock" },
    { symbol: "TRIP", name: "TripAdvisor, Inc. - Common Stock" },
    { symbol: "MMS", name: "Maximus, Inc. Common Stock" },
    { symbol: "LAES", name: "SEALSQ Corp - Ordinary Shares" },
    { symbol: "AAMI", name: "Acadian Asset Management Inc. Common Stock" },
    { symbol: "ARQT", name: "Arcutis Biotherapeutics, Inc. - Common stock" },
    { symbol: "PAGP", name: "Plains GP Holdings, L.P. - Class A Shares representing limit" },
    { symbol: "FMC", name: "FMC Corporation Common Stock" },
    { symbol: "GIB", name: "CGI Inc. Common Stock" },
    { symbol: "HASI", name: "HA Sustainable Infrastructure Capital, Inc. Common Stock" },
    { symbol: "ARRY", name: "Array Technologies, Inc. - Common Stock" },
    { symbol: "PRGO", name: "Perrigo Company plc Ordinary Shares" },
    { symbol: "BOKF", name: "BOK Financial Corporation - Common Stock" },
    { symbol: "OPLN", name: "OPENLANE, Inc. Common Stock" },
    { symbol: "FFBC", name: "First Financial Bancorp. - Common Stock" },
    { symbol: "HUN", name: "Huntsman Corporation Common Stock" },
    { symbol: "RXT", name: "Rackspace Technology, Inc. - Common Stock" },
    { symbol: "SKT", name: "Tanger Inc. Common Stock" },
    { symbol: "SBLK", name: "Star Bulk Carriers Corp. - Common Shares" },
    { symbol: "REAL", name: "The RealReal, Inc. - Common Stock" },
  ],
  materials: [
    { symbol: "APD", name: "Air Products and Chemicals, Inc. Common Stock" },
    { symbol: "ALB", name: "Albemarle Corporation Common Stock" },
    { symbol: "AMCR", name: "Amcor plc Ordinary Shares" },
    { symbol: "AVY", name: "Avery Dennison Corporation Common Stock" },
    { symbol: "BALL", name: "Ball Corporation Common Stock" },
    { symbol: "CF", name: "CF Industries Holdings, Inc. Common Stock" },
    { symbol: "CTVA", name: "Corteva, Inc. Common Stock" },
    { symbol: "CRH", name: "CRH PLC Ordinary Shares" },
    { symbol: "DOW", name: "Dow Inc. Common Stock" },
    { symbol: "ECL", name: "Ecolab Inc. Common Stock" },
    { symbol: "FCX", name: "Freeport-McMoRan, Inc. Common Stock" },
    { symbol: "IFF", name: "International Flavors & Fragrances, Inc. Common Stock" },
    { symbol: "IP", name: "International Paper Company Common Stock" },
    { symbol: "LIN", name: "Linde plc - Ordinary Shares" },
    { symbol: "LYB", name: "LyondellBasell Industries NV Ordinary Shares Class A (Nether" },
    { symbol: "MLM", name: "Martin Marietta Materials, Inc. Common Stock" },
    { symbol: "MOS", name: "Mosaic Company (The) Common Stock" },
    { symbol: "NEM", name: "Newmont Corporation" },
    { symbol: "NUE", name: "Nucor Corporation Common Stock" },
    { symbol: "PKG", name: "Packaging Corporation of America Common Stock" },
    { symbol: "PPG", name: "PPG Industries, Inc. Common Stock" },
    { symbol: "SHW", name: "Sherwin-Williams Company (The) Common Stock" },
    { symbol: "SW", name: "Smurfit WestRock plc Ordinary Shares" },
    { symbol: "STLD", name: "Steel Dynamics, Inc. - Common Stock" },
    { symbol: "VMC", name: "Vulcan Materials Company (Holding Company) Common Stock" },
  ],
  real_estate: [
    { symbol: "ARE", name: "Alexandria Real Estate Equities, Inc. Common Stock" },
    { symbol: "AMT", name: "American Tower Corporation (REIT) Common Stock" },
    { symbol: "AVB", name: "AvalonBay Communities, Inc. Common Stock" },
    { symbol: "BXP", name: "BXP, Inc. Common Stock" },
    { symbol: "CPT", name: "Camden Property Trust Common Stock" },
    { symbol: "CBRE", name: "CBRE Group Inc Common Stock Class A" },
    { symbol: "CSGP", name: "CoStar Group, Inc. - Common Stock" },
    { symbol: "CCI", name: "Crown Castle Inc. Common Stock" },
    { symbol: "DLR", name: "Digital Realty Trust, Inc. Common Stock" },
    { symbol: "EQIX", name: "Equinix, Inc. - Common Stock" },
    { symbol: "EQR", name: "Equity Residential Common Shares of Beneficial Interest" },
    { symbol: "ESS", name: "Essex Property Trust, Inc. Common Stock" },
    { symbol: "EXR", name: "Extra Space Storage Inc Common Stock" },
    { symbol: "FRT", name: "Federal Realty Investment Trust Common Stock" },
    { symbol: "DOC", name: "Healthpeak Properties, Inc. Common Stock" },
    { symbol: "HST", name: "Host Hotels & Resorts, Inc. - Common Stock" },
    { symbol: "INVH", name: "Invitation Homes Inc. Common Stock" },
    { symbol: "IRM", name: "Iron Mountain Incorporated (Delaware)Common Stock REIT" },
    { symbol: "KIM", name: "Kimco Realty Corporation (HC) Common Stock" },
    { symbol: "MAA", name: "Mid-America Apartment Communities, Inc. Common Stock" },
    { symbol: "PLD", name: "Prologis, Inc. Common Stock" },
    { symbol: "PSA", name: "Public Storage Common Stock" },
    { symbol: "O", name: "Realty Income Corporation Common Stock" },
    { symbol: "REG", name: "Regency Centers Corporation - Common Stock" },
    { symbol: "SBAC", name: "SBA Communications Corporation - Class A Common Stock" },
    { symbol: "SPG", name: "Simon Property Group, Inc. Common Stock" },
    { symbol: "UDR", name: "UDR, Inc. Common Stock" },
    { symbol: "VTR", name: "Ventas, Inc. Common Stock" },
    { symbol: "VICI", name: "VICI Properties Inc. Common Stock" },
    { symbol: "WELL", name: "Welltower Inc. Common Stock" },
    { symbol: "WY", name: "Weyerhaeuser Company Common Stock" },
  ],
  tech: [
    { symbol: "ACN", name: "Accenture plc Class A Ordinary Shares (Ireland)" },
    { symbol: "ADBE", name: "Adobe Inc. - Common Stock" },
    { symbol: "AMD", name: "Advanced Micro Devices, Inc. - Common Stock" },
    { symbol: "AKAM", name: "Akamai Technologies, Inc. - Common Stock" },
    { symbol: "APH", name: "Amphenol Corporation Common Stock" },
    { symbol: "ADI", name: "Analog Devices, Inc. - Common Stock" },
    { symbol: "AAPL", name: "Apple Inc. - Common Stock" },
    { symbol: "AMAT", name: "Applied Materials, Inc. - Common Stock" },
    { symbol: "ANET", name: "Arista Networks, Inc. Common Stock" },
    { symbol: "ADSK", name: "Autodesk, Inc. - Common Stock" },
    { symbol: "AVGO", name: "Broadcom Inc. - Common Stock" },
    { symbol: "CDNS", name: "Cadence Design Systems, Inc. - Common Stock" },
    { symbol: "CDW", name: "CDW Corporation - Common Stock" },
    { symbol: "CIEN", name: "Ciena Corporation Common Stock" },
    { symbol: "CSCO", name: "Cisco Systems, Inc. - Common Stock" },
    { symbol: "CTSH", name: "Cognizant Technology Solutions Corporation - Class A Common " },
    { symbol: "COHR", name: "Coherent Corp. Common Stock" },
    { symbol: "GLW", name: "Corning Incorporated Common Stock" },
    { symbol: "CRWD", name: "CrowdStrike Holdings, Inc. - Class A Common Stock" },
    { symbol: "DDOG", name: "Datadog, Inc. - Class A Common Stock" },
    { symbol: "DELL", name: "Dell Technologies Inc. Class C Common Stock" },
    { symbol: "FFIV", name: "F5, Inc. - Common Stock" },
    { symbol: "FICO", name: "Fair Isaac Corporation Common Stock" },
    { symbol: "FSLR", name: "First Solar, Inc. - Common Stock" },
    { symbol: "FLEX", name: "Flex Ltd. - Ordinary Shares" },
    { symbol: "FTNT", name: "Fortinet, Inc. - Common Stock" },
    { symbol: "IT", name: "Gartner, Inc. Common Stock" },
    { symbol: "GEN", name: "Gen Digital Inc. - Common Stock" },
    { symbol: "GDDY", name: "GoDaddy Inc. Class A Common Stock" },
    { symbol: "HPE", name: "Hewlett Packard Enterprise Company Common Stock" },
    { symbol: "HPQ", name: "HP Inc. Common Stock" },
    { symbol: "IBM", name: "International Business Machines Corporation Common Stock" },
    { symbol: "INTC", name: "Intel Corporation - Common Stock" },
    { symbol: "INTU", name: "Intuit Inc. - Common Stock" },
    { symbol: "JBL", name: "Jabil Inc. Common Stock" },
    { symbol: "KEYS", name: "Keysight Technologies Inc. Common Stock" },
    { symbol: "KLAC", name: "KLA Corporation - Common Stock" },
    { symbol: "LRCX", name: "Lam Research Corporation - Common Stock" },
    { symbol: "LITE", name: "Lumentum Holdings Inc. - Common Stock" },
    { symbol: "MRVL", name: "Marvell Technology, Inc. - Common Stock" },
    { symbol: "MCHP", name: "Microchip Technology Incorporated - Common Stock" },
    { symbol: "MU", name: "Micron Technology, Inc. - Common Stock" },
    { symbol: "MSFT", name: "Microsoft Corporation - Common Stock" },
    { symbol: "MPWR", name: "Monolithic Power Systems, Inc. - Common Stock" },
    { symbol: "MSI", name: "Motorola Solutions, Inc. Common Stock" },
    { symbol: "NTAP", name: "NetApp, Inc. - Common Stock" },
    { symbol: "NVDA", name: "NVIDIA Corporation - Common Stock" },
    { symbol: "NXPI", name: "NXP Semiconductors N.V. - Common Stock" },
    { symbol: "ON", name: "ON Semiconductor Corporation - Common Stock" },
    { symbol: "ORCL", name: "Oracle Corporation Common Stock" },
    { symbol: "PLTR", name: "Palantir Technologies Inc. - Class A Common Stock" },
    { symbol: "PANW", name: "Palo Alto Networks, Inc. - Common Stock" },
    { symbol: "PTC", name: "PTC Inc. - Common Stock" },
    { symbol: "QCOM", name: "QUALCOMM Incorporated - Common Stock" },
    { symbol: "Q", name: "Qnity Electronics, Inc. Common Stock" },
    { symbol: "ROP", name: "Roper Technologies, Inc. - Common Stock" },
    { symbol: "CRM", name: "Salesforce, Inc. Common Stock" },
    { symbol: "SNDK", name: "Sandisk Corporation - Common Stock When-Issued" },
    { symbol: "STX", name: "Seagate Technology Holdings PLC - Ordinary Shares (Ireland)" },
    { symbol: "NOW", name: "ServiceNow, Inc. Common Stock" },
    { symbol: "SWKS", name: "Skyworks Solutions, Inc. - Common Stock" },
    { symbol: "SMCI", name: "Super Micro Computer, Inc. - Common Stock" },
    { symbol: "SNPS", name: "Synopsys, Inc. - Common Stock" },
    { symbol: "TEL", name: "TE Connectivity plc Ordinary Shares" },
    { symbol: "TDY", name: "Teledyne Technologies Incorporated Common Stock" },
    { symbol: "TER", name: "Teradyne, Inc. - Common Stock" },
    { symbol: "TXN", name: "Texas Instruments Incorporated - Common Stock" },
    { symbol: "TRMB", name: "Trimble Inc. - Common Stock" },
    { symbol: "TYL", name: "Tyler Technologies, Inc. Common Stock" },
    { symbol: "VRSN", name: "VeriSign, Inc. - Common Stock" },
    { symbol: "WDC", name: "Western Digital Corporation - Common Stock" },
    { symbol: "WDAY", name: "Workday, Inc. - Class A Common Stock" },
    { symbol: "ZBRA", name: "Zebra Technologies Corporation - Class A Common Stock" },
  ],
  utilities: [
    { symbol: "AES", name: "The AES Corporation Common Stock" },
    { symbol: "LNT", name: "Alliant Energy Corporation - Common Stock" },
    { symbol: "AEE", name: "Ameren Corporation Common Stock" },
    { symbol: "AEP", name: "American Electric Power Company, Inc. - Common Stock" },
    { symbol: "AWK", name: "American Water Works Company, Inc. Common Stock" },
    { symbol: "ATO", name: "Atmos Energy Corporation Common Stock" },
    { symbol: "CNP", name: "CenterPoint Energy, Inc (Holding Co) Common Stock" },
    { symbol: "CMS", name: "CMS Energy Corporation Common Stock" },
    { symbol: "ED", name: "Consolidated Edison, Inc. Common Stock" },
    { symbol: "CEG", name: "Constellation Energy Corporation - Common Stock When-Issued" },
    { symbol: "D", name: "Dominion Energy, Inc. Common Stock" },
    { symbol: "DTE", name: "DTE Energy Company Common Stock" },
    { symbol: "DUK", name: "Duke Energy Corporation (Holding Company) Common Stock" },
    { symbol: "EIX", name: "Edison International Common Stock" },
    { symbol: "ETR", name: "Entergy Corporation Common Stock" },
    { symbol: "EVRG", name: "Evergy, Inc. - Common Stock" },
    { symbol: "ES", name: "Eversource Energy (D/B/A) Common Stock" },
    { symbol: "EXC", name: "Exelon Corporation - Common Stock" },
    { symbol: "FE", name: "FirstEnergy Corp. Common Stock" },
    { symbol: "NEE", name: "NextEra Energy, Inc. Common Stock" },
    { symbol: "NI", name: "NiSource Inc Common Stock" },
    { symbol: "NRG", name: "NRG Energy, Inc. Common Stock" },
    { symbol: "PCG", name: "Pacific Gas & Electric Co. Common Stock" },
    { symbol: "PNW", name: "Pinnacle West Capital Corporation Common Stock" },
    { symbol: "PPL", name: "PPL Corporation Common Stock" },
    { symbol: "PEG", name: "Public Service Enterprise Group Incorporated Common Stock" },
    { symbol: "SRE", name: "DBA Sempra Common Stock" },
    { symbol: "SO", name: "Southern Company (The) Common Stock" },
    { symbol: "VST", name: "Vistra Corp. Common Stock" },
    { symbol: "WEC", name: "WEC Energy Group, Inc. Common Stock" },
    { symbol: "XEL", name: "Xcel Energy Inc. - Common Stock" },
  ],
  // liquid_extended: added 2026-08-14 from an Alpaca tradable-asset screen
  // (13,062 tradable non-OTC US equities -> 12,540 clean tickers -> ranked by dollar
  //  volume). Filters: price >= $5, marginable, >= 60 trades/day, >= $0.05M dollar
  //  volume, no leveraged/inverse/ETN/warrant/unit/preferred/buffer products.
  //  Bulk 5-minute bars still come from the consolidated feed, not Alpaca IEX.
  liquid_extended: [
    { symbol: "NOK", name: "Nokia Corporation" },
    { symbol: "HTFL", name: "Heartflow, Inc. Common Stock" },
    { symbol: "VALE", name: "VALE S.A." },
    { symbol: "JAAA", name: "Janus Henderson AAA CLO ETF" },
    { symbol: "ASX", name: "ASE Technology Holding Co., Ltd." },
    { symbol: "VCSH", name: "Vanguard Short-Term Corporate Bond ETF" },
    { symbol: "BIDU", name: "Baidu, Inc. ADS" },
    { symbol: "RDW", name: "Redwire Corporation" },
    { symbol: "IGSB", name: "iShares Trust iShares 1-5 Year Investment Grade Corporate Bond ETF" },
    { symbol: "SCHO", name: "Schwab Short-Term U.S. Treasury ETF" },
    { symbol: "PINC", name: "PGIM Securitized Income ETF" },
    { symbol: "GFI", name: "Gold Fields Ltd ADR" },
    { symbol: "ET", name: "Energy Transfer LP Common Units representing limited partner interests" },
    { symbol: "EWI", name: "iShares MSCI Italy ETF" },
    { symbol: "RELX", name: "RELX PLC" },
    { symbol: "SNY", name: "Sanofi ADS" },
    { symbol: "CAPR", name: "Capricor Therapeutics, Inc. Common Stock" },
    { symbol: "EROC", name: "ERock, Inc." },
    { symbol: "STNE", name: "StoneCo Ltd. Class A Common Shares" },
    { symbol: "UL", name: "Unilever plc" },
    { symbol: "TFLO", name: "iShares Treasury Floating Rate Bond ETF" },
    { symbol: "GMAB", name: "Genmab A/S ADS" },
    { symbol: "GBIL", name: "Goldman Sachs Access Treasury 0-1 Year ETF" },
    { symbol: "APGE", name: "Apogee Therapeutics, Inc. Common Stock" },
    { symbol: "GDS", name: "GDS Holdings Limited ADS" },
    { symbol: "OCTV", name: "Octave Intelligence plc Class B Ordinary Shares" },
    { symbol: "USPH", name: "US Physical Therapy Inc" },
    { symbol: "ETON", name: "Eton Pharmaceuticals, Inc. Common Stock" },
    { symbol: "MKTX", name: "MarketAxess Holdings, Inc. Common Stock" },
    { symbol: "AVAH", name: "Aveanna Healthcare Holdings Inc. Common Stock" },
    { symbol: "LYTE", name: "Roundhill Photonics & Optics ETF" },
    { symbol: "BINC", name: "iShares Flexible Income Active ETF" },
    { symbol: "NMAX", name: "Newsmax, Inc." },
    { symbol: "ZIM", name: "ZIM Integrated Shipping Services Ltd." },
    { symbol: "FCG", name: "First Trust Natural Gas ETF" },
    { symbol: "IXG", name: "iShares Global Financials ETF" },
    { symbol: "LMAT", name: "LeMaitre Vascular, Inc. Common Stock" },
    { symbol: "ANGL", name: "VanEck Fallen Angel High Yield Bond ETF" },
    { symbol: "IMXI", name: "International Money Express, Inc. Common Stock" },
    { symbol: "REZI", name: "Resideo Technologies, Inc. Common Stock" },
    { symbol: "MINT", name: "PIMCO Enhanced Short Maturity Active Exchange-Traded Fund" },
    { symbol: "BKLN", name: "Invesco Senior Loan ETF" },
    { symbol: "BATRK", name: "Atlanta Braves Holdings, Inc. Series C Common Stock" },
    { symbol: "LOPE", name: "Grand Canyon Education, Inc. Common Stock" },
    { symbol: "EWQ", name: "iShares MSCI France ETF" },
    { symbol: "YSS", name: "York Space Systems Inc." },
    { symbol: "TBBB", name: "BBB Foods Inc." },
    { symbol: "PPH", name: "VanEck Pharmaceutical ETF" },
    { symbol: "SFNC", name: "Simmons First National Corporation Class A Common Stock" },
    { symbol: "BOXX", name: "Alpha Architect 1-3 Month Box ETF" },
    { symbol: "DLO", name: "DLocal Limited Class A Common Shares" },
    { symbol: "BSCS", name: "Invesco BulletShares 2028 Corporate Bond ETF" },
    { symbol: "JQUA", name: "JPMorgan U.S. Quality Factor ETF" },
    { symbol: "KT", name: "KT Corp." },
    { symbol: "GUNR", name: "FlexShares Global Upstream Natural Resources Index Fund" },
    { symbol: "PAA", name: "Plains All American Pipeline, L.P. Common Units representing Limited Partner Interests" },
    { symbol: "LPTH", name: "LightPath Technologies, Inc. Class A Common Stock" },
    { symbol: "ADIG", name: "ADI Global Distribution Inc." },
    { symbol: "TALO", name: "Talos Energy, Inc. Common Stock" },
    { symbol: "OR", name: "OR Royalties Inc." },
    { symbol: "SATL", name: "Satellogic Inc. Class A Common Stock" },
    { symbol: "AGYS", name: "Agilysys, Inc. Common Stock (DE)" },
    { symbol: "SPT", name: "Sprout Social, Inc Class A Common Stock" },
    { symbol: "LFTO", name: "Liftoff Mobile, Inc. Common Stock" },
    { symbol: "NGG", name: "National Grid PLC" },
    { symbol: "WCLD", name: "WisdomTree Trust WisdomTree Cloud Computing Fund" },
    { symbol: "SGHC", name: "Super Group (SGHC) Limited" },
    { symbol: "BEP", name: "Brookfield Renewable Partners L.P." },
    { symbol: "VGSH", name: "Vanguard Short-Term Treasury ETF" },
    { symbol: "CLBT", name: "Cellebrite DI Ltd. Ordinary Shares" },
    { symbol: "IAK", name: "iShares U.S. Insurance ETF" },
    { symbol: "AMPL", name: "Amplitude, Inc. Class A Common Stock" },
    { symbol: "ALMS", name: "Alumis Inc. Common Stock" },
    { symbol: "SGML", name: "Sigma Lithium Corporation Common Shares" },
    { symbol: "TSLY", name: "YieldMax TSLA Option Income Strategy ETF" },
    { symbol: "ECO", name: "Okeanis Eco Tankers Corp." },
    { symbol: "BSBR", name: "BANCO SANTANDER (BRASIL) SA" },
    { symbol: "HEFA", name: "iShares Currency Hedged MSCI EAFE ETF" },
    { symbol: "PAGS", name: "PagSeguro Digital Ltd." },
    { symbol: "IOND", name: "Ionic Digital Inc. Class A Common Stock" },
    { symbol: "OMER", name: "Omeros Corporation Common Stock" },
    { symbol: "TS", name: "Tenaris S. A." },
    { symbol: "LGND", name: "Ligand Pharmaceuticals Incorporated Common Stock" },
    { symbol: "STN", name: "Stantec, Inc." },
    { symbol: "AVUS", name: "Avantis U.S. Equity ETF" },
    { symbol: "SAFT", name: "Safety Insurance Group, Inc. Common Stock" },
    { symbol: "VTEC", name: "Vanguard California Tax-Exempt Bond ETF" },
    { symbol: "TAL", name: "TAL Education Group" },
    { symbol: "INTR", name: "Inter & Co. Inc. Class A Common Shares" },
    { symbol: "DFIS", name: "Dimensional International Small Cap ETF" },
    { symbol: "PGEN", name: "Precigen, Inc. Common Stock" },
    { symbol: "IVLU", name: "iShares MSCI Intl Value Factor ETF" },
    { symbol: "HLX", name: "Helix Energy Solutions Group, Inc." },
    { symbol: "BLBD", name: "Blue Bird Corporation Common Stock" },
    { symbol: "SGOV", name: "iShares 0-3 Month Treasury Bond ETF" },
    { symbol: "CALY", name: "Callaway Golf Company" },
    { symbol: "EMLC", name: "VanEck J. P. Morgan EM Local Currency Bond ETF" },
    { symbol: "FSEC", name: "Fidelity Investment Grade Securitized ETF" },
    { symbol: "TAFI", name: "AB Tax-Aware Short Duration Municipal ETF" },
    { symbol: "RCUS", name: "Arcus Biosciences, Inc." },
    { symbol: "FTK", name: "Flotek Industries, Inc." },
    { symbol: "NATL", name: "NCR Atleos Corporation" },
    { symbol: "PCT", name: "PureCycle Technologies, Inc. Common stock" },
    { symbol: "AGM", name: "Federal Agricultural Mortgage Corporation" },
    { symbol: "EWS", name: "iShares MSCI Singapore ETF" },
    { symbol: "BYND", name: "Beyond Meat, Inc. Common Stock" },
    { symbol: "IBDY", name: "iShares iBonds Dec 2033 Term Corporate ETF" },
    { symbol: "ACVA", name: "ACV Auctions Inc." },
    { symbol: "IBDR", name: "iShares iBonds Dec 2026 Term Corporate ETF" },
    { symbol: "ABG", name: "Asbury Automotive Group, Inc." },
    { symbol: "SVM", name: "Silvercorp Metals Inc. Common Shares" },
    { symbol: "GOVZ", name: "iShares 25+ Year Treasury STRIPS Bond ETF" },
    { symbol: "XOVR", name: "EntrepreneurShares Series Trust ERShares Private-Public Crossover ETF" },
    { symbol: "VTIP", name: "Vanguard Malvern Funds Vanguard Short-Term Inflation-Protected Securities Index Fund ETF Shares" },
    { symbol: "AYA", name: "Aya Gold & Silver Inc. Common Shares" },
    { symbol: "AX", name: "Axos Financial, Inc. Common Stock" },
    { symbol: "EWG", name: "iShares MSCI Germany ETF" },
    { symbol: "VCX", name: "Fundrise Innovation Fund, LLC" },
    { symbol: "UAMY", name: "United States Antimony Corporation" },
    { symbol: "BL", name: "BlackLine, Inc. Common Stock" },
    { symbol: "MRP", name: "Millrose Properties, Inc." },
    { symbol: "CLOU", name: "Global X Funds Global X Cloud Computing ETF" },
    { symbol: "PAAA", name: "PGIM AAA CLO ETF" },
    { symbol: "FTRE", name: "Fortrea Holdings Inc. Common Stock" },
    { symbol: "INBX", name: "Inhibrx Biosciences, Inc. Common Stock" },
    { symbol: "STIP", name: "iShares 0-5 Year TIPS Bond ETF" },
    { symbol: "MHO", name: "M/I Homes, Inc." },
    { symbol: "AVPT", name: "AvePoint, Inc. Class A Common Stock" },
    { symbol: "MPLX", name: "MPLX LP" },
    { symbol: "AKRE", name: "Akre Focus ETF" },
    { symbol: "AADX", name: "Applied Aerospace & Defense, Inc." },
    { symbol: "BELFB", name: "Bel Fuse Inc. Class B Common Stock" },
    { symbol: "LNN", name: "Lindsay Corporation" },
    { symbol: "BWMN", name: "Bowman Consulting Group Ltd. Common Stock" },
    { symbol: "NUVB", name: "Nuvation Bio Inc." },
    { symbol: "METC", name: "Ramaco Resources, Inc. Class A Common Stock" },
    { symbol: "HAWK", name: "HawkEye 360, Inc." },
    { symbol: "GO", name: "Grocery Outlet Holding Corp. Common Stock" },
    { symbol: "ABEO", name: "Abeona Therapeutics Inc. Common Stock" },
    { symbol: "CNS", name: "Cohen & Steers Inc." },
    { symbol: "MMED", name: "MiniMed Group, Inc. Common Stock" },
    { symbol: "KOD", name: "Kodiak Sciences Inc Common Stock" },
    { symbol: "DJCO", name: "Daily Journal Corp. (S.C.) Common Stock" },
    { symbol: "HACK", name: "Amplify Cybersecurity ETF" },
    { symbol: "JCAP", name: "Jefferson Capital, Inc. Common Stock" },
    { symbol: "VIGI", name: "Vanguard Whitehall Funds Vanguard International Dividend Appreciation ETF" },
    { symbol: "IHG", name: "InterContinental Hotels Group Plc" },
    { symbol: "TALK", name: "Talkspace, Inc. Common Stock" },
    { symbol: "MOO", name: "VanEck Agribusiness ETF" },
    { symbol: "VIST", name: "Vista Energy S.A.B. de C.V." },
    { symbol: "OCFC", name: "OceanFirst Financial Corp. Common Stock" },
    { symbol: "CLYM", name: "Climb Bio, Inc. Common Stock" },
    { symbol: "BZH", name: "Beazer Homes USA, Inc. New" },
    { symbol: "UPWK", name: "Upwork Inc. Common Stock" },
    { symbol: "TATT", name: "TAT Technologies Ltd. Ordinary Shares" },
    { symbol: "CEVA", name: "CEVA, Inc. Common Stock" },
    { symbol: "OTF", name: "Blue Owl Technology Finance Corp." },
    { symbol: "ALH", name: "Alliance Laundry Holdings Inc." },
    { symbol: "KOPN", name: "Kopin Corporation Common Stock" },
    { symbol: "NIQ", name: "NIQ Global Intelligence plc" },
    { symbol: "ETOR", name: "eToro Group Ltd. Class A Common Shares" },
    { symbol: "CIGI", name: "Colliers International Group Inc. Subordinate Voting Shares" },
    { symbol: "APMD", name: "Apnimed, Inc. Common Stock" },
    { symbol: "ARTY", name: "iShares Future AI & Tech ETF" },
    { symbol: "MRVI", name: "Maravai LifeSciences Holdings, Inc. Class A Common Stock" },
    { symbol: "NNI", name: "Nelnet, Inc. Class A" },
    { symbol: "GNK", name: "GENCO SHIPPING & TRADING LTD" },
    { symbol: "IPGP", name: "IPG Photonics Corporation Common Stock" },
    { symbol: "BGC", name: "BGC Group, Inc. Class A Common Stock" },
    { symbol: "BILS", name: "State Street SPDR Bloomberg 3-12 Month T-Bill ETF" },
    { symbol: "MSGE", name: "Madison Square Garden Entertainment Corp." },
    { symbol: "AIPO", name: "Tidal Trust II Defiance AI & Power Infrastructure ETF" },
    { symbol: "REMX", name: "VanEck Rare Earth and Strategic Metals ETF" },
    { symbol: "RPD", name: "Rapid7, Inc. Common Stock" },
    { symbol: "GNL", name: "Global Net Lease, Inc." },
    { symbol: "SMA", name: "SmartStop Self Storage REIT, Inc." },
    { symbol: "DTCR", name: "Global X Funds Global X Data Center & Digital Infrastructure ETF" },
    { symbol: "CGAU", name: "Centerra Gold Inc." },
    { symbol: "NHC", name: "National Healthcare Corp." },
    { symbol: "TFI", name: "State Street SPDR Nuveen ICE Municipal Bond ETF" },
    { symbol: "DXPE", name: "DXP Enterprises, Inc. Common Stock" },
    { symbol: "HLIT", name: "Harmonic Inc. Common Stock" },
    { symbol: "CGMU", name: "Capital Group Municipal Income ETF" },
    { symbol: "SBCF", name: "Seacoast Banking Corporation of Florida Common Stock" },
    { symbol: "CDNL", name: "Cardinal Infrastructure Group Inc. Class A Common Stock" },
    { symbol: "RAMP", name: "LiveRamp Holdings, Inc. Common Stock" },
    { symbol: "BJRI", name: "BJ's Restaurants, Inc. Common Stock" },
    { symbol: "IOSP", name: "Innospec Inc. Common Stock" },
    { symbol: "ARKX", name: "ARK Space & Defense Innovation ETF" },
    { symbol: "TNK", name: "Teekay Tankers Ltd." },
    { symbol: "USRT", name: "iShares Core U.S. REIT ETF" },
    { symbol: "GFF", name: "Griffon Corp" },
    { symbol: "GBX", name: "The Greenbrier Companies, Inc." },
    { symbol: "ADNT", name: "Adient plc Ordinary Shares" },
    { symbol: "DXYZ", name: "Destiny Tech100 Inc." },
    { symbol: "FBRX", name: "Forte Biosciences, Inc. Common Stock" },
    { symbol: "TNC", name: "TENNANT COMPANY" },
    { symbol: "RSKD", name: "Riskified Ltd." },
    { symbol: "CADL", name: "Candel Therapeutics, Inc. Common Stock" },
    { symbol: "CALF", name: "Pacer US Small Cap Cash Cows ETF" },
    { symbol: "LINC", name: "Lincoln Educational Services Corporation Common Stock" },
    { symbol: "JBIO", name: "Jade Biosciences, Inc. Common Stock" },
    { symbol: "VERX", name: "Vertex, Inc. Class A Common Stock" },
    { symbol: "KALU", name: "Kaiser Aluminum Corporation Common Stock" },
    { symbol: "IE", name: "Ivanhoe Electric Inc." },
    { symbol: "RNST", name: "Renasant Corporation" },
    { symbol: "ABSI", name: "Absci Corporation Common Stock" },
    { symbol: "ASST", name: "Strive, Inc. Class A Common Stock" },
    { symbol: "FCOM", name: "Fidelity MSCI Communication Services Index ETF" },
    { symbol: "CGGE", name: "Capital Group Global Equity ETF" },
    { symbol: "ESGD", name: "iShares Trust iShares ESG Aware MSCI EAFE ETF" },
    { symbol: "HLIO", name: "Helios Technologies, Inc." },
    { symbol: "NEOG", name: "Neogen Corporation Common Stock" },
    { symbol: "GRND", name: "Grindr Inc." },
    { symbol: "BUSE", name: "First Busey Corporation Class A Common Stock" },
    { symbol: "PBW", name: "Invesco WilderHill Clean Energy ETF" },
    { symbol: "WSE", name: "Wise Group plc Class A Ordinary Shares" },
    { symbol: "PLGO", name: "Pelagos Insurance Capital Limited" },
    { symbol: "PUK", name: "PRUDENTIAL PLC ADS (REP 2 ORD SHARES)" },
    { symbol: "SDVY", name: "First Trust Exchange-Traded Fund VI First Trust SMID Cap Rising Dividend Achievers ETF" },
    { symbol: "MICC", name: "The Magnum Ice Cream Company N.V." },
    { symbol: "FLOT", name: "iShares Floating Rate Bond ETF" },
    { symbol: "BSOL", name: "Bitwise Solana Staking ETF" },
    { symbol: "RHLD", name: "Resolute Holdings Management, Inc." },
    { symbol: "FXN", name: "First Trust Energy AlphaDEX Fund" },
    { symbol: "CSIQ", name: "Canadian Solar Inc. Common Shares (ON)" },
    { symbol: "BKSY", name: "BlackSky Technology Inc." },
    { symbol: "DFAX", name: "Dimensional World ex U.S. Core Equity 2 ETF" },
    { symbol: "BBT", name: "Beacon Financial Corporation" },
    { symbol: "CGIC", name: "Capital Group International Core Equity ETF" },
    { symbol: "SEPN", name: "Septerna, Inc. Common Stock" },
    { symbol: "GSIE", name: "Goldman Sachs ActiveBeta International Equity ETF" },
    { symbol: "EWL", name: "iShares MSCI Switzerland ETF" },
    { symbol: "ENOV", name: "Enovis Corporation" },
    { symbol: "HAPN", name: "Happen, Inc. Common Stock" },
    { symbol: "LILAK", name: "Liberty Latin America Ltd. Class C Common Stock" },
    { symbol: "VLRS", name: "CONTROLADORA VUELA COMPAniA DE AVIACIoN, S.A.B. DE C.V." },
    { symbol: "PAX", name: "Patria Investments Limited Class A Common Shares" },
    { symbol: "RMAX", name: "RE/MAX HOLDINGS, INC." },
    { symbol: "LAR", name: "Lithium Argentina AG" },
    { symbol: "OXLC", name: "Oxford Lane Capital Corp. Common Stock" },
    { symbol: "HEDJ", name: "WisdomTree Europe Hedged Equity Fund" },
    { symbol: "NUAI", name: "New Era Energy & Digital, Inc. Common Stock" },
    { symbol: "SVV", name: "Savers Value Village, Inc." },
    { symbol: "ANRO", name: "Alto Neuroscience Inc." },
    { symbol: "OUNZ", name: "VanEck Merk Gold ETF" },
    { symbol: "SCHM", name: "Schwab U.S. Mid-Cap ETF" },
    { symbol: "CSHI", name: "NEOS Enhanced Income 1-3 Month T-Bill ETF" },
    { symbol: "NUTX", name: "Nutex Health Inc. Common Stock" },
    { symbol: "DFAS", name: "Dimensional U.S. Small Cap ETF" },
    { symbol: "CAE", name: "CAE Inc. Common Shares" },
    { symbol: "STAA", name: "STAAR Surgical Company Common Stock" },
    { symbol: "BCRX", name: "BioCryst Pharmaceuticals, Inc. Common Stock" },
    { symbol: "ECH", name: "iShares MSCI Chile ETF" },
    { symbol: "KB", name: "KB Financial Group Inc" },
    { symbol: "BELFA", name: "Bel Fuse Inc. Class A Common Stock" },
    { symbol: "BCPC", name: "Balchem Corporation Common Stock" },
    { symbol: "INVX", name: "Innovex International, Inc." },
    { symbol: "FTH", name: "Faeth Therapeutics, Inc. Common Stock" },
    { symbol: "CNXC", name: "Concentrix Corporation Common Stock" },
    { symbol: "ETH", name: "Grayscale Ethereum Staking Mini ETF Shares" },
    { symbol: "GOLF", name: "Acushnet Holdings Corp." },
    { symbol: "VIPS", name: "Vipshop Holdings Limited" },
    { symbol: "FETH", name: "Fidelity Ethereum Fund" },
    { symbol: "CGXU", name: "Capital Group International Focus Equity ETF" },
    { symbol: "SPB", name: "Spectrum Brands Holdings, Inc." },
    { symbol: "BTC", name: "Grayscale Bitcoin Mini Trust ETF" },
    { symbol: "OCUL", name: "Ocular Therapeutix, Inc. Common Stock" },
    { symbol: "JPIE", name: "JPMorgan Income ETF" },
    { symbol: "LWLG", name: "Lightwave Logic, Inc. Common Stock" },
    { symbol: "NAMS", name: "NewAmsterdam Pharma Company N.V. Ordinary Shares" },
    { symbol: "SFBS", name: "ServisFirst Bancshares Inc." },
    { symbol: "GBDC", name: "Golub Capital BDC, Inc. Common Stock" },
    { symbol: "LSPD", name: "Lightspeed Commerce Inc." },
    { symbol: "AIS", name: "VistaShares Artificial Intelligence Supercycle ETF" },
    { symbol: "UA", name: "Under Armour, Inc. Class C Common Stock, $0.0003 1/3 par value" },
    { symbol: "ONEQ", name: "Fidelity Nasdaq Composite Index ETF" },
    { symbol: "PEY", name: "Invesco Exchange-Traded Fund Trust Invesco High Yield Equity Dividend Achievers ETF" },
    { symbol: "BOTZ", name: "Global X Funds Global X Robotics & Artificial Intelligence ETF" },
    { symbol: "EC", name: "Ecopetrol S.A" },
    { symbol: "SPUS", name: "SP Funds S&P 500 Sharia ETF" },
    { symbol: "SFD", name: "Smithfield Foods, Inc. Common Stock" },
    { symbol: "PNRG", name: "PrimeEnergy Resources Corporation Common Stock" },
    { symbol: "LVHI", name: "Franklin International Low Volatility High Dividend Index ETF" },
    { symbol: "ADEA", name: "Adeia Inc. Common Stock" },
    { symbol: "OGN", name: "Organon & Co." },
    { symbol: "SECZ", name: "Securitize Corp." },
    { symbol: "ASM", name: "Avino Silver & Gold Mines Ltd. (Canada)" },
    { symbol: "ENVA", name: "Enova International, Inc." },
    { symbol: "PECO", name: "Phillips Edison & Company, Inc. Common Stock" },
    { symbol: "ACDC", name: "ProFrac Holding Corp. Class A Common Stock" },
    { symbol: "CRK", name: "Comstock Resources, Inc." },
    { symbol: "PHVS", name: "Pharvaris N.V. Ordinary Shares" },
    { symbol: "EPP", name: "iShares MSCI Pacific ex Japan ETF" },
    { symbol: "RSPA", name: "Invesco S&P 500 Equal Weight Income Advantage ETF" },
    { symbol: "SKWD", name: "Skyward Specialty Insurance Group, Inc. Common Stock" },
    { symbol: "FVD", name: "First Trust Value Line Dividend Fund" },
    { symbol: "WETO", name: "Wetour Robotics Limited Ordinary Shares" },
    { symbol: "AMTB", name: "Amerant Bancorp Inc." },
    { symbol: "AOSL", name: "Alpha and Omega Semiconductor Limited Common Shares" },
    { symbol: "LIND", name: "Lindblad Expeditions Holdings Inc. Common Stock" },
    { symbol: "NAT", name: "Nordic American Tanker" },
    { symbol: "EYPT", name: "EyePoint, Inc. Common Stock" },
    { symbol: "ESNT", name: "Essent Group LTD" },
    { symbol: "PPLT", name: "abrdn Physical Platinum Shares ETF" },
    { symbol: "CGCB", name: "Capital Group Core Bond ETF" },
    { symbol: "BLKB", name: "Blackbaud, Inc. Common Stock" },
    { symbol: "LION", name: "Lionsgate Studios Corp." },
    { symbol: "TFPM", name: "Triple Flag Precious Metals Corp." },
    { symbol: "PHG", name: "KONINKLIJKE PHILIPS  N.V." },
    { symbol: "HELP", name: "Cybin Inc. Common Stock" },
    { symbol: "DOO", name: "BRP Inc. Common Subordinate Voting Shares" },
    { symbol: "IHAK", name: "iShares Cybersecurity and Tech ETF" },
    { symbol: "ALG", name: "Alamo Group, Inc." },
    { symbol: "NRIX", name: "Nurix Therapeutics, Inc. Common stock" },
    { symbol: "FLJP", name: "Franklin FTSE Japan ETF" },
    { symbol: "DSGX", name: "Descartes Systems Group Inc. (The) Common Stock" },
    { symbol: "SPHD", name: "Invesco S&P 500 High Dividend Low Volatility ETF" },
    { symbol: "EWN", name: "iShares MSCI Netherlands ETF" },
    { symbol: "USAS", name: "Americas Gold and Silver Corporation" },
    { symbol: "MUX", name: "McEwen Inc." },
    { symbol: "ECPG", name: "Encore Capital Group Inc Common Stock" },
    { symbol: "RDVT", name: "Red Violet, Inc. Common Stock" },
    { symbol: "RUM", name: "RUM Group Inc. Class A Common Stock" },
    { symbol: "RLJ", name: "RLJ Lodging Trust" },
    { symbol: "ENR", name: "Energizer Holdings, Inc" },
    { symbol: "NEA", name: "Nuveen AMT-Free Quality Municipal Income Fund" },
    { symbol: "SMIG", name: "Bahl & Gaynor Small/Mid Cap Income Growth ETF" },
    { symbol: "USFR", name: "WisdomTree Floating Rate Treasury Fund" },
    { symbol: "BSCQ", name: "Invesco BulletShares 2026 Corporate Bond ETF" },
    { symbol: "FBK", name: "FB Financial Corporation" },
    { symbol: "FNDE", name: "Schwab Fundamental Emerging Markets Equity ETF" },
    { symbol: "MDU", name: "MDU Resources Group, Inc." },
    { symbol: "TRAX", name: "First Tracks Biotherapeutics, Inc. Ordinary Shares" },
    { symbol: "SLAB", name: "Silicon Laboratories, Inc. Common Stock" },
    { symbol: "AIP", name: "Arteris, Inc. Common Stock" },
    { symbol: "IDEF", name: "BlackRock ETF Trust iShares Defense Industrials Active ETF" },
    { symbol: "TIC", name: "TIC Solutions, Inc" },
    { symbol: "CVBF", name: "CVB Financial Corporation Common Stock" },
    { symbol: "SUNC", name: "SunocoCorp LLC" },
    { symbol: "ACHV", name: "Achieve Life Sciences, Inc. Common Shares" },
    { symbol: "BRSL", name: "Brightstar Lottery PLC" },
    { symbol: "RMIX", name: "Suncrete, Inc. Class A Common Stock" },
    { symbol: "GNW", name: "Genworth Financial, Inc." },
    { symbol: "AUPH", name: "Aurinia Pharmaceuticals Inc Ordinary Shares" },
    { symbol: "E", name: "ENI S.p.A." },
    { symbol: "SERV", name: "Serve Robotics Inc. Common Stock" },
    { symbol: "FELE", name: "Franklin Electric Co., Inc. Common Stock" },
    { symbol: "GMRS", name: "GMR Solutions Inc." },
    { symbol: "HTLD", name: "Heartland Express, Inc. Common Stock" },
    { symbol: "AMRX", name: "Amneal Pharmaceuticals, Inc. Class A Common Stock" },
    { symbol: "BXDC", name: "Blackstone Digital Infrastructure Trust Inc." },
    { symbol: "IEP", name: "Icahn Enterprises, L.P. Common Stock" },
    { symbol: "DBA", name: "Invesco DB Agriculture Fund" },
    { symbol: "AQN", name: "Algonquin Power & Utilities Corp" },
    { symbol: "WRLD", name: "World Acceptance Corporation Common Stock" },
    { symbol: "JACK", name: "Jack In The Box Inc. Common Stock" },
    { symbol: "OSW", name: "OneSpaWorld Holdings Limited Common Shares" },
    { symbol: "BSCT", name: "Invesco BulletShares 2029 Corporate Bond ETF" },
    { symbol: "UCB", name: "United Community Banks, Inc." },
    { symbol: "SMPL", name: "The Simply Good Foods Company Common Stock" },
    { symbol: "NGVT", name: "Ingevity Corporation" },
    { symbol: "CWK", name: "Cushman & Wakefield Ltd." },
    { symbol: "MNPR", name: "Monopar Therapeutics Inc. Common Stock" },
    { symbol: "REYN", name: "Reynolds Consumer Products Inc. Common Stock" },
    { symbol: "SII", name: "Sprott Inc." },
    { symbol: "BIP", name: "Brookfield Infrastructure Partners L.P. Limited Partnership Units" },
    { symbol: "UTZ", name: "Utz Brands, Inc." },
    { symbol: "FWONA", name: "Liberty Media Corporation Series A Liberty Formula One Common Stock" },
    { symbol: "KMPR", name: "Kemper Corporation" },
    { symbol: "VCEL", name: "Vericel Corporation Common Stock" },
    { symbol: "AZ", name: "A2Z Cust2Mate Solutions Corp. Common Shares" },
    { symbol: "SKHZ", name: "Leverage Shares 1X Short SK Hynix Daily ETF" },
    { symbol: "ETHE", name: "Grayscale Ethereum Staking ETF Shares" },
    { symbol: "TSLX", name: "Sixth Street Specialty Lending, Inc." },
    { symbol: "HTGC", name: "Hercules Capital, Inc." },
    { symbol: "WWW", name: "Wolverine World Wide, Inc." },
    { symbol: "SSL", name: "Sasol Limited" },
    { symbol: "APPN", name: "Appian Corporation Class A Common Stock" },
    { symbol: "LTPZ", name: "PIMCO 15+ Year U.S. TIPS Index Exchange-Traded Fund" },
    { symbol: "GDYN", name: "Grid Dynamics Holdings, Inc. Class A Common Stock" },
    { symbol: "PDYN", name: "Palladyne AI Corp. Common Stock" },
    { symbol: "TSHA", name: "Taysha Gene Therapies, Inc. Common Stock" },
    { symbol: "BLMN", name: "Bloomin' Brands, Inc. Common Stock" },
    { symbol: "IRON", name: "Disc Medicine, Inc. Common Stock" },
    { symbol: "CGNG", name: "Capital Group New Geography Equity ETF" },
    { symbol: "WVE", name: "Wave Life Sciences, Inc. Common Stock" },
    { symbol: "PDFS", name: "PDF Solutions, Inc. Common Stock" },
    { symbol: "LBTYA", name: "Liberty Global Ltd. Class A Common Shares" },
    { symbol: "DGII", name: "Digi International Inc. Common Stock" },
    { symbol: "ALNT", name: "Allient Inc. Common Stock" },
    { symbol: "TROX", name: "TRONOX LIMITED CL A ORDINARY SHARES" },
    { symbol: "EZPW", name: "EZCORP, Inc. Class A Non Voting Common Stock" },
    { symbol: "STRA", name: "Strategic Education, Inc. Common Stock" },
    { symbol: "YMAG", name: "YieldMax Magnificent 7 Fund of Option Income ETFs" },
    { symbol: "NEXT", name: "NextDecade Corporation Common Stock" },
    { symbol: "ATEC", name: "Alphatec Holdings, Inc. Common Stock" },
    { symbol: "AMBP", name: "Ardagh Metal Packaging S.A." },
    { symbol: "SHO", name: "Sunstone Hotel Investors, Inc." },
    { symbol: "HROW", name: "Harrow, Inc. Common Stock" },
    { symbol: "RRGB", name: "Red Robin Gourmet Burgers, Inc. Common Stock" },
    { symbol: "FALN", name: "iShares Trust iShares Fallen Angels USD Bond ETF" },
    { symbol: "AKR", name: "Acadia Realty Trust" },
    { symbol: "JMKE", name: "Jersey Mike's Subs Inc." },
    { symbol: "THRM", name: "Gentherm Inc Common Stock" },
    { symbol: "PSMT", name: "PriceSmart, Inc. Common Stock" },
    { symbol: "CRVS", name: "Corvus Pharmaceuticals, Inc. Common Stock" },
    { symbol: "DEI", name: "Douglas Emmett, Inc." },
    { symbol: "WLY", name: "John Wiley & Sons, Inc. Class A" },
    { symbol: "NPK", name: "National Presto Industries, Inc." },
    { symbol: "CRVL", name: "CorVel Corp. Common Stock" },
    { symbol: "DEC", name: "Diversified Energy Company" },
    { symbol: "JMBS", name: "Janus Henderson Mortgage-Backed Securities ETF" },
    { symbol: "PRE", name: "Prenetics Global Limited Class A Ordinary Share" },
    { symbol: "SUN", name: "SUNOCO L.P." },
    { symbol: "CDP", name: "COPT Defense Properties" },
    { symbol: "MTA", name: "Metalla Royalty & Streaming Ltd." },
    { symbol: "ATMU", name: "Atmus Filtration Technologies Inc." },
    { symbol: "PAR", name: "PAR Technology Corp." },
    { symbol: "HE", name: "Hawaiian Electric Industries, Inc." },
    { symbol: "YELP", name: "YELP INC." },
    { symbol: "PSUS", name: "Pershing Square USA, Ltd." },
    { symbol: "RPC", name: "Ridgepost Capital, Inc." },
    { symbol: "DIVO", name: "Amplify CWP Enhanced Dividend Income ETF" },
    { symbol: "CERT", name: "Certara, Inc. Common Stock" },
    { symbol: "PVLA", name: "Palvella Therapeutics, Inc. Common Stock" },
    { symbol: "NWE", name: "NorthWestern Energy Group, Inc. Common Stock" },
    { symbol: "COLL", name: "Collegium Pharmaceutical, Inc. Common Stock" },
    { symbol: "HOPE", name: "Hope Bancorp, Inc. Common Stock" },
    { symbol: "IVES", name: "Dan IVES Wedbush AI Revolution ETF" },
    { symbol: "SFL", name: "SFL Corporation Ltd." },
    { symbol: "HCSG", name: "Healthcare Services Group, Inc. Common Stock" },
    { symbol: "YSWY", name: "Yesway, Inc. Class A Common Stock" },
    { symbol: "BHC", name: "Bausch Health Companies Inc" },
    { symbol: "EFOR", name: "Everforth, Inc." },
    { symbol: "GHC", name: "GRAHAM HOLDINGS COMPANY" },
    { symbol: "NRDS", name: "NerdWallet, Inc. Class A Common Stock" },
    { symbol: "MCRI", name: "Monarch Casino & Resort, Inc. Common Stock" },
    { symbol: "IMNM", name: "Immunome, Inc. Common Stock" },
    { symbol: "PCRX", name: "Pacira BioSciences, Inc. Common Stock" },
    { symbol: "CRSR", name: "Corsair Gaming, Inc. Common Stock" },
    { symbol: "SNDX", name: "Syndax Pharmaceuticals, Inc. Common Stock" },
    { symbol: "KAI", name: "Kadant Inc." },
    { symbol: "CXM", name: "Sprinklr, Inc." },
    { symbol: "FSSL", name: "FS Specialty Lending Fund" },
    { symbol: "BCAX", name: "Bicara Therapeutics Inc. Common Stock" },
    { symbol: "NVAX", name: "Novavax, Inc. Common Stock" },
    { symbol: "ARLP", name: "Alliance Resource Partners, L.P. Common Units representing Limited Partners Interests" },
    { symbol: "TKC", name: "TURKCELL ILETISIM HIZMETLERI A.S. ADS" },
    { symbol: "TSSI", name: "TSS, Inc. Common Stock" },
    { symbol: "DRH", name: "Diamondrock Hospitality Company Common Stock" },
    { symbol: "BIZD", name: "VanEck BDC Income ETF" },
    { symbol: "MLTX", name: "MoonLake Immunotherapeutics Class A Ordinary Shares" },
    { symbol: "GTY", name: "Getty Realty Corp." },
    { symbol: "BITB", name: "Bitwise Bitcoin ETF" },
    { symbol: "LTC", name: "LTC Properties, Inc." },
    { symbol: "FUBO", name: "FuboTV Inc." },
    { symbol: "PLOW", name: "DOUGLAS DYNAMICS, INC." },
    { symbol: "VET", name: "VERMILION ENERGY INC." },
    { symbol: "ARCI", name: "Archimedes Tech SPAC Partners III Co. Ordinary Share" },
    { symbol: "CMBT", name: "CMB.TECH NV" },
    { symbol: "CATY", name: "Cathay General Bancorp Common Stock" },
    { symbol: "KURA", name: "Kura Oncology, Inc. Common Stock" },
    { symbol: "KSA", name: "iShares MSCI Saudi Arabia ETF" },
    { symbol: "LZ", name: "LegalZoom.com, Inc. Common Stock" },
    { symbol: "XPRO", name: "Expro Ltd" },
    { symbol: "DISK", name: "Tema Memory ETF" },
    { symbol: "ALLW", name: "SSGA Active Trust State Street Bridgewater All Weather ETF" },
    { symbol: "DHC", name: "Diversified Healthcare Trust Common Shares of Beneficial Interest" },
    { symbol: "FSK", name: "FS KKR Capital Corp. Common Stock" },
    { symbol: "PRCH", name: "Porch Group, Inc. Common Stock" },
    { symbol: "MHD", name: "Blackrock Muniholdings Fund, Inc." },
    { symbol: "FSV", name: "FirstService Corporation Common Shares" },
    { symbol: "IWMI", name: "NEOS Russell 2000 High Income ETF" },
    { symbol: "DFSV", name: "Dimensional US Small Cap Value ETF" },
    { symbol: "TFSL", name: "TFS Financial Corporation Common Stock" },
    { symbol: "HWKN", name: "Hawkins, Inc. Common Stock" },
    { symbol: "ORIC", name: "Oric Pharmaceuticals, Inc. Common Stock" },
    { symbol: "SNDA", name: "Sonida Senior Living, Inc." },
    { symbol: "QDPL", name: "Pacer Metaurus US Large Cap Dividend Multiplier 400 ETF" },
    { symbol: "PRVA", name: "Privia Health Group, Inc. Common Stock" },
    { symbol: "FMS", name: "Fresenius Medical Care AG" },
    { symbol: "INTA", name: "Intapp, Inc. Common Stock" },
    { symbol: "ATEX", name: "Anterix Inc. Common Stock" },
    { symbol: "SPFI", name: "South Plains Financial, Inc. Common Stock" },
    { symbol: "ADMA", name: "ADMA Biologics Inc Common Stock" },
    { symbol: "ROG", name: "Rogers Corporation" },
    { symbol: "MCHB", name: "Mechanics Bancorp Class A Common Stock" },
    { symbol: "UHAL", name: "U-Haul Holding Company" },
    { symbol: "PD", name: "PagerDuty, Inc." },
    { symbol: "SPPP", name: "Sprott Physical Platinum and Palladium Trust" },
    { symbol: "VREX", name: "Varex Imaging Corporation Common Stock" },
    { symbol: "AORT", name: "Artivion, Inc." },
    { symbol: "MZTI", name: "The Marzetti Company Common Stock" },
    { symbol: "FLOC", name: "Flowco Holdings Inc." },
    { symbol: "MLYS", name: "Mineralys Therapeutics, Inc. Common Stock" },
    { symbol: "LYG", name: "Lloyds Banking Group PLC" },
    { symbol: "FLO", name: "Flowers Foods, Inc." },
    { symbol: "LLYVK", name: "Liberty Live Holdings, Inc. Series C Liberty Live Group Common Stock" },
    { symbol: "EIDO", name: "iShares MSCI Indonesia ETF" },
    { symbol: "ASTH", name: "Astrana Health Inc. Common Stock" },
    { symbol: "NIC", name: "Nicolet Bankshares,Inc." },
    { symbol: "BOBS", name: "Bobs Discount Furniture, Inc." },
    { symbol: "IVR", name: "Invesco Mortgage Capital Inc." },
    { symbol: "DCH", name: "Dauch Corporation" },
    { symbol: "SRCE", name: "1st Source Corporation Common Stock" },
    { symbol: "GSBC", name: "Great Southern Bancorp, Inc. Common Stock" },
    { symbol: "REM", name: "iShares Mortgage Real Estate ETF" },
    { symbol: "QDEL", name: "QuidelOrtho Corporation Common Stock" },
    { symbol: "OCSL", name: "Oaktree Specialty Lending Corporation Common Stock" },
    { symbol: "STOK", name: "Stoke Therapeutics, Inc. Common Stock" },
    { symbol: "KFRC", name: "Kforce Inc." },
    { symbol: "SMJF", name: "SMJ International Holdings Inc." },
    { symbol: "ASMB", name: "Assembly Biosciences, Inc. Common Stock" },
    { symbol: "STRT", name: "STRATTEC SECURITY CORPORATION Common Stock" },
    { symbol: "WPP", name: "WPP PLC" },
    { symbol: "ZGN", name: "Ermenegildo Zegna N.V." },
    { symbol: "DORM", name: "Dorman Products, Inc. Common Stock" },
    { symbol: "ATEN", name: "A10 NETWORKS INC" },
    { symbol: "CON", name: "Concentra Group Holdings Parent, Inc." },
    { symbol: "EQBK", name: "Equity Bancshares, Inc." },
    { symbol: "MH", name: "McGraw Hill, Inc." },
    { symbol: "PRG", name: "PROG Holdings, Inc." },
    { symbol: "MQ", name: "Marqeta, Inc. Class A Common Stock" },
    { symbol: "UNIT", name: "Uniti Group Inc. Common Stock" },
    { symbol: "RYZ", name: "RYERSON HOLDING CORPORATION" },
    { symbol: "VSTS", name: "Vestis Corporation" },
    { symbol: "NVCR", name: "NovoCure Limited Ordinary Shares" },
    { symbol: "TMB", name: "Thornburg ETF Trust Thornburg Multi Sector Bond ETF" },
    { symbol: "SPRY", name: "ARS Pharmaceuticals, Inc. Common Stock" },
    { symbol: "WFG", name: "West Fraser Timber Co. Ltd" },
    { symbol: "SION", name: "Sionna Therapeutics, Inc. Common Stock" },
    { symbol: "AB", name: "AllianceBernstein Holding, L.P." },
    { symbol: "UE", name: "UBRAN EDGE PROPERTIES" },
    { symbol: "WES", name: "Western Midstream Partners, LP" },
    { symbol: "PHIN", name: "PHINIA Inc." },
    { symbol: "SONO", name: "Sonos, Inc. Common Stock" },
    { symbol: "FHI", name: "Federated Hermes, Inc." },
    { symbol: "NWPX", name: "NWPX Infrastructure, Inc. Common Stock" },
    { symbol: "ZD", name: "Ziff Davis, Inc. Common Stock" },
    { symbol: "FFIN", name: "First Financial Bankshares, Inc. Common Stock" },
    { symbol: "IPAR", name: "Interparfums, Inc. Common Stock" },
    { symbol: "LB", name: "LandBridge Company LLC" },
    { symbol: "GSL", name: "Global Ship Lease, Inc." },
    { symbol: "MBC", name: "MasterBrand, Inc." },
    { symbol: "ZBIO", name: "Zenas BioPharma, Inc. Common Stock" },
    { symbol: "BMA", name: "Banco Macro S.A." },
    { symbol: "CVCO", name: "Cavco Industries, Inc. Common Stock When Issued" },
    { symbol: "SDGR", name: "Schrodinger, Inc. Common Stock" },
    { symbol: "CVI", name: "CVR ENERGY, INC." },
    { symbol: "AMBQ", name: "Ambiq Micro, Inc." },
    { symbol: "PBH", name: "Prestige Consumer Healthcare Inc." },
    { symbol: "ADTN", name: "ADTRAN Holdings, Inc. Common Stock" },
    { symbol: "DC", name: "Dakota Gold Corp." },
    { symbol: "XERS", name: "Xeris Biopharma Holdings, Inc. Common Stock" },
    { symbol: "FMTM", name: "EA Series Trust MarketDesk Focused U.S. Momentum ETF" },
    { symbol: "ANNX", name: "Annexon, Inc. Common Stock" },
    { symbol: "IDYA", name: "IDEAYA Biosciences, Inc. Common Stock" },
    { symbol: "DCOM", name: "Dime Commercial Bancshares, Inc." },
    { symbol: "CRMD", name: "CorMedix Inc. Common Stock" },
    { symbol: "KRP", name: "Kimbell Royalty Partners, LP Common Units representing Limited Partner Interests" },
    { symbol: "NB", name: "NioCorp Developments Ltd. Common Stock" },
    { symbol: "PHAT", name: "Phathom Pharmaceuticals, Inc. Common Stock" },
    { symbol: "AAUC", name: "Allied Gold Corporation" },
    { symbol: "AIRJ", name: "AirJoule Technologies Corporation Class A Common Stock" },
    { symbol: "PFS", name: "Provident Financial Services, Inc." },
    { symbol: "EPOL", name: "iShares MSCI Poland ETF" },
    { symbol: "VSTM", name: "Verastem, Inc. Common Stock" },
    { symbol: "EVLV", name: "Evolv Technologies Holdings, Inc. Class A Common Stock" },
    { symbol: "FLIA", name: "Franklin International Aggregate Bond ETF" },
    { symbol: "BBDC", name: "Barings BDC, Inc." },
    { symbol: "SILC", name: "Silicom Ltd Ordinary Shares" },
    { symbol: "SA", name: "Seabridge Gold, Inc." },
    { symbol: "WNC", name: "Wabash National Corp." },
    { symbol: "PZA", name: "Invesco National AMT-Free Municipal Bond ETF" },
    { symbol: "IIPR", name: "Innovative Industrial Properties, Inc. Common stock" },
    { symbol: "SVRA", name: "Savara Inc. Common Stock" },
    { symbol: "IVT", name: "InvenTrust Properties Corp." },
    { symbol: "ALRM", name: "Alarm.com Holdings, Inc. Common Stock" },
    { symbol: "PDS", name: "Precision Drilling Corporation" },
    { symbol: "MLAB", name: "Mesa Laboratories, Inc. Common Stock" },
    { symbol: "SBH", name: "Sally Beauty Holdings, Inc." },
    { symbol: "ANIP", name: "ANI Pharmaceuticals, Inc." },
    { symbol: "PSIX", name: "Power Solutions International, Inc. Common Stock" },
    { symbol: "XNDU", name: "Xanadu Quantum Technologies Limited Class B Subordinate Voting Shares" },
    { symbol: "OI", name: "O-I Glass, Inc." },
    { symbol: "NOMD", name: "Nomad Foods Limited" },
    { symbol: "AGL", name: "agilon health, inc." },
    { symbol: "PSO", name: "Pearson plc" },
    { symbol: "BBNX", name: "Beta Bionics, Inc. Common Stock" },
    { symbol: "ARHS", name: "Arhaus, Inc. Class A Common Stock" },
    { symbol: "PLSE", name: "Pulse Biosciences, Inc Common Stock (DE)" },
    { symbol: "BXMT", name: "Blackstone Mortgage Trust, Inc. (NEW)" },
    { symbol: "RDN", name: "Radian Group Inc." },
    { symbol: "TRS", name: "TriMas Corporation Common Stock" },
    { symbol: "MD", name: "Pediatrix Medical Group, Inc." },
    { symbol: "RVII", name: "Robinhood Ventures Fund II" },
    { symbol: "FRME", name: "First Merchants Corporation Common Stock" },
    { symbol: "IMMX", name: "Immix Biopharma, Inc. Common Stock" },
    { symbol: "FRNM", name: "Freenome, Inc. Common stock" },
    { symbol: "BHVN", name: "Biohaven Ltd." },
    { symbol: "PGNY", name: "Progyny, Inc. Common Stock" },
    { symbol: "TRIN", name: "Trinity Capital Inc." },
    { symbol: "ULCC", name: "Frontier Group Holdings, Inc. Common Stock" },
    { symbol: "CTNM", name: "Contineum Therapeutics, Inc. Class A Common Stock" },
    { symbol: "SNDR", name: "Schneider National, Inc." },
    { symbol: "MSTY", name: "YieldMax MSTR Option Income Strategy ETF" },
    { symbol: "IALT", name: "BlackRock ETF Trust iShares Systematic Alternatives Active ETF" },
    { symbol: "IDV", name: "iShares International Select Dividend ETF" },
    { symbol: "CCOI", name: "Cogent Communications Holdings, Inc." },
    { symbol: "LOB", name: "Live Oak Bancshares, Inc." },
    { symbol: "FWRG", name: "First Watch Restaurant Group, Inc. Common Stock" },
    { symbol: "ARIS", name: "Aris Mining Corporation" },
    { symbol: "FMNB", name: "Farmers National Banc Corp. Common Stock" },
    { symbol: "TAC", name: "TransAlta Corporation" },
    { symbol: "EXPO", name: "Exponent, Inc. Common Stock" },
    { symbol: "RVLV", name: "Revolve Group, Inc." },
    { symbol: "NPKI", name: "NPK International Inc." },
    { symbol: "GRRR", name: "Gorilla Technology Group Inc. Ordinary shares" },
    { symbol: "DCTH", name: "Delcath Systems, Inc. Common Stock" },
    { symbol: "SGRY", name: "Surgery Partners, Inc. Common Stock" },
    { symbol: "BVN", name: "Compania de Minas Buenaventura S.A." },
    { symbol: "LIME", name: "Neutron Holdings, Inc. Common Stock" },
    { symbol: "LCII", name: "LCI Industries" },
    { symbol: "GRDN", name: "Guardian Pharmacy Services, Inc." },
    { symbol: "DKL", name: "DELEK LOGISTICS PARTNERS, LP" },
    { symbol: "MRAM", name: "Everspin Technologies, Inc. Common Stock" },
    { symbol: "BHRB", name: "Burke & Herbert Financial Services Corp. Common Stock" },
    { symbol: "PBLS", name: "Parabilis Medicines, Inc. Common Stock" },
    { symbol: "KN", name: "KNOWLES CORPORATION" },
    { symbol: "BWX", name: "State Street SPDR Bloomberg International Treasury Bond ETF" },
    { symbol: "JMIA", name: "Jumia Technologies AG" },
    { symbol: "SGMT", name: "Sagimet Biosciences Inc. Series A Common Stock" },
    { symbol: "MSDL", name: "Morgan Stanley Direct Lending Fund" },
    { symbol: "HLMN", name: "Hillman Solutions Corp. Common Stock" },
    { symbol: "STGW", name: "Stagwell Inc. Class A Common Stock" },
    { symbol: "THD", name: "iShares MSCI Thailand ETF" },
    { symbol: "AROW", name: "Arrow Financial Corporation Common Stock" },
    { symbol: "SR", name: "Spire Inc." },
    { symbol: "AVLN", name: "Avalyn Pharma Inc. Common Stock" },
    { symbol: "BFC", name: "Bank First Corporation Common Stock" },
    { symbol: "RNW", name: "ReNew Energy Global plc Class A Ordinary Shares" },
    { symbol: "VITL", name: "Vital Farms, Inc. Common Stock" },
    { symbol: "EWP", name: "iShares MSCI Spain ETF" },
    { symbol: "AMN", name: "AMN Healthcare Services" },
    { symbol: "PWP", name: "Perella Weinberg Partners Class A Common Stock" },
    { symbol: "TSAT", name: "Telesat Corporation Class A Common Shares and Class B Variable Voting Shares" },
    { symbol: "NTST", name: "NetSTREIT Corp." },
    { symbol: "BANF", name: "BancFirst Corporation Common Stock" },
    { symbol: "NAD", name: "Nuveen Quality Municipal Income Fund" },
    { symbol: "OMCL", name: "Omnicell, Inc. Common Stock ($0.001 par value)" },
    { symbol: "NBR", name: "Nabors Industries Ltd." },
    { symbol: "VYX", name: "NCR Voyix Corporation" },
    { symbol: "HMH", name: "HMH Holding Inc. Class A Common Stock" },
    { symbol: "XNCR", name: "Xencor, Inc. Common Stock" },
    { symbol: "EMBC", name: "Embecta Corp. Common Stock" },
    { symbol: "PRKS", name: "United Parks & Resorts Inc." },
    { symbol: "CGMS", name: "Capital Group U.S. Multi-Sector Income ETF" },
    { symbol: "TOWN", name: "TowneBank Common Stock" },
    { symbol: "UMH", name: "UMH Properties, Inc." },
    { symbol: "CPER", name: "United States Copper Index Fund" },
    { symbol: "CSWC", name: "Capital Southwest Corporation Common Stock" },
    { symbol: "KRT", name: "Karat Packaging Inc. Common Stock" },
    { symbol: "PAC", name: "Grupo Aeroportuario del Pacifico, S.A.B. de C.V. Amer. Dep. Shares (each rep. 10 Ser. B shares)" },
    { symbol: "TILE", name: "Interface, Inc. Common Stock" },
    { symbol: "JOE", name: "St. Joe Company" },
    { symbol: "RWAY", name: "Runway Growth Finance Corp. Common Stock" },
    { symbol: "BKE", name: "The Buckle, Inc." },
    { symbol: "OSIS", name: "OSI Systems, Inc. Common Stock (DE)" },
    { symbol: "VKQ", name: "Invesco Municipal Trust" },
    { symbol: "NHI", name: "National Health Investors" },
    { symbol: "ICFI", name: "ICF International, Inc. Common Stock" },
    { symbol: "OFG", name: "OFG BANCORP" },
    { symbol: "ANDG", name: "Andersen Group Inc." },
    { symbol: "AVA", name: "Avista Corporation" },
    { symbol: "TASK", name: "TaskUs, Inc. Class A Common Stock" },
    { symbol: "ESQ", name: "Esquire Financial Holdings, Inc. Common Stock" },
    { symbol: "HEEM", name: "iShares Currency Hedged MSCI Emerging Markets" },
    { symbol: "NJR", name: "New Jersey Resources Corp" },
    { symbol: "JANX", name: "Janux Therapeutics, Inc. Common Stock" },
    { symbol: "BRC", name: "Brady Corporation" },
    { symbol: "TRN", name: "Trinity Industries, Inc." },
    { symbol: "MWA", name: "Mueller Water Products, Inc." },
    { symbol: "BHE", name: "Benchmark Electronics" },
    { symbol: "WOR", name: "Worthington Enterprises, Inc." },
    { symbol: "BSAC", name: "Banco Santander-Chile" },
    { symbol: "AZTA", name: "Azenta, Inc." },
    { symbol: "LGIH", name: "LGI Homes, Inc. Common Stock" },
    { symbol: "VELO", name: "Velo3D, Inc. Common Stock" },
    { symbol: "NRK", name: "Nuveen New York AMT-Free Quality Municipal Income Fund" },
    { symbol: "LMB", name: "Limbach Holdings, Inc. Common Stock" },
    { symbol: "VOR", name: "Vor Biopharma Inc. Common Stock" },
    { symbol: "TNET", name: "TRINET GROUP, INC." },
    { symbol: "FCF", name: "First Commonwealth Financial Corporation" },
    { symbol: "NBHC", name: "NATIONAL BANK HOLDINGS CORP." },
    { symbol: "TYRA", name: "Tyra Biosciences, Inc. Common Stock" },
    { symbol: "NTCT", name: "NetScout Systems, Inc. Common Stock" },
    { symbol: "TDAY", name: "USA TODAY Co., Inc." },
    { symbol: "PEBO", name: "Peoples Bancorp Inc. Common Stock" },
    { symbol: "MITK", name: "Mitek Systems, Inc. Common Stock" },
    { symbol: "ATLC", name: "Atlanticus Holdings Corporation Common Stock" },
    { symbol: "NTB", name: "The Bank of N.T. Butterfield & Son Limited" },
    { symbol: "PLAB", name: "Photronics, Inc. Common Stock" },
    { symbol: "CODI", name: "Compass Diversified" },
    { symbol: "TRUP", name: "Trupanion, Inc. Common Stock" },
    { symbol: "PS", name: "Pershing Square Inc." },
    { symbol: "ARCT", name: "Arcturus Therapeutics Holdings Inc. Common Stock" },
    { symbol: "PUBM", name: "PubMatic, Inc. Class A Common Stock" },
    { symbol: "CONY", name: "YieldMax COIN Option Income Strategy ETF" },
    { symbol: "PRK", name: "Park National Corporation" },
    { symbol: "CNMD", name: "CONMED Corporation" },
    { symbol: "SAH", name: "Sonic Automotive, Inc." },
    { symbol: "CNO", name: "CNO Financial Group, Inc." },
    { symbol: "ABR", name: "Arbor Realty Trust, Inc." },
    { symbol: "WTBA", name: "West Bancorporation Common Stock" },
    { symbol: "AHCO", name: "AdaptHealth Corp. Common Stock" },
    { symbol: "GHRS", name: "GH Research PLC Ordinary Shares" },
    { symbol: "SVC", name: "Service Properties Trust Common Shares of Beneficial Interest" },
    { symbol: "FSTR", name: "L.B. Foster Company Common Stock" },
    { symbol: "GEM", name: "Goldman Sachs ActiveBeta Emerging Markets Equity ETF" },
    { symbol: "DAC", name: "Danaos Corporation" },
    { symbol: "SFST", name: "Southern First Bancshares, Inc. Common Stock" },
    { symbol: "AMSC", name: "American Superconductor Corporation Common Stock" },
    { symbol: "OCC", name: "Optical Cable Corporation Common Stock" },
    { symbol: "ICL", name: "ICL Group Ltd." },
    { symbol: "HBCP", name: "Home Bancorp, Inc. Common Stock" },
    { symbol: "CGEM", name: "Cullinan Therapeutics, Inc. Common Stock" },
    { symbol: "EVER", name: "EverQuote, Inc. Class A Common Stock" },
    { symbol: "VIR", name: "Vir Biotechnology, Inc. Common Stock" },
    { symbol: "ARLO", name: "Arlo Technologies, Inc." },
    { symbol: "ERII", name: "Energy Recovery, Inc. Common Stock" },
    { symbol: "DOLE", name: "Dole plc" },
    { symbol: "KEP", name: "Korea Electric Power Corp" },
    { symbol: "HIFS", name: "Hingham Institution for Savings Common Stock" },
    { symbol: "NVDY", name: "YieldMax NVDA Option Income Strategy ETF" },
    { symbol: "SKE", name: "Skeena Resources Limited" },
    { symbol: "BTGO", name: "BitGo Holdings, Inc." },
    { symbol: "NVEC", name: "NVE Corporation Common Stock" },
    { symbol: "DMRA", name: "Damora Therapeutics, Inc. Ordinary Shares" },
    { symbol: "SWIM", name: "Latham Group, Inc. Common Stock" },
    { symbol: "ONT", name: "Onterris, Inc." },
    { symbol: "HY", name: "Hyster-Yale, Inc." },
    { symbol: "CGBD", name: "Carlyle Secured Lending, Inc. Common Stock" },
    { symbol: "XPEL", name: "XPEL, Inc. Common Stock" },
    { symbol: "SMWB", name: "Similarweb Ltd." },
    { symbol: "LTGO", name: "Latigo Biotherapeutics, Inc. Common Stock" },
    { symbol: "FIDI", name: "Fidelity International High Dividend ETF" },
    { symbol: "EFSC", name: "Enterprise Financial Services Corporation Common Stock" },
    { symbol: "GDXY", name: "YieldMax Gold Miners Option Income Strategy ETF" },
    { symbol: "SRZN", name: "Surrozen, Inc. Common Stock" },
    { symbol: "TRMD", name: "TORM plc Class A Common Stock" },
    { symbol: "CWH", name: "Camping World Holdings, Inc." },
    { symbol: "NATH", name: "Nathan's Famous, Inc. Common Stock" },
    { symbol: "NSP", name: "Insperity, Inc" },
    { symbol: "AVBP", name: "ArriVent BioPharma, Inc. Common Stock" },
    { symbol: "HBNC", name: "Horizon Bancorp, Inc. Common Stock" },
    { symbol: "AIRO", name: "AIRO Group Holdings, Inc. Common Stock" },
    { symbol: "CWT", name: "California Water Service" },
    { symbol: "WEAV", name: "Weave Communications, Inc." },
    { symbol: "BFST", name: "Business First Bancshares, Inc. Common Stock" },
    { symbol: "STRO", name: "Sutro Biopharma, Inc. Common Stock" },
    { symbol: "OBX", name: "Obsidian Therapeutics, Inc. Common Stock" },
    { symbol: "CRAI", name: "CRA International, Inc. Common Stock" },
    { symbol: "RES", name: "RPC, Inc." },
    { symbol: "PGC", name: "Peapack-Gladstone Financial Corporation Common Stock" },
    { symbol: "SSTI", name: "SoundThinking, Inc. Common Stock" },
    { symbol: "TBBK", name: "The Bancorp Inc Common Stock" },
    { symbol: "INVA", name: "Innoviva, Inc. Common Stock" },
    { symbol: "TH", name: "Target Hospitality Corp. Common Stock" },
    { symbol: "ZYME", name: "Zymeworks Inc. Common Stock" },
    { symbol: "ANAB", name: "AnaptysBio, Inc. Common Stock" },
    { symbol: "KLRA", name: "Kailera Therapeutics, Inc. Common Stock" },
    { symbol: "OLMA", name: "Olema Pharmaceuticals, Inc. Common Stock" },
    { symbol: "EFC", name: "Ellington Financial Inc. Common Stock" },
    { symbol: "STVN", name: "Stevanato Group S.p.A." },
    { symbol: "HG", name: "Hamilton Insurance Group, Ltd. Class B Common Shares" },
    { symbol: "GEF", name: "Greif, Inc." },
    { symbol: "GPRE", name: "Green Plains Inc. Common Stock" },
    { symbol: "ORRF", name: "Orrstown Financial Services, Inc. Common Stock" },
    { symbol: "HBB", name: "Hamilton Beach Brands Holding Company Class A Common Stock" },
    { symbol: "ZVRA", name: "Zevra Therapeutics, Inc. Common Stock" },
    { symbol: "LZB", name: "La-Z-Boy Incorporated" },
    { symbol: "GOF", name: "Guggenheim Strategic Opportunities Fund" },
    { symbol: "HNRG", name: "Hallador Energy Company Common Stock" },
    { symbol: "LEG", name: "Leggett & Platt, Inc." },
    { symbol: "NAVI", name: "Navient Corporation Common Stock" },
    { symbol: "BFS", name: "Saul Centers, Inc." },
    { symbol: "STTK", name: "Shattuck Labs, Inc. Common Stock" },
    { symbol: "BETR", name: "Better Home & Finance Holding Company Class A Common Stock" },
    { symbol: "QNST", name: "QuinStreet, Inc. Common Stock" },
    { symbol: "ABX", name: "Abacus Global Management, Inc." },
    { symbol: "PRSU", name: "Pursuit Attractions and Hospitality, Inc." },
    { symbol: "AWR", name: "American States Water Company" },
    { symbol: "AMSF", name: "AMERISAFE, Inc. Common Stock" },
    { symbol: "LBTYK", name: "Liberty Global Ltd. Class C Common Shares" },
    { symbol: "LTRX", name: "Lantronix, Inc. Common Stock" },
    { symbol: "EPC", name: "Edgewell Personal Care Company" },
    { symbol: "OSBC", name: "Old Second Bancorp, Inc. Common Stock" },
    { symbol: "WBI", name: "WaterBridge Infrastructure LLC" },
    { symbol: "CIM", name: "Chimera Investment Corp." },
    { symbol: "ADUS", name: "Addus HomeCare Corporation Common Stock" },
    { symbol: "MQY", name: "Blackrock Muni Yield Quality Fund, Inc" },
    { symbol: "SND", name: "Smart Sand, Inc. Common Stock" },
    { symbol: "WLFC", name: "Willis Lease Finance Corporation Common Stock" },
    { symbol: "PLMR", name: "Palomar Holdings, Inc. Common stock" },
    { symbol: "XIFR", name: "XPLR Infrastructure, LP" },
    { symbol: "MCB", name: "Metropolitan Bank Holding Corp. Common Stock, $0.01 par value per share" },
    { symbol: "MANU", name: "MANCHESTER UNITED PLC" },
    { symbol: "BRVE", name: "Braveheart Bio, Inc. Common Stock" },
    { symbol: "OBE", name: "Obsidian Energy Ltd." },
    { symbol: "CRAK", name: "VanEck Oil Refiners ETF" },
    { symbol: "RIGL", name: "Rigel Pharmaceuticals, Inc. Common Stock" },
    { symbol: "HRMY", name: "Harmony Biosciences Holdings, Inc. Common Stock" },
    { symbol: "VNQI", name: "Vanguard International Equity Index Funds Vanguard Global ex-U.S. Real Estate ETF" },
    { symbol: "ARCO", name: "ARCOS DORADOS HOLDINGS INC." },
    { symbol: "VNM", name: "VanEck Vietnam ETF" },
    { symbol: "PDM", name: "Piedmont Realty Trust, Inc." },
    { symbol: "CXT", name: "Crane NXT, Co." },
    { symbol: "WSFS", name: "WSFS Financial Corporation Common Stock" },
    { symbol: "ROCK", name: "Gibraltar Industries, Inc. Common Stock" },
    { symbol: "WLDN", name: "Willdan Group, Inc. Common Stock" },
    { symbol: "PPTA", name: "Perpetua Resources Corp. Common Shares" },
    { symbol: "SLDB", name: "Solid Biosciences Inc. Common Stock" },
    { symbol: "OTTR", name: "Otter Tail Corporation Common Stock" },
    { symbol: "ZURA", name: "Zura Bio Limited Class A Ordinary Shares" },
    { symbol: "AEBI", name: "Aebi Schmidt Holding AG Common Stock" },
    { symbol: "ALX", name: "Alexander's Inc." },
    { symbol: "ISSC", name: "Innovative Solutions and Support, Inc. Common Stock" },
    { symbol: "CBC", name: "Central Bancompany, Inc. Class A Common Stock" },
    { symbol: "ELMT", name: "The Elmet Group Co. Common Stock" },
    { symbol: "HTO", name: "H2O America Common Stock" },
    { symbol: "INMD", name: "InMode Ltd. Ordinary Shares" },
    { symbol: "CASH", name: "Pathward Financial, Inc. Common Stock" },
    { symbol: "VIA", name: "Via Transportation, Inc." },
    { symbol: "SPRX", name: "Listed Funds Trust Spear Alpha ETF" },
    { symbol: "CORO", name: "BlackRock ETF Trust iShares International Country Rotation Active ETF" },
    { symbol: "IBOC", name: "International Bancshares Corporation Common Stock" },
    { symbol: "DEA", name: "Easterly Government Properties, Inc." },
    { symbol: "MTW", name: "The Manitowoc Company, Inc." },
    { symbol: "NEWP", name: "New Pacific Metals Corp." },
    { symbol: "SLP", name: "Simulations Plus, Inc. Common Stock" },
    { symbol: "TTI", name: "TETRA Technologies, Inc." },
    { symbol: "GRPN", name: "Groupon, Inc. Common Stock" },
    { symbol: "WGO", name: "Winnebago Industries, Inc." },
    { symbol: "FOR", name: "Forestar Group Inc." },
    { symbol: "NMFC", name: "New Mountain Finance Corporation Common Stock" },
    { symbol: "ARTV", name: "Artiva Biotherapeutics, Inc. Common Stock" },
    { symbol: "PLUS", name: "ePlus inc. Common Stock" },
    { symbol: "HHH", name: "Howard Hughes Holdings Inc." },
    { symbol: "ORC", name: "Orchid Island Capital, Inc." },
    { symbol: "EUV", name: "Corgi Lithography & Semiconductor Photonics ETF" },
    { symbol: "ASC", name: "ARDMORE SHIPPING CORPORATION" },
    { symbol: "FELG", name: "Fidelity Enhanced Large Cap Growth ETF" },
    { symbol: "UAE", name: "iShares Trust iShares MSCI UAE ETF" },
    { symbol: "EVTC", name: "EVERTEC, INC." },
    { symbol: "AAT", name: "AMERICAN ASSETS TRUST, INC." },
    { symbol: "BBGI", name: "Beasley Broadcast Group, Inc. Class A Common Stock" },
    { symbol: "BCC", name: "Boise Cascade Company" },
    { symbol: "MYI", name: "BLACKROCK MUNIYIELD QUALITY FUND III, INC." },
    { symbol: "RELL", name: "Richardson Electronics, Ltd. Common Stock" },
    { symbol: "MGTX", name: "MeiraGTx Holdings plc Ordinary Shares" },
    { symbol: "EROK", name: "EagleRock Land, LLC" },
    { symbol: "XHR", name: "Xenia Hotels & Resorts, Inc." },
    { symbol: "AVTX", name: "Avalo Therapeutics, Inc. Common Stock" },
    { symbol: "PLAY", name: "Dave & Buster's Entertainment, Inc. Common Stock" },
    { symbol: "MRTN", name: "Marten Transport, Ltd. Common Stock" },
    { symbol: "AIN", name: "Albany International Corp Class A" },
    { symbol: "EE", name: "Excelerate Energy, Inc." },
    { symbol: "RCMT", name: "RCM Technologies, Inc. Common Stock" },
    { symbol: "BBAR", name: "Banco BBVA Argentina S.A." },
    { symbol: "YEXT", name: "Yext, Inc." },
    { symbol: "RAPP", name: "Rapport Therapeutics, Inc. Common Stock" },
    { symbol: "CMCL", name: "Caledonia Mining Corporation Plc" },
    { symbol: "UNCY", name: "Unicycive Therapeutics, Inc. Common Stock" },
    { symbol: "EFTY", name: "Etoiles Capital Group Co., Ltd. Class A Ordinary Shares" },
    { symbol: "THFF", name: "First Financial Corporation Common Stock" },
    { symbol: "IBCP", name: "Independent Bank Corporation Common Stock" },
    { symbol: "TLK", name: "PT Telekomunikasi Indonesia" },
    { symbol: "INN", name: "Summit Hotel Properties, Inc." },
    { symbol: "BCAT", name: "BlackRock Capital Allocation Term Trust" },
    { symbol: "GSBD", name: "Goldman Sachs BDC, Inc." },
    { symbol: "STDN", name: "Standard Nuclear, Inc." },
    { symbol: "SXC", name: "SUNCOKE ENERGY INC" },
    { symbol: "CMPR", name: "Cimpress PLC Ordinary Shares (Ireland)" },
    { symbol: "WLTH", name: "Wealthfront Corporation Common Stock" },
    { symbol: "MNRO", name: "Monro, Inc. Common Stock" },
    { symbol: "ABTC", name: "American Bitcoin Corp. Class A Common Stock" },
    { symbol: "PBI", name: "Pitney Bowes Inc." },
    { symbol: "NRIM", name: "Northrim BanCorp Inc Common Stock" },
    { symbol: "CHT", name: "CHUNGHWA TELECOM CO., LTD" },
    { symbol: "CIVB", name: "Civista Bancshares, Inc. Common Stock" },
    { symbol: "USAU", name: "U.S. Gold Corp. Common Stock" },
    { symbol: "HLF", name: "Herbalife Ltd." },
    { symbol: "SLDE", name: "Slide Insurance Holdings, Inc. Common Stock" },
    { symbol: "CUE", name: "Cue Biopharma, Inc. Common Stock" },
    { symbol: "PAYP", name: "PayPay Corporation American Depository Shares" },
    { symbol: "KELYA", name: "Kelly Services, Inc. Class A Common Stock" },
    { symbol: "IHS", name: "IHS Holding Limited" },
    { symbol: "SDRL", name: "Seadrill Limited" },
    { symbol: "AEYE", name: "AudioEye, Inc. Common Stock" },
    { symbol: "ALKT", name: "Alkami Technology, Inc. Common Stock" },
    { symbol: "KFY", name: "Korn Ferry" },
    { symbol: "UTL", name: "Unitil Corporation" },
    { symbol: "IMKTA", name: "Ingles Markets, Incorporated Class A Common Stock" },
    { symbol: "FIZZ", name: "National Beverage Corp. Common Stock" },
    { symbol: "MAMA", name: "Mama's Creations, Inc. Common Stock" },
    { symbol: "CLM", name: "Cornerstone Strategic Investment Fund, Inc." },
    { symbol: "AMCX", name: "AMC Global Media Inc. Class A Common Stock" },
    { symbol: "CDRE", name: "Cadre Holdings, Inc." },
    { symbol: "MLKN", name: "MillerKnoll, Inc. Common Stock" },
    { symbol: "LXU", name: "LSB INDUSTRIES INC" },
    { symbol: "TSL", name: "GraniteShares ETF Trust GraniteShares 1.25x Long TSLA Daily ETF" },
    { symbol: "CTOS", name: "Custom Truck One Source, Inc." },
    { symbol: "CTEV", name: "Claritev Corporation" },
    { symbol: "HAFN", name: "Hafnia Limited" },
    { symbol: "QCRH", name: "QCR Holdings, Inc. Common Stock" },
    { symbol: "DNA", name: "Ginkgo Bioworks Holdings, Inc." },
    { symbol: "ANDE", name: "Andersons, Inc. (The) Common Stock" },
    { symbol: "FCAP", name: "First Capital, Inc. Common Stock" },
    { symbol: "WSBF", name: "Waterstone Financial, Inc. Common Stock (MD)" },
    { symbol: "SPNT", name: "SiriusPoint Ltd." },
    { symbol: "AII", name: "American Integrity Insurance Group, Inc." },
    { symbol: "HRTG", name: "HERITAGE INSURANCE HOLDINGS INC" },
    { symbol: "MAX", name: "MediaAlpha, Inc." },
    { symbol: "GRNT", name: "Granite Ridge Resources, Inc." },
    { symbol: "RGNX", name: "REGENXBIO Inc. Common Stock" },
    { symbol: "SSYS", name: "Stratasys, Ltd. Ordinary Shares (Israel)" },
    { symbol: "PALL", name: "abrdn Physical Palladium Shares ETF" },
    { symbol: "PKE", name: "Park Aerospace Corp. Common Stock" },
    { symbol: "VTS", name: "Vitesse Energy, Inc.." },
    { symbol: "LPG", name: "DORIAN LPG LTD" },
    { symbol: "SOBO", name: "South Bow Corporation" },
    { symbol: "LBRX", name: "LB Pharmaceuticals Inc Common Stock" },
    { symbol: "FCPT", name: "Four Corners Property Trust, Inc." },
    { symbol: "PRDO", name: "Perdoceo Education Corporation Common Stock" },
    { symbol: "AMPH", name: "Amphastar Pharmaceuticals, Inc. Common Stock" },
    { symbol: "UPB", name: "Upstream Bio, Inc. Common Stock" },
    { symbol: "GOOS", name: "Canada Goose Holdings Inc." },
    { symbol: "UPBD", name: "Upbound Group, Inc. Common Stock" },
    { symbol: "KBDC", name: "Kayne Anderson BDC, Inc." },
    { symbol: "TRLV", name: "Trulieve Cannabis Corp." },
    { symbol: "BWFG", name: "Bankwell Financial Group, Inc. Common Stock" },
    { symbol: "NZF", name: "Nuveen Municipal Credit Income Fund" },
    { symbol: "ESIM", name: "Eventide International ETF" },
    { symbol: "SLN", name: "Silence Therapeutics Plc American Depository Share" },
    { symbol: "CCS", name: "CENTURY COMMUNITIES, INC." },
    { symbol: "EH", name: "EHang Holdings Limited ADS" },
    { symbol: "PESI", name: "Perma-Fix Environmental Services, Inc. Common Stock" },
    { symbol: "CFFN", name: "Capitol Federal Financial, Inc. Common Stock" },
    { symbol: "BGSI", name: "Boyd Group Services Inc." },
    { symbol: "IIIV", name: "i3 Verticals, Inc. Class A Common Stock" },
    { symbol: "BV", name: "BrightView Holdings, Inc. Common Stock" },
    { symbol: "INGM", name: "Ingram Micro Holding Corporation" },
    { symbol: "OGC", name: "OceanaGold Corporation" },
    { symbol: "NMRK", name: "Newmark Group, Inc. Class A Common Stock" },
    { symbol: "FELC", name: "Fidelity Enhanced Large Cap Core ETF" },
    { symbol: "KOP", name: "Koppers Holdings, Inc." },
    { symbol: "WINA", name: "Winmark Corporation Common Stock" },
    { symbol: "GRC", name: "The Gorman-Rupp Company Common Shares" },
    { symbol: "AMRC", name: "Ameresco, Inc." },
    { symbol: "ROOT", name: "Root, Inc. Class A Common Stock" },
    { symbol: "TPB", name: "Turning Point Brands, Inc." },
    { symbol: "ACRS", name: "Aclaris Therapeutics, Inc. Common Stock" },
    { symbol: "IART", name: "Integra LifeSciences Holdings Corporation Common Stock" },
    { symbol: "GLRE", name: "Greenlight Capital Re, Ltd. Class A Ordinary Shares" },
    { symbol: "JKS", name: "JINKOSOLAR HOLDINGS CO" },
    { symbol: "CRCT", name: "Cricut, Inc. Class A Common Stock" },
    { symbol: "FDUS", name: "Fidus Investment Corporation Common Stock" },
    { symbol: "CTGO", name: "Contango Silver & Gold Inc." },
    { symbol: "KREF", name: "KKR Real Estate Finance Trust Inc." },
    { symbol: "MPLT", name: "MapLight Therapeutics, Inc. Common Stock" },
    { symbol: "NTGR", name: "NETGEAR, Inc. Common Stock" },
    { symbol: "BOH", name: "Bank of Hawaii Corp." },
    { symbol: "CNA", name: "CNA Financial Corporation" },
    { symbol: "FBNC", name: "First Bancorp Common Stock" },
    { symbol: "OSS", name: "One Stop Systems, Inc. Common Stock" },
    { symbol: "MCBS", name: "MetroCity Bankshares, Inc. Common Stock" },
    { symbol: "FBRT", name: "Franklin BSP Realty Trust, Inc." },
    { symbol: "PMT", name: "PennyMac Mortgage Investment Trust" },
    { symbol: "FDMT", name: "4D Molecular Therapeutics, Inc. Common Stock" },
    { symbol: "ABM", name: "ABM Industries, Inc." },
    { symbol: "NP", name: "Neptune Insurance Holdings Inc." },
    { symbol: "UHT", name: "Universal Health Realty Income Trust" },
    { symbol: "EVC", name: "Entravision Communication" },
    { symbol: "PAL", name: "Proficient Auto Logistics, Inc. Common Stock" },
    { symbol: "WS", name: "Worthington Steel, Inc." },
    { symbol: "AGEN", name: "Agenus Inc. Common Stock" },
    { symbol: "ECVT", name: "Ecovyst Inc." },
    { symbol: "SMTI", name: "Sanara MedTech Inc. Common Stock" },
    { symbol: "OMAB", name: "Grupo Aeroportuario del Centro Norte S.A.B. de C.V. ADS" },
    { symbol: "BWLP", name: "BW LPG Limited" },
    { symbol: "TFIN", name: "Triumph Financial, Inc." },
    { symbol: "FSUN", name: "FirstSun Capital Bancorp Common Stock" },
    { symbol: "ELE", name: "Elemental Royalty Corporation Common Stock" },
    { symbol: "TMP", name: "Tompkins Financial Corporation" },
    { symbol: "CUBI", name: "CUSTOMERS BANCORP INC" },
    { symbol: "GLP", name: "Global Partners LP" },
    { symbol: "AMAL", name: "Amalgamated Financial Corp. Common Stock (DE)" },
    { symbol: "RYAM", name: "Rayonier Advanced Materials Inc." },
    { symbol: "KRNT", name: "Kornit Digital Ltd. Ordinary Shares" },
    { symbol: "TBPH", name: "Theravance Biopharma, Inc. Ordinary Shares" },
    { symbol: "ALRS", name: "Alerus Financial Corporation Common Stock" },
    { symbol: "STBA", name: "S&T Bancorp, Inc. Common Stock" },
    { symbol: "EGY", name: "Vaalco Energy, Inc." },
    { symbol: "CENTA", name: "Central Garden & Pet Company Class A Common Stock Nonvoting" },
    { symbol: "CLB", name: "Core Laboratories Inc." },
    { symbol: "GDOT", name: "Green Dot Corporation" },
    { symbol: "DMII", name: "Drugs Made In America Acquisition II Corp. Ordinary Shares" },
    { symbol: "SPAI", name: "Safe Pro Group Inc. Common Stock" },
    { symbol: "RRBI", name: "Red River Bancshares, Inc. Common Stock" },
    { symbol: "CHMG", name: "Chemung Financial Corp Common Stock" },
    { symbol: "PSFE", name: "Paysafe Limited" },
    { symbol: "CNOB", name: "ConnectOne Bancorp, Inc. Common Stock" },
    { symbol: "NBN", name: "Northeast Bank Common Stock" },
    { symbol: "MNTN", name: "MNTN, Inc." },
    { symbol: "PERI", name: "Perion Network Ltd. Ordinary Shares" },
    { symbol: "FWRD", name: "Forward Air Corporation Common Stock" },
    { symbol: "PTLO", name: "Portillo's Inc. Class A Common Stock" },
    { symbol: "AVO", name: "Mission Produce, Inc. Common Stock" },
    { symbol: "PFLT", name: "PennantPark Floating Rate Capital Ltd." },
    { symbol: "WAFD", name: "WaFd, Inc. Common Stock" },
    { symbol: "FLXS", name: "Flexsteel Industries, Inc. Common Stock" },
    { symbol: "BKV", name: "BKV Corporation" },
    { symbol: "JBSS", name: "John B. Sanfilippo & Son, Inc. Common Stock" },
    { symbol: "GILT", name: "Gilat Satellite Networks Ltd. Ordinary Shares" },
    { symbol: "LWAY", name: "Lifeway Foods, Inc. Common Stock" },
    { symbol: "OPRX", name: "OptimizeRx Corporation Common Stock" },
    { symbol: "GLIBK", name: "Liberty Capital Corporation Series C GCI Group Common Stock" },
    { symbol: "EIKN", name: "Eikon Therapeutics, Inc. Common Stock" },
    { symbol: "CCSI", name: "Consensus Cloud Solutions, Inc. Common Stock" },
    { symbol: "HNI", name: "HNI Corporation" },
    { symbol: "IMSR", name: "Terrestrial Energy Inc. Common Stock" },
    { symbol: "FSCO", name: "FS Credit Opportunities Corp." },
    { symbol: "FET", name: "Forum Energy Technologies, Inc." },
    { symbol: "REF", name: "Reformation Inc." },
    { symbol: "LAKE", name: "Lakeland Industries, Inc. Common Stock" },
    { symbol: "AURA", name: "Aura Biosciences, Inc. Common Stock" },
    { symbol: "ASPN", name: "Aspen Aerogels, Inc." },
    { symbol: "TREE", name: "LendingTree, Inc. Common Stock" },
    { symbol: "MASS", name: "908 Devices Inc. Common Stock" },
    { symbol: "SUJA", name: "Suja Life, Inc. Class A Common Stock" },
    { symbol: "NMIH", name: "NMI Holdings Inc. Common Stock" },
    { symbol: "CGNT", name: "Cognyte Software Ltd. Ordinary Shares" },
    { symbol: "DMC", name: "Del Monte Corporation" },
    { symbol: "EMA", name: "Emera Incorporated" },
    { symbol: "MEC", name: "Mayville Engineering Company, Inc." },
    { symbol: "FNKO", name: "Funko, Inc. Class A Common Stock" },
    { symbol: "NSSC", name: "NAPCO Security Technologies, Inc. Common Stock" },
    { symbol: "APEI", name: "American Public Education, Inc. Common Stock" },
    { symbol: "SLRC", name: "SLR Investment Corp. Common Stock" },
    { symbol: "INDB", name: "Independent Bank Corp. Common Stock" },
    { symbol: "NVRI", name: "Enviri Corporation" },
    { symbol: "NEXA", name: "Nexa Resources S.A. Common Shares" },
    { symbol: "NHP", name: "National Healthcare Properties, Inc. Class A Common Stock" },
    { symbol: "EVV", name: "Eaton Vance Limited Duration Income Fund" },
    { symbol: "SB", name: "Safe Bulkers, Inc." },
    { symbol: "EVMN", name: "Evommune, Inc." },
    { symbol: "GEL", name: "Genesis Energy, L.P." },
    { symbol: "LAND", name: "Gladstone Land Corporation Common Stock" },
    { symbol: "ADAM", name: "Adamas Trust, Inc. Common Stock" },
    { symbol: "LKFN", name: "Lakeland Financial Corporation Common Stock" },
    { symbol: "FEIM", name: "Frequency Electronics, Inc. Common Stock" },
    { symbol: "CSTL", name: "Castle Biosciences, Inc. Common Stock" },
    { symbol: "ODC", name: "Oil-Dri Corporation of America" },
    { symbol: "LADR", name: "LADDER CAPITAL CORP" },
    { symbol: "MATV", name: "Mativ Holdings, Inc." },
    { symbol: "GTN", name: "Gray Media, Inc." },
    { symbol: "RWX", name: "State Street SPDR Dow Jones International Real Estate ETF" },
    { symbol: "MF", name: "MindForge Inc. Class A Ordinary Shares" },
    { symbol: "SPIR", name: "Spire Global, Inc." },
    { symbol: "ZAP", name: "Global X Funds Global X U.S. Electrification ETF" },
    { symbol: "NBTB", name: "NBT Bancorp Inc. Common Stock" },
    { symbol: "AGRO", name: "ADECOAGRO S.A." },
    { symbol: "ILPT", name: "Industrial Logistics Properties Trust Common Shares of Beneficial Interest" },
    { symbol: "PAYO", name: "Payoneer Global Inc. Common Stock" },
    { symbol: "ALMU", name: "Aeluma, Inc. Common Stock" },
    { symbol: "CNNE", name: "Cannae Holdings, Inc. Common Stock" },
    { symbol: "SMIN", name: "iShares MSCI India Small-Cap ETF" },
    { symbol: "ACNB", name: "ACNB Corporation Common Stock" },
    { symbol: "IFS", name: "Intercorp Financial Services Inc." },
    { symbol: "MGEE", name: "MGE Energy, Inc" },
    { symbol: "FOXF", name: "Fox Factory Holding Corp. Common Stock" },
    { symbol: "HMN", name: "Horace Mann Educators Corporation" },
    { symbol: "GABC", name: "German American Bancorp, Inc. Common Stock" },
    { symbol: "CHCO", name: "City Holding Company Common Stock" },
    { symbol: "TRMK", name: "Trustmark Corporation Common Stock" },
    { symbol: "EMD", name: "Western Asset Emerging Markets Debt Fund, Inc" },
    { symbol: "ITRN", name: "Ituran Location and Control Ltd. Ordinary Shares" },
    { symbol: "STLN", name: "Starling Oncology, Inc. Common Stock" },
    { symbol: "CRNC", name: "Cerence Inc. Common Stock" },
    { symbol: "CCNE", name: "CNB Financial Corporation Common Stock" },
    { symbol: "NWBI", name: "Northwest Bancshares, Inc. Common Stock" },
    { symbol: "CENT", name: "Central Garden & Pet Company Common Stock" },
    { symbol: "VEL", name: "Velocity Financial, Inc." },
    { symbol: "ASTE", name: "Astec Industries, Inc. Common Stock" },
    { symbol: "GIII", name: "G-III Apparel Group, LTD. Common Stock" },
    { symbol: "LCLN", name: "Lincoln International, Inc." },
    { symbol: "WABC", name: "Westamerica Bancorporation Common Stock" },
    { symbol: "CSR", name: "Centerspace" },
    { symbol: "SCSC", name: "ScanSource, Inc. Common Stock" },
    { symbol: "FOSL", name: "Fossil Group, Inc. Common Stock" },
    { symbol: "TK", name: "Teekay Corporation Ltd." },
    { symbol: "FLNG", name: "FLEX LNG Ltd. Ordinary Shares" },
    { symbol: "FMBH", name: "First Mid Bancshares, Inc. Common Stock" },
    { symbol: "PRAA", name: "PRA Group, Inc. Common Stock" },
    { symbol: "FVRR", name: "Fiverr International Ltd." },
    { symbol: "NMR", name: "Nomura Holdings, Inc" },
    { symbol: "SMCY", name: "YieldMax SMCI Option Income Strategy ETF" },
    { symbol: "SHBI", name: "Shore Bancshares Inc Common Stock" },
    { symbol: "GPGI", name: "GPGI, Inc." },
    { symbol: "ADUR", name: "Aduro Clean Technologies Inc. Common Stock" },
    { symbol: "GLUE", name: "Monte Rosa Therapeutics, Inc. Common Stock" },
    { symbol: "FG", name: "F&G Annuities & Life, Inc." },
    { symbol: "CRTO", name: "Criteo S.A. Ordinary Shares" },
    { symbol: "SPH", name: "Suburban Propane Partners L P" },
    { symbol: "UVSP", name: "Univest Financial Corporation Common Stock" },
    { symbol: "ELVA", name: "Electrovaya Inc. Common Shares" },
    { symbol: "DIN", name: "Dine Brands Global, Inc." },
    { symbol: "GOLD", name: "Gold.com, Inc." },
    { symbol: "IDR", name: "Idaho Strategic Resources, Inc." },
    { symbol: "HRZN", name: "Horizon Technology Finance Corporation Common Stock" },
    { symbol: "BXC", name: "BlueLinx Holdings Inc." },
    { symbol: "MYE", name: "Myers Industries, Inc." },
    { symbol: "OCS", name: "Oculis Holding AG Ordinary shares" },
    { symbol: "SPRB", name: "Spruce Biosciences, Inc. Common Stock" },
    { symbol: "LTBR", name: "Lightbridge Corporation Common Stock" },
    { symbol: "GIC", name: "Global Industrial Company" },
    { symbol: "QTTB", name: "Q32 Bio Inc. Common Stock" },
    { symbol: "AKTS", name: "Aktis Oncology, Inc. Common stock" },
    { symbol: "FCBC", name: "First Community Bankshares, Inc. (VA) Common Stock" },
    { symbol: "SENS", name: "Senseonics Holdings, Inc. Common Stock" },
    { symbol: "ALMR", name: "Alamar Biosciences, Inc. Common Stock" },
    { symbol: "TEN", name: "Tsakos Energy Navigation Ltd." },
    { symbol: "OSPN", name: "OneSpan Inc. Common Stock" },
    { symbol: "PNTG", name: "The Pennant Group, Inc. Common Stock" },
    { symbol: "GAIN", name: "Gladstone Investment Corporation Business Development Company" },
    { symbol: "MAZE", name: "Maze Therapeutics, Inc. Common Stock" },
    { symbol: "ATS", name: "ATS Corporation" },
    { symbol: "EFXT", name: "Enerflex Ltd." },
    { symbol: "MATW", name: "Matthews International Corporation Class A Common Stock" },
    { symbol: "CRF", name: "Cornerstone Total Return Fund, Inc" },
    { symbol: "CRBP", name: "Corbus Pharmaceuticals Holdings, Inc. Common Stock" },
    { symbol: "OBT", name: "Orange County Bancorp, Inc. Common Stock" },
    { symbol: "EXG", name: "Eaton Vance Tax-Managed Global Diversified Equity Income Fund" },
    { symbol: "WMK", name: "Weis Markets, Inc." },
    { symbol: "VOXR", name: "Vox Royalty Corp. Common Stock" },
    { symbol: "SPOK", name: "Spok Holdings, Inc. Common Stock" },
    { symbol: "DUOT", name: "Duos Technologies Group, Inc. Common Stock" },
    { symbol: "NEXN", name: "Nexxen International Ltd. Ordinary Shares" },
    { symbol: "TNXP", name: "Tonix Pharmaceuticals Holding Corp. Common Stock" },
    { symbol: "FBIZ", name: "First Business Financial Services, Inc. Common Stock" },
    { symbol: "OPFI", name: "OppFi Inc." },
    { symbol: "AD", name: "Array Digital Infrastructure, Inc." },
    { symbol: "HFWA", name: "Heritage Financial Corporation Common Stock" },
    { symbol: "FRST", name: "Primis Financial Corp. Common Stock" },
    { symbol: "BIOA", name: "BioAge Labs, Inc. Common Stock" },
    { symbol: "CYRX", name: "CryoPort, Inc. Common Stock" },
    { symbol: "HSHP", name: "Himalaya Shipping Ltd." },
    { symbol: "EGBN", name: "Eagle Bancorp, Inc. Common Stock" },
    { symbol: "KARD", name: "Kardigan, Inc. Common Stock" },
    { symbol: "OXM", name: "Oxford Industries, Inc." },
    { symbol: "MTUS", name: "Metallus Inc." },
    { symbol: "UNFI", name: "United Natural Foods Inc" },
    { symbol: "PLBC", name: "Plumas Bancorp" },
    { symbol: "PRTA", name: "Prothena Corporation plc Ordinary Shares" },
    { symbol: "TKNO", name: "Alpha Teknova, Inc. Common Stock" },
    { symbol: "GLAD", name: "Gladstone Capital Corporation Common Stock" },
    { symbol: "GSIT", name: "GSI Technology Common Stock" },
    { symbol: "EIG", name: "Employers Holdings, Inc." },
    { symbol: "IMTX", name: "Immatics N.V. Ordinary Shares" },
    { symbol: "GOOD", name: "Gladstone Commercial Corporation Real Estate Investment Trust" },
    { symbol: "AVBC", name: "Avidia Bancorp, Inc." },
    { symbol: "SHOE", name: "Shoe Station Group, Inc. Common Stock" },
    { symbol: "BKKT", name: "Bakkt, Inc." },
    { symbol: "CPAC", name: "CEMENTOS PACASMAYO S.A.A." },
    { symbol: "VNDA", name: "Vanda Pharmaceuticals Inc. Common Stock" },
    { symbol: "PAYS", name: "Paysign, Inc. Common Stock" },
    { symbol: "BMRC", name: "Bank of Marin Bancorp Common Stock" },
    { symbol: "RXST", name: "RxSight, Inc. Common Stock" },
    { symbol: "VTOL", name: "Bristow Group Inc." },
    { symbol: "HSTM", name: "HealthStream, Inc. Common Stock" },
    { symbol: "CTS", name: "CTS Corporation" },
    { symbol: "VEON", name: "VEON Ltd. ADS" },
    { symbol: "SIF", name: "SIFCO Industries, Inc." },
    { symbol: "WD", name: "Walker & Dunlop, Inc." },
    { symbol: "UVV", name: "Universal Corporation" },
    { symbol: "WASH", name: "Washington Trust Bancorp, Inc. Common Stock" },
    { symbol: "CARE", name: "Carter Bankshares, Inc. Common Stock" },
    { symbol: "KE", name: "Kimball Electronics, Inc. Common Stock" },
    { symbol: "STC", name: "Stewart Information Services Corporation" },
    { symbol: "HTH", name: "HILLTOP HOLDINGS INC." },
    { symbol: "IPI", name: "Intrepid Potash, Inc" },
    { symbol: "SCHL", name: "Scholastic Corporation Common Stock" },
    { symbol: "CARS", name: "Cars.com Inc. Common Stock" },
    { symbol: "CCB", name: "Coastal Financial Corporation Common Stock" },
    { symbol: "AVR", name: "Anteris Technologies Global Corp. Common Stock" },
    { symbol: "BY", name: "Byline Bancorp, Inc. Common Stock" },
    { symbol: "HWBK", name: "Hawthorn Bancshares, Inc. Common Stock" },
    { symbol: "DRNZ", name: "REX ETF Trust REX Drone ETF" },
    { symbol: "ZTG", name: "Zenta Group Company Limited Class A Ordinary Shares" },
    { symbol: "SMBK", name: "SmartFinancial, Inc." },
    { symbol: "REPX", name: "Riley Exploration Permian, Inc." },
    { symbol: "FPI", name: "Farmland Partners Inc." },
    { symbol: "RILY", name: "BRC Group Holdings, Inc. Common Stock" },
    { symbol: "MPB", name: "Mid Penn Bancorp Common Stock" },
    { symbol: "BBUC", name: "Brookfield Business Corporation Class A Subordinate Voting Shares" },
    { symbol: "BVS", name: "Bioventus Inc. Class A Common Stock" },
    { symbol: "PSTL", name: "Postal Realty Trust, Inc" },
    { symbol: "TECX", name: "Tectonic Therapeutic, Inc. Common Stock" },
    { symbol: "CMCO", name: "Columbus McKinnon Corporation Common Stock" },
    { symbol: "DFIN", name: "Donnelley Financial Solutions, Inc." },
    { symbol: "EDEN", name: "iShares MSCI Denmark ETF" },
    { symbol: "GENB", name: "Generate Biomedicines, Inc. Common Stock" },
    { symbol: "BNTC", name: "Benitec Biopharma Inc. Common Stock" },
    { symbol: "XMAX", name: "XMAX, Inc. Common Stock" },
    { symbol: "ETW", name: "Eaton Vance Tax-Managed Global Buy-Write Opportunities Fund" },
    { symbol: "BBSI", name: "Barrett Business Services, Inc. Common Stock" },
    { symbol: "BSM", name: "Black Stone Minerals, L.P." },
    { symbol: "TCMD", name: "Tactile Systems Technology, Inc. Common Stock" },
    { symbol: "DAKT", name: "Daktronics, Inc. Common Stock" },
    { symbol: "PBYI", name: "Puma Biotechnology Inc Common Stock" },
    { symbol: "VMD", name: "Viemed Healthcare, Inc. Common Shares" },
    { symbol: "ASIX", name: "AdvanSix Inc." },
    { symbol: "ARVN", name: "Arvinas, Inc. Common Stock" },
    { symbol: "BOXL", name: "Boxlight Corporation Class A Common Stock" },
    { symbol: "CTO", name: "CTO Realty Growth, Inc." },
    { symbol: "SHMD", name: "SCHMID Group N.V. Class A Ordinary Shares" },
    { symbol: "BLCO", name: "Bausch + Lomb Corporation" },
    { symbol: "WQTM", name: "WisdomTree Quantum Computing Fund" },
    { symbol: "CMP", name: "Compass Minerals International, Inc." },
    { symbol: "TOYO", name: "TOYO Co., Ltd Ordinary Shares" },
    { symbol: "SBGI", name: "Sinclair, Inc. Class A Common Stock" },
    { symbol: "CAL", name: "Caleres Inc" },
    { symbol: "SIBN", name: "SI-BONE, Inc. Common Stock" },
    { symbol: "PRTH", name: "Priority Technology Holdings, Inc. Common Stock" },
    { symbol: "JILL", name: "J.Jill, Inc. Common Stock" },
    { symbol: "LILA", name: "Liberty Latin America Ltd. Class A Common Stock" },
    { symbol: "PINE", name: "Alpine Income Property Trust, Inc" },
    { symbol: "APC", name: "ARKO Petroleum Corp. Class A Common Stock" },
    { symbol: "HSLV", name: "Highlander Silver Corp." },
    { symbol: "RJET", name: "Republic Airways Holdings Inc. Common Stock" },
    { symbol: "TR", name: "Tootsie Roll Industries, Inc." },
    { symbol: "CWBC", name: "Community West Bancshares Common Stock" },
    { symbol: "OPI", name: "Office Properties Income Trust Common shares of beneficial interest" },
    { symbol: "FC", name: "Franklin Covey Company" },
    { symbol: "OPRT", name: "Oportun Financial Corporation Common Stock" },
    { symbol: "MFA", name: "MFA Financial, Inc" },
    { symbol: "DFH", name: "Dream Finders Homes, Inc." },
    { symbol: "AVBH", name: "Avidbank Holdings, Inc. Common Stock" },
    { symbol: "HPP", name: "Hudson Pacific Properties, Inc." },
    { symbol: "LMRI", name: "Lumexa Imaging Holdings, Inc. Common Stock" },
    { symbol: "LYTS", name: "LSI Industries Inc. Common Stock" },
    { symbol: "KRO", name: "Kronos Worldwide, Inc." },
    { symbol: "GTE", name: "Gran Tierra Energy Inc." },
    { symbol: "OFRM", name: "Once Upon a Farm, PBC" },
    { symbol: "DRVN", name: "Driven Brands Holdings Inc. Common Stock" },
    { symbol: "MAGH", name: "Magnitude International Ltd Ordinary Shares" },
    { symbol: "TTAM", name: "Titan America SA" },
    { symbol: "CBIO", name: "Crescent Biopharma, Inc. Common Stock" },
    { symbol: "ALCO", name: "Alico, Inc. Common Stock" },
    { symbol: "SRTA", name: "Strata Critical Medical, Inc. Class A Common Stock" },
    { symbol: "SCZM", name: "Santacruz Silver Mining Ltd. Common Shares" },
    { symbol: "NXRT", name: "NexPoint Residential Trust Inc" },
    { symbol: "NLOP", name: "Net Lease Office Properties" },
    { symbol: "TAYD", name: "Taylor Devices, Inc. Common Stock" },
    { symbol: "DRD", name: "DRDGOLD Ltd." },
    { symbol: "QUAD", name: "QUAD/GRAPHICS, INC." },
    { symbol: "NEGG", name: "Newegg Commerce, Inc. Common Shares" },
    { symbol: "VMET", name: "Versamet Royalties Corporation Common Stock" },
    { symbol: "GCMG", name: "GCM Grosvenor Inc. Class A Common Stock" },
    { symbol: "DRTS", name: "Alpha Tau Medical Ltd. Ordinary Shares" },
    { symbol: "RMNI", name: "Rimini Street, Inc. (DE) Common Stock" },
    { symbol: "LEGH", name: "Legacy Housing Corporation Common Stock (TX)" },
    { symbol: "NBBK", name: "NB Bancorp, Inc. Common Stock" },
    { symbol: "EOLS", name: "Evolus, Inc. Common Stock" },
    { symbol: "PANL", name: "Pangaea Logistics Solutions Ltd. Common Shares" },
    { symbol: "SWMR", name: "Swarmer, Inc Common Stock" },
    { symbol: "ODD", name: "ODDITY Tech Ltd. Class A Ordinary Shares" },
    { symbol: "APOG", name: "Apogee Enterprises, Inc. Common Stock" },
    { symbol: "CAAP", name: "Corporacion America Airports S.A." },
    { symbol: "STRZ", name: "Starz Entertainment Corp. Common Shares" },
    { symbol: "OIS", name: "OIL STATES INTERNATIONAL, INC." },
    { symbol: "JBGS", name: "JBG SMITH Properties Common Shares" },
    { symbol: "NX", name: "Quanex Building Products Corporation" },
    { symbol: "FLGT", name: "Fulgent Genetics, Inc. Common Stock" },
    { symbol: "WBTN", name: "WEBTOON Entertainment Inc. Common stock" },
    { symbol: "MNSB", name: "MainStreet Bancshares, Inc. Common Stock" },
    { symbol: "DLX", name: "Deluxe Corporation" },
    { symbol: "CABO", name: "Cable One, Inc." },
    { symbol: "HELE", name: "Helen of Troy Limited Common Stock" },
    { symbol: "RDNW", name: "RideNow Group, Inc. Class B Common Stock" },
    { symbol: "BSVN", name: "Bank7 Corp. Common stock" },
    { symbol: "TWI", name: "Titan International, Inc.(Delaware)" },
    { symbol: "BWB", name: "Bridgewater Bancshares, Inc. Common Stock" },
    { symbol: "CION", name: "CION Investment Corporation" },
    { symbol: "KRUS", name: "Kura Sushi USA, Inc. Class A Common Stock" },
    { symbol: "NVCT", name: "Nuvectis Pharma, Inc. Common Stock" },
    { symbol: "KRNY", name: "Kearny Financial Corp Common Stock" },
    { symbol: "HAFC", name: "Hanmi Financial Corporation Common Stock" },
    { symbol: "MNR", name: "Mach Natural Resources LP Common Units representing Limited Partner Interests" },
    { symbol: "MAAS", name: "Maase Inc. Class A Ordinary Shares" },
    { symbol: "HTB", name: "HomeTrust Bancshares, Inc." },
    { symbol: "CBLL", name: "CeriBell, Inc. Common Stock" },
    { symbol: "FXHO", name: "UTime Limited Class A Ordinary Shares" },
    { symbol: "UTMD", name: "Utah Medical Products, Inc. Common Stock" },
    { symbol: "ATLO", name: "Ames National Corporation Common Stock" },
    { symbol: "GFR", name: "Greenfire Resources Ltd." },
    { symbol: "ODTX", name: "Odyssey Therapeutics, Inc. Common Stock" },
    { symbol: "AVIR", name: "Atea Pharmaceuticals, Inc. Common Stock" },
    { symbol: "NVGS", name: "NAVIGATOR HOLDINGS LTD." },
    { symbol: "PRGS", name: "Progress Software Corporation Common Stock (DE)" },
    { symbol: "NGL", name: "NGL ENERGY PARTNERS LP" },
    { symbol: "RCEL", name: "Avita Medical, Inc. Common Stock" },
    { symbol: "SUPV", name: "Grupo Supervielle S.A." },
    { symbol: "IMRX", name: "Immuneering Corporation Class A Common Stock" },
    { symbol: "SLVM", name: "Sylvamo Corporation" },
    { symbol: "PHR", name: "Phreesia, Inc." },
    { symbol: "NPCE", name: "Neuropace, Inc. Common Stock" },
    { symbol: "NRC", name: "NRC Health Common Stock" },
    { symbol: "ZUMZ", name: "Zumiez Inc. Common Stock" },
    { symbol: "KODK", name: "EASTMAN KODAK COMPANY" },
    { symbol: "CBU", name: "Community Financial System, Inc." },
    { symbol: "SRBK", name: "SR Bancorp, Inc. Common stock" },
    { symbol: "WHK", name: "WhiteHawk Minerals Corp." },
    { symbol: "ETD", name: "Ethan Allen Interiors Inc" },
    { symbol: "BRSP", name: "BrightSpire Capital, Inc." },
    { symbol: "HQ", name: "Horizon Quantum Holdings Ltd. Class A Ordinary Shares" },
    { symbol: "KROS", name: "Keros Therapeutics, Inc. Common Stock" },
    { symbol: "MLR", name: "Miller Industries, Inc." },
    { symbol: "DCBO", name: "Docebo Inc. Common Shares" },
  ],
};

export const WATCHLIST_STOCKS = [
  ...STOCK_CATEGORIES.tech.slice(0, 6),
  ...STOCK_CATEGORIES.etfs.slice(0, 5),
  ...STOCK_CATEGORIES.finance.slice(0, 2),
  ...STOCK_CATEGORIES.ev_energy.slice(0, 2),
];

export function getAllStocks() {
  // Update 4.0 (9/11/26): concat the ADV-vetted expansion (lib/universe-extra.ts),
  // deduped by symbol. Existing curated names take precedence. Reversible: remove the
  // UNIVERSE_EXTRA concat line below to revert to the original curated universe.
  const combined = [...Object.values(STOCK_CATEGORIES).flat(), ...UNIVERSE_EXTRA];
  const seen = new Set<string>();
  const out: { symbol: string; name: string }[] = [];
  for (const s of combined) {
    const k = s.symbol.toUpperCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(s);
  }
  return out;
}

export function getStocksByCategory(category: keyof typeof STOCK_CATEGORIES) {
  return STOCK_CATEGORIES[category] || [];
}

// Classify a trade based on heat, indicators, and market conditions
function classifyTrade(
  heat: number,
  rsi: number,
  volumeRatio: number,
  changePercent: number,
  heatResult: HeatTrackerResult
): TradeClassification {
  const absHeat = Math.abs(heat);
  const direction = heat > 0 ? 'buy' : 'sell';
  const { momentumHeat, volumeHeat, candlestickHeat, trendHeat } = heatResult.components;
  const hasCandlestickSignal = Math.abs(candlestickHeat) >= 5;
  const hasVolumeSurge = Math.abs(volumeHeat) >= 15;
  const hasStrongMomentum = Math.abs(momentumHeat) >= 10;
  const hasTrend = Math.abs(trendHeat) >= 5;
  
  const reasons: string[] = [];
  
  // INTRADAY: High heat + volume surge + strong short-term momentum
  // These are fast-moving setups where ROI is expected within minutes to hours
  if (absHeat >= 60 && (hasVolumeSurge || hasStrongMomentum)) {
    reasons.push('Heat score above 60 indicates strong immediate pressure');
    if (hasVolumeSurge) reasons.push(`Volume surge detected (${Math.abs(volumeHeat).toFixed(0)} volume heat)`);
    if (hasStrongMomentum) reasons.push('Strong short-term momentum detected');
    if (hasCandlestickSignal) reasons.push(`Candlestick pattern confirms ${direction} signal`);
    if (rsi < 25 || rsi > 75) reasons.push(`Extreme RSI (${rsi.toFixed(0)}) suggests imminent reversal`);
    
    return {
      tradeType: 'intraday',
      label: '⚡ Intraday Trade',
      roiTimeline: 'Minutes to hours',
      expectedHoldTime: '15 min - 4 hours',
      whyThisCategory: reasons,
      exitStrategy: `Watch for heat reversal below ${heat > 0 ? '20' : '-20'}. Set tight stop-loss at ${heat > 0 ? 'recent low' : 'recent high'}.`,
    };
  }
  
  // SHORT-TERM SWING: Moderate heat + trend alignment + support/resistance
  // ROI expected in 1-5 days
  if (absHeat >= 35 && (hasTrend || hasCandlestickSignal)) {
    reasons.push(`Heat score of ${absHeat} shows building momentum`);
    if (hasTrend) reasons.push(`EMA trend alignment confirms ${direction} direction`);
    if (hasCandlestickSignal) reasons.push('Candlestick pattern supports entry');
    if (rsi < 35 || rsi > 65) reasons.push(`RSI (${rsi.toFixed(0)}) in ${rsi < 35 ? 'oversold' : 'overbought'} territory`);
    if (Math.abs(changePercent) > 1) reasons.push(`${Math.abs(changePercent).toFixed(1)}% price move shows directional pressure`);
    
    return {
      tradeType: 'short_swing',
      label: '📈 Short-Term Swing',
      roiTimeline: '1-5 days',
      expectedHoldTime: '1-5 trading days',
      whyThisCategory: reasons,
      exitStrategy: `Target ${heat > 0 ? '2-3%' : '-2-3%'} move. Exit if heat drops below ${heat > 0 ? '10' : '-10'} or RSI ${heat > 0 ? 'exceeds 70' : 'drops below 30'}.`,
    };
  }
  
  // LONG-TERM SWING: Trend + RSI position + multiple indicators aligning
  // ROI expected in 1-4 weeks
  if (absHeat >= 20) {
    reasons.push(`Heat score of ${absHeat} shows directional bias`);
    if (hasTrend) reasons.push('EMA trend in favorable direction');
    if (rsi < 40 || rsi > 60) reasons.push(`RSI (${rsi.toFixed(0)}) suggests room for continuation`);
    if (heatResult.components.priceActionHeat > 5) reasons.push('Price near support - favorable entry');
    if (heatResult.components.priceActionHeat < -5) reasons.push('Price near resistance - favorable short entry');
    if (!reasons.some(r => r.includes('Candlestick')) && hasCandlestickSignal) {
      reasons.push('Candlestick confirmation present');
    }
    
    return {
      tradeType: 'long_swing',
      label: '📅 Long-Term Swing',
      roiTimeline: '1-4 weeks',
      expectedHoldTime: '5-20 trading days',
      whyThisCategory: reasons,
      exitStrategy: `Target ${heat > 0 ? '5-8%' : '-5-8%'} move. Trail stop at ${heat > 0 ? 'rising' : 'falling'} EMA21. Re-evaluate weekly.`,
    };
  }
  
  // Default: not a strong enough signal for any classification
  return {
    tradeType: 'long_swing',
    label: '⏸️ Watch & Wait',
    roiTimeline: 'No clear timeline',
    expectedHoldTime: 'N/A - signal too weak',
    whyThisCategory: ['Heat score below actionable threshold', 'Wait for stronger confirmation'],
    exitStrategy: 'No trade recommended at this time.',
  };
}

function getRecommendation(heat: number, rsi: number, volumeRatio: number, changePercent: number, tradeType: TradeType): ScreenerResult['recommendation'] {
  const absHeat = Math.abs(heat);
  
  // Confidence based on alignment of multiple indicators
  let confidence: 'HIGH' | 'MEDIUM' | 'LOW' = 'LOW';
  if (absHeat >= 60) confidence = 'HIGH';
  else if (absHeat >= 35) confidence = 'MEDIUM';
  
  // Timeframe based on trade type
  let timeframe = '1-4 weeks (Long Swing)';
  if (tradeType === 'intraday') timeframe = '15 min - 4 hours (Intraday)';
  else if (tradeType === 'short_swing') timeframe = '1-5 days (Short Swing)';
  
  if (heat >= 60) {
    return {
      action: 'STRONG BUY',
      timeframe,
      confidence,
      reason: rsi < 30 ? 'Oversold bounce with volume' : 'Multiple bullish indicators aligned',
    };
  } else if (heat >= 35) {
    return {
      action: 'BUY',
      timeframe,
      confidence,
      reason: 'Bullish momentum with trend support',
    };
  } else if (heat >= 20) {
    return {
      action: 'LEAN BUY',
      timeframe,
      confidence: 'LOW',
      reason: 'Mild bullish bias - needs confirmation',
    };
  } else if (heat <= -60) {
    return {
      action: 'STRONG SHORT',
      timeframe,
      confidence,
      reason: rsi > 70 ? 'Overbought reversal with volume' : 'Multiple bearish indicators aligned',
    };
  } else if (heat <= -35) {
    return {
      action: 'SHORT',
      timeframe,
      confidence,
      reason: 'Bearish momentum with trend support',
    };
  } else if (heat <= -20) {
    return {
      action: 'LEAN SHORT',
      timeframe,
      confidence: 'LOW',
      reason: 'Mild bearish bias - needs confirmation',
    };
  } else {
    return {
      action: 'HOLD/WATCH',
      timeframe: 'Wait for clearer signal',
      confidence: 'LOW',
      reason: 'No clear directional bias',
    };
  }
}

export async function scanStock(symbol: string, name: string): Promise<ScreenerResult | null> {
  try {
    const [intradayData, quote, earnings] = await Promise.all([
      fetchIntradayData(symbol, '5m'),
      fetchQuote(symbol),
      fetchEarningsInfo(symbol).catch(() => null),
    ]);
    
    const heatResult = calculateHeatTracker(intradayData);
    
    // Classify the trade type
    const tradeClassification = classifyTrade(
      heatResult.heat,
      heatResult.indicators.rsi,
      heatResult.indicators.volumeRatio,
      quote.changePercent,
      heatResult
    );
    
    const recommendation = getRecommendation(
      heatResult.heat,
      heatResult.indicators.rsi,
      heatResult.indicators.volumeRatio,
      quote.changePercent,
      tradeClassification.tradeType
    );
    
    // Check earnings warning for this trade type
    const earningsTradeWarning = earnings ? getEarningsTradeWarning(earnings, tradeClassification.tradeType) : null;
    
    return {
      symbol,
      name,
      price: quote.price,
      change: quote.change,
      changePercent: quote.changePercent,
      heat: heatResult.heat,
      mode: heatResult.mode,
      isRedline: heatResult.isRedline,
      rsi: heatResult.indicators.rsi,
      volumeRatio: heatResult.indicators.volumeRatio,
      keyDrivers: heatResult.keyDrivers || [],
      candlestickPatterns: heatResult.candlestickPatterns || [],
      recommendation,
      tradeClassification,
      earnings: earnings || null,
      earningsTradeWarning,
    };
  } catch (error) {
    console.error(`Failed to scan ${symbol}:`, error);
    return null;
  }
}

export async function scanWatchlist(symbols?: { symbol: string; name: string }[]): Promise<ScreenerResult[]> {
  const stocksToScan = symbols || WATCHLIST_STOCKS;
  const results: ScreenerResult[] = [];
  
  for (const stock of stocksToScan) {
    const result = await scanStock(stock.symbol, stock.name);
    if (result) results.push(result);
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  
  return results;
}

```

---

## FILE: code/lib/trade-postmortem.ts

```typescript
import { prisma } from './db';
import type { RawLever } from './lever-reconciliation';

// ---------------------------------------------------------------------------
// EL#3 — Per-Trade Nightly Post-Mortem
//
// Read-only. Extends the worst-20 loss report to EVERY losing trade: for each
// one it asks "what could have been adjusted to make it work?" and classifies
// the loss as FIXABLE (our exit handling / entry timing / a broker-fill glitch)
// or a genuinely FALSE signal (the directional thesis was simply wrong, or the
// setup had no edge and chopped).
//
// For FALSE signals it records the trigger fingerprint (direction · heat band ·
// session) and mines the clean window for RECURRING false profiles, so we can
// propose exclusion rules that isolate those patterns OUT of future setups.
//
// Philosophy (owner directive 9/3): losses are analyzed by SYSTEM / SETUP
// failure mode, never by blaming a ticker. Nothing here changes live strategy —
// it proposes, reconciles, and feeds the learning loop.
// ---------------------------------------------------------------------------

const CLEAN_WINDOW_START_ET = '2026-08-28';
export const POSTMORTEM_RECIPIENT = 'misiti15@gmail.com';

// ---- ET helpers -----------------------------------------------------------
function etDayKey(d: Date): string {
  return d.toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
}
function etDayBounds(dateEt: string): { start: Date; end: Date } {
  const start = new Date(`${dateEt}T00:00:00-04:00`);
  const end = new Date(start.getTime() + 24 * 60 * 60 * 1000);
  return { start, end };
}
function fmtEtTime(d: Date | null): string {
  if (!d) return '\u2014';
  return d.toLocaleTimeString('en-US', { timeZone: 'America/New_York', hour: '2-digit', minute: '2-digit', hour12: false });
}
function round1(n: number): number { return Math.round(n * 10) / 10; }
function round2(n: number): number { return Math.round(n * 100) / 100; }

// ---- Types ----------------------------------------------------------------
export type Verdict = 'fixable' | 'false';
export type PmCategory =
  | 'bad_fill'          // fixable — execution / data glitch (no confirmed broker fill)
  | 'exit_giveback'     // fixable — the setup worked, our exit gave it back
  | 'entry_timing'      // fixable — fast reversal right after entry
  | 'false_directional' // false   — never went green, drove to a stop (thesis wrong)
  | 'false_weak';       // false   — no edge, chopped flat-to-red and expired

const CATEGORY_LABEL: Record<PmCategory, string> = {
  bad_fill: 'Execution / fill glitch',
  exit_giveback: 'Exit gave back a winner',
  entry_timing: 'Entry timing (fast reversal)',
  false_directional: 'False signal — thesis wrong',
  false_weak: 'False signal — no edge (chop)',
};
const CATEGORY_VERDICT: Record<PmCategory, Verdict> = {
  bad_fill: 'fixable',
  exit_giveback: 'fixable',
  entry_timing: 'fixable',
  false_directional: 'false',
  false_weak: 'false',
};

export interface PostmortemRow {
  symbol: string;
  direction: string;
  entryEt: string;
  exitEt: string;
  returnPct: number | null;
  pnlDollars: number | null;
  peakPct: number | null;
  troughPct: number | null;
  holdMin: number | null;
  exitReason: string | null;
  heat: number | null;
  sessionSlot: string | null;
  category: PmCategory;
  verdict: Verdict;
  diagnosis: string;   // what happened, in plain English
  fix: string;         // the concrete adjustment (or exclusion) to test
}

export interface CategoryStat {
  category: PmCategory;
  label: string;
  verdict: Verdict;
  count: number;
  pctOfLosers: number;
  netPnl: number;
}

export interface FalseProfile {
  fingerprint: string;   // e.g. "SHORT · heat 30-40 · open"
  direction: string;
  heatBand: string;
  session: string;
  count: number;
  netPnl: number;
  avgPct: number;
}

export interface PostmortemReport {
  dateEt: string;
  generatedAt: string;
  dayClosed: number;
  dayLosers: number;
  fixableCount: number;
  falseCount: number;
  fixablePnl: number;
  falsePnl: number;
  rows: PostmortemRow[];              // per-loser detail for the day
  windowStartEt: string;
  windowLosers: number;
  categories: CategoryStat[];         // clean-window category breakdown
  falseProfiles: FalseProfile[];      // recurring false-signal fingerprints (clean window)
  gaveBackWinners: number;            // winners that gave back >= half their peak
  gaveBackWinnersPct: number;
  summary: string[];
}

interface RawTrade {
  symbol: string; direction: string; entryPrice: number; entryTime: Date;
  exitPrice: number | null; exitTime: Date | null; exitReason: string | null;
  returnPct: number | null; pnlDollars: number | null; peakPct: number | null;
  troughPct: number | null; heat: number | null; sessionSlot: string | null;
  etHour: number | null; ruleName: string | null; alpacaExitId: string | null;
}

const TRADE_SELECT = {
  symbol: true, direction: true, entryPrice: true, entryTime: true,
  exitPrice: true, exitTime: true, exitReason: true, returnPct: true,
  pnlDollars: true, peakPct: true, troughPct: true, heat: true,
  sessionSlot: true, etHour: true, ruleName: true, alpacaExitId: true,
} as const;

function holdMinutes(t: RawTrade): number | null {
  if (!t.exitTime) return null;
  return Math.round((t.exitTime.getTime() - t.entryTime.getTime()) / 60000);
}
function heatBand(h: number | null): string {
  if (h === null) return 'heat n/a';
  const a = Math.abs(h);
  if (a < 30) return 'heat <30';
  if (a < 40) return 'heat 30-40';
  if (a < 50) return 'heat 40-50';
  return 'heat 50+';
}
function cleanFill(t: RawTrade): boolean {
  return !!(t.alpacaExitId && t.alpacaExitId.length > 0);
}

// ---- Per-trade classifier -------------------------------------------------
// First match wins. Every loser gets exactly one category + a concrete fix.
export function classifyLoser(t: RawTrade): { category: PmCategory; diagnosis: string; fix: string } {
  const peak = t.peakPct ?? 0;
  const trough = t.troughPct ?? 0;
  const hold = holdMinutes(t) ?? 999;
  const dir = t.direction.toUpperCase();

  // 1) Execution / data glitch — no confirmed broker fill on the exit.
  if (!cleanFill(t)) {
    return {
      category: 'bad_fill',
      diagnosis: `Exit had no confirmed broker fill (quote-derived), so the recorded ${t.returnPct}% may be an execution/data artifact rather than a real trade outcome.`,
      fix: 'Execution: require a confirmed Alpaca fill before recording the exit; ignore quote-derived exits in stats.',
    };
  }
  // 2) Exit gave back a winner — the setup was RIGHT, our exit handling failed.
  if (peak >= 1.5) {
    return {
      category: 'exit_giveback',
      diagnosis: `Reached +${round2(peak)}% (at/through the take-profit target) then closed ${t.returnPct}%. The signal worked; the exit gave the whole move back.`,
      fix: 'Exit handling: resting take-profit at target and/or tighter trailing activation — bank the move the setup earned.',
    };
  }
  if (peak >= 0.5) {
    return {
      category: 'exit_giveback',
      diagnosis: `Went +${round2(peak)}% green before reversing to ${t.returnPct}%. A real favorable move we failed to protect.`,
      fix: 'Exit handling: earlier trailing activation or a partial take-profit around +0.3\u20130.5%.',
    };
  }
  // 3) Entry timing — stopped out fast, barely/never green: entered into an adverse move.
  if (t.exitReason === 'stop_loss' && hold <= 10 && peak < 0.5) {
    return {
      category: 'entry_timing',
      diagnosis: `Stopped out in ${hold} min having peaked only +${round2(peak)}% (trough ${round2(trough)}%). We entered right before an adverse move — an entry-timing miss, not necessarily a bad thesis.`,
      fix: 'Entry timing: a short confirmation delay (1\u20132 bars/ticks) before committing, or avoid entering into an already-extended spike.',
    };
  }
  // 4) Never went meaningfully green — false signal.
  if (peak < 0.5) {
    if (t.exitReason === 'stop_loss' || t.exitReason === 'trailing_stop') {
      return {
        category: 'false_directional',
        diagnosis: `Never went green (peak +${round2(peak)}%), drove straight against us to a stop (trough ${round2(trough)}%). The ${dir} thesis was simply wrong here.`,
        fix: `Exclusion: isolate this trigger profile (${dir} \u00b7 ${heatBand(t.heat)} \u00b7 ${t.sessionSlot || 'n/a'}) and gate it out if it recurs.`,
      };
    }
    return {
      category: 'false_weak',
      diagnosis: `Never gained traction (peak +${round2(peak)}%), chopped flat-to-red and expired via ${t.exitReason || 'time'}. No edge — the setup produced no real move.`,
      fix: `Exclusion: this trigger profile (${dir} \u00b7 ${heatBand(t.heat)} \u00b7 ${t.sessionSlot || 'n/a'}) shows no edge; require stronger confirmation or gate it out.`,
    };
  }
  // Fallback (peak in [0.5,1.5) handled above): treat as mild give-back.
  return {
    category: 'exit_giveback',
    diagnosis: `Went +${round2(peak)}% then closed ${t.returnPct}%.`,
    fix: 'Exit handling: protect small favorable moves sooner.',
  };
}

function toRow(t: RawTrade): PostmortemRow {
  const c = classifyLoser(t);
  return {
    symbol: t.symbol,
    direction: t.direction,
    entryEt: fmtEtTime(t.entryTime),
    exitEt: fmtEtTime(t.exitTime),
    returnPct: t.returnPct !== null ? round2(t.returnPct) : null,
    pnlDollars: t.pnlDollars !== null ? round2(t.pnlDollars) : null,
    peakPct: t.peakPct !== null ? round2(t.peakPct) : null,
    troughPct: t.troughPct !== null ? round2(t.troughPct) : null,
    holdMin: holdMinutes(t),
    exitReason: t.exitReason,
    heat: t.heat !== null ? round1(t.heat) : null,
    sessionSlot: t.sessionSlot,
    category: c.category,
    verdict: CATEGORY_VERDICT[c.category],
    diagnosis: c.diagnosis,
    fix: c.fix,
  };
}

// ---- Aggregate builders ---------------------------------------------------
function buildCategoryStats(losers: RawTrade[]): CategoryStat[] {
  const map = new Map<PmCategory, { count: number; netPnl: number }>();
  for (const t of losers) {
    const c = classifyLoser(t).category;
    const e = map.get(c) || { count: 0, netPnl: 0 };
    e.count++; e.netPnl += (t.pnlDollars ?? 0);
    map.set(c, e);
  }
  return [...map.entries()]
    .map(([category, e]) => ({
      category,
      label: CATEGORY_LABEL[category],
      verdict: CATEGORY_VERDICT[category],
      count: e.count,
      pctOfLosers: losers.length ? round1(100 * e.count / losers.length) : 0,
      netPnl: round2(e.netPnl),
    }))
    .sort((a, b) => b.count - a.count);
}

function buildFalseProfiles(losers: RawTrade[]): FalseProfile[] {
  const falses = losers.filter(t => {
    const c = classifyLoser(t).category;
    return c === 'false_directional' || c === 'false_weak';
  });
  const map = new Map<string, { direction: string; heatBand: string; session: string; count: number; netPnl: number; sumPct: number }>();
  for (const t of falses) {
    const dir = t.direction.toUpperCase();
    const hb = heatBand(t.heat);
    const sess = t.sessionSlot || 'n/a';
    const key = `${dir} \u00b7 ${hb} \u00b7 ${sess}`;
    const e = map.get(key) || { direction: dir, heatBand: hb, session: sess, count: 0, netPnl: 0, sumPct: 0 };
    e.count++; e.netPnl += (t.pnlDollars ?? 0); e.sumPct += (t.returnPct ?? 0);
    map.set(key, e);
  }
  return [...map.entries()]
    .map(([fingerprint, e]) => ({
      fingerprint, direction: e.direction, heatBand: e.heatBand, session: e.session,
      count: e.count, netPnl: round2(e.netPnl), avgPct: round2(e.sumPct / e.count),
    }))
    .filter(p => p.count >= 3)               // only recurring profiles are actionable
    .sort((a, b) => a.netPnl - b.netPnl);    // worst money-losers first
}

// ---- Main entry -----------------------------------------------------------
export async function getPostmortemReport(dateEt?: string): Promise<PostmortemReport> {
  const targetDate = dateEt || etDayKey(new Date());
  const { start, end } = etDayBounds(targetDate);
  const cleanStart = etDayBounds(CLEAN_WINDOW_START_ET).start;

  const [dayRaw, cleanRaw] = await Promise.all([
    prisma.paperTrade.findMany({
      where: { status: 'CLOSED', exitTime: { gte: start, lt: end } },
      select: TRADE_SELECT, orderBy: { returnPct: 'asc' },
    }) as Promise<RawTrade[]>,
    prisma.paperTrade.findMany({
      where: { status: 'CLOSED', exitTime: { gte: cleanStart } },
      select: TRADE_SELECT,
    }) as Promise<RawTrade[]>,
  ]);

  const dayClosed = dayRaw.filter(t => t.returnPct !== null);
  const dayLosers = dayClosed.filter(t => (t.returnPct as number) <= 0);
  const rows = dayLosers.map(toRow);
  const fixableCount = rows.filter(r => r.verdict === 'fixable').length;
  const falseCount = rows.filter(r => r.verdict === 'false').length;
  const fixablePnl = round2(rows.filter(r => r.verdict === 'fixable').reduce((s, r) => s + (r.pnlDollars ?? 0), 0));
  const falsePnl = round2(rows.filter(r => r.verdict === 'false').reduce((s, r) => s + (r.pnlDollars ?? 0), 0));

  const cleanClosed = cleanRaw.filter(t => t.returnPct !== null);
  const cleanLosers = cleanClosed.filter(t => (t.returnPct as number) <= 0);
  const categories = buildCategoryStats(cleanLosers);
  const falseProfiles = buildFalseProfiles(cleanLosers);

  // Winners that gave back >= half their peak = exit inefficiency (not a loss, but leakage).
  const cleanWinners = cleanClosed.filter(t => (t.returnPct as number) > 0);
  const gaveBack = cleanWinners.filter(t => t.peakPct !== null && (t.peakPct as number) >= 0.75 && (t.returnPct as number) <= (t.peakPct as number) / 2).length;

  const summary: string[] = [];
  if (cleanLosers.length > 0) {
    const fixable = categories.filter(c => c.verdict === 'fixable').reduce((s, c) => s + c.count, 0);
    const fals = categories.filter(c => c.verdict === 'false').reduce((s, c) => s + c.count, 0);
    const fixablePct = round1(100 * fixable / cleanLosers.length);
    summary.push(`Of ${cleanLosers.length} losers in the clean window, ${fixable} (${fixablePct}%) are FIXABLE by our own exit/entry/execution handling; ${fals} were genuinely FALSE signals.`);
    const topFix = categories.find(c => c.verdict === 'fixable');
    if (topFix) summary.push(`Biggest fixable bucket: \u201c${topFix.label}\u201d \u2014 ${topFix.count} losers (${topFix.pctOfLosers}%), net $${topFix.netPnl}. This is the highest-leverage thing WE control.`);
    const topFalse = falseProfiles[0];
    if (topFalse) summary.push(`Worst recurring false profile: ${topFalse.fingerprint} \u2014 ${topFalse.count} losers, net $${topFalse.netPnl}. Candidate to gate out of future setups.`);
    if (gaveBack > 0) summary.push(`${gaveBack} WINNERS also gave back \u2265 half their peak \u2014 exit leakage on trades that were working.`);
  } else {
    summary.push('No losers in the clean window to post-mortem yet.');
  }

  return {
    dateEt: targetDate,
    generatedAt: new Date().toISOString(),
    dayClosed: dayClosed.length,
    dayLosers: dayLosers.length,
    fixableCount, falseCount, fixablePnl, falsePnl,
    rows,
    windowStartEt: CLEAN_WINDOW_START_ET,
    windowLosers: cleanLosers.length,
    categories,
    falseProfiles,
    gaveBackWinners: gaveBack,
    gaveBackWinnersPct: cleanWinners.length ? round1(100 * gaveBack / cleanWinners.length) : 0,
    summary,
  };
}

// ---- Structured levers for cross-source reconciliation (feeds EL#5 slate) --
// The post-mortem is the learning loop's evidence source: it turns recurring
// failure modes into levers the nightly self-correction job reconciles against
// its own proposals + the EOD levers. Framed by SYSTEM failure mode, per owner.
export async function getPostmortemLevers(): Promise<RawLever[]> {
  const report = await getPostmortemReport();
  const levers: RawLever[] = [];
  const byCat = new Map(report.categories.map(c => [c.category, c] as const));

  const giveback = byCat.get('exit_giveback');
  if (giveback && giveback.count >= 3) {
    levers.push({
      source: 'postmortem', severity: 'watch', target: 'exit_giveback', direction: 'tighten',
      title: `${giveback.count} losers were winners we gave back (${giveback.pctOfLosers}%)`,
      detail: `Per-trade review: ${giveback.count} losing trades had actually gone green (net $${giveback.netPnl}) before our exit handling gave the move back. Fixable by us.`,
      edit: 'Exit handling: resting take-profit / tighter trailing activation',
      score: 45 + giveback.pctOfLosers,
    });
  }
  const entry = byCat.get('entry_timing');
  if (entry && entry.count >= 3) {
    levers.push({
      source: 'postmortem', severity: 'watch', target: 'entry_timing', direction: 'tighten',
      title: `${entry.count} losers were entry-timing misses (${entry.pctOfLosers}%)`,
      detail: `Per-trade review: ${entry.count} losers stopped out fast having barely gone green (net $${entry.netPnl}). Entered into an adverse move — a confirmation delay would help.`,
      edit: 'Entry timing: short confirmation delay before committing',
      score: 30 + entry.pctOfLosers,
    });
  }
  const topFalse = report.falseProfiles[0];
  if (topFalse && topFalse.count >= 3) {
    levers.push({
      source: 'postmortem', severity: 'suspend', target: `exclude:${topFalse.direction}-${topFalse.heatBand}-${topFalse.session}`.replace(/\s+/g, ''), direction: 'tighten',
      title: `Recurring false profile: ${topFalse.fingerprint} (${topFalse.count}\u00d7)`,
      detail: `Per-trade review: this trigger fingerprint produced ${topFalse.count} genuinely false signals for net $${topFalse.netPnl} (avg ${topFalse.avgPct}%). No timing/exit fix applies \u2014 the thesis is wrong; gate it out.`,
      edit: `Exclusion rule: filter ${topFalse.fingerprint} out of future setups`,
      score: 50 + Math.abs(topFalse.netPnl) / 10,
    });
  }
  return levers;
}

// ---- Email rendering ------------------------------------------------------
function dirTag(dir: string): { label: string; color: string } {
  return dir.toUpperCase() === 'LONG'
    ? { label: 'Bought', color: '#16a34a' }
    : { label: 'Short', color: '#ef4444' };
}
function verdictTag(v: Verdict): { label: string; color: string; bg: string } {
  return v === 'fixable'
    ? { label: 'FIXABLE', color: '#166534', bg: '#dcfce7' }
    : { label: 'FALSE', color: '#991b1b', bg: '#fee2e2' };
}

export function renderPostmortemEmail(r: PostmortemReport): string {
  const etNow = new Date().toLocaleString('en-US', { timeZone: 'America/New_York', dateStyle: 'medium', timeStyle: 'short' });

  const rowsHtml = r.rows.length === 0
    ? `<tr><td colspan="6" style="padding:14px;text-align:center;color:#888;">No losing trades to post-mortem for ${r.dateEt}.</td></tr>`
    : r.rows.map(t => {
        const d = dirTag(t.direction);
        const v = verdictTag(t.verdict);
        return `<tr style="border-bottom:1px solid #eee;vertical-align:top;">
          <td style="padding:8px;font-weight:700;">${t.symbol}<div style="font-size:10px;color:${d.color};font-weight:600;">${d.label}</div></td>
          <td style="padding:8px;text-align:center;color:#666;font-size:11px;">${t.entryEt}\u2192${t.exitEt}<div style="color:#999;">${t.holdMin ?? '\u2014'}m</div></td>
          <td style="padding:8px;text-align:right;font-weight:700;color:${(t.returnPct ?? 0) < 0 ? '#dc2626' : '#16a34a'};">${t.returnPct !== null ? t.returnPct + '%' : '\u2014'}<div style="font-size:10px;color:#999;font-weight:400;">pk +${t.peakPct ?? 0}%</div></td>
          <td style="padding:8px;"><span style="font-size:10px;font-weight:700;color:${v.color};background:${v.bg};padding:2px 6px;border-radius:4px;">${v.label}</span><div style="font-size:11px;color:#555;margin-top:3px;">${CATEGORY_LABEL[t.category]}</div></td>
          <td style="padding:8px;font-size:11px;color:#444;line-height:1.4;">${t.diagnosis}</td>
          <td style="padding:8px;font-size:11px;color:#1e40af;line-height:1.4;">${t.fix}</td>
        </tr>`;
      }).join('');

  const catHtml = r.categories.map(c => {
    const v = verdictTag(c.verdict);
    return `<tr style="border-bottom:1px solid #f0f0f0;">
      <td style="padding:6px 8px;"><span style="font-size:10px;font-weight:700;color:${v.color};background:${v.bg};padding:1px 5px;border-radius:3px;">${v.label}</span> ${c.label}</td>
      <td style="padding:6px 8px;text-align:right;">${c.count}</td>
      <td style="padding:6px 8px;text-align:right;color:#666;">${c.pctOfLosers}%</td>
      <td style="padding:6px 8px;text-align:right;font-weight:600;color:${c.netPnl < 0 ? '#dc2626' : '#16a34a'};">$${c.netPnl}</td>
    </tr>`;
  }).join('');

  const falseHtml = r.falseProfiles.length
    ? r.falseProfiles.map(p => `<tr style="border-bottom:1px solid #f0f0f0;">
        <td style="padding:6px 8px;font-weight:600;">${p.fingerprint}</td>
        <td style="padding:6px 8px;text-align:right;">${p.count}</td>
        <td style="padding:6px 8px;text-align:right;color:#666;">${p.avgPct}%</td>
        <td style="padding:6px 8px;text-align:right;font-weight:600;color:#dc2626;">$${p.netPnl}</td>
      </tr>`).join('')
    : `<tr><td colspan="4" style="padding:10px;color:#888;text-align:center;">No false profile recurs \u22653\u00d7 yet \u2014 nothing to exclude.</td></tr>`;

  const summaryHtml = r.summary.map(s => `<li style="margin:0 0 8px;line-height:1.5;">${s}</li>`).join('');

  return `
  <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:720px;margin:0 auto;color:#333;">
    <div style="background:#404040;padding:16px 20px;border-radius:12px 12px 0 0;">
      <h1 style="margin:0;font-size:20px;color:#4CBB17;">MarcoFlow \u2014 Per-Trade Post-Mortem</h1>
      <p style="margin:4px 0 0;font-size:12px;color:#ccc;">${r.dateEt} \u00b7 generated ${etNow} ET</p>
    </div>
    <div style="padding:14px 20px;background:#f8f9fa;border-bottom:1px solid #eee;font-size:13px;">
      <strong>${r.dateEt}:</strong> ${r.dayClosed} closed \u00b7 ${r.dayLosers} losers \u2014
      <span style="color:#166534;font-weight:700;">${r.fixableCount} fixable</span> (our handling, $${r.fixablePnl}) \u00b7
      <span style="color:#991b1b;font-weight:700;">${r.falseCount} false</span> (bad signal, $${r.falsePnl})
    </div>

    <div style="padding:16px 20px;">
      <h2 style="font-size:15px;margin:0 0 6px;">What we learned (clean window since ${r.windowStartEt})</h2>
      <ul style="font-size:13px;color:#333;padding-left:18px;margin:0 0 4px;">${summaryHtml}</ul>
    </div>

    <div style="padding:0 20px 8px;">
      <h3 style="font-size:14px;margin:10px 0 6px;">Loss anatomy \u2014 fixable vs false (${r.windowLosers} clean-window losers)</h3>
      <table style="width:100%;border-collapse:collapse;font-size:12px;">
        <thead><tr style="background:#f1f5f9;text-align:left;"><th style="padding:6px 8px;">Failure mode</th><th style="padding:6px 8px;text-align:right;">#</th><th style="padding:6px 8px;text-align:right;">% losers</th><th style="padding:6px 8px;text-align:right;">Net $</th></tr></thead>
        <tbody>${catHtml}</tbody>
      </table>
    </div>

    <div style="padding:8px 20px;">
      <h3 style="font-size:14px;margin:10px 0 6px;">Recurring false-signal profiles \u2014 exclusion candidates</h3>
      <table style="width:100%;border-collapse:collapse;font-size:12px;">
        <thead><tr style="background:#f1f5f9;text-align:left;"><th style="padding:6px 8px;">Fingerprint (direction \u00b7 heat \u00b7 session)</th><th style="padding:6px 8px;text-align:right;">#</th><th style="padding:6px 8px;text-align:right;">avg %</th><th style="padding:6px 8px;text-align:right;">Net $</th></tr></thead>
        <tbody>${falseHtml}</tbody>
      </table>
    </div>

    <div style="padding:8px 20px 16px;">
      <h3 style="font-size:14px;margin:14px 0 6px;">${r.dateEt} \u2014 every losing trade, diagnosed</h3>
      <table style="width:100%;border-collapse:collapse;font-size:12px;">
        <thead><tr style="background:#f1f5f9;text-align:left;">
          <th style="padding:8px;">Ticker</th><th style="padding:8px;text-align:center;">In\u2192Out</th><th style="padding:8px;text-align:right;">Return</th>
          <th style="padding:8px;">Verdict</th><th style="padding:8px;">Diagnosis</th><th style="padding:8px;">Adjustment to test</th>
        </tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>
    </div>

    <div style="padding:14px 20px;font-size:11px;color:#999;border-top:1px solid #eee;">
      <p style="margin:0 0 4px;">Every loss is diagnosed by SYSTEM / SETUP failure mode \u2014 never by blaming a ticker. \u201cFixable\u201d = something we control (exit, entry, execution). \u201cFalse\u201d = the signal was wrong; the fix is to exclude the pattern. These are data-derived observations to guide testing; nothing changes live strategy until you approve it.</p>
      <p style="margin:0;"><strong>Educational only \u2014 not financial advice.</strong></p>
    </div>
  </div>`;
}

// ---- Send -----------------------------------------------------------------
export async function sendPostmortemReport(dateEt?: string): Promise<{ ok: boolean; losers: number; dateEt: string }> {
  const report = await getPostmortemReport(dateEt);
  const html = renderPostmortemEmail(report);
  const appUrl = process.env.NEXTAUTH_URL || '';
  try {
    const response = await fetch('https://apps.abacus.ai/api/sendNotificationEmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deployment_token: process.env.ABACUSAI_API_KEY,
        app_id: process.env.WEB_APP_ID,
        notification_id: process.env.NOTIF_ID_TRADE_SIGNAL_ALERT,
        subject: `\ud83d\udd0e MarcoFlow Post-Mortem \u2014 ${report.dateEt} \u00b7 ${report.fixableCount} fixable / ${report.falseCount} false`,
        body: html,
        is_html: true,
        recipient_email: POSTMORTEM_RECIPIENT,
        sender_email: appUrl ? `noreply@${new URL(appUrl).hostname}` : undefined,
        sender_alias: 'MarcoFlow',
      }),
    });
    const res = await response.json();
    if (!res.success && !res.notification_disabled) {
      console.error('Post-mortem email failed:', res);
      return { ok: false, losers: report.dayLosers, dateEt: report.dateEt };
    }
    return { ok: true, losers: report.dayLosers, dateEt: report.dateEt };
  } catch (e: any) {
    console.error('Post-mortem email error:', e?.message);
    return { ok: false, losers: report.dayLosers, dateEt: report.dateEt };
  }
}

```

---

## FILE: code/lib/trading-strategies.ts

```typescript
// Trading strategy implementations

import { StockDataPoint } from './alpha-vantage';

export interface Signal {
  type: 'BUY' | 'SELL' | 'HOLD';
  strength: number; // 0-100
  price: number;
  shortMA: number;
  longMA: number;
  reason: string;
}

export interface SignalPoint extends Signal {
  date: string;
}

// Calculate Simple Moving Average
function calculateSMA(data: number[], period: number): number[] {
  const sma: number[] = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      sma.push(NaN);
    } else {
      const slice = data.slice(i - period + 1, i + 1);
      const avg = slice.reduce((a, b) => a + b, 0) / period;
      sma.push(avg);
    }
  }
  return sma;
}

// Moving Average Crossover Strategy
export function movingAverageCrossover(
  stockData: StockDataPoint[],
  shortPeriod: number = 10,
  longPeriod: number = 50
): { currentSignal: Signal; historicalSignals: SignalPoint[]; chartData: any[] } {
  if (stockData.length < longPeriod) {
    throw new Error(`Insufficient data. Need at least ${longPeriod} data points.`);
  }
  
  const closePrices = stockData.map(d => d.close);
  const shortMA = calculateSMA(closePrices, shortPeriod);
  const longMA = calculateSMA(closePrices, longPeriod);
  
  const historicalSignals: SignalPoint[] = [];
  const chartData: any[] = [];
  
  for (let i = longPeriod; i < stockData.length; i++) {
    const currentShortMA = shortMA[i];
    const currentLongMA = longMA[i];
    const prevShortMA = shortMA[i - 1];
    const prevLongMA = longMA[i - 1];
    const currentPrice = stockData[i].close;
    const date = stockData[i].date;
    
    chartData.push({
      date,
      price: currentPrice,
      shortMA: currentShortMA,
      longMA: currentLongMA,
      volume: stockData[i].volume,
    });
    
    // Detect crossover
    const shortAboveLong = currentShortMA > currentLongMA;
    const prevShortAboveLong = prevShortMA > prevLongMA;
    
    if (shortAboveLong && !prevShortAboveLong) {
      // Golden Cross - BUY signal
      const crossoverStrength = Math.min(100, Math.abs(currentShortMA - currentLongMA) / currentLongMA * 1000);
      historicalSignals.push({
        date,
        type: 'BUY',
        strength: Math.round(crossoverStrength),
        price: currentPrice,
        shortMA: currentShortMA,
        longMA: currentLongMA,
        reason: `Golden Cross: ${shortPeriod}-day MA crossed above ${longPeriod}-day MA`,
      });
    } else if (!shortAboveLong && prevShortAboveLong) {
      // Death Cross - SELL signal
      const crossoverStrength = Math.min(100, Math.abs(currentLongMA - currentShortMA) / currentLongMA * 1000);
      historicalSignals.push({
        date,
        type: 'SELL',
        strength: Math.round(crossoverStrength),
        price: currentPrice,
        shortMA: currentShortMA,
        longMA: currentLongMA,
        reason: `Death Cross: ${shortPeriod}-day MA crossed below ${longPeriod}-day MA`,
      });
    }
  }
  
  // Get current signal based on MA positions
  const lastIdx = stockData.length - 1;
  const currentShortMA = shortMA[lastIdx];
  const currentLongMA = longMA[lastIdx];
  const currentPrice = stockData[lastIdx].close;
  
  let currentSignal: Signal;
  const maDiff = currentShortMA - currentLongMA;
  const diffPercent = Math.abs(maDiff / currentLongMA * 100);
  
  if (maDiff > 0) {
    currentSignal = {
      type: diffPercent > 1 ? 'BUY' : 'HOLD',
      strength: Math.min(100, Math.round(diffPercent * 20)),
      price: currentPrice,
      shortMA: currentShortMA,
      longMA: currentLongMA,
      reason: `${shortPeriod}-day MA is ${diffPercent.toFixed(2)}% above ${longPeriod}-day MA`,
    };
  } else {
    currentSignal = {
      type: diffPercent > 1 ? 'SELL' : 'HOLD',
      strength: Math.min(100, Math.round(diffPercent * 20)),
      price: currentPrice,
      shortMA: currentShortMA,
      longMA: currentLongMA,
      reason: `${shortPeriod}-day MA is ${diffPercent.toFixed(2)}% below ${longPeriod}-day MA`,
    };
  }
  
  return { currentSignal, historicalSignals, chartData };
}

```

---

## FILE: code/lib/types.ts

```typescript
export type Expense = {
  id: string
  amount: number
  category: string
  description: string
  date: Date
}

export type ExpenseFormData = Omit<Expense, 'id' | 'date'> & {
  date: string
}

export const EXPENSE_CATEGORIES = [
  'Food',
  'Transportation',
  'Housing',
  'Utilities',
  'Entertainment',
  'Healthcare',
  'Shopping',
  'Education',
  'Other'
] as const

export type DateRange = {
  from: Date | undefined
  to: Date | undefined
}
```

---

## FILE: code/lib/universe-extra.ts

```typescript
/**
 * MarcoFlow Update 4.0 (9/11/26) — ADV-vetted universe expansion (Part 1b).
 * AUTO-GENERATED by scripts/build-universe.mjs. Do not hand-edit.
 *
 * 7 new common shares, pulled from Alpaca active/tradable us_equity,
 * filtered to tradable + shortable normal common shares NOT already in
 * STOCK_CATEGORIES, ADV >= $20M (~20-day avg dollar volume, Alpaca IEX daily
 * bars), ranked by ADV descending. Concatenated (dedup) by getAllStocks() in
 * lib/stock-screener.ts. Reversible: remove the concat line there.
 */
export const UNIVERSE_EXTRA: { symbol: string; name: string }[] = [
  { symbol: "SKHY", name: "SK hynix Inc. American Depositary Shares" },
  { symbol: "BABA", name: "Alibaba Group Holding Limited American Depositary Shares, each represents eight Ordinary Shares" },
  { symbol: "SHEL", name: "Shell plc American Depositary Shares (Each represents two Ordinary shares)" },
  { symbol: "ARM", name: "Arm Holdings plc American Depositary Shares" },
  { symbol: "PDD", name: "PDD Holdings Inc. American Depositary Shares" },
  { symbol: "SE", name: "Sea Limited American Depositary Shares, each representing one Class A Ordinary Share" },
  { symbol: "VMRK", name: "Vivmark Residential" },
];

```

---

## FILE: code/api/agent/daily-brief/route.ts

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { getEodLossReport } from '@/lib/eod-losses';
import { getPostmortemReport } from '@/lib/trade-postmortem';
import { buildSelfCorrectionReport } from '@/lib/self-correction';
import { renderDailyBrief, sendDailyBrief, type OptimizerProposal } from '@/lib/daily-brief';

export const dynamic = 'force-dynamic';
export const maxDuration = 120;

// Update 3.5 — Consolidated Daily Brief (EOD Worst-20 + per-trade Post-Mortem).
// Agent-secret protected. Report-only; the two legacy emails keep running until
// this is verified in production.
//   GET ?key=<secret>                 -> build the combined report only (JSON)
//   GET ?key=<secret>&date=YYYY-MM-DD -> brief for a specific ET day
//   GET ?key=<secret>&preview=1       -> render the combined HTML (no email)
//   GET ?key=<secret>&send=1          -> build + email the owner the Daily Brief
// Accepts Authorization: Bearer <secret> or ?key= for daemon convenience.
export async function GET(req: NextRequest) {
  const secret = process.env.AGENT_SECRET;
  const auth = req.headers.get('authorization') || '';
  const bearer = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  const key = req.nextUrl.searchParams.get('key') || '';
  if (!secret || (bearer !== secret && key !== secret)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  try {
    const date = req.nextUrl.searchParams.get('date') || undefined;
    const send = req.nextUrl.searchParams.get('send') === '1';
    const preview = req.nextUrl.searchParams.get('preview') === '1';
    if (send) {
      const sent = await sendDailyBrief(date);
      return NextResponse.json({ ok: sent.ok, emailed: sent.ok, losers: sent.losers, dateEt: sent.dateEt });
    }
    if (preview) {
      const [eod, pm] = await Promise.all([getEodLossReport(date), getPostmortemReport(date)]);
      let sc = null;
      try { sc = await buildSelfCorrectionReport(); } catch (e: any) { console.error('preview self-correction failed:', e?.message); }
      return new NextResponse(renderDailyBrief(eod, pm, sc), { headers: { 'Content-Type': 'text/html' } });
    }
    const [eod, pm] = await Promise.all([getEodLossReport(date), getPostmortemReport(date)]);
    return NextResponse.json({ eod, pm });
  } catch (error: any) {
    console.error('daily-brief error:', error);
    return NextResponse.json({ error: error?.message ?? 'Failed' }, { status: 500 });
  }
}

// POST — accept nightly-optimizer proposals and fold them into the SAME single
// Daily Brief email (no second email). Called by the optimizer VM over HTTPS
// with the AGENT_SECRET bearer token. Same auth as GET.
//   POST ?key=<secret>&send=1  body { optimizerProposals: [...] } -> build + email
//   POST ?key=<secret>         body { optimizerProposals: [...] }  -> preview/ack (no email)
//   POST ?key=<secret>&date=YYYY-MM-DD&send=1                      -> brief for a specific ET day
export async function POST(req: NextRequest) {
  const secret = process.env.AGENT_SECRET;
  const auth = req.headers.get('authorization') || '';
  const bearer = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  const key = req.nextUrl.searchParams.get('key') || '';
  if (!secret || (bearer !== secret && key !== secret)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  try {
    const date = req.nextUrl.searchParams.get('date') || undefined;
    const send = req.nextUrl.searchParams.get('send') === '1';

    // Null-safe body parse: missing/invalid JSON => empty proposals.
    let optimizerProposals: OptimizerProposal[] = [];
    try {
      const body = await req.json();
      if (body && Array.isArray(body.optimizerProposals)) {
        optimizerProposals = body.optimizerProposals as OptimizerProposal[];
      }
    } catch {
      optimizerProposals = [];
    }

    if (send) {
      const sent = await sendDailyBrief(date, optimizerProposals);
      return NextResponse.json({ ok: sent.ok, emailed: sent.ok, losers: sent.losers, dateEt: sent.dateEt });
    }
    // No send: acknowledge how many proposals were received (do NOT email).
    return NextResponse.json({ ok: true, emailed: false, received: optimizerProposals.length });
  } catch (error: any) {
    console.error('daily-brief POST error:', error);
    return NextResponse.json({ error: error?.message ?? 'Failed' }, { status: 500 });
  }
}

```

---

## FILE: code/api/agent/heartbeat/route.ts

```typescript
import { NextResponse } from 'next/server';
import { recordSignals, resolvePendingSignals, isMarketHours } from '@/lib/signal-recorder';
import { checkAndSendAlerts } from '@/lib/alert-checker';
import { paperTick } from '@/lib/paper-trader';
import { getAllStocks } from '@/lib/stock-screener';
import { sendDailyBrief } from '@/lib/daily-brief';
import { prisma } from '@/lib/db';

// ─────────────────────────────────────────────────────────────────────────────
// SELF-HEALING HEARTBEAT  (Update 6.2 — 9/21/26)
//
// This endpoint is the app's OWN autonomous engine. It is designed to be pinged
// on a tight schedule (every 1–5 min) by an always-on EXTERNAL uptime/cron
// service (cron-job.org, UptimeRobot, etc.). That external trigger is the single
// source of ignition — it does not depend on the in-platform scheduled task,
// which has repeatedly lost its next-run anchor ("orphaned") and silently
// stopped the pipeline for a whole session.
//
// Every call is fully self-orchestrating and idempotent:
//   • Market closed        → do the light post-close housekeeping (resolve +
//                            once-per-day Daily Brief), otherwise no-op.
//   • Market open          → advance a DB-persisted scan cursor through the
//                            universe for a bounded time budget, then always
//                            run the alert pass, paper-trade pass and a light
//                            resolve pass. Because the cursor lives in the DB it
//                            survives serverless instance recycling, and repeated
//                            calls simply push the scan forward — a missed window
//                            self-heals on the very next ping (minutes, not
//                            hours). Nothing is ever double-recorded (dedupe is
//                            enforced in recordSignals) and alerts/paper are
//                            idempotent (alertedAt / candidate windows).
//
// Auth: a token in the query string (?key=...) so a plain GET from an external
// cron works. Falls back to AGENT_SECRET if HEARTBEAT_SECRET is unset.
// ─────────────────────────────────────────────────────────────────────────────

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

// One symbol chunk per recordSignals call. Small enough to keep peak memory low
// (matches the chunked record mode of the main tick), looped against a time
// budget so a single heartbeat covers as much of the universe as fits.
const CHUNK_SIZE = 120;
// Leave head-room under maxDuration for the alert + paper + resolve passes.
const SCAN_BUDGET_MS = 40_000;
// DB-lease so only ONE heartbeat does heavy work at a time across the whole
// serverless fleet (a module-level bool only covers a single instance).
const LEASE_MS = 55_000;

const CURSOR_KEY = 'heartbeat_scan_cursor';
const LEASE_KEY = 'heartbeat_lease';

async function readState(key: string): Promise<any> {
  try {
    const row = await prisma.agentState.findUnique({ where: { key } });
    return row?.valueJson ?? null;
  } catch {
    return null;
  }
}
async function writeState(key: string, valueJson: any): Promise<void> {
  try {
    await prisma.agentState.upsert({
      where: { key },
      create: { key, valueJson },
      update: { valueJson },
    });
  } catch {
    /* best-effort */
  }
}

// Try to acquire the heavy-work lease. Returns true if we own it.
async function acquireLease(): Promise<boolean> {
  const now = Date.now();
  const cur = await readState(LEASE_KEY);
  const until = typeof cur?.until === 'number' ? cur.until : 0;
  if (now < until) return false; // someone else holds a live lease
  await writeState(LEASE_KEY, { until: now + LEASE_MS, at: new Date().toISOString() });
  return true;
}
async function releaseLease(): Promise<void> {
  await writeState(LEASE_KEY, { until: 0, at: new Date().toISOString() });
}

function authed(request: Request): boolean {
  const { searchParams } = new URL(request.url);
  const key = (searchParams.get('key') || '').trim();
  const auth = request.headers.get('authorization') || '';
  const bearer = auth.replace(/^Bearer\s+/i, '').trim();
  const secret = process.env.HEARTBEAT_SECRET || process.env.AGENT_SECRET;
  return !!secret && (key === secret || bearer === secret);
}

// Is it a weekday, after the close, and within the post-close housekeeping window?
function inPostCloseWindow(now: Date = new Date()): boolean {
  const et = new Date(now.toLocaleString('en-US', { timeZone: 'America/New_York' }));
  const day = et.getDay();
  if (day === 0 || day === 6) return false;
  const mins = et.getHours() * 60 + et.getMinutes();
  // 16:45 ET → 20:00 ET. The window opens AFTER the nightly optimizer's 4:30 PM ET
  // run so the day's fresh proposals are already in the DB and land in this same
  // (single) Daily Brief — letting the owner approve/deny same-day.
  return mins >= 16 * 60 + 45 && mins <= 20 * 60;
}

async function runHeartbeat(): Promise<any> {
  const startedAt = Date.now();
  const marketOpen = isMarketHours();

  // ── Market closed: light housekeeping only ──────────────────────────────
  if (!marketOpen) {
    const out: any = { ok: true, market: 'closed', timestamp: new Date().toISOString() };
    // Resolve any overdue observations (cheap, bounded internally).
    try {
      out.resolve = await resolvePendingSignals(200);
    } catch (e: any) {
      out.resolve = { error: e?.message };
    }
    // Once-per-day consolidated Daily Brief, independent of the flaky hourly task.
    if (inPostCloseWindow()) {
      try {
        const brief = await sendDailyBrief();
        out.dailyBrief = { emailed: brief.ok && !brief.skipped, skipped: !!brief.skipped, dateEt: brief.dateEt };
      } catch (e: any) {
        out.dailyBrief = { error: e?.message };
      }
    }
    return out;
  }

  // ── Market open: drive the trading pipeline ─────────────────────────────
  const universe = getAllStocks();
  const total = universe.length;

  let cursor = 0;
  const cur = await readState(CURSOR_KEY);
  if (typeof cur?.offset === 'number' && cur.offset < total) cursor = cur.offset;

  let chunks = 0;
  let scanned = 0;
  let recorded = 0;
  let wrapped = false;

  // Time-budgeted record loop — advance the cursor as far as fits this call.
  while (Date.now() - startedAt < SCAN_BUDGET_MS) {
    const rec = await recordSignals(CHUNK_SIZE, cursor);
    chunks++;
    scanned += rec.scanned;
    recorded += rec.recorded;
    cursor += CHUNK_SIZE;
    if (cursor >= total) {
      cursor = 0; // completed a full universe pass; wrap for next call
      wrapped = true;
      break;
    }
  }
  await writeState(CURSOR_KEY, { offset: cursor, at: new Date().toISOString(), universe: total });

  // Alert pass (idempotent — sets alertedAt; never re-alerts the same signal).
  let alerts: any = null;
  try {
    const confirmed = await checkAndSendAlerts();
    alerts = { confirmed };
  } catch (e: any) {
    alerts = { error: e?.message };
  }

  // Paper-trade pass (entries + exits; candidate window keeps it idempotent).
  let paper: any = null;
  try {
    const p = await paperTick();
    paper = { entries: p.entries.entered, exits: p.monitor.closed, open: p.portfolio.openTrades };
  } catch (e: any) {
    paper = { error: e?.message };
  }

  // Light resolve pass so outcomes keep grading through the session.
  let resolve: any = null;
  try {
    resolve = await resolvePendingSignals(150);
  } catch (e: any) {
    resolve = { error: e?.message };
  }

  return {
    ok: true,
    market: 'open',
    universe: total,
    cursor,
    wrapped,
    chunks,
    scanned,
    recorded,
    alerts,
    paper,
    resolve,
    elapsedMs: Date.now() - startedAt,
    timestamp: new Date().toISOString(),
  };
}

export async function GET(request: Request) {
  if (!authed(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // Fleet-wide single-flight: only the lease holder does work; others ack fast.
  const gotLease = await acquireLease();
  if (!gotLease) {
    return NextResponse.json({ ok: true, busy: true, note: 'another heartbeat holds the lease', timestamp: new Date().toISOString() });
  }

  try {
    const result = await runHeartbeat();
    return NextResponse.json(result);
  } catch (e: any) {
    console.error('[heartbeat] error:', e);
    return NextResponse.json({ ok: false, error: e?.message ?? 'heartbeat failed' }, { status: 500 });
  } finally {
    await releaseLease();
  }
}

// POST behaves identically — some cron services default to POST.
export async function POST(request: Request) {
  return GET(request);
}

```

---

## FILE: code/api/agent/tick/route.ts

```typescript
import { NextResponse } from 'next/server';
import { recordSignals, resolvePendingSignals, isMarketHours } from '@/lib/signal-recorder';
import { maybeRunReview, runAndSaveReview } from '@/lib/strategy-review';
import { maybeRunDailySim } from '@/lib/daily-sim';
import { checkAndSendAlerts, checkAndSendFormingAlerts } from '@/lib/alert-checker';
import { ensureScannerStarted } from '@/lib/market-scanner';
import { paperTick, type PaperTickResult } from '@/lib/paper-trader';

// Start the 5-minute in-app scanner on first import (server-side only)
ensureScannerStarted();

export const dynamic = 'force-dynamic';
export const maxDuration = 300;

// ── Concurrency guard ──────────────────────────────────────────────────
// Only ONE tick runs at a time. If the scanner timer, hourly daemon, or a
// manual call overlap, the late-comers get a 429 instead of piling into
// a second full-watchlist scan that OOM-kills the process.
let tickRunning = false;

// Called by the scheduled background agent. Records new signals and resolves
// the outcomes of past ones. Protected by AGENT_SECRET.
export async function POST(request: Request) {
  if (tickRunning) {
    return NextResponse.json(
      { ok: false, busy: true, hint: 'Another tick is already running' },
      { status: 429 }
    );
  }
  tickRunning = true;
  try {
    const mem = process.memoryUsage();
    console.log(`[tick] START rss=${Math.round(mem.rss/1024/1024)}MB heap=${Math.round(mem.heapUsed/1024/1024)}/${Math.round(mem.heapTotal/1024/1024)}MB`);
    const auth = request.headers.get('authorization') || '';
    const token = auth.replace(/^Bearer\s+/i, '').trim();
    const secret = process.env.AGENT_SECRET;

    if (!secret || token !== secret) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const force = searchParams.get('force') === 'true';
    const mode = searchParams.get('mode') || 'both'; // 'record' | 'resolve' | 'both' | 'review' | 'alert'
    const offset = parseInt(searchParams.get('offset') || '0', 10);
    const limit = parseInt(searchParams.get('limit') || '5000', 10);

    const marketOpen = isMarketHours();

    let record = null;
    let resolve = null;
    let review = null;
    let dailySim = null;
    let alerts = null;
    let paper: PaperTickResult | null = null;

    // Dedicated review-only run (forced) — always runs and stores a snapshot.
    if (mode === 'review') {
      const r = await runAndSaveReview();
      return NextResponse.json({ ok: true, marketOpen, forced: force, review: r, timestamp: new Date().toISOString() });
    }

    // Always resolve (outcomes can be measured any time after horizon).
    // The after-hours resolver fix: resolve runs on EVERY tick (even after
    // market close) so pending observations from the last scan don't block
    // the EOD completeness check.
    if (mode === 'resolve' || mode === 'both') {
      resolve = await resolvePendingSignals();
      const m1 = process.memoryUsage();
      console.log(`[tick] after-resolve rss=${Math.round(m1.rss/1024/1024)}MB heap=${Math.round(m1.heapUsed/1024/1024)}/${Math.round(m1.heapTotal/1024/1024)}MB`);
    }

    // Resolve-only: return immediately — no review, no sim, no paper.
    if (mode === 'resolve') {
      return NextResponse.json({ ok: true, marketOpen, resolve, timestamp: new Date().toISOString() });
    }

    // Dedicated alert-only mode: just check and send alerts for recent signals.
    if (mode === 'alert') {
      try {
        const confirmed = await checkAndSendAlerts();
        return NextResponse.json({ ok: true, marketOpen, alerts: { confirmed }, timestamp: new Date().toISOString() });
      } catch (e: any) {
        return NextResponse.json({ ok: true, marketOpen, alerts: { error: e?.message }, timestamp: new Date().toISOString() });
      }
    }

    // Only record fresh signals during market hours (unless forced for testing).
    if ((mode === 'record' || mode === 'both') && (marketOpen || force)) {
      record = await recordSignals(limit, offset);
      const m2 = process.memoryUsage();
      console.log(`[tick] after-record(offset=${offset},limit=${limit}) scanned=${record.scanned} rss=${Math.round(m2.rss/1024/1024)}MB heap=${Math.round(m2.heapUsed/1024/1024)}/${Math.round(m2.heapTotal/1024/1024)}MB`);

      // If this was a chunked request, return immediately without alerts
      // (alerts run in a separate mode=alert call after all chunks finish).
      if (mode === 'record') {
        return NextResponse.json({
          ok: true,
          done: record.scanned === 0, // signal to scanner that universe is exhausted
          marketOpen,
          record,
          timestamp: new Date().toISOString(),
        });
      }

      // Trade-signal alerts. We now send ONLY confirmed "act now" alerts (a
      // setup fully matches a qualifying high-confidence rule right now).
      //
      // The anticipatory "setup forming" pre-alerts are intentionally DISABLED
      // for the autonomous workflow: they were a heads-up-to-prep feature aimed
      // at manual traders, and are not wanted while the tool drives itself. The
      // function is left fully intact and can be switched back on at any time by
      // setting ENABLE_FORMING_ALERTS=true (e.g. if we open the tool up to users
      // who trade the alerts by hand). Off by default.
      try {
        const formingEnabled = process.env.ENABLE_FORMING_ALERTS === 'true';
        const forming = formingEnabled
          ? await checkAndSendFormingAlerts()
          : { disabled: true };
        const confirmed = await checkAndSendAlerts();
        alerts = { forming, confirmed };
      } catch (e: any) {
        console.error('Alert check failed:', e);
        alerts = { sent: 0, error: e?.message };
      }
    }

    // Continuous Review: the agentic self-improvement loop. Runs at most about
    // once a day (guarded), so it costs nothing extra on the frequent ticks.
    // ONLY in 'both' mode — resolve-only must stay ultra-light to avoid OOM.
    if (mode === 'both') {
      try {
        const rv = await maybeRunReview(20);
        if (rv.ran) review = { ran: true, bestRuleLabel: rv.review?.bestRuleLabel, bestWinRateLB: rv.review?.bestWinRateLB, trend: rv.review?.trend };
        else review = { ran: false };
      } catch (e: any) {
        console.error('Review step failed:', e);
        review = { ran: false, error: e?.message };
      }

      // Fresh-trader daily simulation: runs once per ET day after the close.
      try {
        const ds = await maybeRunDailySim(force);
        dailySim = ds.ran ? { ran: true, ...ds.result } : { ran: false };
      } catch (e: any) {
        console.error('Daily simulation step failed:', e);
        dailySim = { ran: false, error: e?.message };
      }
    }

    // Paper trading: only in 'both' mode. When the scanner splits into
    // separate resolve/record requests, paper runs via its own /api/paper/tick
    // call — keep it out of the record-only request to save memory.
    if ((mode === 'both') && (marketOpen || force)) {
      try {
        paper = await paperTick();
      } catch (e: any) {
        console.error('Paper tick failed:', e);
        paper = null;
      }
    }

    return NextResponse.json({
      ok: true,
      marketOpen,
      forced: force,
      record,
      resolve,
      review,
      dailySim,
      alerts,
      paper: paper ? { entries: paper.entries.entered, exits: paper.monitor.closed, openPositions: paper.portfolio.openTrades } : null,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Agent tick error:', error);
    return NextResponse.json(
      { error: error?.message ?? 'Agent tick failed' },
      { status: 500 }
    );
  } finally {
    tickRunning = false;
  }
}

// Allow a lightweight GET health check (no secret needed, no work done)
export async function GET() {
  ensureScannerStarted();
  return NextResponse.json({
    ok: true,
    marketOpen: isMarketHours(),
    hint: 'POST with Bearer AGENT_SECRET to run a tick',
  });
}

```

---

## FILE: code/api/health/route.ts

```typescript
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { ensureScannerStarted } from '@/lib/market-scanner';

// Ensure the 15-min market scanner is running on first health check
ensureScannerStarted();

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    // Check database connection
    await prisma.$queryRaw`SELECT 1`;
    
    return NextResponse.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      database: 'connected',
      version: '7.0.0',
    });
  } catch (error) {
    console.error('Health check failed:', error);
    return NextResponse.json(
      {
        status: 'unhealthy',
        timestamp: new Date().toISOString(),
        database: 'disconnected',
        error: 'Database connection failed',
      },
      { status: 503 }
    );
  }
}

```

---

## FILE: code/api/insights/route.ts

```typescript
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

// ---- "Did You Know?" data-driven insight cards ------------------------------
// Every card is computed live from the SignalObservation outcome dataset so the
// numbers stay honest and current. A win = the setup finished GREEN
// (returnPct > 0). Each card reports the exact sample it is based on.

interface InsightCard {
  id: string;
  headline: string;   // the big stat
  title: string;      // short label
  detail: string;     // plain-English explanation
  basis: string;      // sample size + what data it is drawn from
}

// simple in-memory cache — the dataset only changes on scans/backfills
let CACHE: { at: number; payload: any } | null = null;
const TTL_MS = 5 * 60 * 1000;

function pct(numer: number, denom: number): number | null {
  if (!denom) return null;
  return Math.round((numer / denom) * 1000) / 10;
}

export async function GET() {
  try {
    if (CACHE && Date.now() - CACHE.at < TTL_MS) {
      return NextResponse.json(CACHE.payload);
    }

    const rows = await prisma.$queryRawUnsafe<any[]>(`
      SELECT
        count(*) FILTER (WHERE status <> 'PENDING')                                                    AS resolved_all,
        count(*) FILTER (WHERE status <> 'PENDING' AND "returnPct" > 0)                                 AS green_all,
        count(*) FILTER (WHERE status <> 'PENDING' AND direction = 'LONG' AND "maxAdversePct" >= 1)      AS long_dip1_n,
        count(*) FILTER (WHERE status <> 'PENDING' AND direction = 'LONG' AND "maxAdversePct" >= 1 AND "returnPct" > 0) AS long_dip1_green,
        count(*) FILTER (WHERE status <> 'PENDING' AND "maxAdversePct" < 0.3)                            AS clean_n,
        count(*) FILTER (WHERE status <> 'PENDING' AND "maxAdversePct" < 0.3 AND "returnPct" > 0)         AS clean_green,
        avg("maxAdversePct") FILTER (WHERE status <> 'PENDING')                                          AS avg_adv,
        count(*) FILTER (WHERE status <> 'PENDING' AND "maxAdversePct" >= 1.5)                           AS stop_n,
        count(*) FILTER (WHERE status <> 'PENDING' AND abs(heat) BETWEEN 50 AND 60)                      AS mod_n,
        count(*) FILTER (WHERE status <> 'PENDING' AND abs(heat) BETWEEN 50 AND 60 AND "returnPct" > 0)   AS mod_green,
        count(*) FILTER (WHERE status <> 'PENDING' AND abs(heat) >= 70)                                  AS ext_n,
        count(*) FILTER (WHERE status <> 'PENDING' AND abs(heat) >= 70 AND "returnPct" > 0)              AS ext_green
      FROM "SignalObservation";
    `);

    const r = rows[0] || {};
    const num = (v: any) => (v == null ? 0 : Number(v));

    const resolvedAll = num(r.resolved_all);
    const greenAll = num(r.green_all);
    const longDip1N = num(r.long_dip1_n);
    const longDip1Green = num(r.long_dip1_green);
    const cleanN = num(r.clean_n);
    const cleanGreen = num(r.clean_green);
    const avgAdv = num(r.avg_adv);
    const stopN = num(r.stop_n);
    const modN = num(r.mod_n);
    const modGreen = num(r.mod_green);
    const extN = num(r.ext_n);
    const extGreen = num(r.ext_green);

    const baselinePct = pct(greenAll, resolvedAll);
    const dip1Pct = pct(longDip1Green, longDip1N);
    const cleanPct = pct(cleanGreen, cleanN);
    const stopHitPct = pct(stopN, resolvedAll);
    const modPct = pct(modGreen, modN);
    const extPct = pct(extGreen, extN);

    const fmt = (n: number) => n.toLocaleString('en-US');
    const cards: InsightCard[] = [];

    if (dip1Pct != null && longDip1N >= 100) {
      cards.push({
        id: 'falling-knife',
        headline: `${dip1Pct}%`,
        title: 'The Falling Knife',
        detail: `Once a long setup dips 1% against you, only about ${dip1Pct}% still finish green. Chasing a setup that is already sliding rarely pays off \u2014 patience beats catching the knife.`,
        basis: `Based on ${fmt(longDip1N)} resolved long setups that dipped \u22651% before resolving.`,
      });
    }

    if (cleanPct != null && cleanN >= 100) {
      cards.push({
        id: 'clean-entries',
        headline: `${cleanPct}%`,
        title: 'Clean Entries Win',
        detail: `Setups that barely wobble \u2014 never dipping more than 0.3% against you \u2014 finish green ${cleanPct}% of the time. The best trades tend to work almost immediately.`,
        basis: `Based on ${fmt(cleanN)} resolved setups with under 0.3% adverse move. (Shown as motivation \u2014 wobble is only known after entry, so it is not a live filter.)`,
      });
    }

    if (avgAdv > 0 && resolvedAll >= 100) {
      cards.push({
        id: 'average-wobble',
        headline: `${Math.round(avgAdv * 100) / 100}%`,
        title: 'Expect Some Heat',
        detail: `The typical setup dips about ${Math.round(avgAdv * 100) / 100}% against you at some point before it resolves. A little red early is normal \u2014 a big red is the warning sign.`,
        basis: `Average maximum adverse move across ${fmt(resolvedAll)} resolved setups.`,
      });
    }

    if (modPct != null && extPct != null && modN >= 100 && extN >= 100) {
      cards.push({
        id: 'moderate-beats-extreme',
        headline: `${modPct}% vs ${extPct}%`,
        title: 'Moderate Beats Extreme',
        detail: `Moderate-heat setups (50\u201360) finish green ${modPct}% of the time \u2014 more often than red-hot ones (70+) at ${extPct}%. Extreme readings often mean the move already happened.`,
        basis: `Based on ${fmt(modN)} moderate-heat and ${fmt(extN)} extreme-heat resolved setups.`,
      });
    }

    if (stopHitPct != null && resolvedAll >= 100) {
      cards.push({
        id: 'stop-reality',
        headline: `${stopHitPct}%`,
        title: 'Stops Get Tested',
        detail: `About ${stopHitPct}% of setups touch the 1.5% stop level at some point before resolving. Sizing for that reality keeps one bad tick from wrecking the day.`,
        basis: `Based on ${fmt(resolvedAll)} resolved setups (any that dipped \u22651.5%).`,
      });
    }

    if (baselinePct != null && resolvedAll >= 100) {
      cards.push({
        id: 'baseline',
        headline: `${baselinePct}%`,
        title: 'The Baseline To Beat',
        detail: `Across every setup MarcoFlow has tracked, ${baselinePct}% finished green with no filtering at all. Every rule and filter in the tool earns its keep only by beating this number.`,
        basis: `Based on all ${fmt(resolvedAll)} resolved setups in the learning dataset.`,
      });
    }

    const payload = { ok: true, generatedAt: new Date().toISOString(), sampleSize: resolvedAll, cards };
    CACHE = { at: Date.now(), payload };
    return NextResponse.json(payload);
  } catch (err: any) {
    console.error('[insights] error', err);
    return NextResponse.json({ ok: false, error: err?.message || 'failed', cards: [] }, { status: 500 });
  }
}

```

---

## FILE: code/api/observations/route.ts

```typescript
import { NextRequest, NextResponse } from 'next/server';
import { getLiveFeed } from '@/lib/signal-recorder';

export const dynamic = 'force-dynamic';

// Lightweight, fast endpoint for the live monitoring view. Auto-refreshed by the
// client so the user can watch data collection in near real-time.
export async function GET(req: NextRequest) {
  try {
    const limit = Math.min(100, Math.max(10, Number(req.nextUrl.searchParams.get('limit')) || 40));
    const feed = await getLiveFeed(limit);
    return NextResponse.json(feed);
  } catch (error: any) {
    console.error('Live feed error:', error);
    return NextResponse.json(
      { error: error?.message ?? 'Failed to load live feed' },
      { status: 500 }
    );
  }
}

```

---

## FILE: code/api/paper/status/route.ts

```typescript
import { NextResponse } from 'next/server';
import { getPortfolioState, getTradeHistory, getEquityCurve, getDailyScorecard } from '@/lib/paper-trader';
import { getScannerHealth, ensureScannerStarted } from '@/lib/market-scanner';

export const dynamic = 'force-dynamic';

// Loading the dashboard (which polls this endpoint) is enough to guarantee the
// 5-minute scanner is armed — so the owner's "just load the page" health check
// also self-heals a freshly-restarted instance. Idempotent (guarded internally).
ensureScannerStarted();

/**
 * GET /api/paper/status — public, returns paper-trading dashboard data.
 * No auth required (read-only, paper money).
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = Math.min(parseInt(searchParams.get('limit') || '50', 10), 200);

    const [portfolio, trades, equityCurve, scorecard] = await Promise.all([
      getPortfolioState(),
      getTradeHistory(limit),
      getEquityCurve(),
      getDailyScorecard(),
    ]);

    return NextResponse.json({
      ok: true,
      portfolio,
      trades,
      equityCurve,
      scorecard,
      health: getScannerHealth(),
      generatedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('[paper/status] error:', error);
    return NextResponse.json({ error: error?.message || 'Failed to load paper status' }, { status: 500 });
  }
}

```

---

## FILE: code/api/paper/tick/route.ts

```typescript
import { NextResponse } from 'next/server';
import { paperTick, monitorPositions } from '@/lib/paper-trader';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

/**
 * POST /api/paper/tick — called by the 5-minute scanner (agent tick route)
 * during market hours. Evaluates new entries + monitors open positions.
 * Protected by AGENT_SECRET.
 */
export async function POST(request: Request) {
  try {
    const auth = request.headers.get('authorization') || '';
    const token = auth.replace(/^Bearer\s+/i, '').trim();
    const secret = process.env.AGENT_SECRET;
    if (!secret || token !== secret) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Monitor-only mode (Task 2 give-back fix): the fast ~60s loop calls this
    // to watch open positions for target/stop/trailing/EOD exits WITHOUT
    // evaluating new entries, scanning, or recording signals. Ultra-light.
    const { searchParams } = new URL(request.url);
    if (searchParams.get('mode') === 'monitor') {
      const monitor = await monitorPositions();
      return NextResponse.json({ ok: true, mode: 'monitor', monitor, timestamp: new Date().toISOString() });
    }

    const result = await paperTick();
    return NextResponse.json({ ok: true, ...result, timestamp: new Date().toISOString() });
  } catch (error: any) {
    console.error('[paper/tick] error:', error);
    return NextResponse.json({ error: error?.message || 'Paper tick failed' }, { status: 500 });
  }
}

// Health check
export async function GET() {
  return NextResponse.json({ ok: true, hint: 'POST with Bearer AGENT_SECRET to run paper tick' });
}

```

---

## FILE: code/api/performance/route.ts

```typescript
import { NextResponse } from 'next/server';
import { getPerformanceStats, discoverTopStrategies } from '@/lib/signal-recorder';
import { getMarketRegime } from '@/lib/market-regime';

export const dynamic = 'force-dynamic';

// Public read endpoint powering the on-site "Live Accuracy" section.
// Bundles: overall stats, the rolling Top-5 strategy leaderboard, and the
// current market regime so accuracy can be read in context.
export async function GET() {
  try {
    const [stats, strategies, market] = await Promise.all([
      getPerformanceStats(),
      discoverTopStrategies(),
      getMarketRegime().catch(() => null),
    ]);
    return NextResponse.json({ ...stats, strategies, market });
  } catch (error: any) {
    console.error('Performance stats error:', error);
    return NextResponse.json(
      { error: error?.message ?? 'Failed to load performance stats' },
      { status: 500 }
    );
  }
}

```

---

## FILE: code/api/review/route.ts

```typescript
import { NextResponse } from 'next/server';
import { getLatestReview, getReviewHistory, runAndSaveReview } from '@/lib/strategy-review';

export const dynamic = 'force-dynamic';
export const maxDuration = 300;

// GET — public. Returns the most recent Continuous Review snapshot for display.
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const historyParam = searchParams.get('history');
    const review = await getLatestReview();
    let history: any[] | undefined;
    if (historyParam !== null) {
      const n = Math.min(60, Math.max(2, parseInt(historyParam, 10) || 21));
      history = await getReviewHistory(n);
    }
    return NextResponse.json({ ok: true, review: review ?? null, history });
  } catch (error: any) {
    console.error('Review GET error:', error);
    return NextResponse.json({ error: error?.message ?? 'Failed to load review' }, { status: 500 });
  }
}

// POST — protected by AGENT_SECRET. Runs a fresh review and stores it.
export async function POST(request: Request) {
  try {
    const auth = request.headers.get('authorization') || '';
    const token = auth.replace(/^Bearer\s+/i, '').trim();
    const secret = process.env.AGENT_SECRET;
    if (!secret || token !== secret) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const review = await runAndSaveReview();
    return NextResponse.json({ ok: true, review });
  } catch (error: any) {
    console.error('Review POST error:', error);
    return NextResponse.json({ error: error?.message ?? 'Review failed' }, { status: 500 });
  }
}

```

---

## FILE: code/api/scorecard/route.ts

```typescript
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

/**
 * SETUP SCORECARD — how did the setups we actually EMAILED perform?
 *
 * This is deliberately different from the pool-wide review stats. The review
 * measures every observation we record (tens of thousands). This measures only
 * the handful that cleared every gate and landed in Phillip's inbox — the ones
 * he could actually have traded. That is the only number that reflects real
 * decision quality.
 *
 * Costs nothing ongoing: alertedAt and status are already persisted on every
 * row, so the entire progressive history is recomputed from scratch on each
 * request. No snapshots, no extra storage, no scheduled job.
 */

// Wilson score lower bound — the same honest metric used everywhere else in the
// app. With small samples a raw win rate is wildly overconfident; this reports
// what we can actually defend at 95% confidence.
function wilsonLB(wins: number, n: number): number {
  if (n === 0) return 0;
  const p = wins / n;
  const z = 1.96;
  const d = 1 + (z * z) / n;
  const c = p + (z * z) / (2 * n);
  const m = z * Math.sqrt((p * (1 - p)) / n + (z * z) / (4 * n * n));
  return Math.round((((c - m) / d) * 100) * 10) / 10;
}

function etDayKey(d: Date): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(d);
}

export async function GET() {
  try {
    const rows = await prisma.signalObservation.findMany({
      where: { alertedAt: { not: null } },
      select: {
        symbol: true, direction: true, alertedAt: true, status: true,
        returnPct: true, maxFavorablePct: true, maxAdversePct: true,
        livePriceDrift: true,
      },
      orderBy: { alertedAt: 'asc' },
    });

    const decided = rows.filter(r => r.status === 'WIN' || r.status === 'LOSS');
    const wins = decided.filter(r => r.status === 'WIN').length;
    const losses = decided.length - wins;
    const expired = rows.filter(r => r.status === 'EXPIRED').length;
    const pending = rows.filter(r => r.status === 'PENDING').length;

    // Average return across everything that finished, including time exits —
    // counting only decided trades would flatter the number.
    const finished = rows.filter(r => r.status !== 'PENDING' && r.returnPct != null);
    const avgReturn = finished.length
      ? Math.round((finished.reduce((s, r) => s + (r.returnPct || 0), 0) / finished.length) * 1000) / 1000
      : null;

    // Day-by-day cumulative trend, so improvement (or drift) is visible.
    const byDay = new Map<string, { alerted: number; win: number; loss: number }>();
    for (const r of rows) {
      const k = etDayKey(r.alertedAt as Date);
      const e = byDay.get(k) || { alerted: 0, win: 0, loss: 0 };
      e.alerted++;
      if (r.status === 'WIN') e.win++;
      else if (r.status === 'LOSS') e.loss++;
      byDay.set(k, e);
    }
    let cw = 0, cl = 0, ca = 0;
    const daily = Array.from(byDay.entries()).map(([day, v]) => {
      ca += v.alerted; cw += v.win; cl += v.loss;
      const cd = cw + cl;
      return {
        day,
        alerted: v.alerted,
        cumulativeAlerted: ca,
        cumulativeDecided: cd,
        cumulativeWinRate: cd ? Math.round((cw / cd) * 1000) / 10 : null,
        cumulativeWinRateLB: wilsonLB(cw, cd),
      };
    });

    // How far the delayed scan price had drifted by the time we sent the alert.
    // Populated once the real-time layer has run; null before that.
    const drifts = rows.map(r => r.livePriceDrift).filter((d): d is number => d != null);
    const drift = drifts.length
      ? {
          checked: drifts.length,
          avgAbsDriftPct: Math.round((drifts.reduce((s, d) => s + Math.abs(d), 0) / drifts.length) * 100) / 100,
          maxAbsDriftPct: Math.round(Math.max(...drifts.map(Math.abs)) * 100) / 100,
        }
      : null;

    return NextResponse.json({
      totalAlerted: rows.length,
      decided: decided.length,
      wins,
      losses,
      expired,
      pending,
      winRate: decided.length ? Math.round((wins / decided.length) * 1000) / 10 : null,
      winRateLB: wilsonLB(wins, decided.length),
      avgReturn,
      firstAlertAt: rows[0]?.alertedAt ?? null,
      lastAlertAt: rows[rows.length - 1]?.alertedAt ?? null,
      daily,
      drift,
      // Honest sample-size guidance rather than a confident-looking percentage.
      readiness:
        decided.length >= 30 ? 'meaningful'
        : decided.length >= 10 ? 'early'
        : 'insufficient',
    });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'scorecard failed' }, { status: 500 });
  }
}

```

---

## FILE: code/api/simulations/route.ts

```typescript
import { NextResponse } from 'next/server';
import { getSimulations, runDailySimulation, maybeRunDailySim } from '@/lib/daily-sim';

export const dynamic = 'force-dynamic';
export const maxDuration = 300;

// GET — public. Returns the fresh-trader daily journal (most recent first).
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = Math.min(90, Math.max(1, parseInt(searchParams.get('limit') || '40', 10) || 40));
    const data = await getSimulations(limit);
    return NextResponse.json({ ok: true, ...data });
  } catch (error: any) {
    console.error('Simulations GET error:', error);
    return NextResponse.json({ error: error?.message ?? 'Failed to load simulations' }, { status: 500 });
  }
}

// POST — protected by AGENT_SECRET. Force-runs the simulation for a given ET
// date (or today) so a recap can be generated on demand / for testing.
export async function POST(request: Request) {
  try {
    const auth = request.headers.get('authorization') || '';
    const token = auth.replace(/^Bearer\s+/i, '').trim();
    const secret = process.env.AGENT_SECRET;
    if (!secret || token !== secret) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    const { searchParams } = new URL(request.url);
    const date = searchParams.get('date'); // YYYY-MM-DD (ET)
    const force = searchParams.get('force') === 'true';
    const result = date
      ? await runDailySimulation(date, true)
      : (await maybeRunDailySim(force)).result ?? null;
    return NextResponse.json({ ok: true, result });
  } catch (error: any) {
    console.error('Simulations POST error:', error);
    return NextResponse.json({ error: error?.message ?? 'Simulation failed' }, { status: 500 });
  }
}

```
