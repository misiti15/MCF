# 06 — Owner Rules and Preferences

These are the MarcoFlow owner's standing instructions. A new system with different strategies does not have to copy MarcoFlow's trading rules, but these reflect how the owner wants work done and what he has already rejected.

## Philosophy
- Quality over quantity. Conservative signals; never inflate scores or lower thresholds just to show more results.
- Data recording, learning and accuracy come first. Alerts and emails are secondary.
- Be honest about results: report what failed first, label estimates, separate hindsight from tradeable findings.
- Every on-screen result and email carries "Educational only — not financial advice".

## Hard rules for MarcoFlow (in force at export)
1. **Never limit entries or filter out bad alerts** — no entry caps, no alert suppression, no blanket filters. Instead, diagnose *why* bad alerts happen. (The large position count is intentional.)
2. **Priority 1 = execution quality on great alerts** (capture more of the move). **Priority 2 = root-cause the bad alerts.**
3. Do not change the **Heat Score** calculation, signal/setup identification, alert parameters or timeframes during execution work.
4. Do not change the **skipped entry hours (9 and 12 ET)** or the **knife guard** (no shorts at RSI ≤ 30).
5. Never hard-veto shorts only because RSI is rising; require multiple confirming factors.
6. Exactly **one concise Daily Brief email** after each market close (how we did + how to improve). Keep data collection running regardless.
7. Make every change visible and dated (MarcoFlow logs to `/changelog` and release notes).
8. The nightly optimizer stays **paused** until the owner asks for a revamp.
9. Changes must be reversible (one toggle) and backtested on the clean window before going live.
10. Keep the system fully operational at every market open.

## Working preferences
- Credit- and time-conscious: prefers the smallest change that solves the problem, and direct answers over long reports.
- Wants verified claims only ("tested", "live" only when actually observed).
- Wants to see day by day what changed and when.
- Prefers improving what he sees on the site over building heavy background infrastructure, but accepts automation that keeps data flowing.
- Never expose secrets (API keys, tokens) in chat, files or logs.
- Release numbering: major updates 3.0, 3.5, 4.0, 5.0, 6.0–6.2, 7.0. The next major would be 8.0.
